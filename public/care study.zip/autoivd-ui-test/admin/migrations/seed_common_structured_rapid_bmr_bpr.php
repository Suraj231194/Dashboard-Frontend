<?php

declare(strict_types=1);

/**
 * Installs the audited, code-only Rapid Test BMR/BPR templates.
 *
 * Product variants receive separate profiles even when they reuse the same
 * approved source layout. Existing started, completed and populated work
 * items are never reassigned.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_rapid_profiles.php';

$families = bmrBprRapidCatalog();
$approvedProductIds = bmrBprRapidApprovedProductIds();
$approvedProductSql = implode(',', $approvedProductIds);
$productNames = [];
$catalogRows = $conn->query(
    "SELECT id, product_name
     FROM products
     WHERE id IN ({$approvedProductSql}) AND status != 3 AND deleted_at IS NULL"
);
if (!$catalogRows) {
    fwrite(STDERR, "Unable to read the Rapid product catalogue.\n");
    exit(1);
}
while ($catalogRow = $catalogRows->fetch_assoc()) {
    $productNames[(int) $catalogRow['id']] = trim((string) $catalogRow['product_name']);
}
if (count($productNames) !== count($approvedProductIds)) {
    fwrite(STDERR, "One or more mapped Rapid products are unavailable.\n");
    exit(1);
}

$document = [
    'document_no' => 'BIPL-BMR-01',
    'issue_no' => '01',
    'revision_no' => '02',
    'effective_date' => '03/04/2025',
    'license_no' => 'MFG/IVD/2020/000082',
    'department' => 'Production',
    'company_name' => 'BIOGENIX INC. PVT. LTD.',
    'company_address' => "B19/A S.I.L. Ancillary Estate,\nAmausi Industrial Area, Nadarganj-\n226008 (Lucknow)",
    'title' => 'BATCH MANUFACTURING RECORD',
];
$editablePrefixes = [
    'BMR' => ['cover.', 'attachments.', 'rm.', 'manufacturing.', 'completion.', 'qa.'],
    'BPR' => ['cover.', 'attachments.', 'dispensing.', 'washing.', 'filling.', 'coding.', 'labeling.', 'packing.', 'transfer.', 'yield.', 'qa.'],
];

$definitions = [];
foreach (['BMR' => 'bmr_documents', 'BPR' => 'bpr_documents'] as $formType => $documentKey) {
    $maxDocuments = 0;
    foreach ($families as $family) {
        $maxDocuments = max($maxDocuments, count($family[$documentKey] ?? []));
    }
    for ($sequence = 1; $sequence <= $maxDocuments; $sequence++) {
        $profiles = [];
        $pageCount = 0;
        foreach ($families as $family) {
            $sourceProfile = $family[$documentKey][$sequence - 1] ?? null;
            if (!is_array($sourceProfile)) {
                continue;
            }
            $pageCount = max($pageCount, (int) ($sourceProfile['page_count'] ?? 0));
            foreach ($family['product_ids'] as $productIdValue) {
                $productId = (int) $productIdValue;
                $profile = $sourceProfile;
                // Every mapped database product is separately identified in
                // the rendered template, including pack/specimen variants.
                $profile['product_name'] = $productNames[$productId];
                $profile['catalog_product_id'] = $productId;
                $profiles[(string) $productId] = $profile;
            }
        }
        if ($profiles === []) {
            continue;
        }
        ksort($profiles, SORT_NUMERIC);
        $layoutDocument = $document;
        if ($formType === 'BPR') {
            $layoutDocument['document_no'] = 'BIPL-BPR-01';
            $layoutDocument['title'] = 'BATCH PACKING RECORD';
        }
        $suffix = str_pad((string) $sequence, 2, '0', STR_PAD_LEFT);
        $definitions[] = [
            'form_type' => $formType,
            'sequence' => $sequence,
            'template_code' => "COMMON_RAPID_{$formType}_{$suffix}_V03",
            'template_name' => "Common Rapid Test {$formType} #{$sequence}",
            'page_count' => $pageCount,
            'layout' => [
                'schema_version' => 2,
                'renderer' => 'structured_html',
                'renderer_variant' => 'rapid',
                'form_type' => $formType,
                'document' => $layoutDocument,
                'editable_prefixes' => $editablePrefixes[$formType],
                'profiles' => $profiles,
            ],
        ];
    }
}
$rapidTemplateCodesSql = implode(',', array_map(
    static fn(array $definition): string => "'"
        . $conn->real_escape_string((string) $definition['template_code']) . "'",
    $definitions
));

$lockName = 'common_structured_rapid_bmr_bpr_v3';
$lockStmt = $conn->prepare('SELECT GET_LOCK(?, 15) AS acquired');
$lockStmt->bind_param('s', $lockName);
$lockStmt->execute();
$lockAcquired = (int) ($lockStmt->get_result()->fetch_assoc()['acquired'] ?? 0) === 1;
$lockStmt->close();
if (!$lockAcquired) {
    fwrite(STDERR, "Unable to acquire the Rapid template seed lock.\n");
    exit(1);
}

try {
    $conn->begin_transaction();
    $upsertTemplate = $conn->prepare(
        "INSERT INTO bmr_templates
            (product_id, product_name, template_name, form_type, template_code, version_no,
             document_no, issue_no, revision_no, effective_date, mfr_reference,
             source_pdf_path, page_asset_path, source_checksum, page_count, layout_json,
             status, created_by, created_at)
         VALUES (?, 'Rapid Test Common', ?, ?, ?, 3, ?, '01', '02', '2025-04-03',
                 'PROFILE-DRIVEN', NULL, NULL, NULL, ?, ?, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             product_id = VALUES(product_id),
             product_name = VALUES(product_name),
             template_name = VALUES(template_name),
             form_type = VALUES(form_type),
             version_no = 3,
             document_no = VALUES(document_no),
             issue_no = '01',
             revision_no = '02',
             effective_date = '2025-04-03',
             mfr_reference = 'PROFILE-DRIVEN',
             source_pdf_path = NULL,
             page_asset_path = NULL,
             source_checksum = NULL,
             page_count = VALUES(page_count),
             layout_json = VALUES(layout_json),
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    $findTemplate = $conn->prepare(
        'SELECT id FROM bmr_templates WHERE template_code = ? AND deleted_at IS NULL LIMIT 1'
    );
    $upsertMapping = $conn->prepare(
        "INSERT INTO bmr_template_product_mappings
            (template_id, product_id, form_type, document_sequence, required_quantity,
             status, created_by, created_at)
         VALUES (?, ?, ?, ?, 1, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             template_id = VALUES(template_id),
             required_quantity = 1,
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    if (!$upsertTemplate || !$findTemplate || !$upsertMapping) {
        throw new RuntimeException('Unable to prepare Rapid template statements.');
    }

    if (!$conn->query(
        "UPDATE bmr_template_product_mappings mapping
         LEFT JOIN bmr_templates template
           ON template.id = mapping.template_id
          AND template.deleted_at IS NULL
         SET mapping.status = 0, mapping.updated_by = 1, mapping.updated_at = NOW()
         WHERE (
               mapping.product_id IN ({$approvedProductSql})
               OR template.template_code IN ({$rapidTemplateCodesSql})
           )
           AND mapping.form_type IN ('BMR', 'BPR')
           AND mapping.status = 1 AND mapping.deleted_at IS NULL"
    )) {
        throw new RuntimeException('Unable to retire superseded Rapid mappings.');
    }

    $templateCount = 0;
    $mappingCount = 0;
    foreach ($definitions as $definition) {
        $layoutJson = json_encode(
            $definition['layout'],
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR
        );
        $profiles = $definition['layout']['profiles'];
        $canonicalProductId = (int) array_key_first($profiles);
        $templateName = (string) $definition['template_name'];
        $formType = (string) $definition['form_type'];
        $templateCode = (string) $definition['template_code'];
        $documentNo = $formType === 'BPR' ? 'BIPL-BPR-01' : 'BIPL-BMR-01';
        $pageCount = (int) $definition['page_count'];
        $upsertTemplate->bind_param(
            'issssis',
            $canonicalProductId,
            $templateName,
            $formType,
            $templateCode,
            $documentNo,
            $pageCount,
            $layoutJson
        );
        if (!$upsertTemplate->execute()) {
            throw new RuntimeException(
                "Unable to save Rapid template {$templateCode}: {$upsertTemplate->error}"
            );
        }
        $findTemplate->bind_param('s', $templateCode);
        $findTemplate->execute();
        $templateId = (int) ($findTemplate->get_result()->fetch_assoc()['id'] ?? 0);
        if ($templateId <= 0) {
            throw new RuntimeException("Unable to resolve Rapid template {$templateCode}.");
        }
        $templateCount++;

        $sequence = (int) $definition['sequence'];
        foreach (array_keys($profiles) as $productIdValue) {
            $productId = (int) $productIdValue;
            $upsertMapping->bind_param('iisi', $templateId, $productId, $formType, $sequence);
            if (!$upsertMapping->execute()) {
                throw new RuntimeException(
                    "Unable to map Rapid product {$productId} {$formType} #{$sequence}: "
                    . $upsertMapping->error
                );
            }
            $mappingCount++;
        }
    }

    $safeSnapshots = $conn->query(
        "UPDATE bmr_bpr_request_documents request_document
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = request_document.request_id
           AND request_row.deleted_at IS NULL
         INNER JOIN bmr_template_product_mappings mapping
            ON mapping.product_id = request_row.product_id
           AND mapping.form_type = request_document.form_type
           AND mapping.document_sequence = request_document.document_sequence
           AND mapping.status = 1 AND mapping.deleted_at IS NULL
         SET request_document.template_id = mapping.template_id,
             request_document.updated_by = 1,
             request_document.updated_at = NOW()
         WHERE request_row.product_id IN ({$approvedProductSql})
           AND NOT EXISTS (
               SELECT 1 FROM bmr_bpr_work_items started_item
               WHERE started_item.request_id = request_document.request_id
                 AND started_item.form_type = request_document.form_type
                 AND started_item.deleted_at IS NULL
                 AND (
                     started_item.status IN ('IN_PROCESS', 'COMPLETE')
                     OR (
                         started_item.form_payload_json IS NOT NULL
                         AND started_item.form_payload_json NOT IN ('', '{}')
                     )
                 )
           )"
    );
    if ($safeSnapshots === false) {
        throw new RuntimeException('Unable to update safe Rapid request snapshots.');
    }
    $snapshotCount = $conn->affected_rows;

    $safeIncoming = $conn->query(
        "UPDATE bmr_bpr_work_items work_item
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = work_item.request_id
           AND request_row.deleted_at IS NULL
         INNER JOIN bmr_template_product_mappings mapping
            ON mapping.product_id = request_row.product_id
           AND mapping.form_type = work_item.form_type
           AND mapping.document_sequence = work_item.form_sequence
           AND mapping.status = 1 AND mapping.deleted_at IS NULL
         SET work_item.template_id = mapping.template_id,
             work_item.updated_by = 1,
             work_item.updated_at = NOW()
         WHERE request_row.product_id IN ({$approvedProductSql})
           AND work_item.status IN ('QUEUED', 'PENDING')
           AND (
               work_item.form_payload_json IS NULL
               OR work_item.form_payload_json IN ('', '{}')
           )"
    );
    if ($safeIncoming === false) {
        throw new RuntimeException('Unable to map safe incoming Rapid work items.');
    }
    $incomingCount = $conn->affected_rows;

    $upsertTemplate->close();
    $findTemplate->close();
    $upsertMapping->close();
    $conn->commit();

    $counts = bmrBprRapidDocumentCounts();
    echo "Common Rapid structured templates saved: {$templateCount}\n";
    echo "Distinct Rapid document mappings updated: {$mappingCount}\n";
    echo 'Separately mapped Rapid catalog products: ' . count($approvedProductIds) . "\n";
    echo "Configured product documents: {$counts['BMR']} BMR, {$counts['BPR']} BPR\n";
    echo "Safe Rapid request snapshots updated: {$snapshotCount}\n";
    echo "Blank queued/pending Rapid work items mapped: {$incomingCount}\n";
    echo "In-process, completed and populated records were not reassigned.\n";
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
} finally {
    $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
    if ($releaseStmt) {
        $releaseStmt->bind_param('s', $lockName);
        $releaseStmt->execute();
        $releaseStmt->close();
    }
}
