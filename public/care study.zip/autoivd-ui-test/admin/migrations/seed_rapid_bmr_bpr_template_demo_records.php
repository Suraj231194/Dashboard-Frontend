<?php

declare(strict_types=1);

/**
 * Adds one identifiable, blank Rapid acceptance request per separately mapped
 * product. Records remain PENDING so this BMR/BPR-only seed cannot feed the
 * IP/FG COA banners.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/../workflow/bmr_bpr_common.php';
require_once __DIR__ . '/../workflow/bmr_bpr_rapid_profiles.php';

$productIds = bmrBprRapidApprovedProductIds();
$seedUserId = 1;
$seedDate = date('Y-m-d');
$fiscalYear = bmrBprFiscalYearLabel($seedDate);
$lockName = 'common_rapid_bmr_bpr_widget_seed_v1';
$lockStmt = $conn->prepare('SELECT GET_LOCK(?, 15) AS acquired');
$lockStmt->bind_param('s', $lockName);
$lockStmt->execute();
$lockAcquired = (int) ($lockStmt->get_result()->fetch_assoc()['acquired'] ?? 0) === 1;
$lockStmt->close();
if (!$lockAcquired) {
    fwrite(STDERR, "Unable to acquire the Rapid acceptance-record seed lock.\n");
    exit(1);
}

try {
    $conn->begin_transaction();
    $maxSequenceStmt = $conn->prepare(
        "SELECT COALESCE(MAX(CAST(RIGHT(document_batch_no, 6) AS UNSIGNED)), 0) AS max_sequence
         FROM production_plans
         WHERE document_batch_no LIKE ? AND deleted_at IS NULL"
    );
    $batchPrefixLike = 'BIO/PROD/FY' . $fiscalYear . '/%';
    $maxSequenceStmt->bind_param('s', $batchPrefixLike);
    $maxSequenceStmt->execute();
    $nextSequence = (int) ($maxSequenceStmt->get_result()->fetch_assoc()['max_sequence'] ?? 0) + 1;
    $maxSequenceStmt->close();

    $findProduct = $conn->prepare(
        "SELECT id, product_name, COALESCE(product_code, '') AS product_code,
                COALESCE(NULLIF(unit_id, 0), 12) AS unit_id
         FROM products
         WHERE id = ? AND status != 3 AND deleted_at IS NULL LIMIT 1"
    );
    $findCounts = $conn->prepare(
        "SELECT mapping.form_type, COUNT(*) AS document_count
         FROM bmr_template_product_mappings mapping
         INNER JOIN bmr_templates template
            ON template.id = mapping.template_id
           AND template.template_code LIKE 'COMMON_RAPID_%'
           AND template.status = 1 AND template.deleted_at IS NULL
         WHERE mapping.product_id = ? AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         GROUP BY mapping.form_type"
    );
    $findExistingMr = $conn->prepare(
        "SELECT id, prod_plan_id, lot_batch_no
         FROM material_requisition
         WHERE slip_no = ? AND deleted_at IS NULL LIMIT 1 FOR UPDATE"
    );
    $insertPlan = $conn->prepare(
        "INSERT INTO production_plans
            (date, name, lo_batch_no, document_batch_no, batch_size, batch_size_unit,
             timeline, status, prodplan_remark, is_locked, bom_master_id, product_id,
             created_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 1, 0,
                 'Common Rapid BMR/BPR widget acceptance record.',
                 0, 0, ?, ?, NOW())"
    );
    $insertMr = $conn->prepare(
        "INSERT INTO material_requisition
            (mr_raw, mr_packing, mr_consumable, date, product_name, lot_batch_no,
             batch_size, batch_size_unit, slip_no, department, requested_by,
             status, auto_generated_batch, prod_plan_id, bom_master_id, created_by, created_at)
         VALUES (1, 1, 1, ?, ?, ?, ?, ?, ?, 1, 'Template Acceptance',
                 0, ?, ?, 0, ?, NOW())"
    );
    $findRequest = $conn->prepare(
        "SELECT id FROM bmr_bpr_requests
         WHERE material_requisition_id = ? AND deleted_at IS NULL
         LIMIT 1 FOR UPDATE"
    );
    $insertRequest = $conn->prepare(
        "INSERT INTO bmr_bpr_requests
            (material_requisition_id, production_plan_id, product_id, request_date,
             product_name, category_code, lot_number, production_batch_number,
             batch_size, batch_size_unit_id, pack_size, form_count, bmr_form_count,
             bpr_form_count, remarks, status, requested_by, requested_at,
             reviewed_by, reviewed_at, review_comments, created_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                 'Common Rapid template widget acceptance record.', 'APPROVED',
                 ?, NOW(), ?, NOW(),
                 'Approved for common-template visual acceptance testing.', ?, NOW())"
    );
    $updateRequestNumber = $conn->prepare(
        'UPDATE bmr_bpr_requests SET request_no = ? WHERE id = ?'
    );
    $updateRequestCounts = $conn->prepare(
        "UPDATE bmr_bpr_requests
         SET form_count = ?, bmr_form_count = ?, bpr_form_count = ?,
             updated_by = ?, updated_at = NOW()
         WHERE id = ?"
    );
    $updateWidgetStatuses = $conn->prepare(
        "UPDATE bmr_bpr_work_items
         SET status = 'PENDING', updated_by = ?, updated_at = NOW()
         WHERE request_id = ? AND deleted_at IS NULL
           AND status IN ('QUEUED', 'PENDING')
           AND (form_payload_json IS NULL OR form_payload_json IN ('', '{}'))"
    );
    if (
        !$findProduct || !$findCounts || !$findExistingMr || !$insertPlan || !$insertMr
        || !$findRequest || !$insertRequest || !$updateRequestNumber
        || !$updateRequestCounts || !$updateWidgetStatuses
    ) {
        throw new RuntimeException('Unable to prepare the Rapid acceptance-record insert.');
    }

    $createdRequests = 0;
    $verifiedWorkItems = 0;
    $skippedIncompleteProducts = 0;
    foreach ($productIds as $productId) {
        $findProduct->bind_param('i', $productId);
        $findProduct->execute();
        $product = $findProduct->get_result()->fetch_assoc();
        if (!$product) {
            throw new RuntimeException("Mapped Rapid product {$productId} is unavailable.");
        }
        $productName = trim((string) $product['product_name']);
        $productCode = trim((string) $product['product_code']);
        $unitId = (int) $product['unit_id'];
        $batchSize = 1000.0;
        $packSize = $productName;

        $findCounts->bind_param('i', $productId);
        $findCounts->execute();
        $counts = ['BMR' => 0, 'BPR' => 0];
        foreach ($findCounts->get_result()->fetch_all(MYSQLI_ASSOC) as $countRow) {
            $counts[(string) $countRow['form_type']] = (int) $countRow['document_count'];
        }
        if ($counts['BMR'] + $counts['BPR'] <= 0) {
            throw new RuntimeException("Rapid document mappings are missing for {$productName}.");
        }
        if ($counts['BMR'] <= 0 || $counts['BPR'] <= 0) {
            // The core workflow requires a complete BMR/BPR pair. Preserve
            // each audited single-document mapping without inventing its
            // missing counterpart or creating an invalid request.
            $skippedIncompleteProducts++;
            continue;
        }
        $formCount = $counts['BMR'] + $counts['BPR'];
        $seedKey = 'BMR-COMMON-RAPID-DEMO-' . $productId;

        $findExistingMr->bind_param('s', $seedKey);
        $findExistingMr->execute();
        $existingMr = $findExistingMr->get_result()->fetch_assoc();
        if ($existingMr) {
            $materialRequisitionId = (int) $existingMr['id'];
            $productionPlanId = (int) $existingMr['prod_plan_id'];
            $batchNumber = (string) $existingMr['lot_batch_no'];
        } else {
            $sequence = $nextSequence++;
            $batchNumber = 'BIO/PROD/FY' . $fiscalYear . '/' . str_pad(
                (string) $sequence,
                6,
                '0',
                STR_PAD_LEFT
            );
            $insertPlan->bind_param(
                'ssssdiii',
                $seedDate,
                $productName,
                $batchNumber,
                $batchNumber,
                $batchSize,
                $unitId,
                $productId,
                $seedUserId
            );
            if (!$insertPlan->execute()) {
                throw new RuntimeException(
                    "Unable to create the Rapid Production Plan for {$productName}: {$insertPlan->error}"
                );
            }
            $productionPlanId = (int) $conn->insert_id;
            $autoBatch = 'BIPL-MR-' . date('d-m-Y') . '-' . $sequence;
            $insertMr->bind_param(
                'sssdissii',
                $seedDate,
                $productName,
                $batchNumber,
                $batchSize,
                $unitId,
                $seedKey,
                $autoBatch,
                $productionPlanId,
                $seedUserId
            );
            if (!$insertMr->execute()) {
                throw new RuntimeException(
                    "Unable to create the Rapid Material Requisition for {$productName}: {$insertMr->error}"
                );
            }
            $materialRequisitionId = (int) $conn->insert_id;
        }

        $findRequest->bind_param('i', $materialRequisitionId);
        $findRequest->execute();
        $existingRequest = $findRequest->get_result()->fetch_assoc();
        if ($existingRequest) {
            $requestId = (int) $existingRequest['id'];
        } else {
            $insertRequest->bind_param(
                'iiisssssdisiiiiii',
                $materialRequisitionId,
                $productionPlanId,
                $productId,
                $seedDate,
                $productName,
                $productCode,
                $batchNumber,
                $batchNumber,
                $batchSize,
                $unitId,
                $packSize,
                $formCount,
                $counts['BMR'],
                $counts['BPR'],
                $seedUserId,
                $seedUserId,
                $seedUserId
            );
            if (!$insertRequest->execute()) {
                throw new RuntimeException(
                    "Unable to create the Rapid request for {$productName}: {$insertRequest->error}"
                );
            }
            $requestId = (int) $conn->insert_id;
            $requestNumber = bmrBprRequestNumber($requestId, $seedDate);
            $updateRequestNumber->bind_param('si', $requestNumber, $requestId);
            if (!$updateRequestNumber->execute()) {
                throw new RuntimeException("Unable to number the Rapid request for {$productName}.");
            }
            bmrBprInsertHistory(
                $conn,
                'REQUEST',
                $requestId,
                'COMMON_TEMPLATE_WIDGET_RECORD_CREATED',
                null,
                'APPROVED',
                'Created for common Rapid template widget acceptance testing.',
                [
                    'product_id' => $productId,
                    'material_requisition_id' => $materialRequisitionId,
                    'production_plan_id' => $productionPlanId,
                ],
                $seedUserId
            );
            $createdRequests++;
        }

        $updateRequestCounts->bind_param(
            'iiiii',
            $formCount,
            $counts['BMR'],
            $counts['BPR'],
            $seedUserId,
            $requestId
        );
        if (!$updateRequestCounts->execute()) {
            throw new RuntimeException("Unable to update Rapid document counts for {$productName}.");
        }
        bmrBprEnsureConfiguredWorkItems(
            $conn,
            $requestId,
            $counts['BMR'],
            $counts['BPR'],
            $seedUserId
        );
        $updateWidgetStatuses->bind_param('ii', $seedUserId, $requestId);
        if (!$updateWidgetStatuses->execute()) {
            throw new RuntimeException("Unable to expose Rapid BMR/BPR records for {$productName}.");
        }

        $verify = $conn->prepare(
            "SELECT wi.form_type, wi.form_sequence, wi.status, template.template_code
             FROM bmr_bpr_work_items wi
             INNER JOIN bmr_templates template
                ON template.id = wi.template_id
               AND template.form_type = wi.form_type
               AND template.status = 1 AND template.deleted_at IS NULL
             WHERE wi.request_id = ? AND wi.deleted_at IS NULL
             ORDER BY wi.form_type, wi.form_sequence"
        );
        $verify->bind_param('i', $requestId);
        $verify->execute();
        $workItems = $verify->get_result()->fetch_all(MYSQLI_ASSOC);
        $verify->close();
        if (count($workItems) !== $formCount) {
            throw new RuntimeException("Configured Rapid documents were not created for {$productName}.");
        }
        foreach ($workItems as $workItem) {
            if (
                !str_starts_with(
                    (string) $workItem['template_code'],
                    'COMMON_RAPID_' . (string) $workItem['form_type'] . '_'
                )
                || $workItem['status'] !== 'PENDING'
            ) {
                throw new RuntimeException("The separate Rapid mapping is invalid for {$productName}.");
            }
        }
        $verifiedWorkItems += count($workItems);
    }

    $findProduct->close();
    $findCounts->close();
    $findExistingMr->close();
    $insertPlan->close();
    $insertMr->close();
    $findRequest->close();
    $insertRequest->close();
    $updateRequestNumber->close();
    $updateRequestCounts->close();
    $updateWidgetStatuses->close();
    $conn->commit();

    echo 'Separately mapped Rapid acceptance requests verified: '
        . (count($productIds) - $skippedIncompleteProducts) . PHP_EOL;
    echo "Incomplete source-pair products skipped: {$skippedIncompleteProducts}\n";
    echo "New Rapid acceptance requests created: {$createdRequests}\n";
    echo "Rapid BMR/BPR work items verified: {$verifiedWorkItems}\n";
    echo "IP/FG COA records were not created or changed.\n";
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(
        STDERR,
        $exception->getMessage()
            . ' at ' . $exception->getFile() . ':' . $exception->getLine()
            . PHP_EOL
    );
    exit(1);
} finally {
    $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
    if ($releaseStmt) {
        $releaseStmt->bind_param('s', $lockName);
        $releaseStmt->execute();
        $releaseStmt->close();
    }
}
