-- Migration: Add deleted_at to low_stocks table
-- This fixes the fatal error 'bind_param() on bool' in the Send to Procurement flow.

ALTER TABLE `low_stocks` 
ADD COLUMN IF NOT EXISTS `deleted_at` DATETIME DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `deleted_by` BIGINT(20) UNSIGNED DEFAULT NULL;
