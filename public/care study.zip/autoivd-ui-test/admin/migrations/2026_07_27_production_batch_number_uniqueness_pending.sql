-- Preserve duplicate legacy batch labels while enforcing uniqueness for every
-- production document number generated in the documented format:
-- <Company Code>/PROD/FY<YY-YY>/<6-digit sequence>.
ALTER TABLE `production_plans`
    ADD COLUMN IF NOT EXISTS `document_batch_no` VARCHAR(191)
        GENERATED ALWAYS AS (
            CASE
                WHEN `lo_batch_no` REGEXP '^[A-Z0-9]+/PROD/FY[0-9]{2}-[0-9]{2}/[0-9]{6}$'
                    THEN `lo_batch_no`
                ELSE NULL
            END
        ) PERSISTENT;

CREATE UNIQUE INDEX IF NOT EXISTS `uq_production_plans_document_batch_no`
    ON `production_plans` (`document_batch_no`);
