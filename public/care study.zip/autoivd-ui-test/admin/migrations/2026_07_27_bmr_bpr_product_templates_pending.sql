-- Product-specific BMR/BPR template catalog.
-- Additive only: existing template, workflow and execution records are preserved.

ALTER TABLE `bmr_templates`
    ADD COLUMN IF NOT EXISTS `form_type` ENUM('BMR','BPR') DEFAULT NULL AFTER `template_name`,
    ADD COLUMN IF NOT EXISTS `template_code` VARCHAR(100) DEFAULT NULL AFTER `form_type`,
    ADD COLUMN IF NOT EXISTS `document_no` VARCHAR(100) DEFAULT NULL AFTER `version_no`,
    ADD COLUMN IF NOT EXISTS `issue_no` VARCHAR(30) DEFAULT NULL AFTER `document_no`,
    ADD COLUMN IF NOT EXISTS `revision_no` VARCHAR(30) DEFAULT NULL AFTER `issue_no`,
    ADD COLUMN IF NOT EXISTS `effective_date` DATE DEFAULT NULL AFTER `revision_no`,
    ADD COLUMN IF NOT EXISTS `mfr_reference` VARCHAR(100) DEFAULT NULL AFTER `effective_date`,
    ADD COLUMN IF NOT EXISTS `source_pdf_path` VARCHAR(500) DEFAULT NULL AFTER `mfr_reference`,
    ADD COLUMN IF NOT EXISTS `page_asset_path` VARCHAR(500) DEFAULT NULL AFTER `source_pdf_path`,
    ADD COLUMN IF NOT EXISTS `source_checksum` CHAR(64) DEFAULT NULL AFTER `page_asset_path`,
    ADD COLUMN IF NOT EXISTS `page_count` SMALLINT UNSIGNED DEFAULT NULL AFTER `source_checksum`,
    ADD COLUMN IF NOT EXISTS `layout_json` LONGTEXT DEFAULT NULL AFTER `page_count`;

CREATE UNIQUE INDEX IF NOT EXISTS `uq_bmr_template_code`
    ON `bmr_templates` (`template_code`);

CREATE INDEX IF NOT EXISTS `idx_bmr_template_form_status`
    ON `bmr_templates` (`form_type`, `status`, `deleted_at`);

CREATE TABLE IF NOT EXISTS `bmr_template_product_mappings` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `template_id` BIGINT(20) NOT NULL,
    `product_id` INT(11) NOT NULL,
    `form_type` ENUM('BMR','BPR') NOT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_by` INT(11) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT(11) DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    `deleted_by` INT(11) DEFAULT NULL,
    `deleted_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_bmr_template_product_form` (`product_id`, `form_type`),
    KEY `idx_bmr_template_product_template` (`template_id`, `status`, `deleted_at`),
    CONSTRAINT `fk_bmr_template_product_template`
        FOREIGN KEY (`template_id`) REFERENCES `bmr_templates` (`id`),
    CONSTRAINT `fk_bmr_template_product_product`
        FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX IF NOT EXISTS `idx_bmr_bpr_work_item_template`
    ON `bmr_bpr_work_items` (`template_id`, `deleted_at`);
