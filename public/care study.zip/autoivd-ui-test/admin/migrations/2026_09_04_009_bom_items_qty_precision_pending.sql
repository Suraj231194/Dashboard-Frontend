-- =============================================================================
-- Migration: 2026_09_04_009_bom_items_qty_precision_pending.sql
-- Purpose: BOM quantity precision widening to DECIMAL(18,6) for reagent micro-ratios
-- Standard: Idempotent, non-destructive
-- =============================================================================

SET @bom_qty_precision_ok := (
    SELECT COUNT(*)
    FROM `information_schema`.`COLUMNS`
    WHERE `TABLE_SCHEMA` = DATABASE()
      AND `TABLE_NAME` = 'bom_items'
      AND `COLUMN_NAME` = 'qty_per_unit'
      AND `NUMERIC_SCALE` >= 6
);

SET @bom_qty_precision_sql := IF(
    @bom_qty_precision_ok = 1,
    'SELECT ''bom_items.qty_per_unit already has sufficient precision'' AS migration_status',
    'ALTER TABLE `bom_items` MODIFY COLUMN `qty_per_unit` DECIMAL(18,6) NOT NULL'
);

PREPARE bom_qty_precision_stmt FROM @bom_qty_precision_sql;
EXECUTE bom_qty_precision_stmt;
DEALLOCATE PREPARE bom_qty_precision_stmt;

INSERT INTO `_schema_migrations_applied` (`migration`, `applied_at`)
SELECT '2026_09_04_009_bom_items_qty_precision_pending.sql', NOW()
WHERE NOT EXISTS (
    SELECT 1
    FROM `_schema_migrations_applied`
    WHERE `migration` IN ('2026_09_04_009_bom_items_qty_precision_pending.sql', '2026_09_04_009_bom_items_qty_precision.sql')
);
