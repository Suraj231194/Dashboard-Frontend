<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

if (!isset($conn) || !$conn instanceof mysqli) {
    require_once dirname(__DIR__) . '/db.php';
}

$migrationPath = __DIR__ . '/2026_09_02_003_annual_calendar_hardening.sql';
$sql = file_get_contents($migrationPath);
if ($sql === false || trim($sql) === '') {
    fwrite(STDERR, "Annual calendar hardening migration SQL is unavailable.\n");
    exit(1);
}

if (!$conn->multi_query($sql)) {
    fwrite(STDERR, 'Annual calendar hardening migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}
while (true) {
    if ($result = $conn->store_result()) {
        $result->free();
    }
    if ($conn->errno !== 0) {
        fwrite(STDERR, 'Annual calendar hardening migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
    if (!$conn->more_results()) {
        break;
    }
    if (!$conn->next_result()) {
        fwrite(STDERR, 'Annual calendar hardening migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
}

$tableCheck = $conn->query("SHOW TABLES LIKE 'hr_annual_calendar_day_overrides'");
if (!$tableCheck || $tableCheck->num_rows !== 1) {
    fwrite(STDERR, "Migration verification failed: hr_annual_calendar_day_overrides not found.\n");
    exit(1);
}

$requiredColumns = [
    'hr_annual_calendars' => ['weekly_off_days', 'total_declared_holidays', 'total_optional_holidays'],
    'hr_annual_calendar_holidays' => ['is_optional'],
    'hr_annual_calendar_days' => ['is_optional_holiday'],
];
foreach ($requiredColumns as $tableName => $columns) {
    foreach ($columns as $columnName) {
        $result = $conn->query("SHOW COLUMNS FROM `{$tableName}` LIKE '{$columnName}'");
        if (!$result || $result->num_rows !== 1) {
            fwrite(STDERR, "Migration verification failed: {$tableName}.{$columnName} not found.\n");
            exit(1);
        }
    }
}

$constraint = $conn->query(
    "SELECT CONSTRAINT_NAME FROM information_schema.TABLE_CONSTRAINTS
     WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'payroll_runs'
       AND CONSTRAINT_NAME = 'fk_payroll_run_calendar_revision'"
);
if (!$constraint || $constraint->num_rows !== 1) {
    fwrite(STDERR, "Migration verification failed: payroll_runs calendar revision foreign key missing.\n");
    exit(1);
}

echo "Annual Calendar hardening migration applied and verified successfully.\n";
