-- ============================================================
-- Migration: Company Setup Tables + Permission
-- Date: 2026-06-26
-- Description: Creates erp_companies, erp_branches, erp_warehouses
--              and adds 'company_setup_view' permission for all roles.
-- HOW TO RUN: Import this file in phpMyAdmin or run via CLI:
--   mysql -u root -p u706677387_dev_autoivd < this_file.sql
-- ============================================================

-- 1. Create erp_companies
CREATE TABLE IF NOT EXISTS `erp_companies` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `company_name` VARCHAR(255) NOT NULL,
    `legal_name` VARCHAR(255) DEFAULT NULL,
    `company_code` VARCHAR(50) DEFAULT NULL,
    `gst_no` VARCHAR(50) DEFAULT NULL,
    `pan_no` VARCHAR(50) DEFAULT NULL,
    `cin_no` VARCHAR(50) DEFAULT NULL,
    `email` VARCHAR(255) DEFAULT NULL,
    `mobile` VARCHAR(20) DEFAULT NULL,
    `alternate_mobile` VARCHAR(20) DEFAULT NULL,
    `website` VARCHAR(255) DEFAULT NULL,
    `logo` VARCHAR(500) DEFAULT NULL,
    `address` TEXT DEFAULT NULL,
    `country` VARCHAR(100) DEFAULT 'India',
    `state` VARCHAR(100) DEFAULT NULL,
    `city` VARCHAR(100) DEFAULT NULL,
    `pincode` VARCHAR(20) DEFAULT NULL,
    `default_currency` VARCHAR(10) DEFAULT 'INR',
    `default_timezone` VARCHAR(50) DEFAULT 'Asia/Kolkata',
    `status` TINYINT(4) NOT NULL DEFAULT 1 COMMENT '1=Active, 2=Inactive, 3=Deleted, 4=Suspended, 5=Under Verification',
    `remarks` TEXT DEFAULT NULL,
    `created_by` INT(11) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT(11) DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    `deleted_by` INT(11) DEFAULT NULL,
    `deleted_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Create erp_branches
CREATE TABLE IF NOT EXISTS `erp_branches` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `company_id` INT(11) NOT NULL,
    `branch_name` VARCHAR(255) NOT NULL,
    `branch_code` VARCHAR(50) DEFAULT NULL,
    `branch_gst_no` VARCHAR(50) DEFAULT NULL,
    `email` VARCHAR(255) DEFAULT NULL,
    `mobile` VARCHAR(20) DEFAULT NULL,
    `phone` VARCHAR(20) DEFAULT NULL,
    `address` TEXT DEFAULT NULL,
    `country` VARCHAR(100) DEFAULT 'India',
    `state` VARCHAR(100) DEFAULT NULL,
    `city` VARCHAR(100) DEFAULT NULL,
    `pincode` VARCHAR(20) DEFAULT NULL,
    `is_head_office` TINYINT(1) NOT NULL DEFAULT 0,
    `status` TINYINT(4) NOT NULL DEFAULT 1 COMMENT '1=Active, 2=Inactive, 3=Deleted',
    `remarks` TEXT DEFAULT NULL,
    `created_by` INT(11) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT(11) DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    `deleted_by` INT(11) DEFAULT NULL,
    `deleted_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `fk_branch_company` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Create erp_warehouses
CREATE TABLE IF NOT EXISTS `erp_warehouses` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `company_id` INT(11) NOT NULL,
    `warehouse_name` VARCHAR(255) NOT NULL,
    `warehouse_code` VARCHAR(50) DEFAULT NULL,
    `warehouse_type` TINYINT(4) DEFAULT 1 COMMENT '1=Finished Goods, 2=Raw Materials, 3=Warehouse 1, 4=Warehouse 2, 5=Warehouse 3',
    `email` VARCHAR(255) DEFAULT NULL,
    `mobile` VARCHAR(20) DEFAULT NULL,
    `phone` VARCHAR(20) DEFAULT NULL,
    `address` TEXT DEFAULT NULL,
    `country` VARCHAR(100) DEFAULT 'India',
    `state` VARCHAR(100) DEFAULT NULL,
    `city` VARCHAR(100) DEFAULT NULL,
    `pincode` VARCHAR(20) DEFAULT NULL,
    `status` TINYINT(4) NOT NULL DEFAULT 1 COMMENT '1=Active, 2=Inactive, 3=Deleted',
    `remarks` TEXT DEFAULT NULL,
    `created_by` INT(11) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT(11) DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    `deleted_by` INT(11) DEFAULT NULL,
    `deleted_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `fk_warehouse_company` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Add 'company_setup_view' permission (skip if already exists)
INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`)
SELECT 'Company Setup View', 'company_setup_view', 1, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `permissions` WHERE `slug` = 'company_setup_view');

-- 5. Grant permission to Super Administrator (role_id=1) and other admin roles
INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT r.id, p.id, 1
FROM `roles` r
CROSS JOIN `permissions` p
WHERE p.slug = 'company_setup_view'
  AND r.id IN (1, 11, 12, 19, 20)
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` rp
      WHERE rp.role_id = r.id AND rp.permission_id = p.id
  );
