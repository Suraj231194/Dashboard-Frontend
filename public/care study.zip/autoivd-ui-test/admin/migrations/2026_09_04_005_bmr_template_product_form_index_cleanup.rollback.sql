-- Rollback for 2026_09_04_005_bmr_template_product_form_index_cleanup.sql
--
-- Restores the superseded (product_id, form_type) unique key. This can only
-- succeed while every product still holds a single document per form type;
-- once multi-document mappings exist the ALTER will fail on duplicates, which
-- is the intended safeguard rather than silently discarding rows.

SET @mapping_form_index_exists := (
    SELECT COUNT(DISTINCT `INDEX_NAME`)
    FROM `information_schema`.`STATISTICS`
    WHERE `TABLE_SCHEMA` = DATABASE()
      AND `TABLE_NAME` = 'bmr_template_product_mappings'
      AND `INDEX_NAME` = 'uq_bmr_template_product_form'
);

SET @mapping_duplicate_count := (
    SELECT COUNT(*) FROM (
        SELECT `product_id`, `form_type`
        FROM `bmr_template_product_mappings`
        WHERE `status` = 1 AND `deleted_at` IS NULL
        GROUP BY `product_id`, `form_type`
        HAVING COUNT(*) > 1
    ) duplicates
);

SET @mapping_form_index_sql := IF(
    @mapping_form_index_exists = 0 AND @mapping_duplicate_count = 0,
    'ALTER TABLE `bmr_template_product_mappings` ADD UNIQUE KEY `uq_bmr_template_product_form` (`product_id`, `form_type`)',
    'SELECT ''index already present, or multi-document mappings exist; refusing to recreate'' AS migration_status'
);

PREPARE mapping_form_index_stmt FROM @mapping_form_index_sql;
EXECUTE mapping_form_index_stmt;
DEALLOCATE PREPARE mapping_form_index_stmt;

DELETE FROM `_schema_migrations_applied`
WHERE `migration` = '2026_09_04_005_bmr_template_product_form_index_cleanup.sql';
