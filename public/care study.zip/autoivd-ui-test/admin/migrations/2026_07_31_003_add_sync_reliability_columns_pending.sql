-- Additive version fields used to reject stale bidirectional inventory updates.
-- Deployment artifact only: this file has not been executed.

ALTER TABLE `products`
  ADD COLUMN IF NOT EXISTS `sync_version` bigint(20) unsigned NOT NULL DEFAULT 0 AFTER `last_stock_sync_at`,
  ADD COLUMN IF NOT EXISTS `last_website_stock_version` bigint(20) unsigned NOT NULL DEFAULT 0 AFTER `sync_version`;

ALTER TABLE `live_stock`
  ADD INDEX IF NOT EXISTS `idx_live_stock_sync_pending` (`sync_pending`, `product_id`);

-- Capture every ERP-side stock mutation without changing the existing stock
-- business services. Website-originated updates set @manuverse_sync_origin so
-- they do not loop back to the website.
DROP TRIGGER IF EXISTS `trg_live_stock_sync_pending_bi`;
CREATE TRIGGER `trg_live_stock_sync_pending_bi`
BEFORE INSERT ON `live_stock`
FOR EACH ROW
SET NEW.`sync_pending` = IF(
  COALESCE(@manuverse_sync_origin, 'erp') <> 'website',
  1,
  COALESCE(NEW.`sync_pending`, 0)
);

DROP TRIGGER IF EXISTS `trg_live_stock_sync_pending_bu`;
CREATE TRIGGER `trg_live_stock_sync_pending_bu`
BEFORE UPDATE ON `live_stock`
FOR EACH ROW
SET NEW.`sync_pending` = IF(
  COALESCE(@manuverse_sync_origin, 'erp') <> 'website'
  AND (
    NOT (NEW.`quantity_available` <=> OLD.`quantity_available`)
    OR NOT (NEW.`status` <=> OLD.`status`)
    OR NOT (NEW.`coa_number` <=> OLD.`coa_number`)
    OR NOT (NEW.`lot_batch_no` <=> OLD.`lot_batch_no`)
    OR NOT (NEW.`mfg_date` <=> OLD.`mfg_date`)
    OR NOT (NEW.`exp_date` <=> OLD.`exp_date`)
  ),
  1,
  NEW.`sync_pending`
);
