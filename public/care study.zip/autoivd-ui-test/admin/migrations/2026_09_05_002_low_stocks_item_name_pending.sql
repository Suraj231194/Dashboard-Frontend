-- Migration: Add item_name column to low_stocks for non-inventory / office supply purchase requests
-- Ensures compliance with Procurement Module.md Section 3: Low-Stock Purchase Request Form
ALTER TABLE `low_stocks` ADD COLUMN IF NOT EXISTS `item_name` VARCHAR(255) NULL DEFAULT NULL AFTER `product_id`;
