<?php

declare(strict_types=1);

/**
 * Ensures every product mapped to the supported structured IP/FG COA
 * templates has:
 *   1) at least one visible incoming IP COA banner source; and
 *   2) at least one visible incoming FG COA banner source.
 *
 * Only missing coverage is appended. Existing workflow, COA, inventory and
 * template records are never reassigned or overwritten. Source-only BMR work
 * items deliberately have no BMR template mapping because they exist solely
 * to satisfy the established IP/FG COA queue relationship.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/functions.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_common.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/common.php';

$ipTemplateCodes = [
    'COMMON_BIOCHEMISTRY_IP_COA_V01',
    'COMMON_URINE_STRIP_IP_COA_V01',
    'COMMON_RAPID_TEST_IP_COA_V01',
    'COMMON_SEROLOGY_IP_COA_V01',
];
$fgTemplateCodes = [
    'COMMON_BIOCHEMISTRY_FG_COA_V01',
    'COMMON_URINE_STRIP_FG_COA_V01',
    'COMMON_RAPID_TEST_FG_COA_V01',
    'COMMON_SEROLOGY_FG_COA_V01',
];
$quoteCodes = static function (mysqli $conn, array $codes): string {
    return implode(',', array_map(
        static fn(string $code): string => "'" . $conn->real_escape_string($code) . "'",
        $codes
    ));
};
$ipCodeSql = $quoteCodes($conn, $ipTemplateCodes);
$fgCodeSql = $quoteCodes($conn, $fgTemplateCodes);

$mappedResult = $conn->query(
    "SELECT ip_mapping.product_id, product.product_name,
            COALESCE(product.product_code, '') AS product_code,
            COALESCE(NULLIF(product.unit_id, 0), 11) AS unit_id,
            ip_template.id AS ip_template_id,
            ip_template.template_code AS ip_template_code
     FROM coa_template_product_mappings ip_mapping
     INNER JOIN coa_document_templates ip_template
        ON ip_template.id = ip_mapping.template_id
       AND ip_template.template_code IN ({$ipCodeSql})
       AND ip_template.coa_type = 'IP'
       AND ip_template.status = 1
       AND ip_template.deleted_at IS NULL
     INNER JOIN products product
        ON product.id = ip_mapping.product_id
       AND product.status != 3
       AND product.deleted_at IS NULL
     WHERE ip_mapping.coa_type = 'IP'
       AND ip_mapping.status = 1
       AND ip_mapping.deleted_at IS NULL
       AND EXISTS (
           SELECT 1
           FROM coa_template_product_mappings fg_mapping
           INNER JOIN coa_document_templates fg_template
              ON fg_template.id = fg_mapping.template_id
             AND fg_template.template_code IN ({$fgCodeSql})
             AND fg_template.coa_type = 'FG'
             AND fg_template.status = 1
             AND fg_template.deleted_at IS NULL
           WHERE fg_mapping.product_id = ip_mapping.product_id
             AND fg_mapping.coa_type = 'FG'
             AND fg_mapping.status = 1
             AND fg_mapping.deleted_at IS NULL
       )
     ORDER BY ip_mapping.product_id"
);
if (!$mappedResult) {
    fwrite(STDERR, "Unable to load the mapped structured COA product catalog.\n");
    exit(1);
}
$products = [];
while ($row = $mappedResult->fetch_assoc()) {
    $products[(int) $row['product_id']] = $row;
}
if (count($products) !== 118) {
    fwrite(STDERR, 'Expected 118 distinct structured COA products; found '
        . count($products) . ".\n");
    exit(1);
}

$visibleIpProducts = [];
$visibleIpResult = $conn->query(
    "SELECT DISTINCT request_row.product_id
     FROM bmr_bpr_work_items wi
     INNER JOIN bmr_bpr_requests request_row
        ON request_row.id = wi.request_id
       AND request_row.product_id IS NOT NULL
       AND request_row.deleted_at IS NULL
     WHERE wi.form_type = 'BMR'
       AND wi.status IN ('IN_PROCESS', 'COMPLETE')
       AND wi.deleted_at IS NULL
       AND wi.id = (
           SELECT MIN(eligible.id)
           FROM bmr_bpr_work_items eligible
           WHERE eligible.request_id = wi.request_id
             AND eligible.form_type = 'BMR'
             AND eligible.status IN ('IN_PROCESS', 'COMPLETE')
             AND eligible.deleted_at IS NULL
       )
       AND NOT EXISTS (
           SELECT 1
           FROM ip_coa_generation existing_ip
           LEFT JOIN bmr_bpr_work_items source_work_item
              ON source_work_item.id = existing_ip.source_bmr_work_item_id
           WHERE (
                   existing_ip.source_bmr_bpr_request_id = wi.request_id
                   OR (
                       existing_ip.source_bmr_bpr_request_id IS NULL
                       AND source_work_item.request_id = wi.request_id
                   )
               )
             AND existing_ip.deleted_at IS NULL
       )"
);
while ($row = $visibleIpResult->fetch_assoc()) {
    $visibleIpProducts[(int) $row['product_id']] = true;
}

$visibleFgProducts = [];
$visibleFgResult = $conn->query(
    "SELECT DISTINCT ip.product_id
     FROM ip_coa_generation ip
     LEFT JOIN fg_coa_generation fg
        ON fg.source_ip_coa_id = ip.id AND fg.deleted_at IS NULL
     WHERE ip.product_id IS NOT NULL
       AND ip.source_bmr_work_item_id IS NOT NULL
       AND ip.deleted_at IS NULL
       AND fg.id IS NULL"
);
while ($row = $visibleFgResult->fetch_assoc()) {
    $visibleFgProducts[(int) $row['product_id']] = true;
}

$missingIpProductIds = array_values(array_diff(array_keys($products), array_keys($visibleIpProducts)));
$missingFgProductIds = array_values(array_diff(array_keys($products), array_keys($visibleFgProducts)));
sort($missingIpProductIds);
sort($missingFgProductIds);
$batchLimit = 0;
foreach ($argv as $argument) {
    if (preg_match('/^--limit=(\d+)$/', (string) $argument, $matches)) {
        $batchLimit = max(0, (int) $matches[1]);
    }
}
$totalMissingBeforeBatch = count($missingIpProductIds) + count($missingFgProductIds);
if ($batchLimit > 0 && $totalMissingBeforeBatch > $batchLimit) {
    $selectedIp = array_slice($missingIpProductIds, 0, $batchLimit);
    $remainingCapacity = $batchLimit - count($selectedIp);
    $selectedFg = $remainingCapacity > 0
        ? array_slice($missingFgProductIds, 0, $remainingCapacity)
        : [];
    $missingIpProductIds = $selectedIp;
    $missingFgProductIds = $selectedFg;
}

$seedUserId = 1;
$seedDate = date('Y-m-d');
$fiscalYear = bmrBprFiscalYearLabel($seedDate);
$lockName = 'all_structured_coa_banner_seed_v1';
$lockStmt = $conn->prepare('SELECT GET_LOCK(?, 15) AS acquired');
$lockStmt->bind_param('s', $lockName);
$lockStmt->execute();
$lockAcquired = (int) ($lockStmt->get_result()->fetch_assoc()['acquired'] ?? 0) === 1;
$lockStmt->close();
if (!$lockAcquired) {
    fwrite(STDERR, "Unable to acquire the structured COA banner seed lock.\n");
    exit(1);
}

try {
    $conn->begin_transaction();

    $maxSequenceStmt = $conn->prepare(
        "SELECT COALESCE(MAX(CAST(RIGHT(document_batch_no, 6) AS UNSIGNED)), 0) AS max_sequence
         FROM production_plans
         WHERE document_batch_no LIKE ? AND deleted_at IS NULL"
    );
    $batchPrefixLike = 'BIO/PROD/FY' . $fiscalYear . '/%';
    $maxSequenceStmt->bind_param('s', $batchPrefixLike);
    $maxSequenceStmt->execute();
    $nextSequence = (int) ($maxSequenceStmt->get_result()->fetch_assoc()['max_sequence'] ?? 0) + 1;
    $maxSequenceStmt->close();

    $findExistingMr = $conn->prepare(
        "SELECT id, prod_plan_id, lot_batch_no
         FROM material_requisition
         WHERE slip_no = ? AND deleted_at IS NULL LIMIT 1 FOR UPDATE"
    );
    $insertPlan = $conn->prepare(
        "INSERT INTO production_plans
            (date, name, lo_batch_no, document_batch_no, batch_size, batch_size_unit,
             timeline, status, prodplan_remark, is_locked, bom_master_id, product_id,
             created_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 1, 0, ?, 0, 0, ?, ?, NOW())"
    );
    $insertMr = $conn->prepare(
        "INSERT INTO material_requisition
            (mr_raw, mr_packing, mr_consumable, date, product_name, lot_batch_no,
             batch_size, batch_size_unit, slip_no, department, requested_by,
             status, auto_generated_batch, prod_plan_id, bom_master_id, created_by, created_at)
         VALUES (1, 1, 1, ?, ?, ?, ?, ?, ?, 1, 'COA Template Acceptance',
                 0, ?, ?, 0, ?, NOW())"
    );
    $findRequest = $conn->prepare(
        "SELECT id FROM bmr_bpr_requests
         WHERE material_requisition_id = ? AND deleted_at IS NULL LIMIT 1 FOR UPDATE"
    );
    $insertRequest = $conn->prepare(
        "INSERT INTO bmr_bpr_requests
            (material_requisition_id, production_plan_id, product_id, request_date,
             product_name, category_code, lot_number, production_batch_number,
             batch_size, batch_size_unit_id, pack_size, form_count, bmr_form_count,
             bpr_form_count, remarks, status, requested_by, requested_at,
             reviewed_by, reviewed_at, review_comments, created_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, 0, ?,
                 'APPROVED', ?, NOW(), ?, NOW(),
                 'Approved only as a structured COA banner source.',
                 ?, NOW())"
    );
    $updateRequestNumber = $conn->prepare(
        'UPDATE bmr_bpr_requests SET request_no = ? WHERE id = ?'
    );
    $findWorkItem = $conn->prepare(
        "SELECT id FROM bmr_bpr_work_items
         WHERE request_id = ? AND form_type = 'BMR' AND form_sequence = 1
           AND deleted_at IS NULL LIMIT 1 FOR UPDATE"
    );
    $insertWorkItem = $conn->prepare(
        "INSERT INTO bmr_bpr_work_items
            (request_id, form_type, form_sequence, status, template_id, execution_id,
             form_payload_json, started_by, started_at, completed_by, completed_at,
             created_by, created_at)
         VALUES (?, 'BMR', 1, 'COMPLETE', NULL, NULL, NULL, ?, NOW(), ?, NOW(), ?, NOW())"
    );
    $findIp = $conn->prepare(
        "SELECT id, coa_ip, coa_template_id
         FROM ip_coa_generation
         WHERE source_bmr_bpr_request_id = ? AND deleted_at IS NULL
         LIMIT 1 FOR UPDATE"
    );
    $insertIp = $conn->prepare(
        "INSERT INTO ip_coa_generation
            (source_bmr_work_item_id, source_bmr_bpr_request_id, product_id,
             coa_template_id, form_payload_json, coa_ip, dept_id, product_name,
             batch_number, batch_size, batch_size_unit, test_date, tested_by,
             review_approved_by, remark, status, created_by, created_at)
         VALUES (?, ?, ?, ?, NULL, NULL, 1, ?, ?, ?, ?, ?,
                 'COA Template Acceptance', 'QC Head', ?, 0, ?, NOW())"
    );
    $updateIpNumber = $conn->prepare(
        'UPDATE ip_coa_generation SET coa_ip = ? WHERE id = ?'
    );
    if (
        !$findExistingMr || !$insertPlan || !$insertMr || !$findRequest
        || !$insertRequest || !$updateRequestNumber || !$findWorkItem
        || !$insertWorkItem || !$findIp || !$insertIp || !$updateIpNumber
    ) {
        throw new RuntimeException('Unable to prepare the structured COA banner seed statements.');
    }

    $createdRequests = 0;
    $createdWorkItems = 0;
    $createdIpSources = 0;
    $ensureSource = static function (
        string $queueType,
        array $product,
        int &$nextSequence
    ) use (
        $conn,
        $seedUserId,
        $seedDate,
        $fiscalYear,
        $findExistingMr,
        $insertPlan,
        $insertMr,
        $findRequest,
        $insertRequest,
        $updateRequestNumber,
        $findWorkItem,
        $insertWorkItem,
        $findIp,
        $insertIp,
        $updateIpNumber,
        &$createdRequests,
        &$createdWorkItems,
        &$createdIpSources
    ): array {
        $productId = (int) $product['product_id'];
        $productName = trim((string) $product['product_name']);
        $productCode = trim((string) $product['product_code']);
        $unitId = max(1, (int) $product['unit_id']);
        $batchSize = 1.0;
        $packSize = 'COA Template Acceptance';
        $queue = strtoupper($queueType);
        $marker = "Common structured COA {$queue} banner acceptance record.";
        $seedKey = "COA-ALL-{$queue}-BANNER-{$productId}";

        $findExistingMr->bind_param('s', $seedKey);
        $findExistingMr->execute();
        $existingMr = $findExistingMr->get_result()->fetch_assoc();
        if ($existingMr) {
            $materialRequisitionId = (int) $existingMr['id'];
            $productionPlanId = (int) $existingMr['prod_plan_id'];
            $batchNumber = (string) $existingMr['lot_batch_no'];
        } else {
            $sequence = $nextSequence++;
            $batchNumber = 'BIO/PROD/FY' . $fiscalYear . '/' . str_pad(
                (string) $sequence,
                6,
                '0',
                STR_PAD_LEFT
            );
            $insertPlan->bind_param(
                'ssssdissi',
                $seedDate,
                $productName,
                $batchNumber,
                $batchNumber,
                $batchSize,
                $unitId,
                $marker,
                $productId,
                $seedUserId
            );
            if (!$insertPlan->execute()) {
                throw new RuntimeException("Unable to create the {$queue} source plan for {$productName}.");
            }
            $productionPlanId = (int) $conn->insert_id;
            $autoBatch = 'BIPL-MR-' . date('d-m-Y') . '-' . $sequence;
            $insertMr->bind_param(
                'sssdissii',
                $seedDate,
                $productName,
                $batchNumber,
                $batchSize,
                $unitId,
                $seedKey,
                $autoBatch,
                $productionPlanId,
                $seedUserId
            );
            if (!$insertMr->execute()) {
                throw new RuntimeException("Unable to create the {$queue} source MR for {$productName}.");
            }
            $materialRequisitionId = (int) $conn->insert_id;
        }

        $findRequest->bind_param('i', $materialRequisitionId);
        $findRequest->execute();
        $request = $findRequest->get_result()->fetch_assoc();
        if ($request) {
            $requestId = (int) $request['id'];
        } else {
            $insertRequest->bind_param(
                'iiisssssdissiii',
                $materialRequisitionId,
                $productionPlanId,
                $productId,
                $seedDate,
                $productName,
                $productCode,
                $batchNumber,
                $batchNumber,
                $batchSize,
                $unitId,
                $packSize,
                $marker,
                $seedUserId,
                $seedUserId,
                $seedUserId
            );
            if (!$insertRequest->execute()) {
                throw new RuntimeException("Unable to create the {$queue} source request for {$productName}.");
            }
            $requestId = (int) $conn->insert_id;
            $requestNumber = bmrBprRequestNumber($requestId, $seedDate);
            $updateRequestNumber->bind_param('si', $requestNumber, $requestId);
            if (!$updateRequestNumber->execute()) {
                throw new RuntimeException("Unable to number the {$queue} source request for {$productName}.");
            }
            bmrBprInsertHistory(
                $conn,
                'REQUEST',
                $requestId,
                'COA_BANNER_SOURCE_CREATED',
                null,
                'APPROVED',
                $marker,
                ['product_id' => $productId, 'queue_type' => $queue],
                $seedUserId
            );
            $createdRequests++;
        }

        $findWorkItem->bind_param('i', $requestId);
        $findWorkItem->execute();
        $workItem = $findWorkItem->get_result()->fetch_assoc();
        if ($workItem) {
            $workItemId = (int) $workItem['id'];
        } else {
            $insertWorkItem->bind_param(
                'iiii',
                $requestId,
                $seedUserId,
                $seedUserId,
                $seedUserId
            );
            if (!$insertWorkItem->execute()) {
                throw new RuntimeException("Unable to create the {$queue} source work item for {$productName}.");
            }
            $workItemId = (int) $conn->insert_id;
            $createdWorkItems++;
        }

        $ipCoaId = null;
        $ipCoaNumber = '';
        if ($queue === 'FG') {
            $templateId = (int) $product['ip_template_id'];
            $findIp->bind_param('i', $requestId);
            $findIp->execute();
            $ipRow = $findIp->get_result()->fetch_assoc();
            if ($ipRow) {
                if ((int) $ipRow['coa_template_id'] !== $templateId) {
                    throw new RuntimeException("The existing FG source has the wrong IP template for {$productName}.");
                }
                $ipCoaId = (int) $ipRow['id'];
                $ipCoaNumber = (string) $ipRow['coa_ip'];
            } else {
                $insertIp->bind_param(
                    'iiiissdissi',
                    $workItemId,
                    $requestId,
                    $productId,
                    $templateId,
                    $productName,
                    $batchNumber,
                    $batchSize,
                    $unitId,
                    $seedDate,
                    $marker,
                    $seedUserId
                );
                if (!$insertIp->execute()) {
                    throw new RuntimeException("Unable to create the FG source IP COA for {$productName}.");
                }
                $ipCoaId = (int) $conn->insert_id;
                $ipCoaNumber = bmrBprIpCoaNumber($ipCoaId, $seedDate);
                $updateIpNumber->bind_param('si', $ipCoaNumber, $ipCoaId);
                if (!$updateIpNumber->execute()) {
                    throw new RuntimeException("Unable to number the FG source IP COA for {$productName}.");
                }
                bmrBprInsertHistory(
                    $conn,
                    'IP_COA',
                    $ipCoaId,
                    'CREATE_IP_COA_BANNER_SOURCE',
                    null,
                    'CREATED',
                    $marker,
                    [
                        'product_id' => $productId,
                        'source_bmr_work_item_id' => $workItemId,
                        'source_bmr_bpr_request_id' => $requestId,
                        'coa_ip' => $ipCoaNumber,
                        'coa_template_id' => $templateId,
                    ],
                    $seedUserId
                );
                $createdIpSources++;
            }
        }
        return [
            'request_id' => $requestId,
            'work_item_id' => $workItemId,
            'ip_coa_id' => $ipCoaId,
            'ip_coa_number' => $ipCoaNumber,
        ];
    };

    foreach ($missingIpProductIds as $productId) {
        $source = $ensureSource('IP', $products[$productId], $nextSequence);
        echo "IP | {$productId} | {$products[$productId]['product_name']} | "
            . "work item {$source['work_item_id']}\n";
    }
    foreach ($missingFgProductIds as $productId) {
        $source = $ensureSource('FG', $products[$productId], $nextSequence);
        echo "FG | {$productId} | {$products[$productId]['product_name']} | "
            . "{$source['ip_coa_number']}\n";
    }

    $conn->commit();
    echo "Structured COA products: " . count($products) . PHP_EOL;
    echo 'Missing IP coverage appended: ' . count($missingIpProductIds) . PHP_EOL;
    echo 'Missing FG coverage appended: ' . count($missingFgProductIds) . PHP_EOL;
    echo "New source requests: {$createdRequests}\n";
    echo "New source work items: {$createdWorkItems}\n";
    echo "New IP rows for the FG banner: {$createdIpSources}\n";
    echo 'Coverage items remaining before this batch: ' . $totalMissingBeforeBatch . PHP_EOL;
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
} finally {
    $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
    if ($releaseStmt) {
        $releaseStmt->bind_param('s', $lockName);
        $releaseStmt->execute();
        $releaseStmt->close();
    }
}
