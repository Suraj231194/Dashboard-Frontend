<?php

declare(strict_types=1);

/**
 * Idempotent CLI runner for the structured Biochemistry IP/FG COA schema.
 *
 * Usage:
 *   php admin/migrations/run_biochemistry_coa_migration.php
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$migrationPath = __DIR__ . '/2026_07_30_biochemistry_coa_templates_pending.sql';
$sql = file_get_contents($migrationPath);
if ($sql === false || trim($sql) === '') {
    fwrite(STDERR, "The Biochemistry COA migration file is unavailable.\n");
    exit(1);
}

if (!$conn->multi_query($sql)) {
    fwrite(STDERR, 'Migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}

do {
    if ($result = $conn->store_result()) {
        $result->free();
    }
    if ($conn->errno !== 0) {
        fwrite(STDERR, 'Migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
} while ($conn->more_results() && $conn->next_result());

if ($conn->errno !== 0) {
    fwrite(STDERR, 'Migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}

echo "Biochemistry IP/FG COA template schema is ready.\n";
