<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

if (!isset($conn) || !$conn instanceof mysqli) {
    require_once dirname(__DIR__) . '/db.php';
}

$migrationPath = __DIR__ . '/2026_09_02_004_shift_management_hardening.sql';
$sql = file_get_contents($migrationPath);
if ($sql === false || trim($sql) === '') {
    fwrite(STDERR, "Shift management migration SQL is unavailable.\n");
    exit(1);
}

if (!$conn->multi_query($sql)) {
    fwrite(STDERR, 'Shift management migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}
while (true) {
    if ($result = $conn->store_result()) {
        $result->free();
    }
    if ($conn->errno !== 0) {
        fwrite(STDERR, 'Shift management migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
    if (!$conn->more_results()) {
        break;
    }
    if (!$conn->next_result()) {
        fwrite(STDERR, 'Shift management migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
}

$requiredColumns = [
    'shifts' => ['company_id', 'branch_id'],
    'hr_shift_policies' => ['id', 'company_id', 'branch_id'],
    'hr_attendance_daily' => ['early_minutes', 'break_minutes'],
];
foreach ($requiredColumns as $table => $columns) {
    foreach ($columns as $column) {
        $result = $conn->query("SHOW COLUMNS FROM `{$table}` LIKE '{$column}'");
        if (!$result || $result->num_rows !== 1) {
            fwrite(STDERR, "Migration verification failed: {$table}.{$column} not found.\n");
            exit(1);
        }
    }
}

$unique = $conn->query(
    "SELECT INDEX_NAME FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'hr_shift_policies'
       AND INDEX_NAME = 'uq_shift_policy_scope' LIMIT 1"
);
if (!$unique || $unique->num_rows !== 1) {
    fwrite(STDERR, "Migration verification failed: tenant-scoped shift policy unique key missing.\n");
    exit(1);
}

$zeroHalfDay = $conn->query('SELECT COUNT(*) total FROM shifts WHERE half_day_hours <= 0')->fetch_assoc()['total'];
if ((int) $zeroHalfDay > 0) {
    fwrite(STDERR, "Migration verification failed: {$zeroHalfDay} shift(s) still have a zero half-day threshold.\n");
    exit(1);
}

echo "Shift management hardening migration applied and verified successfully.\n";
