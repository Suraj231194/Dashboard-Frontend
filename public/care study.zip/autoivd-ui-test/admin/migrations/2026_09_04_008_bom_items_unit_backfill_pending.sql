-- =============================================================================
-- Migration: 2026_09_04_008_bom_items_unit_backfill_pending.sql
-- Purpose: BOM component unit backfill (component unit or fallback to 'pcs')
-- Standard: Idempotent, non-destructive
-- =============================================================================

SET @pcs_unit_id := (
    SELECT `id` FROM `standard_units`
    WHERE `short_name` = 'pcs' AND `status` = 1
    ORDER BY `id` LIMIT 1
);

-- Pass 1: the component's own unit from the product master.
UPDATE `bom_items` AS `item`
INNER JOIN `products` AS `component`
        ON `component`.`id` = `item`.`raw_product_id`
SET `item`.`qty_unit_id` = `component`.`unit_id`,
    `item`.`updated_at` = NOW()
WHERE (`item`.`qty_unit_id` IS NULL OR `item`.`qty_unit_id` = 0)
  AND COALESCE(`component`.`unit_id`, 0) > 0
  AND `item`.`deleted_at` IS NULL;

-- Pass 2: agreed default for everything still unresolved.
UPDATE `bom_items`
SET `qty_unit_id` = @pcs_unit_id,
    `updated_at` = NOW()
WHERE (`qty_unit_id` IS NULL OR `qty_unit_id` = 0)
  AND `deleted_at` IS NULL
  AND @pcs_unit_id IS NOT NULL;

INSERT INTO `_schema_migrations_applied` (`migration`, `applied_at`)
SELECT '2026_09_04_008_bom_items_unit_backfill_pending.sql', NOW()
WHERE NOT EXISTS (
    SELECT 1
    FROM `_schema_migrations_applied`
    WHERE `migration` IN ('2026_09_04_008_bom_items_unit_backfill_pending.sql', '2026_09_04_008_bom_items_unit_backfill.sql')
);
