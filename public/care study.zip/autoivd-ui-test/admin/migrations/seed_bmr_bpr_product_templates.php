<?php

declare(strict_types=1);

/**
 * Idempotently imports the approved product-specific BMR/BPR template catalog.
 *
 * Run from the project root:
 * php admin/migrations/seed_bmr_bpr_product_templates.php
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

echo "Notice: Legacy image-backed templates have been retired. All products use modern schema 2 structured HTML table templates.\n";
exit(0);

if (!isset($conn) || !($conn instanceof mysqli)) {
    require_once __DIR__ . '/../db.php';
}
require_once __DIR__ . '/../workflow/bmr_bpr_legacy_layout.php';

$catalogPath = dirname(__DIR__, 2) . '/assets/bmr-bpr-templates/catalog.json';
if (!is_file($catalogPath)) {
    fwrite(STDERR, "Template catalog not found: {$catalogPath}\n");
    exit(1);
}

$catalog = json_decode((string) file_get_contents($catalogPath), true);
$templates = $catalog['templates'] ?? null;
if (!is_array($templates) || $templates === []) {
    fwrite(STDERR, "Template catalog is empty or invalid.\n");
    exit(1);
}

$migrationPath = __DIR__ . '/2026_07_27_bmr_bpr_product_templates_pending.sql';
$migrationSql = (string) file_get_contents($migrationPath);
if ($migrationSql === '') {
    fwrite(STDERR, "Template migration is empty.\n");
    exit(1);
}
$requirementsMigrationPath = __DIR__ . '/2026_07_27_bmr_bpr_product_document_requirements.sql';
$requirementsMigrationSql = (string) file_get_contents($requirementsMigrationPath);
if ($requirementsMigrationSql === '') {
    fwrite(STDERR, "Product document requirements migration is empty.\n");
    exit(1);
}

function seedBmrBprNormalizeDate(?string $value): ?string
{
    $value = trim((string) $value);
    if ($value === '') {
        return null;
    }
    $date = DateTimeImmutable::createFromFormat('d/m/Y', $value);
    if (!$date) {
        $date = DateTimeImmutable::createFromFormat('d/m/y', $value);
    }
    return $date ? $date->format('Y-m-d') : null;
}

function seedBmrBprApplyMigration(mysqli $conn, string $sql, string $label): void
{
    if (!$conn->multi_query($sql)) {
        throw new RuntimeException("Unable to apply {$label}: {$conn->error}");
    }
    while (true) {
        if ($result = $conn->store_result()) {
            $result->free();
        }
        if (!$conn->more_results()) {
            break;
        }
        if (!$conn->next_result()) {
            throw new RuntimeException("Unable to apply {$label}: {$conn->error}");
        }
    }
}

try {
    seedBmrBprApplyMigration($conn, $migrationSql, 'the template migration');
    seedBmrBprApplyMigration(
        $conn,
        $requirementsMigrationSql,
        'the product document requirements migration'
    );

    $conn->begin_transaction();

    $retireSupersededMappings = $conn->query(
        "UPDATE bmr_template_product_mappings mapping
         INNER JOIN bmr_templates template_row ON template_row.id = mapping.template_id
         SET mapping.status = 0,
             mapping.deleted_by = 1,
             mapping.deleted_at = NOW(),
             mapping.updated_by = 1,
             mapping.updated_at = NOW()
         WHERE mapping.deleted_at IS NULL
           AND (
               template_row.template_code LIKE 'COMMON_BIOCHEMISTRY_%'
               OR template_row.template_code LIKE 'COMMON_HEMATOLOGY_%'
               OR template_row.template_code LIKE 'COMMON_MICROBIOLOGY_%'
               OR template_row.template_code LIKE 'COMMON_SEROLOGY_%'
               OR template_row.template_code LIKE 'COMMON_UROLOGY_%'
           )"
    );
    if ($retireSupersededMappings === false) {
        throw new RuntimeException('Unable to retire superseded product mappings.');
    }

    $upsertTemplate = $conn->prepare(
        "INSERT INTO bmr_templates
            (product_id, product_name, template_name, form_type, template_code, version_no,
             document_no, issue_no, revision_no, effective_date, mfr_reference,
             source_pdf_path, page_asset_path, source_checksum, page_count, layout_json,
             status, created_by, created_at)
         VALUES (?, ?, ?, ?, ?, 2, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             product_id = VALUES(product_id),
             product_name = VALUES(product_name),
             template_name = VALUES(template_name),
             form_type = VALUES(form_type),
             document_no = VALUES(document_no),
             issue_no = VALUES(issue_no),
             revision_no = VALUES(revision_no),
             effective_date = VALUES(effective_date),
             mfr_reference = VALUES(mfr_reference),
             source_pdf_path = VALUES(source_pdf_path),
             page_asset_path = VALUES(page_asset_path),
             source_checksum = VALUES(source_checksum),
             page_count = VALUES(page_count),
             layout_json = VALUES(layout_json),
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    if (!$upsertTemplate) {
        throw new RuntimeException('Unable to prepare template import.');
    }

    $findTemplate = $conn->prepare(
        'SELECT id FROM bmr_templates WHERE template_code = ? AND deleted_at IS NULL LIMIT 1'
    );
    $resolveProduct = $conn->prepare(
        'SELECT id FROM products WHERE product_code = ? AND status != 3 AND deleted_at IS NULL LIMIT 1'
    );
    $upsertMapping = $conn->prepare(
        "INSERT INTO bmr_template_product_mappings
            (template_id, product_id, form_type, document_sequence, required_quantity,
             status, created_by, created_at)
         VALUES (?, ?, ?, ?, ?, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             template_id = VALUES(template_id),
             required_quantity = VALUES(required_quantity),
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    if (!$findTemplate || !$resolveProduct || !$upsertMapping) {
        throw new RuntimeException('Unable to prepare product template mapping import.');
    }

    $templateCount = 0;
    $mappingCount = 0;
    $mappingSequences = [];
    $mappedProductIds = [];
    foreach ($templates as $template) {
        $layoutPath = dirname(__DIR__, 2) . '/' . ltrim((string) ($template['layout_path'] ?? ''), '/');
        if (!is_file($layoutPath)) {
            throw new RuntimeException('Missing template layout: ' . $layoutPath);
        }
        $layoutJson = (string) file_get_contents($layoutPath);
        $decodedLayout = json_decode($layoutJson, true);
        if (!is_array($decodedLayout) || empty($decodedLayout['pages'])) {
            throw new RuntimeException('Invalid template layout: ' . $layoutPath);
        }
        $decodedLayout = bmrBprNormalizeLegacyLayout($decodedLayout);
        $layoutJson = json_encode(
            $decodedLayout,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
        );

        $productCodes = array_values(array_unique(array_filter(array_map(
            static fn ($value): string => trim((string) $value),
            $template['product_codes'] ?? []
        ))));
        if ($productCodes === []) {
            throw new RuntimeException('Template has no mapped products: ' . ($template['template_code'] ?? 'unknown'));
        }

        $productIds = [];
        $productCodesById = [];
        foreach ($productCodes as $productCode) {
            $resolveProduct->bind_param('s', $productCode);
            $resolveProduct->execute();
            $productId = (int) ($resolveProduct->get_result()->fetch_assoc()['id'] ?? 0);
            if ($productId <= 0) {
                throw new RuntimeException("Mapped product code {$productCode} is unavailable.");
            }
            $productIds[] = $productId;
            $productCodesById[$productId] = $productCode;
        }

        $canonicalProductId = $productIds[0];
        $family = trim((string) ($template['family'] ?? ''));
        $templateName = trim((string) ($template['template_name'] ?? ''));
        $formType = strtoupper(trim((string) ($template['form_type'] ?? '')));
        $templateCode = trim((string) ($template['template_code'] ?? ''));
        $documentNo = trim((string) ($template['document_no'] ?? ''));
        $issueNo = trim((string) ($template['issue_no'] ?? ''));
        $revisionNo = trim((string) ($template['revision_no'] ?? ''));
        $effectiveDate = seedBmrBprNormalizeDate($template['effective_date'] ?? null);
        $mfrReference = trim((string) ($template['mfr_reference'] ?? ''));
        $sourcePdfPath = trim((string) ($template['source_pdf_path'] ?? ''));
        $assetDirectory = trim((string) ($template['asset_directory'] ?? ''));
        $sourceChecksum = trim((string) ($template['source_checksum'] ?? ''));
        $pageCount = (int) ($template['page_count'] ?? 0);
        $requiredQuantity = max(1, (int) ($template['required_quantity'] ?? 1));
        $productRequiredQuantities = is_array($template['product_required_quantities'] ?? null)
            ? $template['product_required_quantities']
            : [];
        $configuredDocumentSequence = (int) ($template['document_sequence'] ?? 0);

        if (
            !in_array($formType, ['BMR', 'BPR'], true)
            || $templateCode === ''
            || $pageCount <= 0
            || $requiredQuantity > 1000
        ) {
            throw new RuntimeException('Invalid template catalog entry: ' . $templateCode);
        }

        $upsertTemplate->bind_param(
            'issssssssssssis',
            $canonicalProductId,
            $family,
            $templateName,
            $formType,
            $templateCode,
            $documentNo,
            $issueNo,
            $revisionNo,
            $effectiveDate,
            $mfrReference,
            $sourcePdfPath,
            $assetDirectory,
            $sourceChecksum,
            $pageCount,
            $layoutJson
        );
        if (!$upsertTemplate->execute()) {
            throw new RuntimeException('Unable to import template ' . $templateCode . ': ' . $upsertTemplate->error);
        }

        $findTemplate->bind_param('s', $templateCode);
        $findTemplate->execute();
        $templateId = (int) ($findTemplate->get_result()->fetch_assoc()['id'] ?? 0);
        if ($templateId <= 0) {
            throw new RuntimeException('Unable to resolve imported template ' . $templateCode);
        }
        $templateCount++;

        foreach ($productIds as $productId) {
            $mappedProductIds[$productId] = true;
            $mappingKey = $productId . ':' . $formType;
            $documentSequence = $configuredDocumentSequence > 0
                ? $configuredDocumentSequence
                : (($mappingSequences[$mappingKey] ?? 0) + 1);
            if ($documentSequence > 1000) {
                throw new RuntimeException(
                    "Mapped product ID {$productId} has an invalid {$formType} document sequence."
                );
            }
            $sequenceKey = $mappingKey . ':' . $documentSequence;
            if (isset($mappingSequences[$sequenceKey])) {
                throw new RuntimeException(
                    "Duplicate {$formType} document sequence {$documentSequence} for product ID {$productId}."
                );
            }
            $mappingSequences[$sequenceKey] = true;
            $mappingSequences[$mappingKey] = max(
                (int) ($mappingSequences[$mappingKey] ?? 0),
                $documentSequence
            );
            $mappingRequiredQuantity = max(
                1,
                (int) (
                    $productRequiredQuantities[$productCodesById[$productId]]
                    ?? $productRequiredQuantities[(string) $productId]
                    ?? $requiredQuantity
                )
            );
            if ($mappingRequiredQuantity > 1000) {
                throw new RuntimeException(
                    "Mapped product ID {$productId} has an invalid {$formType} document quantity."
                );
            }
            $upsertMapping->bind_param(
                'iisii',
                $templateId,
                $productId,
                $formType,
                $documentSequence,
                $mappingRequiredQuantity
            );
            if (!$upsertMapping->execute()) {
                throw new RuntimeException(
                    "Unable to map product {$productId} to {$templateCode}: {$upsertMapping->error}"
                );
            }
            $mappingCount++;
        }
    }

    $mappedProductSql = implode(',', array_map('intval', array_keys($mappedProductIds)));
    if ($mappedProductSql === '') {
        throw new RuntimeException('No product mappings were imported.');
    }

    $safeRequestSnapshots = $conn->query(
        "UPDATE bmr_bpr_request_documents request_document
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = request_document.request_id
           AND request_row.deleted_at IS NULL
         INNER JOIN bmr_template_product_mappings mapping
            ON mapping.product_id = request_row.product_id
           AND mapping.form_type = request_document.form_type
           AND mapping.document_sequence = request_document.document_sequence
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         SET request_document.template_id = mapping.template_id,
             request_document.updated_by = 1,
             request_document.updated_at = NOW()
         WHERE request_row.product_id IN ({$mappedProductSql})
           AND NOT EXISTS (
               SELECT 1
               FROM bmr_bpr_work_items started_item
               WHERE started_item.request_id = request_document.request_id
                 AND started_item.form_type = request_document.form_type
                 AND started_item.deleted_at IS NULL
                 AND (
                     started_item.status IN ('IN_PROCESS', 'COMPLETE')
                     OR (
                         started_item.form_payload_json IS NOT NULL
                         AND started_item.form_payload_json NOT IN ('', '{}')
                     )
                 )
           )"
    );
    if ($safeRequestSnapshots === false) {
        throw new RuntimeException('Unable to update safe request template snapshots.');
    }
    $snapshotCount = $conn->affected_rows;

    $safeIncoming = $conn->query(
        "UPDATE bmr_bpr_work_items work_item
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = work_item.request_id
           AND request_row.deleted_at IS NULL
         INNER JOIN bmr_template_product_mappings mapping
            ON mapping.product_id = request_row.product_id
           AND mapping.form_type = work_item.form_type
           AND mapping.document_sequence = work_item.form_sequence
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         SET work_item.template_id = mapping.template_id,
             work_item.updated_by = 1,
             work_item.updated_at = NOW()
         WHERE request_row.product_id IN ({$mappedProductSql})
           AND work_item.status IN ('QUEUED', 'PENDING')
           AND work_item.deleted_at IS NULL
           AND (
               work_item.form_payload_json IS NULL
               OR work_item.form_payload_json IN ('', '{}')
           )"
    );
    if ($safeIncoming === false) {
        throw new RuntimeException('Unable to update safe queued template work items.');
    }
    $incomingCount = $conn->affected_rows;

    $upsertTemplate->close();
    $findTemplate->close();
    $resolveProduct->close();
    $upsertMapping->close();

    $conn->commit();
    echo "Templates imported: {$templateCount}\n";
    echo "Product mappings imported: {$mappingCount}\n";
    echo "Safe request snapshots updated: {$snapshotCount}\n";
    echo "Blank queued/pending work items updated: {$incomingCount}\n";
    echo "In-process, completed and populated records were not reassigned.\n";
} catch (Throwable $exception) {
    if ($conn->errno === 0 || $conn->ping()) {
        $conn->rollback();
    }
    fwrite(STDERR, $exception->getMessage() . "\n");
    exit(1);
}
