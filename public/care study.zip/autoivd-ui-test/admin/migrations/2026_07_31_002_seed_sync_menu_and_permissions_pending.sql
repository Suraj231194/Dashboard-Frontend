-- Put all sync screens below the existing Company Control Room > Sync menu.
-- Deployment artifact only: this file has not been executed.

INSERT INTO `permissions` (`name`, `slug`, `status`)
VALUES
  ('View Sync Dashboard', 'sync_dashboard_view', 1),
  ('Manage Sync Settings', 'sync_settings_manage', 1),
  ('Retry Sync Failures', 'sync_failures_retry', 1),
  ('View Website Customers', 'sync_users_view', 1),
  ('View Website Meeting Requests', 'sync_meetings_view', 1),
  ('View Website Quiz Activity', 'sync_quiz_view', 1),
  ('View Website PI Requests', 'sync_pi_view', 1),
  ('View Website Quotation Requests', 'sync_quotations_view', 1)
ON DUPLICATE KEY UPDATE
  `name` = VALUES(`name`),
  `status` = 1,
  `deleted_at` = NULL;

SET @sync_parent_id := (
  SELECT `id`
  FROM `menus`
  WHERE (`route` = 'index.php?page=sync' OR LOWER(`name`) = 'sync')
    AND `status` != 3
  ORDER BY (`route` = 'index.php?page=sync') DESC, `id` ASC
  LIMIT 1
);

-- A parent with children is rendered as a submenu toggle by the existing sidebar.
UPDATE `menus`
SET `route` = '#', `updated_at` = NOW()
WHERE `id` = @sync_parent_id;

INSERT INTO `menus`
  (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`)
SELECT 'Sync Dashboard', 'index.php?page=sync', 'ti ti-refresh', @sync_parent_id, 10, 'sync_dashboard_view', 1, 1
WHERE @sync_parent_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM `menus` WHERE `route` = 'index.php?page=sync' AND `parent_id` = @sync_parent_id);

-- Normalize the former internal page route without changing its permission or sync entity key.
UPDATE `menus`
SET `name` = 'Customer Management',
    `route` = 'index.php?page=customer-management',
    `updated_at` = NOW()
WHERE `route` = 'index.php?page=user-management';

INSERT INTO `menus`
  (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`)
SELECT 'Customer Management', 'index.php?page=customer-management', 'ti ti-users', @sync_parent_id, 20, 'sync_users_view', 1, 1
WHERE @sync_parent_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM `menus` WHERE `route` = 'index.php?page=customer-management');

INSERT INTO `menus`
  (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`)
SELECT 'Meeting Requests', 'index.php?page=meeting-requests', 'ti ti-calendar-event', @sync_parent_id, 30, 'sync_meetings_view', 1, 1
WHERE @sync_parent_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM `menus` WHERE `route` = 'index.php?page=meeting-requests');

INSERT INTO `menus`
  (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`)
SELECT 'Quiz Activity Feed', 'index.php?page=quiz-activity-feed', 'ti ti-help-circle', @sync_parent_id, 40, 'sync_quiz_view', 1, 1
WHERE @sync_parent_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM `menus` WHERE `route` = 'index.php?page=quiz-activity-feed');

INSERT INTO `menus`
  (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`)
SELECT 'PI Requests', 'index.php?page=pi-requests', 'ti ti-file-invoice', @sync_parent_id, 50, 'sync_pi_view', 1, 1
WHERE @sync_parent_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM `menus` WHERE `route` = 'index.php?page=pi-requests');

INSERT INTO `menus`
  (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`)
SELECT 'Quotation Requests', 'index.php?page=quotation-requests', 'ti ti-file-text', @sync_parent_id, 60, 'sync_quotations_view', 1, 1
WHERE @sync_parent_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM `menus` WHERE `route` = 'index.php?page=quotation-requests');

UPDATE `menus`
SET `parent_id` = @sync_parent_id,
    `name` = CASE `route`
      WHEN 'index.php?page=customer-management' THEN 'Customer Management'
      ELSE `name`
    END,
    `sort_order` = CASE `route`
      WHEN 'index.php?page=sync' THEN 10
      WHEN 'index.php?page=customer-management' THEN 20
      WHEN 'index.php?page=meeting-requests' THEN 30
      WHEN 'index.php?page=quiz-activity-feed' THEN 40
      WHEN 'index.php?page=pi-requests' THEN 50
      WHEN 'index.php?page=quotation-requests' THEN 60
      ELSE `sort_order`
    END,
    `permission_slug` = CASE `route`
      WHEN 'index.php?page=sync' THEN 'sync_dashboard_view'
      WHEN 'index.php?page=customer-management' THEN 'sync_users_view'
      WHEN 'index.php?page=meeting-requests' THEN 'sync_meetings_view'
      WHEN 'index.php?page=quiz-activity-feed' THEN 'sync_quiz_view'
      WHEN 'index.php?page=pi-requests' THEN 'sync_pi_view'
      WHEN 'index.php?page=quotation-requests' THEN 'sync_quotations_view'
      ELSE `permission_slug`
    END,
    `showmenu` = 1,
    `status` = 1,
    `updated_at` = NOW()
WHERE @sync_parent_id IS NOT NULL
  AND `id` != @sync_parent_id
  AND `route` IN (
    'index.php?page=sync',
    'index.php?page=customer-management',
    'index.php?page=meeting-requests',
    'index.php?page=quiz-activity-feed',
    'index.php?page=pi-requests',
    'index.php?page=quotation-requests'
  );

-- Grant only the conventional administrator role. Other roles remain opt-in.
INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT 1, `p`.`id`, 1
FROM `permissions` `p`
WHERE EXISTS (SELECT 1 FROM `roles` WHERE `id` = 1)
  AND `p`.`slug` IN (
    'sync_dashboard_view',
    'sync_settings_manage',
    'sync_failures_retry',
    'sync_users_view',
    'sync_meetings_view',
    'sync_quiz_view',
    'sync_pi_view',
    'sync_quotations_view'
  )
ON DUPLICATE KEY UPDATE `status` = 1;
