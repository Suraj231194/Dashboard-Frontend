ALTER TABLE `production_plans`
    ADD COLUMN `product_id` INT(11) DEFAULT NULL AFTER `order_id`,
    ADD COLUMN `order_item_id` INT(11) DEFAULT NULL AFTER `product_id`;

CREATE INDEX `idx_production_plans_product`
    ON `production_plans` (`product_id`);

CREATE INDEX `idx_production_plans_order_item_active`
    ON `production_plans` (`order_item_id`, `deleted_at`);
