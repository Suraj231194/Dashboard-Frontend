-- Additive customer profile fields required by the Customer Management modal.
-- Existing Website -> ERP customer pull behavior is preserved.

ALTER TABLE `customers`
  ADD COLUMN IF NOT EXISTS `source_origin` varchar(20) NOT NULL DEFAULT 'erp' AFTER `website_user_id`,
  ADD COLUMN IF NOT EXISTS `country_code` varchar(10) NOT NULL DEFAULT '+91' AFTER `phone`,
  ADD COLUMN IF NOT EXISTS `gst_format_valid` tinyint(1) NOT NULL DEFAULT 0 AFTER `gstin`,
  ADD COLUMN IF NOT EXISTS `state_province` varchar(100) DEFAULT NULL AFTER `gst_format_valid`,
  ADD COLUMN IF NOT EXISTS `city` varchar(100) DEFAULT NULL AFTER `state_province`,
  ADD COLUMN IF NOT EXISTS `postal_code` varchar(20) DEFAULT NULL AFTER `city`,
  ADD COLUMN IF NOT EXISTS `detailed_address` text DEFAULT NULL AFTER `postal_code`,
  ADD INDEX IF NOT EXISTS `idx_customers_source_origin` (`source_origin`),
  ADD INDEX IF NOT EXISTS `idx_customers_location` (`state_province`, `city`, `postal_code`);

-- Backfill origin from the existing authoritative Website identifier.
UPDATE `customers`
SET `source_origin` = CASE
  WHEN `website_user_id` IS NOT NULL AND `website_user_id` > 0 THEN 'website'
  ELSE 'erp'
END;

-- Persist format status without claiming external/GST-portal verification.
UPDATE `customers`
SET `gst_format_valid` = CASE
  WHEN UPPER(COALESCE(`gstin`, '')) REGEXP '^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$' THEN 1
  ELSE 0
END;
