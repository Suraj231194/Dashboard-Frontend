-- Finance module schema and navigation seed.
-- Additive only: this migration does not alter any existing table.

CREATE TABLE IF NOT EXISTS finance_company_bank_accounts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    erp_company_id BIGINT UNSIGNED NULL,
    company_profile_id BIGINT UNSIGNED NULL,
    bank_name VARCHAR(255) NOT NULL,
    branch_name VARCHAR(255) NULL,
    account_name VARCHAR(255) NULL,
    account_number VARCHAR(100) NULL,
    ifsc_code VARCHAR(30) NULL,
    swift_code VARCHAR(30) NULL,
    upi_id VARCHAR(150) NULL,
    qr_file VARCHAR(500) NULL,
    is_default TINYINT(1) NOT NULL DEFAULT 0,
    status TINYINT NOT NULL DEFAULT 1,
    created_by INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by INT NULL,
    updated_at DATETIME NULL,
    deleted_by INT NULL,
    deleted_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_finance_bank_company (erp_company_id, status, deleted_at),
    KEY idx_finance_bank_profile (company_profile_id, status, deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS finance_document_terms (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    erp_company_id BIGINT UNSIGNED NULL,
    company_profile_id BIGINT UNSIGNED NULL,
    document_type ENUM('SALES_INVOICE','DELIVERY_CHALLAN','VENDOR_BILL') NOT NULL,
    title VARCHAR(255) NOT NULL,
    terms_text LONGTEXT NOT NULL,
    is_default TINYINT(1) NOT NULL DEFAULT 0,
    status TINYINT NOT NULL DEFAULT 1,
    created_by INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by INT NULL,
    updated_at DATETIME NULL,
    deleted_by INT NULL,
    deleted_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_finance_terms_company (erp_company_id, document_type, status, deleted_at),
    KEY idx_finance_terms_profile (company_profile_id, document_type, status, deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS finance_counterparty_credit_terms (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    counterparty_key CHAR(64) NOT NULL,
    counterparty_name VARCHAR(255) NOT NULL,
    counterparty_gstin VARCHAR(100) NULL,
    credit_days INT NOT NULL DEFAULT 30,
    status TINYINT NOT NULL DEFAULT 1,
    created_by INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by INT NULL,
    updated_at DATETIME NULL,
    deleted_by INT NULL,
    deleted_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_finance_counterparty_credit_key (counterparty_key),
    KEY idx_finance_counterparty_credit_lookup (counterparty_gstin, status, deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS finance_product_commercials (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    product_id INT NOT NULL,
    pack_size_id INT NULL,
    hsn_code VARCHAR(30) NULL,
    mrp DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    selling_rate DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    gst_rate DECIMAL(7,3) NULL,
    effective_from DATE NOT NULL,
    effective_to DATE NULL,
    status TINYINT NOT NULL DEFAULT 1,
    created_by INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by INT NULL,
    updated_at DATETIME NULL,
    deleted_by INT NULL,
    deleted_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_finance_product_effective (product_id, pack_size_id, effective_from),
    KEY idx_finance_product_lookup (product_id, status, effective_from, effective_to, deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS finance_number_sequences (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    erp_company_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
    document_type ENUM('SALES_INVOICE','DELIVERY_CHALLAN') NOT NULL,
    financial_year VARCHAR(9) NOT NULL,
    prefix VARCHAR(30) NOT NULL,
    last_number BIGINT UNSIGNED NOT NULL DEFAULT 0,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_finance_sequence (erp_company_id, document_type, financial_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS finance_documents (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    document_type ENUM('VENDOR_BILL','SALES_INVOICE','DELIVERY_CHALLAN') NOT NULL,
    source_type VARCHAR(40) NOT NULL,
    source_id INT NULL,
    source_key VARCHAR(191) NOT NULL,
    erp_company_id BIGINT UNSIGNED NULL,
    company_profile_id BIGINT UNSIGNED NULL,
    branch_id BIGINT UNSIGNED NULL,
    supplier_id INT NULL,
    order_id INT NULL,
    dispatch_id INT NULL,
    po_type ENUM('RM','PM') NULL,
    po_reference VARCHAR(255) NULL,
    counterparty_type ENUM('VENDOR','CLIENT') NOT NULL,
    counterparty_name VARCHAR(255) NOT NULL,
    counterparty_address TEXT NULL,
    counterparty_shipping_address TEXT NULL,
    counterparty_gstin VARCHAR(100) NULL,
    counterparty_state VARCHAR(100) NULL,
    counterparty_state_code VARCHAR(20) NULL,
    counterparty_contact VARCHAR(100) NULL,
    counterparty_email VARCHAR(255) NULL,
    document_number VARCHAR(100) NULL,
    reference_number VARCHAR(255) NULL,
    document_date DATE NULL,
    due_date DATE NULL,
    credit_days INT NULL,
    decision_status ENUM('PENDING','CREATE','DONT','PAID','UNPAID','NOT_SURE') NOT NULL DEFAULT 'PENDING',
    status ENUM('PENDING','DRAFT','GENERATED','OPEN','PART_PAID','PAID','NO_DOCUMENT','VOID') NOT NULL DEFAULT 'PENDING',
    accounting_effect TINYINT(1) NOT NULL DEFAULT 1,
    currency_code VARCHAR(10) NOT NULL DEFAULT 'INR',
    tax_mode ENUM('INTRA','INTER','NONE') NOT NULL DEFAULT 'INTRA',
    irn VARCHAR(255) NULL,
    acknowledgement_number VARCHAR(255) NULL,
    cases_text VARCHAR(100) NULL,
    lr_number VARCHAR(100) NULL,
    lr_date DATE NULL,
    transport_mode VARCHAR(255) NULL,
    tracking_id VARCHAR(255) NULL,
    shipment_type VARCHAR(100) NULL,
    shipment_type_details VARCHAR(255) NULL,
    delivery_mode VARCHAR(100) NULL,
    dispatched_by INT NULL,
    dispatched_to VARCHAR(255) NULL,
    received_by INT NULL,
    subtotal DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    discount_total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    taxable_total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    cgst_total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    sgst_total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    igst_total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    round_off DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    grand_total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    amount_paid DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    bank_account_id BIGINT UNSIGNED NULL,
    terms_snapshot LONGTEXT NULL,
    notes TEXT NULL,
    document_snapshot LONGTEXT NULL,
    generated_at DATETIME NULL,
    generated_by INT NULL,
    status_changed_at DATETIME NULL,
    status_changed_by INT NULL,
    created_by INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by INT NULL,
    updated_at DATETIME NULL,
    deleted_by INT NULL,
    deleted_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_finance_document_source (document_type, source_key),
    UNIQUE KEY uq_finance_generated_number (erp_company_id, document_type, document_number),
    KEY idx_finance_document_register (document_type, status, document_date, deleted_at),
    KEY idx_finance_document_due (document_type, due_date, status, deleted_at),
    KEY idx_finance_document_counterparty (counterparty_type, counterparty_name, deleted_at),
    KEY idx_finance_document_supplier (supplier_id, deleted_at),
    KEY idx_finance_document_order (order_id, dispatch_id, deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Completion fields are repeated as additive ALTER statements so this migration
-- remains safe for databases where the initial Finance schema was already applied.
ALTER TABLE finance_documents
    ADD COLUMN IF NOT EXISTS counterparty_shipping_address TEXT NULL AFTER counterparty_address,
    ADD COLUMN IF NOT EXISTS counterparty_email VARCHAR(255) NULL AFTER counterparty_contact,
    ADD COLUMN IF NOT EXISTS shipment_type VARCHAR(100) NULL AFTER tracking_id,
    ADD COLUMN IF NOT EXISTS shipment_type_details VARCHAR(255) NULL AFTER shipment_type,
    ADD COLUMN IF NOT EXISTS delivery_mode VARCHAR(100) NULL AFTER shipment_type_details,
    ADD COLUMN IF NOT EXISTS dispatched_by INT NULL AFTER delivery_mode,
    ADD COLUMN IF NOT EXISTS dispatched_to VARCHAR(255) NULL AFTER dispatched_by,
    ADD COLUMN IF NOT EXISTS received_by INT NULL AFTER dispatched_to;

ALTER TABLE finance_documents
    ADD COLUMN IF NOT EXISTS bank_snapshot LONGTEXT NULL AFTER bank_account_id;

ALTER TABLE finance_documents
    ADD INDEX IF NOT EXISTS idx_finance_document_incoming
        (document_type, decision_status, status, deleted_at, id);

CREATE TABLE IF NOT EXISTS finance_document_items (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    document_id BIGINT UNSIGNED NOT NULL,
    source_table VARCHAR(64) NULL,
    source_item_id INT NULL,
    product_id INT NULL,
    product_name VARCHAR(255) NOT NULL,
    hsn_code VARCHAR(30) NULL,
    pack_size VARCHAR(100) NULL,
    quantity DECIMAL(18,3) NOT NULL DEFAULT 0.000,
    free_quantity DECIMAL(18,3) NOT NULL DEFAULT 0.000,
    unit_id INT NULL,
    unit_label VARCHAR(100) NULL,
    batch_number VARCHAR(255) NULL,
    manufacturing_date DATE NULL,
    expiry_date DATE NULL,
    coa_number VARCHAR(255) NULL,
    mrp DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    rate DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    gross_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    discount_percent DECIMAL(7,3) NOT NULL DEFAULT 0.000,
    discount_value DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    taxable_value DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    cgst_percent DECIMAL(7,3) NOT NULL DEFAULT 0.000,
    cgst_value DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    sgst_percent DECIMAL(7,3) NOT NULL DEFAULT 0.000,
    sgst_value DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    igst_percent DECIMAL(7,3) NOT NULL DEFAULT 0.000,
    igst_value DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    line_total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    sort_order INT NOT NULL DEFAULT 0,
    created_by INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by INT NULL,
    updated_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_finance_items_document (document_id, sort_order),
    KEY idx_finance_items_source (document_id, source_table, source_item_id),
    KEY idx_finance_items_product (product_id),
    CONSTRAINT fk_finance_items_document FOREIGN KEY (document_id)
        REFERENCES finance_documents (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS finance_document_source_links (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    document_id BIGINT UNSIGNED NOT NULL,
    source_table VARCHAR(64) NOT NULL,
    source_id INT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_finance_source_link (document_id, source_table, source_id),
    KEY idx_finance_source_reverse (source_table, source_id),
    CONSTRAINT fk_finance_source_document FOREIGN KEY (document_id)
        REFERENCES finance_documents (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS finance_document_files (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    document_id BIGINT UNSIGNED NOT NULL,
    file_type ENUM('SOURCE_INVOICE','GENERATED_PDF','PAYMENT_ATTACHMENT','OTHER') NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    original_name VARCHAR(255) NULL,
    mime_type VARCHAR(100) NULL,
    file_size BIGINT UNSIGNED NULL,
    file_hash VARCHAR(128) NULL,
    version_number INT NOT NULL DEFAULT 1,
    created_by INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_finance_files_document (document_id, file_type, version_number),
    CONSTRAINT fk_finance_files_document FOREIGN KEY (document_id)
        REFERENCES finance_documents (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS finance_payments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    direction ENUM('OUTGOING','INCOMING') NOT NULL,
    counterparty_type ENUM('VENDOR','CLIENT') NOT NULL,
    supplier_id INT NULL,
    counterparty_name VARCHAR(255) NOT NULL,
    payment_date DATE NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    payment_mode ENUM('CASH','BANK_TRANSFER','CHEQUE','UPI','CARD','OTHER') NOT NULL,
    reference_number VARCHAR(255) NULL,
    bank_account_id BIGINT UNSIGNED NULL,
    notes TEXT NULL,
    attachment_path VARCHAR(500) NULL,
    status ENUM('POSTED','REVERSED') NOT NULL DEFAULT 'POSTED',
    reversed_at DATETIME NULL,
    reversed_by INT NULL,
    reversal_reason TEXT NULL,
    created_by INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by INT NULL,
    updated_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_finance_payment_register (direction, payment_date, status),
    KEY idx_finance_payment_counterparty (counterparty_type, counterparty_name),
    KEY idx_finance_payment_supplier (supplier_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS finance_payment_allocations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    payment_id BIGINT UNSIGNED NOT NULL,
    document_id BIGINT UNSIGNED NOT NULL,
    allocated_amount DECIMAL(18,2) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_finance_payment_document (payment_id, document_id),
    KEY idx_finance_allocation_document (document_id),
    CONSTRAINT fk_finance_allocation_payment FOREIGN KEY (payment_id)
        REFERENCES finance_payments (id) ON DELETE CASCADE,
    CONSTRAINT fk_finance_allocation_document FOREIGN KEY (document_id)
        REFERENCES finance_documents (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS finance_document_history (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    document_id BIGINT UNSIGNED NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    from_status VARCHAR(50) NULL,
    to_status VARCHAR(50) NULL,
    remarks TEXT NULL,
    snapshot LONGTEXT NULL,
    created_by INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_finance_history_document (document_id, created_at),
    CONSTRAINT fk_finance_history_document FOREIGN KEY (document_id)
        REFERENCES finance_documents (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Defaults reproduced from the approved Invoice/Challan references. They remain
-- editable per document and can be replaced through Finance configuration.
INSERT INTO finance_document_terms
    (erp_company_id, company_profile_id, document_type, title, terms_text, is_default, status, created_by)
SELECT
    ec.id,
    NULL,
    source.document_type,
    'Standard Terms',
    CONCAT(
        '1. Goods once sold will not be taken back or exchanged after 15 days.', CHAR(10),
        '2. Bills not paid by the due date will attract 24% interest.', CHAR(10),
        '3. All disputes are subject to Lucknow jurisdiction only.'
    ),
    1,
    1,
    1
FROM erp_companies ec
CROSS JOIN (
    SELECT 'SALES_INVOICE' AS document_type
    UNION ALL SELECT 'DELIVERY_CHALLAN'
    UNION ALL SELECT 'VENDOR_BILL'
) source
WHERE ec.status = 1
  AND ec.deleted_at IS NULL
  AND NOT EXISTS (
      SELECT 1
      FROM finance_document_terms fdt
      WHERE fdt.document_type = source.document_type
        AND fdt.erp_company_id <=> ec.id
        AND fdt.is_default = 1
        AND fdt.status = 1
        AND fdt.deleted_at IS NULL
  );

INSERT INTO finance_company_bank_accounts
    (erp_company_id, company_profile_id, bank_name, branch_name, account_name,
     account_number, ifsc_code, is_default, status, created_by)
SELECT
    ec.id,
    NULL,
    'BANK OF BARODA',
    'HAZARAT GANJ',
    COALESCE(ec.legal_name, ec.company_name),
    '00500500000114',
    'BARB0HAZARA',
    1,
    1,
    1
FROM erp_companies ec
WHERE ec.status = 1
  AND ec.deleted_at IS NULL
  AND NOT EXISTS (
      SELECT 1
      FROM finance_company_bank_accounts fcba
      WHERE fcba.erp_company_id <=> ec.id
        AND fcba.status = 1
        AND fcba.deleted_at IS NULL
  );

INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Bill Generation View', 'finance_bill_generation_view', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_bill_generation_view');
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Bill Generation Manage', 'finance_bill_generation_manage', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_bill_generation_manage');
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Payment Made View', 'finance_payment_made_view', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_payment_made_view');
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Payment Made Manage', 'finance_payment_made_manage', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_payment_made_manage');
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Trade Payables View', 'finance_trade_payables_view', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_trade_payables_view');
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Trade Payables Manage', 'finance_trade_payables_manage', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_trade_payables_manage');
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Invoice Generation View', 'finance_invoice_generation_view', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_invoice_generation_view');
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Invoice Generation Manage', 'finance_invoice_generation_manage', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_invoice_generation_manage');
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Delivery Challan View', 'finance_delivery_challan_generation_view', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_delivery_challan_generation_view');
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Delivery Challan Manage', 'finance_delivery_challan_generation_manage', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_delivery_challan_generation_manage');
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Payment Received View', 'finance_payment_received_view', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_payment_received_view');
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Payment Received Manage', 'finance_payment_received_manage', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_payment_received_manage');
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Trade Receivables View', 'finance_trade_receivables_view', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_trade_receivables_view');
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'Finance Trade Receivables Manage', 'finance_trade_receivables_manage', 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'finance_trade_receivables_manage');

INSERT IGNORE INTO role_permissions (role_id, permission_id, status)
SELECT r.id, p.id, 1
FROM roles r
JOIN permissions p ON p.slug LIKE 'finance\\_%' ESCAPE '\\'
WHERE r.status = 1
  AND r.deleted_at IS NULL
  AND r.name IN (
      'Super Administrator',
      'Administrator',
      'Senior Administrator',
      'Production + Ops /Admin + Sales & Billing',
      'Sales & Marketting + Sales & Billing'
  );

INSERT INTO menus (name, route, icon, parent_id, sort_order, permission_slug, showmenu, status, created_at)
SELECT 'Finance', NULL, 'ti ti-currency-rupee', 0, 90, NULL, 1, 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM menus WHERE name = 'Finance' AND deleted_at IS NULL);

SET @finance_menu_id := (
    SELECT id FROM menus WHERE name = 'Finance' AND deleted_at IS NULL ORDER BY id LIMIT 1
);

INSERT INTO menus (name, route, icon, parent_id, sort_order, permission_slug, showmenu, status, created_at)
SELECT 'Bill Module', NULL, 'ti ti-file-invoice', @finance_menu_id, 1, NULL, 1, 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (
    SELECT 1 FROM menus WHERE name = 'Bill Module' AND parent_id = @finance_menu_id AND deleted_at IS NULL
);

INSERT INTO menus (name, route, icon, parent_id, sort_order, permission_slug, showmenu, status, created_at)
SELECT 'Invoice Module', NULL, 'ti ti-receipt', @finance_menu_id, 2, NULL, 1, 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (
    SELECT 1 FROM menus WHERE name = 'Invoice Module' AND parent_id = @finance_menu_id AND deleted_at IS NULL
);

SET @finance_bill_menu_id := (
    SELECT id FROM menus WHERE name = 'Bill Module' AND parent_id = @finance_menu_id AND deleted_at IS NULL ORDER BY id LIMIT 1
);
SET @finance_invoice_menu_id := (
    SELECT id FROM menus WHERE name = 'Invoice Module' AND parent_id = @finance_menu_id AND deleted_at IS NULL ORDER BY id LIMIT 1
);

INSERT INTO menus (name, route, icon, parent_id, sort_order, permission_slug, showmenu, status, created_at)
SELECT 'Bill Generation', 'index.php?page=finance-bill-generation', 'ti ti-file-upload', @finance_bill_menu_id, 1, 'finance_bill_generation_view', 1, 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM menus WHERE route = 'index.php?page=finance-bill-generation' AND deleted_at IS NULL);
INSERT INTO menus (name, route, icon, parent_id, sort_order, permission_slug, showmenu, status, created_at)
SELECT 'Payment Made', 'index.php?page=finance-payment-made', 'ti ti-credit-card-pay', @finance_bill_menu_id, 2, 'finance_payment_made_view', 1, 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM menus WHERE route = 'index.php?page=finance-payment-made' AND deleted_at IS NULL);
INSERT INTO menus (name, route, icon, parent_id, sort_order, permission_slug, showmenu, status, created_at)
SELECT 'Creditors / Trade Payables', 'index.php?page=finance-trade-payables', 'ti ti-hourglass', @finance_bill_menu_id, 3, 'finance_trade_payables_view', 1, 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM menus WHERE route = 'index.php?page=finance-trade-payables' AND deleted_at IS NULL);

INSERT INTO menus (name, route, icon, parent_id, sort_order, permission_slug, showmenu, status, created_at)
SELECT 'Invoice Generation', 'index.php?page=finance-invoice-generation', 'ti ti-file-invoice', @finance_invoice_menu_id, 1, 'finance_invoice_generation_view', 1, 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM menus WHERE route = 'index.php?page=finance-invoice-generation' AND deleted_at IS NULL);
INSERT INTO menus (name, route, icon, parent_id, sort_order, permission_slug, showmenu, status, created_at)
SELECT 'Delivery Challan Generation', 'index.php?page=finance-challan-generation', 'ti ti-truck-delivery', @finance_invoice_menu_id, 2, 'finance_delivery_challan_generation_view', 1, 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM menus WHERE route = 'index.php?page=finance-challan-generation' AND deleted_at IS NULL);
INSERT INTO menus (name, route, icon, parent_id, sort_order, permission_slug, showmenu, status, created_at)
SELECT 'Payment Received', 'index.php?page=finance-payment-received', 'ti ti-credit-card-refund', @finance_invoice_menu_id, 3, 'finance_payment_received_view', 1, 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM menus WHERE route = 'index.php?page=finance-payment-received' AND deleted_at IS NULL);
INSERT INTO menus (name, route, icon, parent_id, sort_order, permission_slug, showmenu, status, created_at)
SELECT 'Debtors / Trade Receivables', 'index.php?page=finance-trade-receivables', 'ti ti-cash-banknote', @finance_invoice_menu_id, 4, 'finance_trade_receivables_view', 1, 1, CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM menus WHERE route = 'index.php?page=finance-trade-receivables' AND deleted_at IS NULL);
