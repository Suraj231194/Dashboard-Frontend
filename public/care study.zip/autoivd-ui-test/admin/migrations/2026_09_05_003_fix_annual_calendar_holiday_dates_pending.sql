-- Migration: Fix accurate Indian holiday dates for 2026 annual calendars
-- Updates incorrect dates for Janmashtami, Dussehra, Diwali, Guru Nanak Jayanti, Eid, etc.

UPDATE `hr_annual_calendar_holidays`
SET `holiday_date` = '2026-09-04'
WHERE `holiday_name` = 'Janmashtami' AND `holiday_date` = '2026-08-06' AND `deleted_at` IS NULL;

UPDATE `hr_annual_calendar_holidays`
SET `holiday_date` = '2026-10-20'
WHERE `holiday_name` = 'Dussehra' AND `holiday_date` = '2026-09-21' AND `deleted_at` IS NULL;

UPDATE `hr_annual_calendar_holidays`
SET `holiday_date` = '2026-11-08'
WHERE `holiday_name` = 'Diwali' AND `holiday_date` = '2026-10-09' AND `deleted_at` IS NULL;

UPDATE `hr_annual_calendar_holidays`
SET `holiday_date` = '2026-11-09'
WHERE `holiday_name` = 'Diwali (Day 2)' AND `holiday_date` = '2026-10-10' AND `deleted_at` IS NULL;

UPDATE `hr_annual_calendar_holidays`
SET `holiday_date` = '2026-11-24'
WHERE `holiday_name` = 'Guru Nanak Jayanti' AND `holiday_date` = '2026-10-25' AND `deleted_at` IS NULL;

UPDATE `hr_annual_calendar_holidays`
SET `holiday_date` = '2026-03-21'
WHERE `holiday_name` = 'Eid ul-Fitr' AND `holiday_date` = '2026-03-20' AND `deleted_at` IS NULL;

UPDATE `hr_annual_calendar_holidays`
SET `holiday_date` = '2026-03-26'
WHERE `holiday_name` = 'Ram Navami' AND `holiday_date` = '2026-03-27' AND `deleted_at` IS NULL;

UPDATE `hr_annual_calendar_holidays`
SET `holiday_date` = '2026-03-31'
WHERE `holiday_name` = 'Mahavir Jayanti' AND `holiday_date` = '2026-04-01' AND `deleted_at` IS NULL;

UPDATE `hr_annual_calendar_holidays`
SET `holiday_date` = '2026-05-28'
WHERE `holiday_name` = 'Eid ul-Adha' AND `holiday_date` = '2026-05-27' AND `deleted_at` IS NULL;

-- Remove duplicate Labour Day if May Day / Labour Day already exists on 2026-05-01 for the same calendar
DELETE h1 FROM `hr_annual_calendar_holidays` h1
INNER JOIN `hr_annual_calendar_holidays` h2
  ON h1.calendar_id = h2.calendar_id
  AND h1.holiday_date = '2026-05-01'
  AND h2.holiday_date = '2026-05-01'
  AND h1.holiday_name = 'Labour Day'
  AND h2.holiday_name = 'May Day / Labour Day';
