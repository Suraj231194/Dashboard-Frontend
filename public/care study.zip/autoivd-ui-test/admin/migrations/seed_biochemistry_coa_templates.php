<?php

declare(strict_types=1);

/**
 * Installs the common product-profile-driven Biochemistry IP and FG COA
 * templates transcribed from /BIOCHEMISTRY COA REPORT 2026.
 *
 * Usage:
 *   php admin/migrations/seed_biochemistry_coa_templates.php
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/biochemistry_profiles.php';

function coaSeedLayout(string $coaType, array $catalog): array
{
    $type = strtoupper($coaType);
    $families = [];
    $profiles = [];

    foreach ($catalog as $familyKey => $catalogProfile) {
        $profile = $catalogProfile;
        $productIds = array_values(array_map('intval', $profile['product_ids'] ?? []));
        unset($profile['product_ids'], $profile['fg_rows']);
        $profile['rows'] = $type === 'FG'
            ? ($catalogProfile['fg_rows'] ?? $catalogProfile['rows'] ?? [])
            : ($catalogProfile['rows'] ?? []);
        $profile['source_document'] = $type === 'FG'
            ? (string) ($catalogProfile['source_fg_document'] ?? '')
            : (string) ($catalogProfile['source_ip_document'] ?? '');
        $stpNumber = trim((string) ($catalogProfile['stp_number'] ?? ''));
        $stpOverride = trim((string) (
            $type === 'FG'
                ? ($catalogProfile['fg_stp_reference'] ?? '')
                : ($catalogProfile['ip_stp_reference'] ?? '')
        ));
        $profile['stp_reference'] = $stpOverride !== ''
            ? $stpOverride
            : ($stpNumber === ''
                ? ''
                : 'BIPL-' . ($type === 'FG' ? 'FPSTP-' : 'IPSTP-') . $stpNumber);
        unset(
            $profile['source_ip_document'],
            $profile['source_fg_document'],
            $profile['stp_number'],
            $profile['ip_stp_reference'],
            $profile['fg_stp_reference']
        );

        $families[(string) $familyKey] = $profile;
        foreach ($productIds as $productId) {
            $profiles[(string) $productId] = ['family_key' => (string) $familyKey];
        }
    }

    ksort($families);
    uksort($profiles, static fn(string $left, string $right): int => (int) $left <=> (int) $right);

    return [
        'schema_version' => 1,
        'renderer' => 'structured_coa_html',
        'renderer_variant' => 'biochemistry',
        'coa_type' => $type,
        'document' => [
            'title' => 'CERTIFICATE OF ANALYSIS',
            'document_no' => 'BIPL-F-COA-01',
            'issue_no' => '01',
            'revision_no' => '02',
            'effective_date' => '03/04/2025',
            'review_date' => '02/04/2028',
            'department' => 'Quality Control',
            'supersedes' => 'Nil',
            'company_address' => 'B19/A, S.I.L. Ancillary Estate, Amausi Industrial Area, Nadarganj-226008 (Lucknow)',
        ],
        'profile_families' => $families,
        'profiles' => $profiles,
        'editable_fields' => [
            'metadata.manufacturing_date',
            'metadata.expiry_date',
            'results.*',
            'approval.decision',
            'approval.comments',
            'approval.analysis_by',
            'approval.verified_by',
        ],
    ];
}

$catalog = coaBiochemistryProfiles();
$productIds = coaBiochemistryMappedProductIds();
if (count($catalog) !== 29 || $productIds === []) {
    fwrite(STDERR, "The Biochemistry COA profile catalog is incomplete.\n");
    exit(1);
}

$definitions = [
    [
        'coa_type' => 'IP',
        'template_code' => 'COMMON_BIOCHEMISTRY_IP_COA_V01',
        'template_name' => 'Common Biochemistry IP COA',
    ],
    [
        'coa_type' => 'FG',
        'template_code' => 'COMMON_BIOCHEMISTRY_FG_COA_V01',
        'template_name' => 'Common Biochemistry FG COA',
    ],
];

$lockName = 'common_biochemistry_ip_fg_coa_v1';
$escapedLockName = $conn->real_escape_string($lockName);
$lockResult = $conn->query("SELECT GET_LOCK('{$escapedLockName}', 15) AS acquired");
$lockRow = $lockResult ? $lockResult->fetch_assoc() : null;
if ((int) ($lockRow['acquired'] ?? 0) !== 1) {
    fwrite(STDERR, "Unable to acquire the Biochemistry COA template seed lock.\n");
    exit(1);
}

try {
    $conn->begin_transaction();

    $upsertTemplate = $conn->prepare(
        "INSERT INTO coa_document_templates
            (template_code, template_name, coa_type, version_no, document_no,
             issue_no, revision_no, effective_date, review_date, source_directory,
             source_checksum, page_count, layout_json, status, created_by, created_at)
         VALUES (?, ?, ?, 1, 'BIPL-F-COA-01', '01', '02', '2025-04-03',
                 '2028-04-02', 'BIOCHEMISTRY COA REPORT 2026', ?, 2, ?, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             template_name = VALUES(template_name),
             coa_type = VALUES(coa_type),
             version_no = 1,
             document_no = VALUES(document_no),
             issue_no = VALUES(issue_no),
             revision_no = VALUES(revision_no),
             effective_date = VALUES(effective_date),
             review_date = VALUES(review_date),
             source_directory = VALUES(source_directory),
             source_checksum = VALUES(source_checksum),
             page_count = VALUES(page_count),
             layout_json = VALUES(layout_json),
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    $findTemplate = $conn->prepare(
        'SELECT id FROM coa_document_templates WHERE template_code = ? AND deleted_at IS NULL LIMIT 1'
    );
    $validateProduct = $conn->prepare(
        'SELECT id FROM products WHERE id = ? AND status != 3 AND deleted_at IS NULL LIMIT 1'
    );
    $upsertMapping = $conn->prepare(
        "INSERT INTO coa_template_product_mappings
            (template_id, product_id, coa_type, status, created_by, created_at)
         VALUES (?, ?, ?, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             template_id = VALUES(template_id),
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    if (!$upsertTemplate || !$findTemplate || !$validateProduct || !$upsertMapping) {
        throw new RuntimeException('Unable to prepare Biochemistry COA seed statements.');
    }

    $templateCount = 0;
    $mappingCount = 0;
    foreach ($definitions as $definition) {
        $coaType = (string) $definition['coa_type'];
        $layout = coaSeedLayout($coaType, $catalog);
        if (count($layout['profiles']) !== count($productIds)) {
            throw new RuntimeException("The {$coaType} COA product profile set is incomplete.");
        }
        $layoutJson = json_encode(
            $layout,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
        );
        $checksum = hash('sha256', $layoutJson);
        $templateCode = (string) $definition['template_code'];
        $templateName = (string) $definition['template_name'];

        $upsertTemplate->bind_param(
            'sssss',
            $templateCode,
            $templateName,
            $coaType,
            $checksum,
            $layoutJson
        );
        if (!$upsertTemplate->execute()) {
            throw new RuntimeException(
                "Unable to save {$coaType} COA template: " . $upsertTemplate->error
            );
        }

        $findTemplate->bind_param('s', $templateCode);
        $findTemplate->execute();
        $templateId = (int) ($findTemplate->get_result()->fetch_assoc()['id'] ?? 0);
        if ($templateId <= 0) {
            throw new RuntimeException("Unable to resolve {$coaType} COA template.");
        }
        $templateCount++;

        foreach ($productIds as $productId) {
            $validateProduct->bind_param('i', $productId);
            $validateProduct->execute();
            if (!$validateProduct->get_result()->fetch_assoc()) {
                throw new RuntimeException("Mapped Biochemistry product ID {$productId} is unavailable.");
            }
            $upsertMapping->bind_param('iis', $templateId, $productId, $coaType);
            if (!$upsertMapping->execute()) {
                throw new RuntimeException(
                    "Unable to map product {$productId} to {$coaType} COA: "
                    . $upsertMapping->error
                );
            }
            $mappingCount++;
        }
    }

    $conn->commit();
    echo "Installed {$templateCount} Biochemistry COA templates and {$mappingCount} product mappings.\n";
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
} finally {
    $conn->query("SELECT RELEASE_LOCK('{$escapedLockName}')");
}
