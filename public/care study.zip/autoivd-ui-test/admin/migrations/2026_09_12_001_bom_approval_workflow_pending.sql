-- =============================================================
-- Migration: 2026_09_12_001_bom_approval_workflow_pending.sql
-- Description: Add BOM approval workflow columns to bom_master
--              and create bom_approval_history audit table.
--              Backfill all existing BOMs as APPROVED.
-- Date: 2026-09-12
-- =============================================================

-- ---------------------------------------------------------------
-- 1. Add approval workflow columns to bom_master
-- ---------------------------------------------------------------
ALTER TABLE `bom_master`
  ADD COLUMN `bom_status` ENUM('DRAFT','PENDING_APPROVAL','APPROVED','REJECTED')
      NOT NULL DEFAULT 'APPROVED'
      COMMENT 'DRAFT=Newly cloned/manual, PENDING_APPROVAL=Awaiting approval, APPROVED=Ready for production, REJECTED=Rejected by approver'
      AFTER `status`,
  ADD COLUMN `source_type` ENUM('ORIGINAL','CLONED','MANUAL')
      NOT NULL DEFAULT 'ORIGINAL'
      COMMENT 'How this BOM was created: ORIGINAL=from seeder/direct, CLONED=cloned from another BOM, MANUAL=created manually without template'
      AFTER `bom_status`,
  ADD COLUMN `source_bom_id` INT(11) DEFAULT NULL
      COMMENT 'FK to bom_master.id — the BOM this was cloned from (NULL for ORIGINAL/MANUAL)'
      AFTER `source_type`,
  ADD COLUMN `approved_by` INT(11) DEFAULT NULL
      COMMENT 'User who approved this BOM'
      AFTER `source_bom_id`,
  ADD COLUMN `approved_at` DATETIME DEFAULT NULL
      COMMENT 'Timestamp when this BOM was approved'
      AFTER `approved_by`;

-- Index for efficient filtering by bom_status in production queries
ALTER TABLE `bom_master`
  ADD KEY `idx_bom_master_bom_status` (`bom_status`, `status`, `deleted_at`);

-- ---------------------------------------------------------------
-- 2. Create BOM approval history audit table
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bom_approval_history` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `bom_master_id` INT(11) NOT NULL,
  `action` ENUM('CREATED','SUBMITTED','APPROVED','REJECTED','MODIFIED') NOT NULL,
  `from_status` VARCHAR(30) DEFAULT NULL,
  `to_status` VARCHAR(30) NOT NULL,
  `comments` TEXT DEFAULT NULL,
  `performed_by` INT(11) NOT NULL,
  `performed_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  PRIMARY KEY (`id`),
  KEY `idx_bom_approval_bom` (`bom_master_id`),
  KEY `idx_bom_approval_performed` (`performed_at`),
  CONSTRAINT `fk_bom_approval_bom` FOREIGN KEY (`bom_master_id`)
    REFERENCES `bom_master` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------
-- 3. Backfill all existing BOMs as APPROVED + ORIGINAL
-- ---------------------------------------------------------------
UPDATE `bom_master`
SET `bom_status` = 'APPROVED',
    `source_type` = 'ORIGINAL'
WHERE `bom_status` != 'APPROVED'
   OR `source_type` != 'ORIGINAL';
