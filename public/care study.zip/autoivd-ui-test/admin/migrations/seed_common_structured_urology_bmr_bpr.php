<?php

declare(strict_types=1);

/**
 * Installs the image/PDF-free Urology templates. The two combined 2P uncut
 * products receive separate Glucose and Protein BMR documents and one BPR.
 *
 * Started, completed and populated work items retain their template snapshot.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$schemaRoot = dirname(__DIR__, 2) . '/assets/bmr-bpr-schemas';
$standardBmrProductIds = [1047, 1048, 1049, 1050, 1051, 1052, 1342, 1466, 1705, 1787];
$twoComponentProductIds = [1422, 1863];
$allProductIds = array_values(array_unique(array_merge(
    $standardBmrProductIds,
    $twoComponentProductIds
)));
sort($allProductIds);
$definitions = [
    [
        'path' => $schemaRoot . '/common-urology-bmr-v3.json',
        'template_code' => 'COMMON_UROLOGY_BMR_V03',
        'template_name' => 'Common Urology BMR',
        'form_type' => 'BMR',
        'page_count' => 7,
        'document_no' => 'BIPL-BMR-01',
        'document_sequence' => 1,
        'product_ids' => $standardBmrProductIds,
    ],
    [
        'path' => $schemaRoot . '/urology-glucose-uncut-bmr-v3.json',
        'template_code' => 'COMMON_UROLOGY_GLUCOSE_UNCUT_BMR_V03',
        'template_name' => 'Urology Glucose Uncut Component BMR',
        'form_type' => 'BMR',
        'page_count' => 5,
        'document_no' => 'BIPL-BMR-01',
        'document_sequence' => 1,
        'product_ids' => $twoComponentProductIds,
    ],
    [
        'path' => $schemaRoot . '/urology-protein-uncut-bmr-v3.json',
        'template_code' => 'COMMON_UROLOGY_PROTEIN_UNCUT_BMR_V03',
        'template_name' => 'Urology Protein Uncut Component BMR',
        'form_type' => 'BMR',
        'page_count' => 4,
        'document_no' => 'BIPL-BMR-01',
        'document_sequence' => 2,
        'product_ids' => $twoComponentProductIds,
    ],
    [
        'path' => $schemaRoot . '/common-urology-bpr-v3.json',
        'template_code' => 'COMMON_UROLOGY_BPR_V03',
        'template_name' => 'Common Urology BPR',
        'form_type' => 'BPR',
        'page_count' => 8,
        'document_no' => 'BIPL-BPR-01',
        'document_sequence' => 1,
        'product_ids' => $allProductIds,
    ],
];
$approvedProductSql = implode(',', $allProductIds);

$lockName = 'common_structured_urology_bmr_bpr_v3';
$lockStmt = $conn->prepare('SELECT GET_LOCK(?, 15) AS acquired');
$lockStmt->bind_param('s', $lockName);
$lockStmt->execute();
$lockAcquired = (int) ($lockStmt->get_result()->fetch_assoc()['acquired'] ?? 0) === 1;
$lockStmt->close();
if (!$lockAcquired) {
    fwrite(STDERR, "Unable to acquire the Urology template seed lock.\n");
    exit(1);
}

try {
    $conn->begin_transaction();

    $upsertTemplate = $conn->prepare(
        "INSERT INTO bmr_templates
            (product_id, product_name, template_name, form_type, template_code, version_no,
             document_no, issue_no, revision_no, effective_date, mfr_reference,
             source_pdf_path, page_asset_path, source_checksum, page_count, layout_json,
             status, created_by, created_at)
         VALUES (?, 'Urology Common', ?, ?, ?, 3, ?, '01', '02', '2025-04-03',
                 'PROFILE-DRIVEN', NULL, NULL, NULL, ?, ?, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             product_id = VALUES(product_id),
             product_name = VALUES(product_name),
             template_name = VALUES(template_name),
             form_type = VALUES(form_type),
             version_no = 3,
             document_no = VALUES(document_no),
             issue_no = '01',
             revision_no = '02',
             effective_date = '2025-04-03',
             mfr_reference = 'PROFILE-DRIVEN',
             source_pdf_path = NULL,
             page_asset_path = NULL,
             source_checksum = NULL,
             page_count = VALUES(page_count),
             layout_json = VALUES(layout_json),
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    $findTemplate = $conn->prepare(
        'SELECT id FROM bmr_templates WHERE template_code = ? AND deleted_at IS NULL LIMIT 1'
    );
    $validateProduct = $conn->prepare(
        'SELECT id FROM products WHERE id = ? AND status != 3 AND deleted_at IS NULL LIMIT 1'
    );
    $upsertMapping = $conn->prepare(
        "INSERT INTO bmr_template_product_mappings
            (template_id, product_id, form_type, document_sequence, required_quantity,
             status, created_by, created_at)
         VALUES (?, ?, ?, ?, 1, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             template_id = VALUES(template_id),
             required_quantity = 1,
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    if (!$upsertTemplate || !$findTemplate || !$validateProduct || !$upsertMapping) {
        throw new RuntimeException('Unable to prepare Urology template statements.');
    }

    $templateCount = 0;
    $mappingCount = 0;
    foreach ($definitions as $definition) {
        if (!is_file($definition['path'])) {
            throw new RuntimeException('Urology schema is missing: ' . $definition['path']);
        }
        $layoutJson = (string) file_get_contents($definition['path']);
        $layout = json_decode($layoutJson, true);
        if (
            !is_array($layout)
            || (int) ($layout['schema_version'] ?? 0) !== 2
            || (string) ($layout['renderer'] ?? '') !== 'structured_html'
            || (string) ($layout['renderer_variant'] ?? '') !== 'urology'
            || strtoupper((string) ($layout['form_type'] ?? '')) !== $definition['form_type']
            || !is_array($layout['profiles'] ?? null)
        ) {
            throw new RuntimeException('Urology schema is invalid: ' . $definition['path']);
        }

        $profileProductIds = array_values(array_map('intval', array_keys($layout['profiles'])));
        sort($profileProductIds);
        $expectedProductIds = $definition['product_ids'];
        sort($expectedProductIds);
        if ($profileProductIds !== $expectedProductIds) {
            throw new RuntimeException(
                'Urology schema profiles do not match the approved product set: '
                . $definition['path']
            );
        }

        $canonicalProductId = $profileProductIds[0];
        $templateName = $definition['template_name'];
        $formType = $definition['form_type'];
        $templateCode = $definition['template_code'];
        $documentNo = $definition['document_no'];
        $pageCount = (int) $definition['page_count'];
        $upsertTemplate->bind_param(
            'issssis',
            $canonicalProductId,
            $templateName,
            $formType,
            $templateCode,
            $documentNo,
            $pageCount,
            $layoutJson
        );
        if (!$upsertTemplate->execute()) {
            throw new RuntimeException(
                "Unable to save Urology template {$templateCode}: {$upsertTemplate->error}"
            );
        }

        $findTemplate->bind_param('s', $templateCode);
        $findTemplate->execute();
        $templateId = (int) ($findTemplate->get_result()->fetch_assoc()['id'] ?? 0);
        if ($templateId <= 0) {
            throw new RuntimeException("Unable to resolve Urology template {$templateCode}.");
        }
        $templateCount++;

        $documentSequence = (int) $definition['document_sequence'];
        foreach ($profileProductIds as $productId) {
            $validateProduct->bind_param('i', $productId);
            $validateProduct->execute();
            if (!$validateProduct->get_result()->fetch_assoc()) {
                throw new RuntimeException("Mapped Urology product {$productId} is unavailable.");
            }
            $upsertMapping->bind_param(
                'iisi',
                $templateId,
                $productId,
                $formType,
                $documentSequence
            );
            if (!$upsertMapping->execute()) {
                throw new RuntimeException(
                    "Unable to map Urology product {$productId}: {$upsertMapping->error}"
                );
            }
            $mappingCount++;
        }
    }

    $safeRequestSnapshots = $conn->query(
        "UPDATE bmr_bpr_request_documents request_document
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = request_document.request_id
           AND request_row.deleted_at IS NULL
         INNER JOIN bmr_template_product_mappings mapping
            ON mapping.product_id = request_row.product_id
           AND mapping.form_type = request_document.form_type
           AND mapping.document_sequence = request_document.document_sequence
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         SET request_document.template_id = mapping.template_id,
             request_document.updated_by = 1,
             request_document.updated_at = NOW()
         WHERE request_row.product_id IN ({$approvedProductSql})
           AND NOT EXISTS (
               SELECT 1
               FROM bmr_bpr_work_items started_item
               WHERE started_item.request_id = request_document.request_id
                 AND started_item.form_type = request_document.form_type
                 AND started_item.deleted_at IS NULL
                 AND (
                     started_item.status IN ('IN_PROCESS', 'COMPLETE')
                     OR (
                         started_item.form_payload_json IS NOT NULL
                         AND started_item.form_payload_json NOT IN ('', '{}')
                     )
                 )
           )"
    );
    if ($safeRequestSnapshots === false) {
        throw new RuntimeException('Unable to update safe Urology request snapshots.');
    }
    $snapshotCount = $conn->affected_rows;

    $safeIncoming = $conn->query(
        "UPDATE bmr_bpr_work_items work_item
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = work_item.request_id
           AND request_row.deleted_at IS NULL
         INNER JOIN bmr_template_product_mappings mapping
            ON mapping.product_id = request_row.product_id
           AND mapping.form_type = work_item.form_type
           AND mapping.document_sequence = work_item.form_sequence
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         SET work_item.template_id = mapping.template_id,
             work_item.updated_by = 1,
             work_item.updated_at = NOW()
         WHERE request_row.product_id IN ({$approvedProductSql})
           AND work_item.status IN ('QUEUED', 'PENDING')
           AND (
               work_item.form_payload_json IS NULL
               OR work_item.form_payload_json IN ('', '{}')
           )"
    );
    if ($safeIncoming === false) {
        throw new RuntimeException('Unable to map safe incoming Urology work items.');
    }
    $incomingCount = $conn->affected_rows;

    $upsertTemplate->close();
    $findTemplate->close();
    $validateProduct->close();
    $upsertMapping->close();
    $conn->commit();

    echo "Common Urology structured templates saved: {$templateCount}\n";
    echo "Distinct Urology document mappings updated: {$mappingCount}\n";
    echo "Safe Urology request snapshots updated: {$snapshotCount}\n";
    echo "Blank queued/pending Urology work items mapped: {$incomingCount}\n";
    echo "In-process, completed and populated records were not reassigned.\n";
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
} finally {
    $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
    if ($releaseStmt) {
        $releaseStmt->bind_param('s', $lockName);
        $releaseStmt->execute();
        $releaseStmt->close();
    }
}
