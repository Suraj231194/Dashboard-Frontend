-- =====================================================
-- WhatsApp Order Processing — Migration
-- Creates the whatsapp_order_log table for tracking
-- every inbound WhatsApp webhook message & processing status.
-- =====================================================

CREATE TABLE IF NOT EXISTS `whatsapp_order_log` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `wamid` VARCHAR(255) NOT NULL COMMENT 'WhatsApp Message ID for deduplication',
    `from_phone` VARCHAR(50) NOT NULL COMMENT 'Sender WhatsApp phone number',
    `from_name` VARCHAR(255) DEFAULT NULL COMMENT 'Sender WhatsApp profile name',
    `raw_message` LONGTEXT DEFAULT NULL COMMENT 'Full message text or payload',
    `parsed_data` JSON DEFAULT NULL COMMENT 'Structured data extracted from parsing',
    `processing_status` ENUM('success','parse_error','validation_error','system_error','duplicate') NOT NULL DEFAULT 'parse_error',
    `error_details` TEXT DEFAULT NULL COMMENT 'Human-readable error details',
    `order_id` INT DEFAULT NULL COMMENT 'FK to order_received.id (on success)',
    `reply_sent` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Whether reply message was sent',
    `reply_status` VARCHAR(255) DEFAULT NULL COMMENT 'API response or error details',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_wa_wamid` (`wamid`),
    KEY `idx_wa_phone` (`from_phone`),
    KEY `idx_wa_status` (`processing_status`),
    KEY `idx_wa_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
