-- Migration: Add reason column to bom_master and create bom_approval permission
-- Date: 2026-09-12

-- 1. Add reason column to bom_master if not exists
SET @dbname = DATABASE();
SET @tablename = "bom_master";
SET @columnname = "reason";
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      TABLE_SCHEMA = @dbname
      AND TABLE_NAME = @tablename
      AND COLUMN_NAME = @columnname
  ) > 0,
  "SELECT 1",
  "ALTER TABLE bom_master ADD COLUMN reason TEXT NULL AFTER bom_status;"
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 2. Insert permission 'bom_approval' if not exists
INSERT INTO permissions (name, slug, status, created_at)
SELECT 'BOM Approval Management', 'bom_approval', 1, NOW()
WHERE NOT EXISTS (
    SELECT 1 FROM permissions WHERE slug = 'bom_approval'
);

-- 3. Assign permission to:
-- Role 1 (Super Administrator)
-- Role 11 (Administrator)
-- Role 12 (Senior Administrator)
-- Role 8 (Manufacturing Plant Head)
SET @perm_id = (SELECT id FROM permissions WHERE slug = 'bom_approval' LIMIT 1);

INSERT INTO role_permissions (role_id, permission_id, status)
SELECT 1, @perm_id, 1
WHERE NOT EXISTS (
    SELECT 1 FROM role_permissions WHERE role_id = 1 AND permission_id = @perm_id
);

INSERT INTO role_permissions (role_id, permission_id, status)
SELECT 11, @perm_id, 1
WHERE NOT EXISTS (
    SELECT 1 FROM role_permissions WHERE role_id = 11 AND permission_id = @perm_id
);

INSERT INTO role_permissions (role_id, permission_id, status)
SELECT 12, @perm_id, 1
WHERE NOT EXISTS (
    SELECT 1 FROM role_permissions WHERE role_id = 12 AND permission_id = @perm_id
);

INSERT INTO role_permissions (role_id, permission_id, status)
SELECT 8, @perm_id, 1
WHERE NOT EXISTS (
    SELECT 1 FROM role_permissions WHERE role_id = 8 AND permission_id = @perm_id
);
