-- MANUVERSE v7 ERP sync foundation.
-- Deployment artifact only: do not execute without backup and staging review.

CREATE TABLE IF NOT EXISTS `sync_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity_type` varchar(50) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `direction` varchar(30) NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `batch_size` int(11) NOT NULL DEFAULT 100,
  `last_started_at` datetime DEFAULT NULL,
  `last_completed_at` datetime DEFAULT NULL,
  `last_status` varchar(30) DEFAULT NULL,
  `last_message` varchar(500) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sync_settings_entity_type` (`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sync_settings`
  (`entity_type`, `display_name`, `direction`, `is_enabled`, `batch_size`)
VALUES
  ('orders', 'Orders', 'bidirectional', 0, 100),
  ('inventory', 'Inventory', 'bidirectional', 0, 100),
  ('users', 'Customer Management', 'website_to_erp', 0, 100),
  ('meetings', 'Meeting Requests', 'website_to_erp', 0, 100),
  ('quiz', 'Quiz Activity Feed', 'website_to_erp', 0, 100),
  ('pi', 'PI Requests', 'website_to_erp', 0, 100),
  ('quotations', 'Quotation Requests', 'website_to_erp', 0, 100)
ON DUPLICATE KEY UPDATE
  `display_name` = VALUES(`display_name`),
  `direction` = VALUES(`direction`);

CREATE TABLE IF NOT EXISTS `sync_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entity_type` varchar(50) NOT NULL,
  `entity_id` varchar(100) NOT NULL,
  `direction` varchar(20) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `request_payload` longtext DEFAULT NULL,
  `response_body` longtext DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `http_code` int(11) DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sync_logs_entity` (`entity_type`, `entity_id`),
  KEY `idx_sync_logs_status_created` (`status`, `created_at`),
  KEY `idx_sync_logs_retry` (`status`, `attempts`, `last_attempt_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `website_user_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `user_type` varchar(30) NOT NULL DEFAULT 'b2c',
  `company_name` varchar(255) DEFAULT NULL,
  `gstin` varchar(50) DEFAULT NULL,
  `credit_limit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `credit_days` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_customers_website_user_id` (`website_user_id`),
  KEY `idx_customers_email` (`email`),
  KEY `idx_customers_type_status` (`user_type`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `meeting_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `website_meeting_id` bigint(20) unsigned NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `organization_name` varchar(255) DEFAULT NULL,
  `preferred_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'new',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_meeting_requests_website_id` (`website_meeting_id`),
  KEY `idx_meeting_requests_date_status` (`preferred_date`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `quiz_leads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `website_quiz_response_id` bigint(20) unsigned NOT NULL,
  `user_type` varchar(30) NOT NULL DEFAULT 'common',
  `participant_first_name` varchar(150) DEFAULT NULL,
  `participant_last_name` varchar(150) DEFAULT NULL,
  `participant_email` varchar(255) DEFAULT NULL,
  `participant_phone` varchar(50) DEFAULT NULL,
  `total_questions` int(11) NOT NULL DEFAULT 0,
  `total_correct_answers` int(11) NOT NULL DEFAULT 0,
  `score_percentage` int(11) NOT NULL DEFAULT 0,
  `reward_coupon_code` varchar(100) DEFAULT NULL,
  `lead_status` varchar(50) NOT NULL DEFAULT 'new',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_quiz_leads_website_id` (`website_quiz_response_id`),
  KEY `idx_quiz_leads_status` (`lead_status`),
  KEY `idx_quiz_leads_email` (`participant_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `pi_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `website_pi_id` bigint(20) unsigned NOT NULL,
  `pi_number` varchar(100) NOT NULL,
  `pi_date` date DEFAULT NULL,
  `requester_type` varchar(50) DEFAULT NULL,
  `target_name` varchar(255) DEFAULT NULL,
  `target_email` varchar(255) DEFAULT NULL,
  `target_phone` varchar(50) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'draft',
  `currency` varchar(10) NOT NULL DEFAULT 'INR',
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `customer_gstin` varchar(50) DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pi_requests_website_id` (`website_pi_id`),
  UNIQUE KEY `uq_pi_requests_number` (`pi_number`),
  KEY `idx_pi_requests_date_status` (`pi_date`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `pi_request_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pi_request_id` bigint(20) unsigned NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `variant_name` varchar(255) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `gst_rate` decimal(7,2) NOT NULL DEFAULT 0.00,
  `line_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pi_request_items_request` (`pi_request_id`),
  CONSTRAINT `fk_pi_request_items_request`
    FOREIGN KEY (`pi_request_id`) REFERENCES `pi_requests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `quotation_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `website_quotation_id` bigint(20) unsigned NOT NULL,
  `quotation_number` varchar(100) NOT NULL,
  `requester_type` varchar(50) DEFAULT NULL,
  `target_name` varchar(255) DEFAULT NULL,
  `target_email` varchar(255) DEFAULT NULL,
  `target_phone` varchar(50) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'generated',
  `currency` varchar(10) NOT NULL DEFAULT 'INR',
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_quotation_requests_website_id` (`website_quotation_id`),
  UNIQUE KEY `uq_quotation_requests_number` (`quotation_number`),
  KEY `idx_quotation_requests_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `quotation_request_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `quotation_request_id` bigint(20) unsigned NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `variant_name` varchar(255) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `gst_rate` decimal(7,2) NOT NULL DEFAULT 0.00,
  `line_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_quotation_request_items_request` (`quotation_request_id`),
  CONSTRAINT `fk_quotation_request_items_request`
    FOREIGN KEY (`quotation_request_id`) REFERENCES `quotation_requests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
