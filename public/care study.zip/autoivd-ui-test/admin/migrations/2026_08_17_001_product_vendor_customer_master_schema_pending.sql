-- Migration: 2026_08_17_001_product_vendor_customer_master_schema.sql
-- Purpose: Schema updates for Product Categories, Products Master, Suppliers (Vendors), and Customers Master

-- -------------------------------------------------------------
-- 1. Product Categories Table
-- -------------------------------------------------------------
ALTER TABLE `product_categories`
  ADD COLUMN IF NOT EXISTS `slug` varchar(150) DEFAULT NULL AFTER `name`,
  ADD COLUMN IF NOT EXISTS `website_sync` tinyint(1) NOT NULL DEFAULT 1 AFTER `status`;

-- -------------------------------------------------------------
-- 2. Products Master Table
-- -------------------------------------------------------------
ALTER TABLE `products`
  MODIFY COLUMN `product_name` text NOT NULL,
  MODIFY COLUMN `product_code` varchar(100) NOT NULL,
  ADD COLUMN IF NOT EXISTS `hsn_code` varchar(50) DEFAULT NULL AFTER `product_code`,
  ADD COLUMN IF NOT EXISTS `erp_sku_web` varchar(100) DEFAULT NULL AFTER `hsn_code`,
  ADD COLUMN IF NOT EXISTS `slug` varchar(255) DEFAULT NULL AFTER `product_name`,
  ADD COLUMN IF NOT EXISTS `inventory_group` int(11) DEFAULT 1 AFTER `category_id`,
  ADD COLUMN IF NOT EXISTS `gst_rate` decimal(5,2) DEFAULT 18.00 AFTER `inventory_group`,
  ADD COLUMN IF NOT EXISTS `description` text DEFAULT NULL AFTER `slug`,
  ADD COLUMN IF NOT EXISTS `reorder_level` decimal(15,3) DEFAULT 0.000 AFTER `gst_rate`,
  ADD COLUMN IF NOT EXISTS `product_image` varchar(255) DEFAULT NULL AFTER `reorder_level`;

-- -------------------------------------------------------------
-- 3. Suppliers / Vendors Master Table
-- -------------------------------------------------------------
ALTER TABLE `suppliers`
  MODIFY COLUMN `contact_number` varchar(150) DEFAULT NULL,
  MODIFY COLUMN `supplier_code` varchar(50) DEFAULT NULL,
  MODIFY COLUMN `gst_no` varchar(100) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `source_origin` varchar(20) NOT NULL DEFAULT 'erp' AFTER `supplier_code`,
  ADD COLUMN IF NOT EXISTS `state` varchar(100) DEFAULT NULL AFTER `contact_details`,
  ADD COLUMN IF NOT EXISTS `address` text DEFAULT NULL AFTER `state`,
  ADD COLUMN IF NOT EXISTS `city` varchar(100) DEFAULT NULL AFTER `address`,
  ADD COLUMN IF NOT EXISTS `pincode` varchar(20) DEFAULT NULL AFTER `city`;

-- -------------------------------------------------------------
-- 4. Customers Master Table
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `website_user_id` bigint(20) unsigned DEFAULT NULL,
  `source_origin` varchar(20) NOT NULL DEFAULT 'erp' COMMENT 'Defines whether customer is from erp or website',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `country_code` varchar(10) NOT NULL DEFAULT '+91',
  `user_type` varchar(30) NOT NULL DEFAULT 'b2b',
  `company_name` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `gstin` varchar(50) DEFAULT NULL,
  `pan` varchar(20) DEFAULT NULL,
  `gst_format_valid` tinyint(1) NOT NULL DEFAULT 0,
  `state_province` varchar(100) DEFAULT NULL,
  `state_code` varchar(20) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `detailed_address` text DEFAULT NULL,
  `credit_limit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `credit_days` int(11) NOT NULL DEFAULT 0,
  `payment_terms_status` int(11) DEFAULT 3,
  `payment_terms_text` varchar(500) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_customers_website_user_id` (`website_user_id`),
  KEY `idx_customers_name` (`name`),
  KEY `idx_customers_gstin` (`gstin`),
  KEY `idx_customers_email` (`email`),
  KEY `idx_customers_type_status` (`user_type`,`status`),
  KEY `idx_customers_source_origin` (`source_origin`),
  KEY `idx_customers_location` (`state_province`,`city`,`postal_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
