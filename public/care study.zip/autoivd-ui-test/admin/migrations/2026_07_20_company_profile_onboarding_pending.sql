-- Standalone Company Setup implementation for requirements 5.1 and 5.2.
-- This migration intentionally does not depend on the legacy erp company tables.

CREATE TABLE IF NOT EXISTS `company_profiles` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `profile_code` VARCHAR(40) NOT NULL,
    `legal_name` VARCHAR(255) NOT NULL,
    `trade_name` VARCHAR(255) NOT NULL,
    `company_type` VARCHAR(100) NOT NULL,
    `industry` VARCHAR(150) NOT NULL,
    `cin_no` VARCHAR(50) DEFAULT NULL,
    `gst_no` VARCHAR(50) DEFAULT NULL,
    `udyam_no` VARCHAR(50) DEFAULT NULL,
    `manufacturing_license_no` VARCHAR(100) DEFAULT NULL,
    `website` VARCHAR(255) DEFAULT NULL,
    `warehouse_same_as_factory` TINYINT(1) NOT NULL DEFAULT 1,
    `multi_location` TINYINT(1) NOT NULL DEFAULT 0,
    `status` TINYINT NOT NULL DEFAULT 1 COMMENT '1=Active, 2=Inactive, 3=Deleted',
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    `deleted_by` INT DEFAULT NULL,
    `deleted_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_company_profiles_code` (`profile_code`),
    KEY `idx_company_profiles_status` (`status`),
    KEY `idx_company_profiles_trade_name` (`trade_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `company_profile_contacts` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `company_id` BIGINT UNSIGNED NOT NULL,
    `contact_type` VARCHAR(20) NOT NULL COMMENT 'email or phone',
    `contact_value` VARCHAR(255) NOT NULL,
    `is_primary` TINYINT(1) NOT NULL DEFAULT 0,
    `sort_order` INT NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_company_profile_contacts_company` (`company_id`),
    CONSTRAINT `fk_company_profile_contacts_company`
        FOREIGN KEY (`company_id`) REFERENCES `company_profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `company_profile_addresses` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `company_id` BIGINT UNSIGNED NOT NULL,
    `address_type` VARCHAR(30) NOT NULL COMMENT 'registered, factory, or warehouse',
    `address` TEXT NOT NULL,
    `is_primary` TINYINT(1) NOT NULL DEFAULT 0,
    `sort_order` INT NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_company_profile_addresses_company` (`company_id`),
    CONSTRAINT `fk_company_profile_addresses_company`
        FOREIGN KEY (`company_id`) REFERENCES `company_profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `company_profile_documents` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `company_id` BIGINT UNSIGNED NOT NULL,
    `document_type` VARCHAR(50) NOT NULL,
    `file_path` VARCHAR(500) NOT NULL,
    `original_name` VARCHAR(255) NOT NULL,
    `mime_type` VARCHAR(100) DEFAULT NULL,
    `file_size` BIGINT UNSIGNED NOT NULL DEFAULT 0,
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_company_profile_document_type` (`company_id`, `document_type`),
    CONSTRAINT `fk_company_profile_documents_company`
        FOREIGN KEY (`company_id`) REFERENCES `company_profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `company_profile_locations` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `company_id` BIGINT UNSIGNED NOT NULL,
    `location_type` VARCHAR(50) NOT NULL,
    `location_name` VARCHAR(255) NOT NULL,
    `address` TEXT NOT NULL,
    `inherit_company_gst` TINYINT(1) NOT NULL DEFAULT 1,
    `gst_no` VARCHAR(50) DEFAULT NULL,
    `gst_state` VARCHAR(100) DEFAULT NULL,
    `contact_person` VARCHAR(150) DEFAULT NULL,
    `phone` VARCHAR(50) DEFAULT NULL,
    `email` VARCHAR(255) DEFAULT NULL,
    `is_default` TINYINT(1) NOT NULL DEFAULT 0,
    `status` TINYINT NOT NULL DEFAULT 1 COMMENT '1=Active, 2=Inactive',
    `sort_order` INT NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_company_profile_locations_company` (`company_id`),
    KEY `idx_company_profile_locations_type` (`location_type`),
    CONSTRAINT `fk_company_profile_locations_company`
        FOREIGN KEY (`company_id`) REFERENCES `company_profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `company_profile_location_emails` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `location_id` BIGINT UNSIGNED NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `is_primary` TINYINT(1) NOT NULL DEFAULT 0,
    `sort_order` INT NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_company_profile_location_email` (`location_id`, `email`),
    KEY `idx_company_profile_location_emails_location` (`location_id`),
    CONSTRAINT `fk_company_profile_location_emails_location`
        FOREIGN KEY (`location_id`) REFERENCES `company_profile_locations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`)
SELECT 'Company Setup View', 'company_setup_view', 1, 1
FROM DUAL
WHERE NOT EXISTS (
    SELECT 1 FROM `permissions` WHERE `slug` = 'company_setup_view'
);

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT DISTINCT menu_roles.role_id, view_permission.id, 1
FROM (
    SELECT rp.role_id
    FROM `role_permissions` rp
    INNER JOIN `permissions` p ON p.id = rp.permission_id
    WHERE rp.status = 1 AND p.slug = 'company_setup_menu_list'
) menu_roles
CROSS JOIN `permissions` view_permission
WHERE view_permission.slug = 'company_setup_view'
  AND NOT EXISTS (
      SELECT 1
      FROM `role_permissions` existing
      WHERE existing.role_id = menu_roles.role_id
        AND existing.permission_id = view_permission.id
        AND existing.status = 1
  );
