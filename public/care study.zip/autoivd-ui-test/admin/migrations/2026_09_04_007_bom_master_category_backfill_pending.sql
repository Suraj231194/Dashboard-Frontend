-- =============================================================================
-- Migration: 2026_09_04_007_bom_master_category_backfill_pending.sql
-- Purpose: BOM master category backfill from finished product master
-- Standard: Idempotent, non-destructive
-- =============================================================================

UPDATE `bom_master` AS `bom`
INNER JOIN `products` AS `finished`
        ON `finished`.`id` = `bom`.`finished_product_id`
SET `bom`.`category_id` = `finished`.`category_id`,
    `bom`.`updated_at` = NOW()
WHERE (`bom`.`category_id` IS NULL OR `bom`.`category_id` = 0)
  AND COALESCE(`finished`.`category_id`, 0) > 0
  AND `bom`.`deleted_at` IS NULL;

INSERT INTO `_schema_migrations_applied` (`migration`, `applied_at`)
SELECT '2026_09_04_007_bom_master_category_backfill_pending.sql', NOW()
WHERE NOT EXISTS (
    SELECT 1
    FROM `_schema_migrations_applied`
    WHERE `migration` IN ('2026_09_04_007_bom_master_category_backfill_pending.sql', '2026_09_04_007_bom_master_category_backfill.sql')
);
