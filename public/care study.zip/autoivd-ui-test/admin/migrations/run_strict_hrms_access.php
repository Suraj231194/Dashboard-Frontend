<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$migrationPath = __DIR__ . '/2026_09_01_003_strict_hrms_access_pending.sql';
$sql = file_get_contents($migrationPath);
if ($sql === false || trim($sql) === '') {
    fwrite(STDERR, "Strict HRMS access migration is unavailable.\n");
    exit(1);
}

if (!$conn->multi_query($sql)) {
    fwrite(STDERR, 'Strict HRMS access migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}
while (true) {
    if ($result = $conn->store_result()) $result->free();
    if ($conn->errno !== 0) {
        fwrite(STDERR, 'Strict HRMS access migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
    if (!$conn->more_results()) break;
    if (!$conn->next_result()) {
        fwrite(STDERR, 'Strict HRMS access migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
}

$permissionCheck = $conn->query(
    "SELECT COUNT(DISTINCT slug) total FROM permissions
        WHERE slug IN ('hrms_attendance_view','hrms_attendance_mark','hrms_biometric_manage') AND status = 1"
);
    if ((int) ($permissionCheck->fetch_assoc()['total'] ?? 0) !== 3) {
    fwrite(STDERR, "Attendance permission verification failed.\n");
    exit(1);
}

$menuCheck = $conn->query(
    "SELECT COUNT(*) total FROM menus
     WHERE route = 'index.php?page=attendance-management'
       AND permission_slug = 'hrms_attendance_view' AND status = 1 AND deleted_at IS NULL"
);
if ((int) ($menuCheck->fetch_assoc()['total'] ?? 0) !== 1) {
    fwrite(STDERR, "Attendance menu verification failed.\n");
    exit(1);
}

echo "Strict HRMS access migration applied and verified successfully.\n";