-- Additive support for multiple configured BMR/BPR documents per request.
-- Existing work items remain sequence 1 and retain their current status.

ALTER TABLE `bmr_bpr_requests`
    ADD COLUMN IF NOT EXISTS `bmr_form_count` INT UNSIGNED DEFAULT NULL AFTER `form_count`,
    ADD COLUMN IF NOT EXISTS `bpr_form_count` INT UNSIGNED DEFAULT NULL AFTER `bmr_form_count`;

ALTER TABLE `bmr_bpr_work_items`
    ADD COLUMN IF NOT EXISTS `form_sequence` INT UNSIGNED NOT NULL DEFAULT 1 AFTER `form_type`;

ALTER TABLE `bmr_bpr_work_items`
    MODIFY COLUMN `status` ENUM('QUEUED','PENDING','IN_PROCESS','COMPLETE')
        NOT NULL DEFAULT 'QUEUED';

CREATE UNIQUE INDEX IF NOT EXISTS `uq_bmr_bpr_work_item_sequence`
    ON `bmr_bpr_work_items` (`request_id`, `form_type`, `form_sequence`);

DROP INDEX IF EXISTS `uq_bmr_bpr_work_item_type` ON `bmr_bpr_work_items`;

CREATE INDEX IF NOT EXISTS `idx_bmr_bpr_work_item_request_status`
    ON `bmr_bpr_work_items` (`request_id`, `form_type`, `status`, `deleted_at`);
