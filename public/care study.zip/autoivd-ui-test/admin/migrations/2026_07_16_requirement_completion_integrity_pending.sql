CREATE INDEX `idx_stock_inwards_po_item`
    ON `stock_inwards` (`po_type`, `po_id`, `deleted_at`);

CREATE UNIQUE INDEX `uq_coa_rm_pm_number`
    ON `coa_rm_pm_table` (`coa_number`);

CREATE UNIQUE INDEX `uq_coa_inbound_stock_inward`
    ON `coa_inbound_queue` (`stock_inward_id`);

ALTER TABLE `purchase_order_final`
    ADD COLUMN `shipment_branch_id` INT(11) DEFAULT NULL AFTER `vendor_name_po`,
    ADD COLUMN `shipment_address_snapshot` TEXT DEFAULT NULL AFTER `shipment_branch_id`,
    ADD COLUMN `shipment_gst_snapshot` VARCHAR(100) DEFAULT NULL AFTER `shipment_address_snapshot`,
    ADD COLUMN `quantity_required_unit` INT(11) DEFAULT NULL AFTER `quantity_required`,
    ADD COLUMN `critical_item` INT(11) DEFAULT NULL AFTER `quantity_required_unit`,
    ADD COLUMN `expected_delivery_date` DATE DEFAULT NULL AFTER `critical_item`;

ALTER TABLE `purchase_order_raw`
    ADD COLUMN `shipment_branch_id` INT(11) DEFAULT NULL AFTER `vendor_name_po`,
    ADD COLUMN `shipment_address_snapshot` TEXT DEFAULT NULL AFTER `shipment_branch_id`,
    ADD COLUMN `shipment_gst_snapshot` VARCHAR(100) DEFAULT NULL AFTER `shipment_address_snapshot`,
    ADD COLUMN `quantity_required_unit` INT(11) DEFAULT NULL AFTER `shipment_gst_snapshot`,
    ADD COLUMN `critical_item` INT(11) DEFAULT NULL AFTER `quantity_required_unit`,
    ADD COLUMN `expected_delivery_date` DATE DEFAULT NULL AFTER `critical_item`;

CREATE INDEX `idx_purchase_order_final_shipment_branch`
    ON `purchase_order_final` (`shipment_branch_id`);

CREATE INDEX `idx_purchase_order_raw_shipment_branch`
    ON `purchase_order_raw` (`shipment_branch_id`);

UPDATE `product_categories`
SET `inventory_group` = 2
WHERE `id` IN (4, 16, 17) AND `inventory_group` = 1;

UPDATE `product_categories`
SET `inventory_group` = 4
WHERE `id` IN (6, 15) AND `inventory_group` = 1;

UPDATE `products`
SET `inventory_group` = 2
WHERE `category_id` IN (4, 16, 17) AND `inventory_group` = 1;

UPDATE `products`
SET `inventory_group` = 4
WHERE `category_id` IN (6, 15) AND `inventory_group` = 1;

ALTER TABLE `order_received`
    ADD COLUMN `external_reference` VARCHAR(191) DEFAULT NULL AFTER `source_type`;

CREATE UNIQUE INDEX `uq_order_received_source_reference`
    ON `order_received` (`source_type`, `external_reference`);
