-- ManuVerse QA/QC Version 6 workflow foundation.
-- This migration is additive: legacy records and legacy CRUD columns are preserved.

CREATE TABLE IF NOT EXISTS `bmr_bpr_requests` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `request_no` VARCHAR(191) DEFAULT NULL,
    `material_requisition_id` INT(11) NOT NULL,
    `production_plan_id` INT(11) DEFAULT NULL,
    `product_id` INT(11) DEFAULT NULL,
    `request_date` DATE NOT NULL,
    `product_name` VARCHAR(255) NOT NULL,
    `category_code` VARCHAR(100) DEFAULT NULL,
    `lot_number` VARCHAR(255) DEFAULT NULL,
    `production_batch_number` VARCHAR(191) DEFAULT NULL,
    `batch_size` DECIMAL(14,3) DEFAULT NULL,
    `batch_size_unit_id` INT(11) DEFAULT NULL,
    `pack_size` VARCHAR(191) DEFAULT NULL,
    `form_count` INT UNSIGNED NOT NULL DEFAULT 1,
    `remarks` TEXT DEFAULT NULL,
    `status` ENUM('UPCOMING','SUBMITTED','APPROVED','REJECTED') NOT NULL DEFAULT 'UPCOMING',
    `requested_by` INT(11) DEFAULT NULL,
    `requested_at` DATETIME DEFAULT NULL,
    `reviewed_by` INT(11) DEFAULT NULL,
    `reviewed_at` DATETIME DEFAULT NULL,
    `review_comments` TEXT DEFAULT NULL,
    `created_by` INT(11) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT(11) DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    `deleted_by` INT(11) DEFAULT NULL,
    `deleted_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_bmr_bpr_request_no` (`request_no`),
    UNIQUE KEY `uq_bmr_bpr_request_mr` (`material_requisition_id`),
    KEY `idx_bmr_bpr_request_status` (`status`, `deleted_at`),
    KEY `idx_bmr_bpr_request_plan` (`production_plan_id`),
    KEY `idx_bmr_bpr_request_product` (`product_id`),
    CONSTRAINT `fk_bmr_bpr_request_mr`
        FOREIGN KEY (`material_requisition_id`) REFERENCES `material_requisition` (`id`),
    CONSTRAINT `fk_bmr_bpr_request_plan`
        FOREIGN KEY (`production_plan_id`) REFERENCES `production_plans` (`id`),
    CONSTRAINT `fk_bmr_bpr_request_product`
        FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bmr_bpr_work_items` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `request_id` BIGINT UNSIGNED NOT NULL,
    `form_type` ENUM('BMR','BPR') NOT NULL,
    `status` ENUM('PENDING','IN_PROCESS','COMPLETE') NOT NULL DEFAULT 'PENDING',
    `template_id` BIGINT(20) DEFAULT NULL,
    `execution_id` BIGINT(20) DEFAULT NULL,
    `form_payload_json` LONGTEXT DEFAULT NULL,
    `started_by` INT(11) DEFAULT NULL,
    `started_at` DATETIME DEFAULT NULL,
    `completed_by` INT(11) DEFAULT NULL,
    `completed_at` DATETIME DEFAULT NULL,
    `created_by` INT(11) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT(11) DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    `deleted_by` INT(11) DEFAULT NULL,
    `deleted_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_bmr_bpr_work_item_type` (`request_id`, `form_type`),
    KEY `idx_bmr_bpr_work_item_queue` (`form_type`, `status`, `deleted_at`),
    CONSTRAINT `fk_bmr_bpr_work_item_request`
        FOREIGN KEY (`request_id`) REFERENCES `bmr_bpr_requests` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bmr_bpr_workflow_history` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `entity_type` VARCHAR(40) NOT NULL,
    `entity_id` BIGINT UNSIGNED NOT NULL,
    `action_name` VARCHAR(80) NOT NULL,
    `from_status` VARCHAR(40) DEFAULT NULL,
    `to_status` VARCHAR(40) DEFAULT NULL,
    `remarks` TEXT DEFAULT NULL,
    `payload_json` LONGTEXT DEFAULT NULL,
    `action_by` INT(11) DEFAULT NULL,
    `action_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_bmr_bpr_history_entity` (`entity_type`, `entity_id`, `action_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `ip_coa_generation`
    ADD COLUMN IF NOT EXISTS `source_bmr_work_item_id` BIGINT UNSIGNED DEFAULT NULL AFTER `id`,
    ADD COLUMN IF NOT EXISTS `product_id` INT(11) DEFAULT NULL AFTER `source_bmr_work_item_id`,
    ADD UNIQUE INDEX IF NOT EXISTS `uq_ip_coa_source_bmr` (`source_bmr_work_item_id`),
    ADD INDEX IF NOT EXISTS `idx_ip_coa_product` (`product_id`);

ALTER TABLE `fg_coa_generation`
    ADD COLUMN IF NOT EXISTS `source_ip_coa_id` INT(11) DEFAULT NULL AFTER `id`,
    ADD UNIQUE INDEX IF NOT EXISTS `uq_fg_coa_source_ip` (`source_ip_coa_id`);

ALTER TABLE `transfer_ticket`
    ADD COLUMN IF NOT EXISTS `source_fg_coa_id` INT(11) DEFAULT NULL AFTER `id`,
    ADD UNIQUE INDEX IF NOT EXISTS `uq_transfer_source_fg` (`source_fg_coa_id`);

INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`, `created_at`)
SELECT 'QA/QC BMR/BPR Form Request Manage', 'qa_qc_bmr_bpr_form_request_manage', 1, 1, NOW()
WHERE NOT EXISTS (
    SELECT 1 FROM `permissions` WHERE `slug` = 'qa_qc_bmr_bpr_form_request_manage'
);

INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`, `created_at`)
SELECT 'QA/QC BMR/BPR Issuance Review', 'qa_qc_bmr_bpr_issuance_review', 1, 1, NOW()
WHERE NOT EXISTS (
    SELECT 1 FROM `permissions` WHERE `slug` = 'qa_qc_bmr_bpr_issuance_review'
);

INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`, `created_at`)
SELECT 'Production BMR/BPR Manage', 'production_bmr_bpr_manage', 1, 1, NOW()
WHERE NOT EXISTS (
    SELECT 1 FROM `permissions` WHERE `slug` = 'production_bmr_bpr_manage'
);

-- New action permissions inherit the roles already allowed to view each page.
INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT DISTINCT rp.role_id, manage_permission.id, 1
FROM `role_permissions` rp
INNER JOIN `permissions` view_permission
    ON view_permission.id = rp.permission_id
   AND view_permission.slug = 'qa_qc_bmr_bpr_form_request_view'
INNER JOIN `permissions` manage_permission
    ON manage_permission.slug = 'qa_qc_bmr_bpr_form_request_manage'
WHERE rp.status = 1
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = rp.role_id
        AND existing.permission_id = manage_permission.id
  );

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT DISTINCT rp.role_id, review_permission.id, 1
FROM `role_permissions` rp
INNER JOIN `permissions` view_permission
    ON view_permission.id = rp.permission_id
   AND view_permission.slug = 'qa_qc_bmr_bpr_issuance_view'
INNER JOIN `permissions` review_permission
    ON review_permission.slug = 'qa_qc_bmr_bpr_issuance_review'
WHERE rp.status = 1
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = rp.role_id
        AND existing.permission_id = review_permission.id
  );

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT DISTINCT rp.role_id, manage_permission.id, 1
FROM `role_permissions` rp
INNER JOIN `permissions` view_permission
    ON view_permission.id = rp.permission_id
   AND view_permission.slug = 'production_bmr_bpr_view'
INNER JOIN `permissions` manage_permission
    ON manage_permission.slug = 'production_bmr_bpr_manage'
WHERE rp.status = 1
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = rp.role_id
        AND existing.permission_id = manage_permission.id
  );
