-- =============================================================================
-- Migration: 2026_09_04_004_whatsapp_processing_status_compatibility_pending.sql
-- Purpose: WhatsApp inbound log compatibility repair (adds 'received' status)
-- Standard: Idempotent, non-destructive
-- =============================================================================

SET @whatsapp_processing_status_is_enum := (
    SELECT COUNT(*)
    FROM `information_schema`.`COLUMNS`
    WHERE `TABLE_SCHEMA` = DATABASE()
      AND `TABLE_NAME` = 'whatsapp_order_log'
      AND `COLUMN_NAME` = 'processing_status'
      AND `DATA_TYPE` = 'enum'
);

SET @whatsapp_processing_status_has_received := (
    SELECT COUNT(*)
    FROM `information_schema`.`COLUMNS`
    WHERE `TABLE_SCHEMA` = DATABASE()
      AND `TABLE_NAME` = 'whatsapp_order_log'
      AND `COLUMN_NAME` = 'processing_status'
      AND `DATA_TYPE` = 'enum'
      AND FIND_IN_SET('received', REPLACE(REPLACE(SUBSTRING(`COLUMN_TYPE`, 6, CHAR_LENGTH(`COLUMN_TYPE`) - 6), '''', ''), ', ', ',')) > 0
);

SET @whatsapp_processing_status_alter_sql := IF(
    @whatsapp_processing_status_is_enum = 0 OR @whatsapp_processing_status_has_received = 1,
    'SELECT ''whatsapp_order_log.processing_status is already compatible'' AS migration_status',
    'ALTER TABLE `whatsapp_order_log` MODIFY COLUMN `processing_status` ENUM(''received'',''success'',''parse_error'',''validation_error'',''system_error'',''duplicate'') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''received'''
);

PREPARE whatsapp_processing_status_alter_stmt FROM @whatsapp_processing_status_alter_sql;
EXECUTE whatsapp_processing_status_alter_stmt;
DEALLOCATE PREPARE whatsapp_processing_status_alter_stmt;

-- Rows written while the value was being truncated carry '' and cannot be
-- distinguished from a real state; restore them to the intended 'received'.
SET @whatsapp_processing_status_repair_sql := IF(
    @whatsapp_processing_status_is_enum = 0,
    'SELECT ''no truncated rows to repair'' AS migration_status',
    'UPDATE `whatsapp_order_log` SET `processing_status` = ''received'' WHERE `processing_status` = '''''
);

PREPARE whatsapp_processing_status_repair_stmt FROM @whatsapp_processing_status_repair_sql;
EXECUTE whatsapp_processing_status_repair_stmt;
DEALLOCATE PREPARE whatsapp_processing_status_repair_stmt;

INSERT INTO `_schema_migrations_applied` (`migration`, `applied_at`)
SELECT '2026_09_04_004_whatsapp_processing_status_compatibility_pending.sql', NOW()
WHERE NOT EXISTS (
    SELECT 1
    FROM `_schema_migrations_applied`
    WHERE `migration` IN ('2026_09_04_004_whatsapp_processing_status_compatibility_pending.sql', '2026_09_04_004_whatsapp_processing_status_compatibility.sql')
);
