-- =============================================================================
-- Migration: 2026_09_04_002_hr_calendar_compatibility_pending.sql
-- Purpose: HR calendar & attendance classification enum compatibility + payroll revision FK
-- Standard: Idempotent, non-destructive
-- =============================================================================

SET @fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_payroll_run_calendar_revision'),
  'SELECT ''fk_payroll_run_calendar_revision already exists'' AS migration_status',
  'ALTER TABLE `payroll_runs` ADD CONSTRAINT `fk_payroll_run_calendar_revision` FOREIGN KEY (`calendar_revision_id`) REFERENCES `hr_annual_calendars` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE'
);
PREPARE fk_stmt FROM @fk_sql;
EXECUTE fk_stmt;
DEALLOCATE PREPARE fk_stmt;

ALTER TABLE `hr_annual_calendars`
    MODIFY COLUMN `saturday_policy`
    ENUM('all_working','all_off','2nd_4th_off','alternate_off','custom')
    NOT NULL DEFAULT 'all_working';

ALTER TABLE `hr_attendance_daily`
    MODIFY COLUMN `classification`
    ENUM('on_time','late','early_leave','half_day','full_day','absent','incomplete','holiday','weekly_off','off_day_work')
    NOT NULL DEFAULT 'incomplete';

INSERT INTO `_schema_migrations_applied` (`migration`, `applied_at`)
SELECT '2026_09_04_002_hr_calendar_compatibility_pending.sql', NOW()
WHERE NOT EXISTS (
    SELECT 1
    FROM `_schema_migrations_applied`
    WHERE `migration` IN ('2026_09_04_002_hr_calendar_compatibility_pending.sql', '2026_09_04_002_hr_calendar_compatibility.sql')
);
