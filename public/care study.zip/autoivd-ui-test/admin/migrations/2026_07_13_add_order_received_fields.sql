ALTER TABLE `order_received` ADD COLUMN `delivery_address` TEXT DEFAULT NULL AFTER `area_city`;
ALTER TABLE `production_plans` ADD COLUMN `order_id` INT DEFAULT NULL;
ALTER TABLE `purchase_order_raw` ADD COLUMN `order_id` INT DEFAULT NULL;
