-- =============================================================================
-- Sales & CRM Module – Schema Migration
-- Created: 2026-08-16
-- Description: Creates CRM lead management tables, salesperson masters,
--              and extends existing quotation/PI/order tables for CRM linkage.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. crm_leads – Central Lead Master Record (Section 2.1)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `crm_leads` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `lead_number` VARCHAR(50) NOT NULL,
  `company_name` VARCHAR(255) DEFAULT NULL,
  `contact_person` VARCHAR(255) DEFAULT NULL,
  `mobile_number` VARCHAR(20) DEFAULT NULL,
  `email` VARCHAR(255) DEFAULT NULL,
  `customer_type` ENUM('Distributor','Dealer','Hospital','Lab','Institution','Other') DEFAULT NULL,
  `source_type` VARCHAR(50) NOT NULL COMMENT 'quiz, whatsapp, generate_code, request_api, meeting, become_partner, manual',
  `source_reference_id` VARCHAR(191) DEFAULT NULL,
  `source_reference_table` VARCHAR(50) DEFAULT NULL COMMENT 'quiz_leads, whatsapp_order_log, meeting_requests, website source identifiers',
  `region` VARCHAR(100) DEFAULT NULL,
  `city` VARCHAR(100) DEFAULT NULL,
  `state` VARCHAR(100) DEFAULT NULL,
  `assigned_salesperson_id` INT UNSIGNED DEFAULT NULL,
  `sales_team` VARCHAR(100) DEFAULT NULL,
  `assignment_reason` VARCHAR(500) DEFAULT NULL,
  `lead_status` ENUM('New','Contacted','Qualified','Unqualified','Converted','Lost') NOT NULL DEFAULT 'New',
  `acceptance_status` ENUM('Pending','Accepted','Rejected') NOT NULL DEFAULT 'Pending',
  `priority` ENUM('Low','Medium','High') NOT NULL DEFAULT 'Medium',
  `last_activity_date` DATETIME DEFAULT NULL,
  `captured_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted_at` DATETIME DEFAULT NULL,
  `accepted_by` INT DEFAULT NULL,
  `rejected_at` DATETIME DEFAULT NULL,
  `rejected_by` INT DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `source_message_text` LONGTEXT DEFAULT NULL,
  `source_payload` LONGTEXT DEFAULT NULL,
  `created_by` INT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` INT DEFAULT NULL,
  `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_by` INT DEFAULT NULL,
  `deleted_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_lead_number` (`lead_number`),
  KEY `idx_lead_status` (`lead_status`, `deleted_at`),
  KEY `idx_lead_acceptance` (`acceptance_status`, `deleted_at`),
  KEY `idx_lead_salesperson` (`assigned_salesperson_id`),
  KEY `idx_lead_source` (`source_type`, `source_reference_id`),
  UNIQUE KEY `uq_lead_source_reference` (`source_reference_table`, `source_reference_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 2. crm_lead_products – Lead → Product interest mapping
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `crm_lead_products` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `lead_id` INT UNSIGNED NOT NULL,
  `product_id` INT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_lead_product` (`lead_id`, `product_id`),
  KEY `idx_lead_product_product` (`product_id`),
  CONSTRAINT `fk_lead_products_lead` FOREIGN KEY (`lead_id`) REFERENCES `crm_leads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 3. crm_lead_activity_log – Salesperson activity timeline per lead
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `crm_lead_activity_log` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `lead_id` INT UNSIGNED NOT NULL,
  `action` VARCHAR(80) NOT NULL,
  `details` TEXT DEFAULT NULL,
  `user_id` INT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lead_activity_lead` (`lead_id`, `created_at`),
  CONSTRAINT `fk_lead_activity_lead` FOREIGN KEY (`lead_id`) REFERENCES `crm_leads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 4. crm_lead_number_sequences – Auto-ID generation
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `crm_lead_number_sequences` (
  `sequence_date` DATE NOT NULL,
  `last_sequence` INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sequence_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 4B. crm_quote_number_sequences - collision-safe CRM quote numbers
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `crm_quote_number_sequences` (
  `sequence_date` DATE NOT NULL,
  `last_sequence` INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sequence_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 5. salesperson_masters – Salesperson Master (Section 3)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `salesperson_masters` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT DEFAULT NULL,
  `employee_id` INT DEFAULT NULL,
  `salesperson_name` VARCHAR(255) NOT NULL,
  `salesperson_code` VARCHAR(50) DEFAULT NULL,
  `email` VARCHAR(255) DEFAULT NULL,
  `mobile` VARCHAR(20) DEFAULT NULL,
  `sales_team` VARCHAR(100) DEFAULT NULL,
  `assignment_priority` INT UNSIGNED NOT NULL DEFAULT 100 COMMENT 'Lower value wins assignment ties',
  `status` TINYINT NOT NULL DEFAULT 1,
  `created_by` INT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` INT DEFAULT NULL,
  `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_salesperson_user` (`user_id`),
  KEY `idx_salesperson_employee` (`employee_id`),
  KEY `idx_salesperson_status` (`status`, `deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 6. salesperson_territories – Salesperson → Territory mapping (Section 3.1)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `salesperson_territories` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `salesperson_id` INT UNSIGNED NOT NULL,
  `territory_name` VARCHAR(100) NOT NULL,
  `territory_type` ENUM('State','City','Region') NOT NULL DEFAULT 'City',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_salesperson_territory_lookup` (`territory_type`, `territory_name`),
  UNIQUE KEY `uq_salesperson_territory` (`salesperson_id`, `territory_type`, `territory_name`),
  CONSTRAINT `fk_territory_salesperson` FOREIGN KEY (`salesperson_id`) REFERENCES `salesperson_masters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 7. salesperson_product_expertise – Salesperson → Product expertise (Section 3.2)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `salesperson_product_expertise` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `salesperson_id` INT UNSIGNED NOT NULL,
  `category_name` VARCHAR(150) DEFAULT NULL,
  `product_id` INT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_salesperson_expertise` (`salesperson_id`),
  UNIQUE KEY `uq_salesperson_product_expertise` (`salesperson_id`, `product_id`),
  CONSTRAINT `fk_expertise_salesperson` FOREIGN KEY (`salesperson_id`) REFERENCES `salesperson_masters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_expertise_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ===========================================================================
-- ALTERATIONS ON EXISTING TABLES
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- A. quotation_requests – Add CRM support (reuse for CRM quotes)
-- ---------------------------------------------------------------------------
-- Step 1: Make website_quotation_id nullable so CRM-created quotes don't need it
ALTER TABLE `quotation_requests`
  MODIFY COLUMN `website_quotation_id` BIGINT(20) UNSIGNED DEFAULT NULL;

-- Step 2: Add new CRM columns
ALTER TABLE `quotation_requests`
  ADD COLUMN IF NOT EXISTS `source_origin` VARCHAR(20) NOT NULL DEFAULT 'website',
  ADD COLUMN IF NOT EXISTS `lead_id` INT UNSIGNED DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `assigned_salesperson_id` INT UNSIGNED DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `valid_until` DATE DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `payment_terms` VARCHAR(100) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `deleted_by` INT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `deleted_at` DATETIME DEFAULT NULL;

-- Step 3: Add indexes for CRM queries
ALTER TABLE `quotation_requests`
  ADD KEY IF NOT EXISTS `idx_quotation_source_origin` (`source_origin`, `status`),
  ADD KEY IF NOT EXISTS `idx_quotation_lead` (`lead_id`),
  ADD KEY IF NOT EXISTS `idx_quotation_deleted` (`deleted_at`);

SET @crm_fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_quotation_crm_lead'),
  'SELECT 1',
  'ALTER TABLE `quotation_requests` ADD CONSTRAINT `fk_quotation_crm_lead` FOREIGN KEY (`lead_id`) REFERENCES `crm_leads` (`id`) ON DELETE SET NULL'
);
PREPARE crm_fk_stmt FROM @crm_fk_sql;
EXECUTE crm_fk_stmt;
DEALLOCATE PREPARE crm_fk_stmt;

SET @crm_fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_quotation_salesperson'),
  'SELECT 1',
  'ALTER TABLE `quotation_requests` ADD CONSTRAINT `fk_quotation_salesperson` FOREIGN KEY (`assigned_salesperson_id`) REFERENCES `salesperson_masters` (`id`) ON DELETE SET NULL'
);
PREPARE crm_fk_stmt FROM @crm_fk_sql;
EXECUTE crm_fk_stmt;
DEALLOCATE PREPARE crm_fk_stmt;

-- ---------------------------------------------------------------------------
-- B. proforma_invoices – Add lead and quote linkage
-- ---------------------------------------------------------------------------
ALTER TABLE `proforma_invoices`
  ADD COLUMN IF NOT EXISTS `lead_id` INT UNSIGNED DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `quote_request_id` BIGINT(20) UNSIGNED DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `crm_conversion_status` ENUM('Draft','Confirmed','Converted') NOT NULL DEFAULT 'Draft',
  ADD COLUMN IF NOT EXISTS `confirmed_at` DATETIME DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `confirmed_by` INT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `converted_order_id` INT DEFAULT NULL;

ALTER TABLE `proforma_invoices`
  ADD KEY IF NOT EXISTS `idx_pi_lead` (`lead_id`),
  ADD KEY IF NOT EXISTS `idx_pi_quote` (`quote_request_id`);

SET @crm_fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_pi_crm_lead'),
  'SELECT 1',
  'ALTER TABLE `proforma_invoices` ADD CONSTRAINT `fk_pi_crm_lead` FOREIGN KEY (`lead_id`) REFERENCES `crm_leads` (`id`) ON DELETE SET NULL'
);
PREPARE crm_fk_stmt FROM @crm_fk_sql;
EXECUTE crm_fk_stmt;
DEALLOCATE PREPARE crm_fk_stmt;

SET @crm_fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_pi_crm_quote'),
  'SELECT 1',
  'ALTER TABLE `proforma_invoices` ADD CONSTRAINT `fk_pi_crm_quote` FOREIGN KEY (`quote_request_id`) REFERENCES `quotation_requests` (`id`) ON DELETE SET NULL'
);
PREPARE crm_fk_stmt FROM @crm_fk_sql;
EXECUTE crm_fk_stmt;
DEALLOCATE PREPARE crm_fk_stmt;

-- ---------------------------------------------------------------------------
-- C. order_received – Add lead linkage
-- ---------------------------------------------------------------------------
ALTER TABLE `order_received`
  ADD COLUMN IF NOT EXISTS `proforma_source` tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `proforma_invoice_id` bigint(20) UNSIGNED DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `lead_id` INT UNSIGNED DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `quotation_request_id` BIGINT(20) UNSIGNED DEFAULT NULL;

ALTER TABLE `order_received`
  ADD KEY IF NOT EXISTS `idx_order_lead` (`lead_id`),
  ADD KEY IF NOT EXISTS `idx_order_quote` (`quotation_request_id`),
  ADD UNIQUE KEY IF NOT EXISTS `uq_order_proforma_source` (`proforma_source`, `proforma_invoice_id`);

SET @crm_fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_order_crm_lead'),
  'SELECT 1',
  'ALTER TABLE `order_received` ADD CONSTRAINT `fk_order_crm_lead` FOREIGN KEY (`lead_id`) REFERENCES `crm_leads` (`id`) ON DELETE SET NULL'
);
PREPARE crm_fk_stmt FROM @crm_fk_sql;
EXECUTE crm_fk_stmt;
DEALLOCATE PREPARE crm_fk_stmt;

SET @crm_fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_order_crm_quote'),
  'SELECT 1',
  'ALTER TABLE `order_received` ADD CONSTRAINT `fk_order_crm_quote` FOREIGN KEY (`quotation_request_id`) REFERENCES `quotation_requests` (`id`) ON DELETE SET NULL'
);
PREPARE crm_fk_stmt FROM @crm_fk_sql;
EXECUTE crm_fk_stmt;
DEALLOCATE PREPARE crm_fk_stmt;

-- ---------------------------------------------------------------------------
-- D. whatsapp_order_log - preserve the complete webhook payload and type
-- ---------------------------------------------------------------------------
ALTER TABLE `whatsapp_order_log`
  ADD COLUMN IF NOT EXISTS `message_type` VARCHAR(50) DEFAULT NULL AFTER `from_name`,
  ADD COLUMN IF NOT EXISTS `raw_payload` LONGTEXT DEFAULT NULL AFTER `raw_message`;
