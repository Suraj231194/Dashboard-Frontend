-- =============================================================================
-- Migration: 2026_09_04_003_order_proforma_source_compatibility_pending.sql
-- Purpose: Convert legacy numeric source column to string definition
-- Standard: Idempotent, non-destructive
-- =============================================================================

SET @order_proforma_source_is_compatible := (
    SELECT COUNT(*)
    FROM `information_schema`.`COLUMNS`
    WHERE `TABLE_SCHEMA` = DATABASE()
      AND `TABLE_NAME` = 'order_received'
      AND `COLUMN_NAME` = 'proforma_source'
      AND `DATA_TYPE` = 'varchar'
      AND `CHARACTER_MAXIMUM_LENGTH` = 20
      AND `IS_NULLABLE` = 'YES'
      AND (`COLUMN_DEFAULT` IS NULL OR UPPER(`COLUMN_DEFAULT`) = 'NULL')
      AND `CHARACTER_SET_NAME` = 'utf8mb4'
      AND `COLLATION_NAME` = 'utf8mb4_unicode_ci'
);

SET @order_proforma_source_alter_sql := IF(
    @order_proforma_source_is_compatible = 1,
    'SELECT ''order_received.proforma_source is already compatible'' AS migration_status',
    'ALTER TABLE `order_received` MODIFY COLUMN `proforma_source` VARCHAR(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL'
);

PREPARE order_proforma_source_alter_stmt FROM @order_proforma_source_alter_sql;
EXECUTE order_proforma_source_alter_stmt;
DEALLOCATE PREPARE order_proforma_source_alter_stmt;

INSERT INTO `_schema_migrations_applied` (`migration`, `applied_at`)
SELECT '2026_09_04_003_order_proforma_source_compatibility_pending.sql', NOW()
WHERE NOT EXISTS (
    SELECT 1
    FROM `_schema_migrations_applied`
    WHERE `migration` IN ('2026_09_04_003_order_proforma_source_compatibility_pending.sql', '2026_09_04_003_order_proforma_source_compatibility.sql')
);
