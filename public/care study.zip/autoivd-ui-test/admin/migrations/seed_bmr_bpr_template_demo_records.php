<?php

declare(strict_types=1);

/**
 * Creates one BMR and one BPR widget record for each of the five common
 * Hematology template profiles. The seed is additive and idempotent; existing
 * production and workflow records are untouched.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/../workflow/bmr_bpr_common.php';

$records = [
    ['product_id' => 1071, 'batch_size' => 800, 'unit_id' => 4, 'pack_size' => '20 ltr'],
    ['product_id' => 1067, 'batch_size' => 10, 'unit_id' => 4, 'pack_size' => '100 ml'],
    ['product_id' => 1064, 'batch_size' => 100, 'unit_id' => 4, 'pack_size' => '500 ml'],
    ['product_id' => 1055, 'batch_size' => 10, 'unit_id' => 4, 'pack_size' => '50 ml'],
    ['product_id' => 1053, 'batch_size' => 800, 'unit_id' => 4, 'pack_size' => '20 ltr'],
];

$seedUserId = 1;
$seedDate = date('Y-m-d');
$fiscalYear = bmrBprFiscalYearLabel($seedDate);
$lockName = 'common_hematology_bmr_bpr_widget_seed_v1';
$lockStmt = $conn->prepare('SELECT GET_LOCK(?, 15) AS acquired');
$lockStmt->bind_param('s', $lockName);
$lockStmt->execute();
$lockAcquired = (int) ($lockStmt->get_result()->fetch_assoc()['acquired'] ?? 0) === 1;
$lockStmt->close();
if (!$lockAcquired) {
    fwrite(STDERR, "Unable to acquire the template-demo seed lock.\n");
    exit(1);
}

try {
    $conn->begin_transaction();

    $maxSequenceStmt = $conn->prepare(
        "SELECT COALESCE(MAX(CAST(RIGHT(document_batch_no, 6) AS UNSIGNED)), 0) AS max_sequence
         FROM production_plans
         WHERE document_batch_no LIKE ?
           AND deleted_at IS NULL"
    );
    $batchPrefixLike = 'BIO/PROD/FY' . $fiscalYear . '/%';
    $maxSequenceStmt->bind_param('s', $batchPrefixLike);
    $maxSequenceStmt->execute();
    $nextSequence = (int) ($maxSequenceStmt->get_result()->fetch_assoc()['max_sequence'] ?? 0) + 1;
    $maxSequenceStmt->close();

    $findProduct = $conn->prepare(
        "SELECT id, product_name, COALESCE(product_code, '') AS product_code
         FROM products
         WHERE id = ? AND status != 3 AND deleted_at IS NULL
         LIMIT 1"
    );
    $findExistingMr = $conn->prepare(
        "SELECT id, prod_plan_id, lot_batch_no
         FROM material_requisition
         WHERE slip_no = ? AND deleted_at IS NULL
         LIMIT 1
         FOR UPDATE"
    );
    $insertPlan = $conn->prepare(
        "INSERT INTO production_plans
            (date, name, lo_batch_no, document_batch_no, batch_size, batch_size_unit, timeline, status,
             prodplan_remark, is_locked, bom_master_id, product_id, created_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 1, 0,
                 'Common Hematology BMR/BPR widget acceptance record.', 0, 0, ?, ?, NOW())"
    );
    $insertMr = $conn->prepare(
        "INSERT INTO material_requisition
            (mr_raw, mr_packing, mr_consumable, date, product_name, lot_batch_no,
             batch_size, batch_size_unit, slip_no, department, requested_by,
             status, auto_generated_batch, prod_plan_id, bom_master_id, created_by, created_at)
         VALUES (1, 1, 1, ?, ?, ?, ?, ?, ?, 1, 'Template Acceptance',
                 0, ?, ?, 0, ?, NOW())"
    );
    $findRequest = $conn->prepare(
        "SELECT id
         FROM bmr_bpr_requests
         WHERE material_requisition_id = ? AND deleted_at IS NULL
         LIMIT 1
         FOR UPDATE"
    );
    $insertRequest = $conn->prepare(
        "INSERT INTO bmr_bpr_requests
            (material_requisition_id, production_plan_id, product_id, request_date,
             product_name, category_code, lot_number, production_batch_number,
             batch_size, batch_size_unit_id, pack_size, form_count, bmr_form_count,
             bpr_form_count, remarks, status, requested_by, requested_at,
             reviewed_by, reviewed_at, review_comments, created_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, 1,
                 'Common Hematology template widget acceptance record.', 'APPROVED',
                 ?, NOW(), ?, NOW(), 'Approved for common-template visual acceptance testing.',
                 ?, NOW())"
    );
    $updateRequestNumber = $conn->prepare(
        'UPDATE bmr_bpr_requests SET request_no = ? WHERE id = ?'
    );
    $updateWidgetStatuses = $conn->prepare(
        "UPDATE bmr_bpr_work_items
         SET status = CASE WHEN form_type = 'BMR' THEN 'IN_PROCESS' ELSE 'PENDING' END,
             started_by = CASE WHEN form_type = 'BMR' THEN ? ELSE started_by END,
             started_at = CASE WHEN form_type = 'BMR' THEN COALESCE(started_at, NOW()) ELSE started_at END,
             updated_by = ?,
             updated_at = NOW()
         WHERE request_id = ?
           AND deleted_at IS NULL
           AND form_payload_json IS NULL
           AND status IN ('QUEUED', 'PENDING', 'IN_PROCESS')"
    );
    if (
        !$findProduct || !$findExistingMr || !$insertPlan || !$insertMr
        || !$findRequest || !$insertRequest || !$updateRequestNumber || !$updateWidgetStatuses
    ) {
        throw new RuntimeException('Unable to prepare the template-demo workflow insert.');
    }

    $created = [];
    foreach ($records as $definition) {
        $productId = (int) $definition['product_id'];
        $batchSize = (float) $definition['batch_size'];
        $unitId = (int) $definition['unit_id'];
        $packSize = (string) $definition['pack_size'];
        $seedKey = 'BMR-COMMON-HEMATOLOGY-DEMO-' . $productId;

        $findProduct->bind_param('i', $productId);
        $findProduct->execute();
        $product = $findProduct->get_result()->fetch_assoc();
        if (!$product) {
            throw new RuntimeException("Mapped product {$productId} is unavailable.");
        }
        $productName = trim((string) $product['product_name']);
        $productCode = trim((string) $product['product_code']);

        $findExistingMr->bind_param('s', $seedKey);
        $findExistingMr->execute();
        $existingMr = $findExistingMr->get_result()->fetch_assoc();
        if ($existingMr) {
            $materialRequisitionId = (int) $existingMr['id'];
            $productionPlanId = (int) $existingMr['prod_plan_id'];
            $batchNumber = (string) $existingMr['lot_batch_no'];
        } else {
            $sequence = $nextSequence++;
            $batchNumber = 'BIO/PROD/FY' . $fiscalYear . '/' . str_pad(
                (string) $sequence,
                6,
                '0',
                STR_PAD_LEFT
            );
            $insertPlan->bind_param(
                'ssssdiii',
                $seedDate,
                $productName,
                $batchNumber,
                $batchNumber,
                $batchSize,
                $unitId,
                $productId,
                $seedUserId
            );
            if (!$insertPlan->execute()) {
                throw new RuntimeException(
                    "Unable to create the Production Plan for {$productName}: {$insertPlan->error}"
                );
            }
            $productionPlanId = (int) $conn->insert_id;
            $autoBatch = 'BIPL-MR-' . date('d-m-Y') . '-' . $sequence;
            $insertMr->bind_param(
                'sssdissii',
                $seedDate,
                $productName,
                $batchNumber,
                $batchSize,
                $unitId,
                $seedKey,
                $autoBatch,
                $productionPlanId,
                $seedUserId
            );
            if (!$insertMr->execute()) {
                throw new RuntimeException(
                    "Unable to create the Material Requisition for {$productName}: {$insertMr->error}"
                );
            }
            $materialRequisitionId = (int) $conn->insert_id;
        }

        $findRequest->bind_param('i', $materialRequisitionId);
        $findRequest->execute();
        $existingRequest = $findRequest->get_result()->fetch_assoc();
        if ($existingRequest) {
            $requestId = (int) $existingRequest['id'];
        } else {
            $insertRequest->bind_param(
                'iiisssssdisiii',
                $materialRequisitionId,
                $productionPlanId,
                $productId,
                $seedDate,
                $productName,
                $productCode,
                $batchNumber,
                $batchNumber,
                $batchSize,
                $unitId,
                $packSize,
                $seedUserId,
                $seedUserId,
                $seedUserId
            );
            if (!$insertRequest->execute()) {
                throw new RuntimeException(
                    "Unable to create the BMR/BPR request for {$productName}: {$insertRequest->error}"
                );
            }
            $requestId = (int) $conn->insert_id;
            $requestNumber = bmrBprRequestNumber($requestId, $seedDate);
            $updateRequestNumber->bind_param('si', $requestNumber, $requestId);
            if (!$updateRequestNumber->execute()) {
                throw new RuntimeException("Unable to number the request for {$productName}.");
            }
            bmrBprInsertHistory(
                $conn,
                'REQUEST',
                $requestId,
                'COMMON_TEMPLATE_WIDGET_RECORD_CREATED',
                null,
                'APPROVED',
                'Created for common Hematology template widget acceptance testing.',
                [
                    'product_id' => $productId,
                    'material_requisition_id' => $materialRequisitionId,
                    'production_plan_id' => $productionPlanId,
                ],
                $seedUserId
            );
        }

        bmrBprEnsureConfiguredWorkItems($conn, $requestId, 1, 1, $seedUserId);
        $updateWidgetStatuses->bind_param('iii', $seedUserId, $seedUserId, $requestId);
        if (!$updateWidgetStatuses->execute()) {
            throw new RuntimeException(
                "Unable to make the BMR/BPR widget records openable for {$productName}."
            );
        }

        $verify = $conn->prepare(
            "SELECT wi.id, wi.form_type, wi.status, template.template_code
             FROM bmr_bpr_work_items wi
             INNER JOIN bmr_templates template
                ON template.id = wi.template_id
               AND template.form_type = wi.form_type
               AND template.status = 1
               AND template.deleted_at IS NULL
             WHERE wi.request_id = ? AND wi.deleted_at IS NULL
             ORDER BY wi.form_type"
        );
        $verify->bind_param('i', $requestId);
        $verify->execute();
        $workItems = $verify->get_result()->fetch_all(MYSQLI_ASSOC);
        $verify->close();
        if (count($workItems) !== 2) {
            throw new RuntimeException("The mapped BMR/BPR work items were not created for {$productName}.");
        }
        $workItemsByType = array_column($workItems, null, 'form_type');
        if (
            ($workItemsByType['BMR']['template_code'] ?? '') !== 'COMMON_HEMATOLOGY_BMR_V03'
            || ($workItemsByType['BPR']['template_code'] ?? '') !== 'COMMON_HEMATOLOGY_BPR_V03'
            || ($workItemsByType['BMR']['status'] ?? '') !== 'IN_PROCESS'
            || ($workItemsByType['BPR']['status'] ?? '') !== 'PENDING'
        ) {
            throw new RuntimeException("The common BMR/BPR widget mapping is invalid for {$productName}.");
        }

        $created[] = [
            'request_id' => $requestId,
            'product_id' => $productId,
            'product_name' => $productName,
            'batch_number' => $batchNumber,
            'work_items' => array_map(
                static fn(array $item): string => implode(':', [
                    $item['id'],
                    $item['form_type'],
                    $item['status'],
                    $item['template_code'],
                ]),
                $workItems
            ),
        ];
    }

    $findProduct->close();
    $findExistingMr->close();
    $insertPlan->close();
    $insertMr->close();
    $findRequest->close();
    $insertRequest->close();
    $updateRequestNumber->close();
    $updateWidgetStatuses->close();

    $conn->commit();
    foreach ($created as $row) {
        echo implode(' | ', [
            $row['request_id'],
            $row['product_id'],
            $row['product_name'],
            $row['batch_number'],
            implode(', ', $row['work_items']),
        ]) . PHP_EOL;
    }
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
} finally {
    $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
    if ($releaseStmt) {
        $releaseStmt->bind_param('s', $lockName);
        $releaseStmt->execute();
        $releaseStmt->close();
    }
}
