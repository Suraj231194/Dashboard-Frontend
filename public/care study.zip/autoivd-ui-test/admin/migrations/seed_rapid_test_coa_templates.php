<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/catalog_seeder.php';
require_once dirname(__DIR__) . '/workflow/coa_templates/rapid_test/profiles.php';

try {
    $result = coaSeedTemplateCatalog($conn, [
        'catalog' => coaRapidTestProfiles(),
        'product_ids' => coaRapidTestMappedProductIds(),
        'renderer_variant' => 'rapid_test',
        'source_directory' => 'Rapid Test',
        'lock_name' => 'common_rapid_test_ip_fg_coa_v1',
        'page_count' => 3,
        'document' => [
            'title' => 'CERTIFICATE OF ANALYSIS',
            'document_no' => 'BIPL-F-COA-01',
            'issue_no' => '01',
            'revision_no' => '02',
            'effective_date' => '03/04/2025',
            'review_date' => '02/04/2028',
            'department' => 'Quality Control',
            'supersedes' => 'Nil',
            'company_address' => 'B19/A S.I.L. Ancillary Estate, Amausi Industrial Area, Nadarganj-226008 (Lucknow)',
        ],
        'effective_date_sql' => '2025-04-03',
        'review_date_sql' => '2028-04-02',
        'definitions' => [
            [
                'coa_type' => 'IP',
                'template_code' => 'COMMON_RAPID_TEST_IP_COA_V01',
                'template_name' => 'Common Rapid Test IP COA',
            ],
            [
                'coa_type' => 'FG',
                'template_code' => 'COMMON_RAPID_TEST_FG_COA_V01',
                'template_name' => 'Common Rapid Test FG COA',
            ],
        ],
    ]);
    echo "Installed {$result['templates']} Rapid Test COA templates and "
        . "{$result['mappings']} product mappings.\n";
} catch (Throwable $exception) {
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
}
