<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$migrationPath = __DIR__ . '/2026_09_01_001_careio_pdf_completion_pending.sql';
$sql = file_get_contents($migrationPath);
if ($sql === false || trim($sql) === '') {
    fwrite(STDERR, "Care IO completion migration is unavailable.\n");
    exit(1);
}

if (!$conn->multi_query($sql)) {
    fwrite(STDERR, 'Care IO completion migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}
while (true) {
    if ($result = $conn->store_result()) $result->free();
    if ($conn->errno !== 0) {
        fwrite(STDERR, 'Care IO completion migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
    if (!$conn->more_results()) break;
    if (!$conn->next_result()) {
        fwrite(STDERR, 'Care IO completion migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
}

$requiredTables = ['hr_biometric_ingest_batches', 'hr_attendance_manual_marks'];
$tableCheck = $conn->prepare('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?');
foreach ($requiredTables as $tableName) {
    $tableCheck->bind_param('s', $tableName);
    $tableCheck->execute();
    $tableCheck->bind_result($count);
    $tableCheck->fetch();
    $tableCheck->free_result();
    if ((int) $count !== 1) {
        fwrite(STDERR, "Completion schema verification failed for {$tableName}.\n");
        exit(1);
    }
}
$tableCheck->close();

$requiredColumns = [
    'hr_biometric_devices' => 'ingest_token_hash',
    'hr_employee_profiles' => 'middle_name',
];
foreach ($requiredColumns as $tableName => $columnName) {
    $columnCheck = $conn->query("SHOW COLUMNS FROM `{$tableName}` LIKE '{$columnName}'");
    if (!$columnCheck || $columnCheck->num_rows !== 1) {
        fwrite(STDERR, "Completion column verification failed for {$tableName}.{$columnName}.\n");
        exit(1);
    }
}

$permissionCheck = $conn->query(
    "SELECT COUNT(DISTINCT slug) total FROM permissions
     WHERE slug IN ('hrms_leave_view','hrms_offboarding_view','hrms_biometric_manage')"
);
if ((int) ($permissionCheck->fetch_assoc()['total'] ?? 0) !== 3) {
    fwrite(STDERR, "Completion permission verification failed.\n");
    exit(1);
}

$menuCheck = $conn->query(
    "SELECT COUNT(DISTINCT route) total FROM menus
     WHERE route IN ('index.php?page=employee-master','index.php?page=leave-management',
       'index.php?page=offboarding','index.php?page=attendance-management','index.php?page=shift-management')
       AND deleted_at IS NULL AND status = 1"
);
if ((int) ($menuCheck->fetch_assoc()['total'] ?? 0) !== 5) {
    fwrite(STDERR, "Completion HRMS menu verification failed.\n");
    exit(1);
}

echo "Care IO PDF completion migration applied and verified successfully.\n";