-- Unified product-level inventory.
-- Run with run_unified_live_stock.php so existing rows and references are
-- consolidated before the final unique key is installed.

ALTER TABLE live_stock
    ADD COLUMN reserved_qty DECIMAL(20,8) NOT NULL DEFAULT 0.00000000 AFTER quantity_available;

UPDATE live_stock
SET reserved_qty = LEAST(
    GREATEST(COALESCE(reserved_qty, 0), 0),
    GREATEST(quantity_available, 0)
);

ALTER TABLE live_stock
    ADD COLUMN unreserved_qty DECIMAL(20,8)
        GENERATED ALWAYS AS (quantity_available - reserved_qty) STORED
        AFTER reserved_qty;

ALTER TABLE live_stock
    DROP COLUMN qauntity_initial_unit;

ALTER TABLE order_stock_reservations
    ADD COLUMN quantity DECIMAL(20,8) NOT NULL DEFAULT 0.00000000 AFTER live_stock_id,
    ADD COLUMN closed_reason VARCHAR(30) DEFAULT NULL AFTER status,
    ADD COLUMN deleted_by INT(11) DEFAULT NULL AFTER updated_at,
    ADD COLUMN deleted_at DATETIME DEFAULT NULL AFTER deleted_by;

ALTER TABLE order_received_items
    ADD COLUMN fulfilled_quantity DECIMAL(20,8) NOT NULL DEFAULT 0.00000000 AFTER quantity,
    ADD COLUMN reserved_quantity DECIMAL(20,8) NOT NULL DEFAULT 0.00000000 AFTER fulfilled_quantity,
    ADD COLUMN shortfall_quantity DECIMAL(20,8) NOT NULL DEFAULT 0.00000000 AFTER reserved_quantity;

CREATE TABLE inventory_movements (
    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    product_id INT(11) NOT NULL,
    live_stock_id INT(11) NOT NULL,
    movement_type VARCHAR(40) NOT NULL,
    quantity DECIMAL(20,8) NOT NULL,
    quantity_available_after DECIMAL(20,8) NOT NULL,
    reserved_qty_after DECIMAL(20,8) NOT NULL,
    source_type VARCHAR(50) DEFAULT NULL,
    source_id BIGINT(20) DEFAULT NULL,
    reference_key VARCHAR(191) DEFAULT NULL,
    notes VARCHAR(500) DEFAULT NULL,
    created_by INT(11) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_inventory_movement_reference (reference_key),
    KEY idx_inventory_movement_product (product_id, created_at),
    KEY idx_inventory_movement_source (source_type, source_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE live_stock_refactor_archive (
    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    legacy_live_stock_id INT(11) NOT NULL,
    product_id INT(11) NOT NULL,
    snapshot_json LONGTEXT NOT NULL,
    archive_reason VARCHAR(100) NOT NULL,
    archived_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_live_stock_archive_legacy (legacy_live_stock_id),
    KEY idx_live_stock_archive_product (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TRIGGER IF EXISTS trg_live_stock_sync_pending_bu;
CREATE TRIGGER trg_live_stock_sync_pending_bu
BEFORE UPDATE ON live_stock
FOR EACH ROW
SET NEW.sync_pending = IF(
    COALESCE(@manuverse_sync_origin, 'erp') <> 'website'
    AND (
        NOT (NEW.quantity_available <=> OLD.quantity_available)
        OR NOT (NEW.reserved_qty <=> OLD.reserved_qty)
        OR NOT (NEW.status <=> OLD.status)
        OR NOT (NEW.deleted_at <=> OLD.deleted_at)
    ),
    1,
    NEW.sync_pending
);
