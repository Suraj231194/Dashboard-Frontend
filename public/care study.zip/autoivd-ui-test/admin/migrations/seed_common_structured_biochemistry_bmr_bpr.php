<?php

declare(strict_types=1);

/**
 * Installs the audited, PDF/image-free Biochemistry BMR/BPR templates.
 *
 * Every logical source document is mapped by document_sequence. Product pack
 * variants share the matching source profile; raw reagent, calibrator,
 * standard, control and bulk-component catalog records are not mapped.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/workflow/bmr_bpr_biochemistry_profiles.php';

$families = bmrBprBiochemistryCatalog();
$approvedProductIds = bmrBprBiochemistryApprovedProductIds();
$approvedProductSql = implode(',', $approvedProductIds);
$document = [
    'document_no' => 'BIPL-BMR-01',
    'issue_no' => '01',
    'revision_no' => '02',
    'effective_date' => '03/04/2025',
    'license_no' => 'MFG/IVD/2020/000082',
    'department' => 'Production',
    'company_name' => 'BIOGENIX INC. PVT. LTD.',
    'company_address' => "B19/A S.I.L. Ancillary Estate,\nAmausi Industrial Area, Nadarganj-\n226008 (Lucknow)",
    'title' => 'BATCH MANUFACTURING RECORD',
];
$editablePrefixes = [
    'BMR' => ['cover.', 'attachments.', 'rm.', 'manufacturing.', 'completion.', 'qa.'],
    'BPR' => ['cover.', 'attachments.', 'dispensing.', 'washing.', 'filling.', 'coding.', 'labeling.', 'packing.', 'transfer.', 'yield.', 'qa.'],
];

$definitions = [];
foreach (['BMR' => 'bmr_documents', 'BPR' => 'bpr_documents'] as $formType => $documentKey) {
    $maxDocuments = 0;
    foreach ($families as $family) {
        $maxDocuments = max($maxDocuments, count($family[$documentKey] ?? []));
    }
    for ($sequence = 1; $sequence <= $maxDocuments; $sequence++) {
        $profiles = [];
        $pageCount = 0;
        foreach ($families as $family) {
            $profile = $family[$documentKey][$sequence - 1] ?? null;
            if (!is_array($profile)) {
                continue;
            }
            $pageCount = max($pageCount, (int) ($profile['page_count'] ?? 0));
            foreach ($family['product_ids'] as $productId) {
                $profiles[(string) (int) $productId] = $profile;
            }
        }
        if ($profiles === []) {
            continue;
        }
        ksort($profiles, SORT_NUMERIC);
        $layoutDocument = $document;
        if ($formType === 'BPR') {
            $layoutDocument['document_no'] = 'BIPL-BPR-01';
            $layoutDocument['title'] = 'BATCH PACKING RECORD';
        }
        $suffix = str_pad((string) $sequence, 2, '0', STR_PAD_LEFT);
        $definitions[] = [
            'form_type' => $formType,
            'sequence' => $sequence,
            'template_code' => "COMMON_BIOCHEMISTRY_{$formType}_{$suffix}_V03",
            'template_name' => "Common Biochemistry {$formType} #{$sequence}",
            'page_count' => $pageCount,
            'layout' => [
                'schema_version' => 2,
                'renderer' => 'structured_html',
                'renderer_variant' => 'biochemistry',
                'form_type' => $formType,
                'document' => $layoutDocument,
                'editable_prefixes' => $editablePrefixes[$formType],
                'profiles' => $profiles,
            ],
        ];
    }
}

$lockName = 'common_structured_biochemistry_bmr_bpr_v3';
$lockStmt = $conn->prepare('SELECT GET_LOCK(?, 15) AS acquired');
$lockStmt->bind_param('s', $lockName);
$lockStmt->execute();
$lockAcquired = (int) ($lockStmt->get_result()->fetch_assoc()['acquired'] ?? 0) === 1;
$lockStmt->close();
if (!$lockAcquired) {
    fwrite(STDERR, "Unable to acquire the Biochemistry template seed lock.\n");
    exit(1);
}

try {
    $conn->begin_transaction();

    $validateProduct = $conn->prepare(
        'SELECT id FROM products WHERE id = ? AND status != 3 AND deleted_at IS NULL LIMIT 1'
    );
    $upsertTemplate = $conn->prepare(
        "INSERT INTO bmr_templates
            (product_id, product_name, template_name, form_type, template_code, version_no,
             document_no, issue_no, revision_no, effective_date, mfr_reference,
             source_pdf_path, page_asset_path, source_checksum, page_count, layout_json,
             status, created_by, created_at)
         VALUES (?, 'Biochemistry Common', ?, ?, ?, 3, ?, '01', '02', '2025-04-03',
                 'PROFILE-DRIVEN', NULL, NULL, NULL, ?, ?, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             product_id = VALUES(product_id),
             product_name = VALUES(product_name),
             template_name = VALUES(template_name),
             form_type = VALUES(form_type),
             version_no = 3,
             document_no = VALUES(document_no),
             issue_no = '01',
             revision_no = '02',
             effective_date = '2025-04-03',
             mfr_reference = 'PROFILE-DRIVEN',
             source_pdf_path = NULL,
             page_asset_path = NULL,
             source_checksum = NULL,
             page_count = VALUES(page_count),
             layout_json = VALUES(layout_json),
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    $findTemplate = $conn->prepare(
        'SELECT id FROM bmr_templates WHERE template_code = ? AND deleted_at IS NULL LIMIT 1'
    );
    $upsertMapping = $conn->prepare(
        "INSERT INTO bmr_template_product_mappings
            (template_id, product_id, form_type, document_sequence, required_quantity,
             status, created_by, created_at)
         VALUES (?, ?, ?, ?, 1, 1, 1, NOW())
         ON DUPLICATE KEY UPDATE
             template_id = VALUES(template_id),
             required_quantity = 1,
             status = 1,
             deleted_by = NULL,
             deleted_at = NULL,
             updated_by = 1,
             updated_at = NOW()"
    );
    if (!$validateProduct || !$upsertTemplate || !$findTemplate || !$upsertMapping) {
        throw new RuntimeException('Unable to prepare Biochemistry template statements.');
    }

    foreach ($approvedProductIds as $productId) {
        $validateProduct->bind_param('i', $productId);
        $validateProduct->execute();
        if (!$validateProduct->get_result()->fetch_assoc()) {
            throw new RuntimeException("Mapped Biochemistry product {$productId} is unavailable.");
        }
    }

    if (!$conn->query(
        "UPDATE bmr_template_product_mappings
         SET status = 0, updated_by = 1, updated_at = NOW()
         WHERE product_id IN ({$approvedProductSql})
           AND form_type IN ('BMR', 'BPR')
           AND status = 1
           AND deleted_at IS NULL"
    )) {
        throw new RuntimeException('Unable to retire superseded Biochemistry mappings.');
    }

    $templateCount = 0;
    $mappingCount = 0;
    foreach ($definitions as $definition) {
        $layoutJson = json_encode(
            $definition['layout'],
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR
        );
        $profiles = $definition['layout']['profiles'];
        $canonicalProductId = (int) array_key_first($profiles);
        $templateName = (string) $definition['template_name'];
        $formType = (string) $definition['form_type'];
        $templateCode = (string) $definition['template_code'];
        $documentNo = $formType === 'BPR' ? 'BIPL-BPR-01' : 'BIPL-BMR-01';
        $pageCount = (int) $definition['page_count'];
        $upsertTemplate->bind_param(
            'issssis',
            $canonicalProductId,
            $templateName,
            $formType,
            $templateCode,
            $documentNo,
            $pageCount,
            $layoutJson
        );
        if (!$upsertTemplate->execute()) {
            throw new RuntimeException(
                "Unable to save Biochemistry template {$templateCode}: {$upsertTemplate->error}"
            );
        }
        $findTemplate->bind_param('s', $templateCode);
        $findTemplate->execute();
        $templateId = (int) ($findTemplate->get_result()->fetch_assoc()['id'] ?? 0);
        if ($templateId <= 0) {
            throw new RuntimeException("Unable to resolve Biochemistry template {$templateCode}.");
        }
        $templateCount++;

        $sequence = (int) $definition['sequence'];
        foreach (array_keys($profiles) as $productIdValue) {
            $productId = (int) $productIdValue;
            $upsertMapping->bind_param(
                'iisi',
                $templateId,
                $productId,
                $formType,
                $sequence
            );
            if (!$upsertMapping->execute()) {
                throw new RuntimeException(
                    "Unable to map Biochemistry product {$productId} {$formType} #{$sequence}: "
                    . $upsertMapping->error
                );
            }
            $mappingCount++;
        }
    }

    $safeRequestSnapshots = $conn->query(
        "UPDATE bmr_bpr_request_documents request_document
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = request_document.request_id
           AND request_row.deleted_at IS NULL
         INNER JOIN bmr_template_product_mappings mapping
            ON mapping.product_id = request_row.product_id
           AND mapping.form_type = request_document.form_type
           AND mapping.document_sequence = request_document.document_sequence
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         SET request_document.template_id = mapping.template_id,
             request_document.updated_by = 1,
             request_document.updated_at = NOW()
         WHERE request_row.product_id IN ({$approvedProductSql})
           AND NOT EXISTS (
               SELECT 1 FROM bmr_bpr_work_items started_item
               WHERE started_item.request_id = request_document.request_id
                 AND started_item.form_type = request_document.form_type
                 AND started_item.deleted_at IS NULL
                 AND (
                     started_item.status IN ('IN_PROCESS', 'COMPLETE')
                     OR (
                         started_item.form_payload_json IS NOT NULL
                         AND started_item.form_payload_json NOT IN ('', '{}')
                     )
                 )
           )"
    );
    if ($safeRequestSnapshots === false) {
        throw new RuntimeException('Unable to update safe Biochemistry request snapshots.');
    }
    $snapshotCount = $conn->affected_rows;

    $safeIncoming = $conn->query(
        "UPDATE bmr_bpr_work_items work_item
         INNER JOIN bmr_bpr_requests request_row
            ON request_row.id = work_item.request_id
           AND request_row.deleted_at IS NULL
         INNER JOIN bmr_template_product_mappings mapping
            ON mapping.product_id = request_row.product_id
           AND mapping.form_type = work_item.form_type
           AND mapping.document_sequence = work_item.form_sequence
           AND mapping.status = 1
           AND mapping.deleted_at IS NULL
         SET work_item.template_id = mapping.template_id,
             work_item.updated_by = 1,
             work_item.updated_at = NOW()
         WHERE request_row.product_id IN ({$approvedProductSql})
           AND work_item.status IN ('QUEUED', 'PENDING')
           AND (
               work_item.form_payload_json IS NULL
               OR work_item.form_payload_json IN ('', '{}')
           )"
    );
    if ($safeIncoming === false) {
        throw new RuntimeException('Unable to map safe incoming Biochemistry work items.');
    }
    $incomingCount = $conn->affected_rows;

    $validateProduct->close();
    $upsertTemplate->close();
    $findTemplate->close();
    $upsertMapping->close();
    $conn->commit();

    $documentCounts = bmrBprBiochemistryDocumentCounts();
    echo "Common Biochemistry structured templates saved: {$templateCount}\n";
    echo "Distinct Biochemistry document mappings updated: {$mappingCount}\n";
    echo "Mapped finished-product catalog records: " . count($approvedProductIds) . "\n";
    echo "Configured product documents: {$documentCounts['BMR']} BMR, {$documentCounts['BPR']} BPR\n";
    echo "Safe Biochemistry request snapshots updated: {$snapshotCount}\n";
    echo "Blank queued/pending Biochemistry work items mapped: {$incomingCount}\n";
    echo "In-process, completed and populated records were not reassigned.\n";
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
} finally {
    $releaseStmt = $conn->prepare('SELECT RELEASE_LOCK(?)');
    if ($releaseStmt) {
        $releaseStmt->bind_param('s', $lockName);
        $releaseStmt->execute();
        $releaseStmt->close();
    }
}
