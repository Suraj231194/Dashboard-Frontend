<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

echo "=== AutoIVD Robust Pending Migrations Runner ===\n";
echo "Connected to database: " . $conn->query("SELECT DATABASE()")->fetch_row()[0] . "\n";
echo "Host: " . $conn->host_info . "\n\n";

$orderedFiles = [
    '2026_07_16_inventory_module_completion_pending.sql',
    '2026_07_16_module2_procurement_completion_pending.sql',
    '2026_07_16_order_management_completion_pending.sql',
    '2026_07_16_production_order_item_routing_pending.sql',
    '2026_07_16_requirement_completion_integrity_pending.sql',
    '2026_07_18_add_product_id_to_order_received_items_pending.sql',
    '2026_07_18_add_warehouse_to_stock_inwards_pending.sql',
    '2026_07_20_company_profile_onboarding_pending.sql',
    '2026_07_20_production_batch_sequences_pending.sql',
    '2026_07_21_add_qty_to_product_pack_sizes_pending.sql',
    '2026_07_21_company_profile_location_emails_pending.sql',
    '2026_07_21_employee_documents_pending.sql',
    '2026_07_23_email_order_processing_pending.sql',
    '2026_07_24_finance_module_pending.sql',
    '2026_07_24_whatsapp_order_processing_pending.sql',
    '2026_07_27_add_bmr_bpr_form_request_menu_pending.sql',
    '2026_07_27_add_bmr_bpr_issuance_menu_pending.sql',
    '2026_07_27_add_production_bmr_bpr_menu_pending.sql',
    '2026_07_27_bmr_bpr_workflow_pending.sql',
    '2026_07_27_bmr_bpr_multi_form_queue_pending.sql',
    '2026_07_27_bmr_bpr_product_templates_pending.sql',
    '2026_07_27_production_batch_number_uniqueness_pending.sql',
    '2026_07_30_biochemistry_coa_templates_pending.sql',
    '2026_07_31_001_create_sync_foundation_pending.sql',
    '2026_07_31_002_seed_sync_menu_and_permissions_pending.sql',
    '2026_07_31_003_add_sync_reliability_columns_pending.sql',
    '2026_07_31_004_extend_customer_management_profile_pending.sql',
    '2026_07_31_005_extend_quiz_lead_details_pending.sql',
    '2026_07_31_006_add_product_hsn_and_cat_sequence_pending.sql',
    '2026_07_31_007_complete_pi_quotation_and_bio_health_pending.sql',
    '2026_08_09_quotation_and_pi_sync_schema_pending.sql',
    '2026_08_16_001_crm_sales_module_pending.sql',
    '2026_08_16_002_crm_menus_and_permissions_pending.sql',
    '2026_08_17_001_crm_sales_completion_pending.sql',
    '2026_08_17_001_product_vendor_customer_master_schema_pending.sql',
    '2026_08_26_restore_purchase_request_product_categories_pending.sql',
    '2026_08_27_001_hrms_pdf_foundation_pending.sql',
    '2026_08_27_002_payroll_management_pending.sql',
    '2026_09_01_001_careio_pdf_completion_pending.sql',
    '2026_09_01_002_salary_statutory_rules_pending.sql',
    '2026_09_01_003_strict_hrms_access_pending.sql',
    '2026_09_02_001_annual_calendar_module_pending.sql',
    '2026_09_04_001_complete_schema_sync_pending.sql',
    '2026_09_04_002_hr_calendar_compatibility_pending.sql',
    '2026_09_04_003_order_proforma_source_compatibility_pending.sql',
    '2026_09_04_004_whatsapp_processing_status_compatibility_pending.sql',
    '2026_09_04_005_bmr_template_product_form_index_cleanup_pending.sql',
    '2026_09_04_006_bom_items_category_backfill_pending.sql',
    '2026_09_04_007_bom_master_category_backfill_pending.sql',
    '2026_09_04_008_bom_items_unit_backfill_pending.sql',
    '2026_09_04_009_bom_items_qty_precision_pending.sql',
    '2026_09_05_001_low_stock_aging_pending.sql',
    '2026_09_05_002_low_stocks_item_name_pending.sql',
    '2026_09_07_001_procurement_flow_completion_pending.sql',
    '2026_09_07_002_pdf_workflow_completion_pending.sql',
    '2026_09_12_001_bom_approval_workflow_pending.sql',
    '2026_09_12_002_bom_approval_permission_and_reason.sql',
    '2026_09_15_001_repair_product_cat_sequence_scope_pending.sql',
    '2026_09_15_002_readable_default_font_size_pending.sql',
    '2026_09_16_003_bmr_bpr_pack_size_mappings_pending.sql',
    '2026_09_17_001_goods_receipt_document_alignment_pending.sql',
    '2026_09_18_001_procurement_quality_hardening_pending.sql',
    '2026_09_23_002_template_snapshots_pending.sql',
    '2026_09_23_003_cleanup_legacy_live_stock_columns_pending.sql',
    '2026_09_23_004_transaction_cleanup_archive_pending.sql',
    '2026_09_25_001_sync_production_hardening_pending.sql',
];

// The unified live-stock migration is a PHP data migration with locking,
// archival, and invariant checks. It must never be fed through the raw SQL
// statement splitter below.
if (in_array('--run-unified-live-stock', $argv, true)) {
    passthru(PHP_BINARY . ' ' . escapeshellarg(__DIR__ . '/run_unified_live_stock.php'), $exitCode);
    if ($exitCode !== 0) {
        throw new RuntimeException('Unified live-stock migration failed.');
    }
}

function splitSqlStatements(string $sql): array
{
    $lines = explode("\n", $sql);
    $cleanLines = [];
    $inBlockComment = false;

    foreach ($lines as $line) {
        $trimmed = trim($line);
        if ($inBlockComment) {
            if (str_contains($trimmed, '*/')) {
                $inBlockComment = false;
            }
            continue;
        }
        if (str_starts_with($trimmed, '/*')) {
            if (!str_contains($trimmed, '*/')) {
                $inBlockComment = true;
            }
            continue;
        }
        if (str_starts_with($trimmed, '--') || str_starts_with($trimmed, '#')) {
            continue;
        }
        $cleanLines[] = $line;
    }

    $cleanSql = implode("\n", $cleanLines);

    $statements = [];
    $current = '';
    $inQuote = false;
    $quoteChar = '';
    $len = strlen($cleanSql);

    for ($i = 0; $i < $len; $i++) {
        $char = $cleanSql[$i];
        if ($inQuote) {
            $current .= $char;
            if ($char === $quoteChar) {
                // Count consecutive backslashes before this char
                $backslashCount = 0;
                for ($j = $i - 1; $j >= 0 && $cleanSql[$j] === '\\'; $j--) {
                    $backslashCount++;
                }
                if ($backslashCount % 2 === 0) {
                    // Check for doubled quote escape (e.g. '' inside '')
                    if ($quoteChar === "'" && $i + 1 < $len && $cleanSql[$i + 1] === "'") {
                        $current .= $cleanSql[$i + 1];
                        $i++;
                    } else {
                        $inQuote = false;
                    }
                }
            }
        } elseif ($char === "'" || $char === '"' || $char === '`') {
            $inQuote = true;
            $quoteChar = $char;
            $current .= $char;
        } elseif ($char === ';') {
            if (trim($current) !== '') {
                $statements[] = trim($current);
            }
            $current = '';
        } else {
            $current .= $char;
        }
    }

    if (trim($current) !== '') {
        $statements[] = trim($current);
    }

    return $statements;
}

function assertProcurementFlowMigrationSafe(mysqli $conn): void
{
    $duplicateChecks = [
        'duplicate Quality queue receipt links' => "SELECT 1 FROM coa_inbound_queue WHERE stock_inward_id IS NOT NULL GROUP BY stock_inward_id HAVING COUNT(*) > 1 LIMIT 1",
        'duplicate PM request-to-PO links' => "SELECT 1 FROM purchase_order_final WHERE low_stock_id IS NOT NULL GROUP BY low_stock_id HAVING COUNT(*) > 1 LIMIT 1",
        'duplicate RM request-to-PO links' => "SELECT 1 FROM purchase_order_raw_items WHERE low_stock_id IS NOT NULL GROUP BY low_stock_id HAVING COUNT(*) > 1 LIMIT 1",
    ];

    foreach ($duplicateChecks as $label => $sql) {
        $result = $conn->query($sql);
        if (!$result) {
            throw new RuntimeException("Unable to validate {$label}: " . $conn->error);
        }
        if ($result->num_rows > 0) {
            throw new RuntimeException("Migration stopped because the database contains {$label}. Resolve them before adding the uniqueness constraint.");
        }
    }
}

$conn->query("SET FOREIGN_KEY_CHECKS = 0");
$conn->query("SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO'");

$total = count($orderedFiles);
echo "Executing {$total} pending migrations in topological order...\n\n";

$startTime = microtime(true);
$successCount = 0;

$idempotentErrors = [
    1022, // Can't write; duplicate key in table
    1050, // Table already exists
    1060, // Duplicate column name
    1061, // Duplicate key name
    1062, // Duplicate entry for key
    1068, // Multiple primary key defined
    1091, // Can't DROP '...'; check that column/key exists
    1826, // Duplicate foreign key constraint name
];

$conn->query("CREATE TABLE IF NOT EXISTS `_schema_migrations_applied` (
    `migration` VARCHAR(255) PRIMARY KEY,
    `applied_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB");

$appliedRes = $conn->query("SELECT `migration` FROM `_schema_migrations_applied`");
$alreadyApplied = [];
if ($appliedRes) {
    while ($row = $appliedRes->fetch_row()) {
        $alreadyApplied[$row[0]] = true;
    }
}

foreach ($orderedFiles as $index => $file) {
    $num = $index + 1;
    $filePath = __DIR__ . '/' . $file;

    if (!file_exists($filePath)) {
        $altFile = str_replace('_pending.sql', '.sql', $file);
        $altPath = __DIR__ . '/' . $altFile;
        if (file_exists($altPath)) {
            $filePath = $altPath;
        } else {
            fwrite(STDERR, "File not found: {$filePath}\n");
            exit(1);
        }
    }

    $altFile = str_replace('_pending.sql', '.sql', $file);
    if (isset($alreadyApplied[$file]) || isset($alreadyApplied[$altFile])) {
        echo "[{$num}/{$total}] ALREADY APPLIED: {$file}\n";
        $successCount++;
        continue;
    }

    if ($file === '2026_09_07_001_procurement_flow_completion_pending.sql') {
        try {
            assertProcurementFlowMigrationSafe($conn);
        } catch (Throwable $e) {
            fwrite(STDERR, "Procurement migration preflight failed: {$e->getMessage()}\n");
            exit(1);
        }
    }

    $sql = file_get_contents($filePath);
    if ($sql === false || trim($sql) === '') {
        echo "[{$num}/{$total}] SKIPPED: {$file}\n";
        continue;
    }

    echo "[{$num}/{$total}] Executing: {$file} ... ";
    $fileStart = microtime(true);

    $statements = splitSqlStatements($sql);

    foreach ($statements as $stmt) {
        if (trim($stmt) === '') continue;

        if (!$conn->query($stmt)) {
            $errNo = $conn->errno;
            $errMsg = $conn->error;

            if (in_array($errNo, $idempotentErrors, true)) {
                continue;
            }

            echo "FAILED!\n";
            fwrite(STDERR, "Error in {$file}:\n{$errMsg} (Error code: {$errNo})\nStatement:\n" . substr($stmt, 0, 300) . "\n");
            exit(1);
        }
    }

    $elapsed = round(microtime(true) - $fileStart, 3);
    echo "DONE ({$elapsed}s)\n";
    $conn->query("INSERT IGNORE INTO `_schema_migrations_applied` (`migration`) VALUES ('" . $conn->real_escape_string($file) . "')");
    $successCount++;
}

$conn->query("SET FOREIGN_KEY_CHECKS = 1");

$totalElapsed = round(microtime(true) - $startTime, 2);
echo "\n=================================================================\n";
echo "SUCCESS: All {$successCount}/{$total} pending migrations executed successfully in {$totalElapsed}s!\n";
echo "=================================================================\n";
