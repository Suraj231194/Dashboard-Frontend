-- Module 1 inventory integrity completion.
-- This migration is idempotent and only backfills relationships that are unambiguous.

SET @has_low_stock_coa = (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'low_stocks' AND COLUMN_NAME = 'coa_number'
);
SET @sql = IF(
    @has_low_stock_coa = 0,
    'ALTER TABLE `low_stocks` ADD COLUMN `coa_number` VARCHAR(255) DEFAULT NULL AFTER `procurement_source`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @has_fg_product_id = (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fg_coa_generation' AND COLUMN_NAME = 'product_id'
);
SET @sql = IF(
    @has_fg_product_id = 0,
    'ALTER TABLE `fg_coa_generation` ADD COLUMN `product_id` INT(11) DEFAULT NULL AFTER `coa_fg`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @has_fg_live_stock_id = (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fg_coa_generation' AND COLUMN_NAME = 'live_stock_id'
);
SET @sql = IF(
    @has_fg_live_stock_id = 0,
    'ALTER TABLE `fg_coa_generation` ADD COLUMN `live_stock_id` INT(11) DEFAULT NULL AFTER `product_id`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @has_fg_coa_unique = (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fg_coa_generation' AND INDEX_NAME = 'uq_fg_coa_number'
);
SET @sql = IF(
    @has_fg_coa_unique = 0,
    'CREATE UNIQUE INDEX `uq_fg_coa_number` ON `fg_coa_generation` (`coa_fg`)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @has_fg_product_index = (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fg_coa_generation' AND INDEX_NAME = 'idx_fg_coa_product_id'
);
SET @sql = IF(
    @has_fg_product_index = 0,
    'CREATE INDEX `idx_fg_coa_product_id` ON `fg_coa_generation` (`product_id`)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @has_fg_stock_index = (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fg_coa_generation' AND INDEX_NAME = 'idx_fg_coa_live_stock_id'
);
SET @sql = IF(
    @has_fg_stock_index = 0,
    'CREATE INDEX `idx_fg_coa_live_stock_id` ON `fg_coa_generation` (`live_stock_id`)',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

CREATE TEMPORARY TABLE `tmp_fg_product_map` (
    `coa_id` INT(11) NOT NULL PRIMARY KEY,
    `product_id` INT(11) NOT NULL
);

INSERT INTO `tmp_fg_product_map` (`coa_id`, `product_id`)
SELECT fg.id, MIN(p.id)
FROM fg_coa_generation fg
JOIN products p ON BINARY TRIM(p.product_name) = BINARY TRIM(fg.product_name)
LEFT JOIN product_categories c ON c.id = p.category_id
WHERE fg.status != 3
  AND fg.deleted_at IS NULL
  AND fg.product_id IS NULL
  AND p.status != 3
  AND p.deleted_at IS NULL
  AND COALESCE(p.inventory_group, c.inventory_group, 1) = 1
GROUP BY fg.id
HAVING COUNT(DISTINCT p.id) = 1;

INSERT IGNORE INTO `tmp_fg_product_map` (`coa_id`, `product_id`)
SELECT fg.id, MIN(p.id)
FROM fg_coa_generation fg
JOIN transfer_ticket tt
  ON BINARY TRIM(tt.fg_coa_no) = BINARY TRIM(fg.coa_fg)
JOIN products p
  ON BINARY TRIM(p.product_name) = BINARY TRIM(tt.product_description)
LEFT JOIN product_categories c ON c.id = p.category_id
WHERE fg.status != 3
  AND fg.deleted_at IS NULL
  AND fg.product_id IS NULL
  AND tt.status != 3
  AND tt.deleted_at IS NULL
  AND p.status != 3
  AND p.deleted_at IS NULL
  AND COALESCE(p.inventory_group, c.inventory_group, 1) = 1
GROUP BY fg.id
HAVING COUNT(DISTINCT p.id) = 1;

UPDATE fg_coa_generation fg
JOIN tmp_fg_product_map map ON map.coa_id = fg.id
SET fg.product_id = map.product_id
WHERE fg.product_id IS NULL;

DROP TEMPORARY TABLE `tmp_fg_product_map`;

CREATE TEMPORARY TABLE `tmp_fg_stock_map` (
    `coa_id` INT(11) NOT NULL PRIMARY KEY,
    `live_stock_id` INT(11) NOT NULL
);

INSERT INTO `tmp_fg_stock_map` (`coa_id`, `live_stock_id`)
SELECT fg.id, MIN(ls.id)
FROM fg_coa_generation fg
JOIN live_stock ls
  ON ls.product_id = fg.product_id
 AND BINARY TRIM(COALESCE(ls.lot_batch_no, '')) = BINARY TRIM(COALESCE(fg.batch_number, ''))
WHERE fg.status != 3
  AND fg.deleted_at IS NULL
  AND fg.live_stock_id IS NULL
  AND fg.product_id IS NOT NULL
  AND ls.status != 3
  AND ls.deleted_at IS NULL
GROUP BY fg.id
HAVING COUNT(DISTINCT ls.id) = 1;

UPDATE fg_coa_generation fg
JOIN tmp_fg_stock_map map ON map.coa_id = fg.id
SET fg.live_stock_id = map.live_stock_id
WHERE fg.live_stock_id IS NULL;

DROP TEMPORARY TABLE `tmp_fg_stock_map`;

UPDATE live_stock ls
JOIN fg_coa_generation fg ON fg.live_stock_id = ls.id
SET ls.coa_number = fg.coa_fg,
    ls.updated_at = NOW()
WHERE fg.status != 3
  AND fg.deleted_at IS NULL
  AND ls.deleted_at IS NULL
  AND COALESCE(ls.coa_number, '') = '';

UPDATE live_stock ls
JOIN coa_rm_pm_table coa ON coa.stock_inward_id = ls.stock_inward_id
SET ls.coa_number = coa.coa_number,
    ls.updated_at = NOW()
WHERE coa.status != 3
  AND coa.deleted_at IS NULL
  AND ls.deleted_at IS NULL
  AND COALESCE(ls.coa_number, '') = '';

-- Recover pack sizes only where an existing business record maps to one exact product.
INSERT INTO product_pack_sizes
    (product_id, pack_size, pack_unit_id, sort_order, status, created_by, created_at)
SELECT p.id, TRIM(po.pack_size), NULL, 0, 1, MIN(po.created_by), NOW()
FROM purchase_order_final po
JOIN products p ON BINARY TRIM(p.product_name) = BINARY TRIM(po.material_name)
LEFT JOIN product_pack_sizes pps
  ON pps.product_id = p.id
 AND BINARY TRIM(pps.pack_size) = BINARY TRIM(po.pack_size)
 AND pps.status != 3
 AND pps.deleted_at IS NULL
WHERE po.status != 3
  AND po.deleted_at IS NULL
  AND p.status != 3
  AND p.deleted_at IS NULL
  AND COALESCE(TRIM(po.pack_size), '') NOT IN ('', '-')
  AND pps.id IS NULL
GROUP BY p.id, TRIM(po.pack_size);

INSERT INTO product_pack_sizes
    (product_id, pack_size, pack_unit_id, sort_order, status, created_by, created_at)
SELECT p.id, TRIM(pi.pack_size), NULL, 0, 1, MIN(pi.created_by), NOW()
FROM proforma_invoice_items pi
JOIN products p ON BINARY TRIM(p.product_name) = BINARY TRIM(pi.product)
LEFT JOIN product_pack_sizes pps
  ON pps.product_id = p.id
 AND BINARY TRIM(pps.pack_size) = BINARY TRIM(pi.pack_size)
 AND pps.status != 3
 AND pps.deleted_at IS NULL
WHERE pi.status != 3
  AND pi.deleted_at IS NULL
  AND p.status != 3
  AND p.deleted_at IS NULL
  AND COALESCE(TRIM(pi.pack_size), '') NOT IN ('', '-')
  AND pps.id IS NULL
GROUP BY p.id, TRIM(pi.pack_size);

INSERT INTO product_pack_sizes
    (product_id, pack_size, pack_unit_id, sort_order, status, created_by, created_at)
SELECT p.id, CAST(tt.pack_size AS CHAR), tt.pack_size_unit, 0, 1, MIN(tt.created_by), NOW()
FROM transfer_ticket tt
JOIN products p ON BINARY TRIM(p.product_name) = BINARY TRIM(tt.product_description)
LEFT JOIN product_pack_sizes pps
  ON pps.product_id = p.id
 AND BINARY TRIM(pps.pack_size) = BINARY CAST(tt.pack_size AS CHAR)
 AND COALESCE(pps.pack_unit_id, 0) = COALESCE(tt.pack_size_unit, 0)
 AND pps.status != 3
 AND pps.deleted_at IS NULL
WHERE tt.status != 3
  AND tt.deleted_at IS NULL
  AND p.status != 3
  AND p.deleted_at IS NULL
  AND tt.pack_size > 0
  AND pps.id IS NULL
GROUP BY p.id, tt.pack_size, tt.pack_size_unit;

INSERT INTO product_pack_sizes
    (product_id, pack_size, pack_unit_id, sort_order, status, created_by, created_at)
SELECT p.id, TRIM(item.pack_size), item.pack_unit_id, 0, 1, MIN(item.created_by), NOW()
FROM coa_rm_pm_bifurcated_items item
JOIN products p ON BINARY TRIM(p.product_name) = BINARY TRIM(item.product_name)
LEFT JOIN product_pack_sizes pps
  ON pps.product_id = p.id
 AND BINARY TRIM(pps.pack_size) = BINARY TRIM(item.pack_size)
 AND COALESCE(pps.pack_unit_id, 0) = COALESCE(item.pack_unit_id, 0)
 AND pps.status != 3
 AND pps.deleted_at IS NULL
WHERE item.status != 3
  AND item.deleted_at IS NULL
  AND p.status != 3
  AND p.deleted_at IS NULL
  AND COALESCE(TRIM(item.pack_size), '') NOT IN ('', '-')
  AND pps.id IS NULL
GROUP BY p.id, TRIM(item.pack_size), item.pack_unit_id;
