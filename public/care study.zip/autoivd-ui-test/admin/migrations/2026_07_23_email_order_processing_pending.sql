-- =====================================================
-- Email Order Processing — Migration
-- Creates the email_order_log table for tracking
-- every inbound email and its processing outcome.
-- =====================================================

CREATE TABLE IF NOT EXISTS `email_order_log` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `message_id` VARCHAR(512) NOT NULL COMMENT 'RFC Message-ID header for deduplication',
    `from_email` VARCHAR(255) NOT NULL,
    `from_name` VARCHAR(255) DEFAULT NULL,
    `subject` VARCHAR(512) DEFAULT NULL,
    `received_at` DATETIME DEFAULT NULL COMMENT 'Date from email headers',
    `raw_body` LONGTEXT DEFAULT NULL COMMENT 'Full email body (text)',
    `parsed_data` JSON DEFAULT NULL COMMENT 'Structured data extracted from parsing',
    `processing_status` ENUM('success','parse_error','validation_error','system_error','duplicate') NOT NULL DEFAULT 'parse_error',
    `error_details` TEXT DEFAULT NULL COMMENT 'Human-readable error for debugging',
    `order_id` INT DEFAULT NULL COMMENT 'FK to order_received.id (on success)',
    `response_sent` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Whether response email was sent',
    `response_type` ENUM('success','failure','duplicate') DEFAULT NULL,
    `retry_count` TINYINT UNSIGNED NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_email_message_id` (`message_id`(255)),
    KEY `idx_email_order_log_status` (`processing_status`),
    KEY `idx_email_order_log_from` (`from_email`),
    KEY `idx_email_order_log_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
