<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/constant.php';
require_once dirname(__DIR__) . '/functions.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

function unifiedStockColumnExists(mysqli $conn, string $table, string $column): bool
{
    $stmt = $conn->prepare(
        'SELECT 1 FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1'
    );
    $stmt->bind_param('ss', $table, $column);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows === 1;
    $stmt->close();
    return $exists;
}

function unifiedStockIndexExists(mysqli $conn, string $table, string $index): bool
{
    $stmt = $conn->prepare(
        'SELECT 1 FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1'
    );
    $stmt->bind_param('ss', $table, $index);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows === 1;
    $stmt->close();
    return $exists;
}

function unifiedStockConstraintExists(mysqli $conn, string $table, string $constraint): bool
{
    $stmt = $conn->prepare(
        'SELECT 1 FROM information_schema.TABLE_CONSTRAINTS
         WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = ?
           AND CONSTRAINT_NAME = ? LIMIT 1'
    );
    $stmt->bind_param('ss', $table, $constraint);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows === 1;
    $stmt->close();
    return $exists;
}

function unifiedStockRunSqlFile(mysqli $conn, string $path): void
{
    $sql = file_get_contents($path);
    if ($sql === false || trim($sql) === '') {
        throw new RuntimeException('Unified stock migration SQL is unavailable.');
    }
    if (!$conn->multi_query($sql)) {
        throw new RuntimeException('Unified stock schema migration failed: ' . $conn->error);
    }
    do {
        if ($result = $conn->store_result()) {
            $result->free();
        }
        if ($conn->errno !== 0) {
            throw new RuntimeException('Unified stock schema migration failed: ' . $conn->error);
        }
    } while ($conn->more_results() && $conn->next_result());
}

$migrationPath = __DIR__ . '/2026_09_23_001_unified_live_stock_pending.sql';
if (!unifiedStockColumnExists($conn, 'live_stock', 'reserved_qty')) {
    unifiedStockRunSqlFile($conn, $migrationPath);
}

$needsCleanup = !unifiedStockIndexExists($conn, 'live_stock', 'uq_live_stock_product');
if ($needsCleanup) {
    $conn->begin_transaction();
    try {
    $productIds = [];
    $products = $conn->query('SELECT id FROM products');
    while ($product = $products->fetch_assoc()) {
        $productIds[(int) $product['id']] = true;
    }

    $rows = $conn->query('SELECT * FROM live_stock ORDER BY product_id, id FOR UPDATE');
    $byProduct = [];
    $orphans = [];
    while ($row = $rows->fetch_assoc()) {
        $productId = (int) $row['product_id'];
        if ($productId <= 0 || !isset($productIds[$productId])) {
            $orphans[] = $row;
            continue;
        }
        $byProduct[$productId][] = $row;
    }

    $archive = $conn->prepare(
        'INSERT IGNORE INTO live_stock_refactor_archive
            (legacy_live_stock_id, product_id, snapshot_json, archive_reason)
         VALUES (?, ?, ?, ?)'
    );
    $repointTables = [
        'fg_coa_generation',
        'goods_received_from_production',
        'order_stock_reservations',
        'stock_outward_items',
    ];

    foreach ($byProduct as $productId => $stockRows) {
        usort($stockRows, static function (array $a, array $b): int {
            $aUsable = empty($a['deleted_at']) ? 1 : 0;
            $bUsable = empty($b['deleted_at']) ? 1 : 0;
            return $aUsable === $bUsable
                ? ((int) $a['id'] <=> (int) $b['id'])
                : ($bUsable <=> $aUsable);
        });
        $keeperId = (int) $stockRows[0]['id'];
        if (count($stockRows) === 1) {
            continue;
        }
        $total = 0.0;
        foreach ($stockRows as $row) {
            if (empty($row['deleted_at']) && (int) $row['status'] !== 3) {
                $total += max(0, (float) $row['quantity_available']);
            }
        }
        $status = $total > 0.00000001 ? 1 : 0;
        $update = $conn->prepare(
            'UPDATE live_stock
             SET quantity_available = ?, reserved_qty = 0, status = ?,
                 deleted_at = NULL, deleted_by = NULL, unit_factor = 1,
                 updated_by = 1, updated_at = NOW()
             WHERE id = ?'
        );
        $update->bind_param('dii', $total, $status, $keeperId);
        $update->execute();
        $update->close();

        foreach (array_slice($stockRows, 1) as $duplicate) {
            $duplicateId = (int) $duplicate['id'];
            $json = json_encode($duplicate);
            $reason = 'duplicate_product_balance';
            $archive->bind_param('iiss', $duplicateId, $productId, $json, $reason);
            $archive->execute();
            foreach ($repointTables as $table) {
                $conn->query(
                    'UPDATE ' . $table . ' SET live_stock_id = ' . $keeperId .
                    ' WHERE live_stock_id = ' . $duplicateId
                );
            }
            $conn->query('DELETE FROM live_stock WHERE id = ' . $duplicateId);
        }
    }

    foreach ($orphans as $orphan) {
        $orphanId = (int) $orphan['id'];
        $productId = (int) $orphan['product_id'];
        $json = json_encode($orphan);
        $reason = 'missing_product';
        $archive->bind_param('iiss', $orphanId, $productId, $json, $reason);
        $archive->execute();
        $close = $conn->prepare(
            'UPDATE order_stock_reservations
             SET status = 0, closed_reason = \'orphaned_by_stock_unification\',
                 updated_by = 1, updated_at = NOW()
             WHERE live_stock_id = ? AND status = 1'
        );
        $close->bind_param('i', $orphanId);
        $close->execute();
        $close->close();
        $conn->query('DELETE FROM live_stock WHERE id = ' . $orphanId);
    }
    $archive->close();

    $conn->query(
        'UPDATE live_stock stock
         INNER JOIN products product ON product.id = stock.product_id
         SET stock.quantity_available = GREATEST(COALESCE(stock.quantity_available, 0), 0),
             stock.reserved_qty = 0,
             stock.status = CASE
                 WHEN stock.deleted_at IS NOT NULL OR stock.status = 3
                      OR product.deleted_at IS NOT NULL OR product.status = 3 THEN 0
                 WHEN stock.quantity_available > 0.00000001 THEN 1
                 ELSE 0
             END,
             stock.deleted_at = CASE
                 WHEN product.deleted_at IS NOT NULL OR product.status = 3
                     THEN COALESCE(stock.deleted_at, product.deleted_at, NOW())
                 ELSE stock.deleted_at
             END,
             stock.unit_factor = 1,
             stock.updated_by = 1,
             stock.updated_at = NOW()'
    );

    $conn->query(
        'INSERT INTO live_stock
            (product_id, quantity_available, reserved_qty, status, created_by, created_at)
         SELECT product.id, 0, 0, 0, 1, NOW()
         FROM products product
         LEFT JOIN live_stock stock ON stock.product_id = product.id
         WHERE product.deleted_at IS NULL AND stock.id IS NULL'
    );
    $conn->query(
        'UPDATE order_stock_reservations
         SET status = 0,
             closed_reason = COALESCE(closed_reason, \'recalculated_by_stock_unification\'),
             quantity = 0, updated_by = 1, updated_at = NOW()
         WHERE status = 1'
    );
    $conn->query(
        'UPDATE live_stock SET reserved_qty = 0, updated_by = 1, updated_at = NOW()'
    );
    $conn->query(
        'UPDATE order_received_items item
         LEFT JOIN (
             SELECT order_item_id, SUM(issued_quantity) quantity
             FROM stock_outward_items
             WHERE order_item_id IS NOT NULL AND deleted_at IS NULL AND status = 1
             GROUP BY order_item_id
         ) issued ON issued.order_item_id = item.id
         SET item.fulfilled_quantity = LEAST(COALESCE(item.quantity, 0), COALESCE(issued.quantity, 0)),
             item.reserved_quantity = 0,
             item.shortfall_quantity = GREATEST(
                 COALESCE(item.quantity, 0)
                 - LEAST(COALESCE(item.quantity, 0), COALESCE(issued.quantity, 0)),
                 0
             )'
    );
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        fwrite(STDERR, 'Unified stock cleanup failed: ' . $e->getMessage() . PHP_EOL);
        exit(1);
    }
}

if (!unifiedStockIndexExists($conn, 'live_stock', 'uq_live_stock_product')) {
    $conn->query('ALTER TABLE live_stock ADD UNIQUE KEY uq_live_stock_product (product_id)');
}

$conn->query(
    'INSERT INTO live_stock
        (product_id, quantity_available, reserved_qty, status, created_by, created_at)
     SELECT product.id, 0, 0, 0, 1, NOW()
     FROM products product
     LEFT JOIN live_stock stock ON stock.product_id = product.id
     WHERE product.status = 1 AND product.deleted_at IS NULL AND stock.id IS NULL'
);

if (!unifiedStockIndexExists($conn, 'live_stock', 'idx_live_stock_status_deleted')) {
    $conn->query('ALTER TABLE live_stock ADD KEY idx_live_stock_status_deleted (status, deleted_at)');
}
if (!unifiedStockConstraintExists($conn, 'live_stock', 'chk_live_stock_quantities')) {
    $conn->query(
        'ALTER TABLE live_stock ADD CONSTRAINT chk_live_stock_quantities
         CHECK (quantity_available >= 0 AND reserved_qty >= 0
                AND reserved_qty <= quantity_available)'
    );
}
if (!unifiedStockConstraintExists($conn, 'live_stock', 'chk_live_stock_status')) {
    $conn->query(
        'ALTER TABLE live_stock ADD CONSTRAINT chk_live_stock_status
         CHECK (status IN (0, 1))'
    );
}

$recalculateOrders = in_array('--recalculate-orders', $argv, true);
$orders = $recalculateOrders
    ? $conn->query(
        'SELECT DISTINCT order_header.id
         FROM order_received order_header
         INNER JOIN order_received_items item ON item.order_id = order_header.id
         WHERE order_header.deleted_at IS NULL
           AND item.deleted_at IS NULL
           AND order_header.status NOT IN (3, 4, 5, 6, 7, 8, 10)
           AND item.fulfilled_quantity + 0.00000001 < COALESCE(item.quantity, 0)
         ORDER BY order_header.id'
    )
    : null;
$recalculated = 0;
$failed = 0;
while ($orders && ($row = $orders->fetch_assoc())) {
    try {
        mvRecalculateOrderFulfillment(
            $conn,
            (int) $row['id'],
            1,
            'Unified stock migration.'
        );
        $recalculated++;
    } catch (Throwable $e) {
        $failed++;
        fwrite(
            STDERR,
            'Order ' . $row['id'] . ' recalculation failed: ' . $e->getMessage() . PHP_EOL
        );
    }
}

$invalid = (int) $conn->query(
    'SELECT COUNT(*) FROM live_stock
     WHERE quantity_available < 0 OR reserved_qty < 0 OR reserved_qty > quantity_available'
)->fetch_row()[0];
$duplicates = (int) $conn->query(
    'SELECT COUNT(*) FROM (
         SELECT product_id FROM live_stock GROUP BY product_id HAVING COUNT(*) > 1
     ) duplicate_products'
)->fetch_row()[0];

if ($invalid !== 0 || $duplicates !== 0) {
    fwrite(
        STDERR,
        'Unified stock verification failed: invalid=' . $invalid
        . ', duplicates=' . $duplicates . '.' . PHP_EOL
    );
    exit(1);
}

echo 'Unified stock migration applied. Orders recalculated: ' . $recalculated
    . '; failures: ' . $failed
    . ($recalculateOrders ? '.' : '; order recalculation skipped by request.')
    . PHP_EOL;
exit($failed === 0 ? 0 : 2);
