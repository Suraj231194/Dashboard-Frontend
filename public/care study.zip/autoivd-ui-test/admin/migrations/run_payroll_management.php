<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$migrationPath = __DIR__ . '/2026_08_27_002_payroll_management_pending.sql';
$sql = file_get_contents($migrationPath);

if ($sql === false || trim($sql) === '') {
    fwrite(STDERR, "Payroll migration file is unavailable.\n");
    exit(1);
}

if (!$conn->multi_query($sql)) {
    fwrite(STDERR, 'Payroll migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}

do {
    if ($result = $conn->store_result()) {
        $result->free();
    }
    if ($conn->errno !== 0) {
        fwrite(STDERR, 'Payroll migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
} while ($conn->more_results() && $conn->next_result());

$requiredTables = [
    'payroll_settings',
    'payroll_runs',
    'payroll_run_items',
    'payroll_reimbursements',
    'payroll_reimbursement_history',
];
$check = $conn->prepare(
    'SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?'
);
foreach ($requiredTables as $tableName) {
    $check->bind_param('s', $tableName);
    $check->execute();
    $check->bind_result($count);
    $check->fetch();
    $check->free_result();
    if ((int) $count !== 1) {
        fwrite(STDERR, "Payroll schema verification failed for {$tableName}.\n");
        exit(1);
    }
}
$check->close();

echo "Payroll Management schema and navigation applied successfully.\n";
