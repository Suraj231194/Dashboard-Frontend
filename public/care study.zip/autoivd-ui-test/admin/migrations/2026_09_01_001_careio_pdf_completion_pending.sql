-- Completion objects for careIo.pdf. This migration is idempotent on MariaDB 11.

ALTER TABLE `hr_biometric_devices`
    ADD COLUMN IF NOT EXISTS `ingest_token_hash` CHAR(64) DEFAULT NULL AFTER `timezone`,
    ADD COLUMN IF NOT EXISTS `ingest_enabled` TINYINT(1) NOT NULL DEFAULT 0 AFTER `ingest_token_hash`,
    ADD COLUMN IF NOT EXISTS `ingest_rate_limit` INT UNSIGNED NOT NULL DEFAULT 120 AFTER `ingest_enabled`,
    ADD COLUMN IF NOT EXISTS `last_ingested_at` DATETIME DEFAULT NULL AFTER `last_synced_at`;

  ALTER TABLE `hr_employee_profiles`
    ADD COLUMN IF NOT EXISTS `middle_name` VARCHAR(100) DEFAULT NULL AFTER `department_id`,
    ADD COLUMN IF NOT EXISTS `is_director` TINYINT(1) NOT NULL DEFAULT 0 AFTER `middle_name`,
    ADD COLUMN IF NOT EXISTS `differently_abled_type` VARCHAR(100) DEFAULT NULL AFTER `differently_abled`,
    ADD COLUMN IF NOT EXISTS `address_line_1` VARCHAR(255) DEFAULT NULL AFTER `annual_ctc`,
    ADD COLUMN IF NOT EXISTS `address_line_2` VARCHAR(255) DEFAULT NULL AFTER `address_line_1`,
    ADD COLUMN IF NOT EXISTS `city` VARCHAR(100) DEFAULT NULL AFTER `address_line_2`,
    ADD COLUMN IF NOT EXISTS `state` VARCHAR(100) DEFAULT NULL AFTER `city`,
    ADD COLUMN IF NOT EXISTS `postal_code` VARCHAR(20) DEFAULT NULL AFTER `state`;

CREATE TABLE IF NOT EXISTS `hr_biometric_ingest_batches` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `device_id` BIGINT UNSIGNED NOT NULL,
    `batch_key` VARCHAR(150) NOT NULL,
    `remote_ip` VARCHAR(45) DEFAULT NULL,
    `event_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `imported_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `duplicate_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `unmapped_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `attendance_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `status` ENUM('processing','success','partial','failed') NOT NULL DEFAULT 'processing',
    `error_message` VARCHAR(1000) DEFAULT NULL,
    `received_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `completed_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_hr_biometric_batch` (`device_id`, `batch_key`),
    KEY `idx_hr_biometric_batch_rate` (`device_id`, `received_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_attendance_manual_marks` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `employee_id` INT NOT NULL,
    `company_id` BIGINT UNSIGNED DEFAULT NULL,
    `branch_id` BIGINT UNSIGNED DEFAULT NULL,
    `attendance_date` DATE NOT NULL,
    `classification` ENUM('on_time','late','half_day','full_day','absent','incomplete') NOT NULL,
    `note` VARCHAR(500) DEFAULT NULL,
    `marked_by` INT NOT NULL,
    `marked_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_hr_attendance_manual_employee_date` (`employee_id`, `attendance_date`),
    KEY `idx_hr_attendance_manual_scope` (`company_id`, `branch_id`, `attendance_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `hr_employee_profiles` (`employee_id`, `company_id`, `branch_id`, `created_by`)
SELECT employee.id, company.id, single_branch.branch_id, 1
FROM `employees` employee
INNER JOIN `erp_companies` company
  ON company.id = employee.company AND company.status = 1 AND company.deleted_at IS NULL
LEFT JOIN (
  SELECT branch.company_id, MIN(branch.id) AS branch_id
  FROM `erp_branches` branch
  WHERE branch.status = 1 AND branch.deleted_at IS NULL
  GROUP BY branch.company_id
  HAVING COUNT(*) = 1
) single_branch ON single_branch.company_id = company.id
WHERE employee.deleted_at IS NULL
ON DUPLICATE KEY UPDATE
  company_id = COALESCE(hr_employee_profiles.company_id, VALUES(company_id)),
  branch_id = COALESCE(hr_employee_profiles.branch_id, VALUES(branch_id));

INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`)
SELECT seed.name, seed.slug, 1, 1
FROM (
    SELECT 'HRMS Leave Self Service' AS name, 'hrms_leave_view' AS slug
    UNION ALL SELECT 'HRMS Offboarding Self Service', 'hrms_offboarding_view'
  UNION ALL SELECT 'HRMS Biometric Administration', 'hrms_biometric_manage'
) seed
WHERE NOT EXISTS (SELECT 1 FROM `permissions` permission WHERE permission.slug = seed.slug);

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT role.id, permission.id, 1
FROM `roles` role
CROSS JOIN `permissions` permission
WHERE role.status = 1 AND role.deleted_at IS NULL
  AND permission.slug IN ('hrms_leave_view', 'hrms_offboarding_view')
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = role.id AND existing.permission_id = permission.id
  );

UPDATE `role_permissions` role_permission
INNER JOIN `permissions` permission ON permission.id = role_permission.permission_id
SET role_permission.status = 1
WHERE permission.slug IN ('hrms_leave_view', 'hrms_offboarding_view');

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT role.id, permission.id, 1
FROM `roles` role
CROSS JOIN `permissions` permission
WHERE role.status = 1 AND role.deleted_at IS NULL
  AND permission.slug = 'hrms_biometric_manage'
  AND LOWER(role.name) IN ('human resources', 'administrator', 'senior administrator', 'super administrator')
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = role.id AND existing.permission_id = permission.id
  );

UPDATE `role_permissions` role_permission
INNER JOIN `permissions` permission ON permission.id = role_permission.permission_id
INNER JOIN `roles` role ON role.id = role_permission.role_id
SET role_permission.status = 1
WHERE permission.slug = 'hrms_biometric_manage'
  AND LOWER(role.name) IN ('human resources', 'administrator', 'senior administrator', 'super administrator');

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT role.id, permission.id, 1
FROM `roles` role
CROSS JOIN `permissions` permission
WHERE role.status = 1 AND role.deleted_at IS NULL
  AND LOWER(role.name) = 'production' AND permission.slug = 'hr_menu'
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = role.id AND existing.permission_id = permission.id
  );

UPDATE `role_permissions` role_permission
INNER JOIN `permissions` permission ON permission.id = role_permission.permission_id
INNER JOIN `roles` role ON role.id = role_permission.role_id
SET role_permission.status = 1
WHERE permission.slug = 'hr_menu' AND LOWER(role.name) = 'production';

INSERT INTO `menus` (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`, `created_by`, `created_at`)
SELECT 'Human Resources', '#', 'ti ti-users', 0, 70, 'hr_menu', 1, 1, 1, CURRENT_TIMESTAMP
FROM DUAL
WHERE NOT EXISTS (
    SELECT 1 FROM `menus` existing
    WHERE existing.deleted_at IS NULL AND COALESCE(existing.parent_id, 0) = 0
      AND (existing.permission_slug = 'hr_menu' OR existing.name = 'Human Resources')
);

INSERT INTO `menus` (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`, `created_by`, `created_at`)
SELECT seed.name, seed.route, seed.icon, parent.id, seed.sort_order, seed.permission_slug, 1, 1, 1, CURRENT_TIMESTAMP
FROM (
    SELECT 'Employee Master' AS name, 'index.php?page=employee-master' AS route, 'ti ti-users' AS icon, 20 AS sort_order, 'hrms_employee_master_view' AS permission_slug
    UNION ALL SELECT 'Leave Management', 'index.php?page=leave-management', 'ti ti-calendar-check', 30, 'hrms_leave_view'
    UNION ALL SELECT 'Offboarding', 'index.php?page=offboarding', 'ti ti-door-exit', 40, 'hrms_offboarding_view'
    UNION ALL SELECT 'Attendance Management', 'index.php?page=attendance-management', 'ti ti-fingerprint', 50, 'hrms_attendance_manage'
    UNION ALL SELECT 'Shift Management', 'index.php?page=shift-management', 'ti ti-clock-cog', 60, 'hrms_shift_manage'
) seed
INNER JOIN `menus` parent ON parent.id = (
    SELECT candidate.id FROM `menus` candidate
    WHERE candidate.deleted_at IS NULL
      AND (candidate.permission_slug = 'hr_menu' OR candidate.name = 'Human Resources')
      AND COALESCE(candidate.parent_id, 0) = 0
    ORDER BY candidate.permission_slug = 'hr_menu' DESC, candidate.id LIMIT 1
)
WHERE NOT EXISTS (
    SELECT 1 FROM `menus` existing WHERE existing.route = seed.route AND existing.deleted_at IS NULL
);

UPDATE `role_permissions` role_permission
INNER JOIN `permissions` permission ON permission.id = role_permission.permission_id
INNER JOIN `roles` role ON role.id = role_permission.role_id
SET role_permission.status = 0
WHERE permission.slug = 'hrms_attendance_manage'
  AND LOWER(role.name) NOT IN ('production', 'human resources', 'administrator', 'senior administrator', 'super administrator');

UPDATE `role_permissions` role_permission
INNER JOIN `permissions` permission ON permission.id = role_permission.permission_id
INNER JOIN `roles` role ON role.id = role_permission.role_id
SET role_permission.status = 0
WHERE permission.slug = 'hrms_shift_manage'
  AND LOWER(role.name) NOT IN ('human resources', 'administrator', 'senior administrator', 'super administrator');

UPDATE `role_permissions` role_permission
INNER JOIN `permissions` permission ON permission.id = role_permission.permission_id
INNER JOIN `roles` role ON role.id = role_permission.role_id
SET role_permission.status = 0
WHERE permission.slug IN (
    'hrms_employee_master_view', 'hrms_employee_master_manage', 'hrms_leave_manage',
    'hrms_offboarding_manage', 'hrms_biometric_manage', 'payroll_reimbursements_manage'
)
  AND LOWER(role.name) NOT IN ('human resources', 'administrator', 'senior administrator', 'super administrator');

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT role.id, permission.id, 1
FROM `roles` role
CROSS JOIN `permissions` permission
WHERE role.status = 1 AND role.deleted_at IS NULL
  AND (
      (permission.slug = 'hrms_attendance_manage' AND LOWER(role.name) IN ('production', 'human resources', 'administrator', 'senior administrator', 'super administrator'))
      OR (permission.slug = 'hrms_shift_manage' AND LOWER(role.name) IN ('human resources', 'administrator', 'senior administrator', 'super administrator'))
        OR (permission.slug IN ('hrms_employee_master_view', 'hrms_employee_master_manage', 'hrms_leave_manage', 'hrms_offboarding_manage', 'hrms_biometric_manage', 'payroll_reimbursements_manage')
          AND LOWER(role.name) IN ('human resources', 'administrator', 'senior administrator', 'super administrator'))
  )
  AND NOT EXISTS (
      SELECT 1 FROM `role_permissions` existing
      WHERE existing.role_id = role.id AND existing.permission_id = permission.id
  );

UPDATE `role_permissions` role_permission
INNER JOIN `permissions` permission ON permission.id = role_permission.permission_id
INNER JOIN `roles` role ON role.id = role_permission.role_id
SET role_permission.status = 1
WHERE (permission.slug = 'hrms_attendance_manage' AND LOWER(role.name) IN ('production', 'human resources', 'administrator', 'senior administrator', 'super administrator'))
  OR (permission.slug = 'hrms_shift_manage' AND LOWER(role.name) IN ('human resources', 'administrator', 'senior administrator', 'super administrator'))
  OR (permission.slug IN ('hrms_employee_master_view', 'hrms_employee_master_manage', 'hrms_leave_manage', 'hrms_offboarding_manage', 'hrms_biometric_manage', 'payroll_reimbursements_manage')
     AND LOWER(role.name) IN ('human resources', 'administrator', 'senior administrator', 'super administrator'));