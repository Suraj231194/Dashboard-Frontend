-- Restores product-category master rows referenced by active products.
-- These IDs and values come from admin/seeders/01_products_master_seeder.sql.

START TRANSACTION;

INSERT INTO `product_categories`
    (`id`, `name`, `slug`, `sort_order`, `inventory_group`, `status`, `website_sync`, `created_by`, `created_at`)
SELECT
    43, 'FIA Rapid Test', 'fia-rapid-test', 150, 1, 1, 1, 0, NOW()
WHERE NOT EXISTS (
    SELECT 1 FROM `product_categories` WHERE `id` = 43
);

INSERT INTO `product_categories`
    (`id`, `name`, `slug`, `sort_order`, `inventory_group`, `status`, `website_sync`, `created_by`, `created_at`)
SELECT
    44, 'Serology And Turbi', 'serology-and-turbi', 170, 1, 1, 1, 0, NOW()
WHERE NOT EXISTS (
    SELECT 1 FROM `product_categories` WHERE `id` = 44
);

COMMIT;
