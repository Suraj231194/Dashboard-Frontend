-- =============================================================================
-- Migration: 2026_09_04_001_complete_schema_sync_pending.sql
-- Purpose: Complete all remaining tables, columns, primary keys, precision,
--          indexes, and foreign keys required to achieve 100% schema parity with DEV.
-- Date: 2026-09-04
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

-- =============================================================================
-- SECTION 1: CREATE MISSING APPLICATION TABLES (IF NOT ALREADY CREATED)
-- =============================================================================

CREATE TABLE IF NOT EXISTS `bmr_bpr_request_documents` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `request_id` bigint(20) UNSIGNED NOT NULL,
  `form_type` enum('BMR','BPR') NOT NULL,
  `document_sequence` int(10) UNSIGNED NOT NULL,
  `template_id` bigint(20) DEFAULT NULL,
  `required_quantity` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `goods_received_from_production` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `transfer_ticket_id` int(11) NOT NULL,
  `production_plan_id` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `live_stock_id` int(11) DEFAULT NULL,
  `ticket_no` varchar(255) NOT NULL,
  `lot_batch_no` varchar(255) DEFAULT NULL,
  `transferred_quantity` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `actual_received_quantity` decimal(20,8) DEFAULT NULL,
  `quantity_unit_id` int(11) DEFAULT NULL,
  `receipt_status` varchar(20) NOT NULL DEFAULT 'PENDING',
  `remarks` text DEFAULT NULL,
  `received_by` int(11) DEFAULT NULL,
  `received_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_annual_calendar_audit_events` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `calendar_id` int(11) DEFAULT NULL,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `calendar_year` smallint(5) UNSIGNED NOT NULL,
  `revision_no` smallint(5) UNSIGNED NOT NULL,
  `action` varchar(50) NOT NULL,
  `field_changed` varchar(100) DEFAULT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `reason` varchar(1000) DEFAULT NULL,
  `before_json` longtext DEFAULT NULL,
  `after_json` longtext DEFAULT NULL,
  `request_id` char(32) NOT NULL,
  `changed_by` int(11) NOT NULL,
  `changed_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_annual_calendar_custom_offs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `calendar_id` int(11) NOT NULL,
  `off_date` date NOT NULL,
  `off_name` varchar(150) NOT NULL DEFAULT 'Custom weekly off',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_annual_calendar_days` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `calendar_id` int(11) NOT NULL,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `calendar_date` date NOT NULL,
  `day_of_week` tinyint(3) UNSIGNED NOT NULL,
  `day_type` enum('working_day','weekly_off','holiday') NOT NULL,
  `is_working` tinyint(1) NOT NULL,
  `is_weekly_off` tinyint(1) NOT NULL DEFAULT 0,
  `is_holiday` tinyint(1) NOT NULL DEFAULT 0,
  `is_optional_holiday` tinyint(1) NOT NULL DEFAULT 0,
  `holiday_names` varchar(500) DEFAULT NULL,
  `holiday_types` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hr_annual_calendar_day_overrides` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `calendar_id` int(11) NOT NULL,
  `override_date` date NOT NULL,
  `override_type` enum('working_day','weekly_off') NOT NULL,
  `note` varchar(200) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `order_management_audit` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `order_id` int(11) NOT NULL,
  `order_item_id` int(11) DEFAULT NULL,
  `action` varchar(80) NOT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `old_value` longtext DEFAULT NULL,
  `new_value` longtext DEFAULT NULL,
  `reason` varchar(1000) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `order_stock_reservations` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `order_id` int(11) NOT NULL,
  `order_item_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `live_stock_id` int(11) NOT NULL,
  `quantity_base` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1=active, 2=consumed, 3=released',
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `production_plan_bom_backfill_audit` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `production_plan_id` int(11) NOT NULL,
  `production_plan_no` varchar(80) DEFAULT NULL,
  `old_product_id` int(11) DEFAULT NULL,
  `new_product_id` int(11) NOT NULL,
  `old_bom_master_id` int(11) DEFAULT NULL,
  `new_bom_master_id` int(11) NOT NULL,
  `old_updated_by` int(11) DEFAULT NULL,
  `old_updated_at` datetime DEFAULT NULL,
  `match_method` varchar(60) NOT NULL,
  `applied_by` int(11) NOT NULL,
  `applied_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `production_plan_number_sequences` (
  `financial_year` varchar(10) NOT NULL PRIMARY KEY,
  `last_sequence` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `transfer_ticket_trace_backfill_audit` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `transfer_ticket_id` int(11) NOT NULL,
  `ticket_no` varchar(255) DEFAULT NULL,
  `old_source_fg_coa_id` int(11) DEFAULT NULL,
  `new_source_fg_coa_id` int(11) DEFAULT NULL,
  `old_production_plan_id` int(11) DEFAULT NULL,
  `new_production_plan_id` int(11) DEFAULT NULL,
  `fg_match_method` varchar(80) DEFAULT NULL,
  `plan_match_method` varchar(80) DEFAULT NULL,
  `old_updated_by` int(11) DEFAULT NULL,
  `old_updated_at` datetime DEFAULT NULL,
  `applied_by` int(11) NOT NULL,
  `applied_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `whatsapp_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `from_phone` varchar(50) NOT NULL,
  `from_name` varchar(255) DEFAULT NULL,
  `current_step` varchar(50) NOT NULL DEFAULT 'MAIN_MENU',
  `selected_category_id` int(11) DEFAULT NULL,
  `selected_product_id` int(11) DEFAULT NULL,
  `selected_product_name` varchar(255) DEFAULT NULL,
  `order_data` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- =============================================================================
-- SECTION 2: HR SHIFT POLICIES PRIMARY KEY RESTRUCTURING
-- =============================================================================

SET @sp_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'hr_shift_policies' AND COLUMN_NAME = 'id'),
  'SELECT 1',
  'ALTER TABLE `hr_shift_policies` DROP PRIMARY KEY, ADD COLUMN `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (`id`)'
);
PREPARE sp_stmt FROM @sp_sql;
EXECUTE sp_stmt;
DEALLOCATE PREPARE sp_stmt;

-- =============================================================================
-- SECTION 3: ADD ALL MISSING COLUMNS (EXACT DEV.SQL SPECIFICATIONS)
-- =============================================================================

-- Table: bmr_template_product_mappings
ALTER TABLE `bmr_template_product_mappings`
  ADD COLUMN IF NOT EXISTS `document_sequence` int(10) UNSIGNED NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `required_quantity` int(10) UNSIGNED NOT NULL DEFAULT 1;

-- Table: customers
ALTER TABLE `customers`
  ADD COLUMN IF NOT EXISTS `contact_person` varchar(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `pan` varchar(20) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `state_code` varchar(20) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `payment_terms_status` int(11) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `payment_terms_text` varchar(500) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `created_by` int(11) DEFAULT 1;

-- Table: fg_coa_generation
ALTER TABLE `fg_coa_generation`
  ADD COLUMN IF NOT EXISTS `production_plan_id` int(11) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `workflow_status` varchar(50) NOT NULL DEFAULT 'draft';

-- Table: hr_annual_calendars
ALTER TABLE `hr_annual_calendars`
  ADD COLUMN IF NOT EXISTS `revision_no` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `weekly_off_days` varchar(20) NOT NULL DEFAULT '7',
  ADD COLUMN IF NOT EXISTS `lifecycle_status` enum('draft','finalized','superseded') NOT NULL DEFAULT 'draft',
  ADD COLUMN IF NOT EXISTS `supersedes_id` int(11) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `content_hash` char(64) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `lock_version` int(10) UNSIGNED NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `source_name` varchar(120) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `source_version` varchar(60) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `total_declared_holidays` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `total_optional_holidays` smallint(5) UNSIGNED NOT NULL DEFAULT 0;

-- Table: hr_annual_calendar_holidays
ALTER TABLE `hr_annual_calendar_holidays`
  ADD COLUMN IF NOT EXISTS `source_name` varchar(120) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `source_version` varchar(60) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `is_optional` tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `deleted_at` datetime DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `deleted_by` int(11) DEFAULT NULL;

-- Table: hr_attendance_daily
ALTER TABLE `hr_attendance_daily`
  ADD COLUMN IF NOT EXISTS `early_minutes` int(10) UNSIGNED NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `break_minutes` int(10) UNSIGNED NOT NULL DEFAULT 0;

-- Table: hr_leave_application_days
ALTER TABLE `hr_leave_application_days`
  ADD COLUMN IF NOT EXISTS `calendar_day_type` enum('working_day','weekly_off','holiday') NOT NULL DEFAULT 'working_day',
  ADD COLUMN IF NOT EXISTS `is_chargeable` tinyint(1) NOT NULL DEFAULT 1;

-- Table: ip_coa_generation
ALTER TABLE `ip_coa_generation`
  ADD COLUMN IF NOT EXISTS `source_bmr_bpr_request_id` bigint(20) UNSIGNED DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `production_plan_id` int(11) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `workflow_status` varchar(50) NOT NULL DEFAULT 'draft';

-- Table: live_stock
ALTER TABLE `live_stock`
  ADD COLUMN IF NOT EXISTS `production_receipt_id` bigint(20) UNSIGNED DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `received_from_production_at` datetime DEFAULT NULL;

-- Table: order_received
ALTER TABLE `order_received`
  ADD COLUMN IF NOT EXISTS `customer_id` bigint(20) UNSIGNED DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `payment_override_reason` text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `proforma_source` tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `proforma_invoice_id` bigint(20) UNSIGNED DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `received_by_user_id` int(11) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `customer_address_snapshot` text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `customer_gstin_snapshot` varchar(50) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `customer_pan_snapshot` varchar(20) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `customer_state_snapshot` varchar(100) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `customer_state_code_snapshot` varchar(20) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `customer_contact_person_snapshot` varchar(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `customer_contact_number_snapshot` varchar(50) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `customer_email_snapshot` varchar(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `lead_id` INT UNSIGNED DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `quotation_request_id` bigint(20) UNSIGNED DEFAULT NULL;

-- Table: order_received_items
ALTER TABLE `order_received_items`
  ADD COLUMN IF NOT EXISTS `fulfilled_quantity_base` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  ADD COLUMN IF NOT EXISTS `reserved_quantity_base` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  ADD COLUMN IF NOT EXISTS `shortfall_quantity_base` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  ADD COLUMN IF NOT EXISTS `fulfillment_status` varchar(40) NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS `fulfillment_action` varchar(30) DEFAULT NULL;

-- Table: payroll_runs
ALTER TABLE `payroll_runs`
  ADD COLUMN IF NOT EXISTS `calendar_revision_id` int(11) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `calendar_hash` char(64) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `calendar_working_days` decimal(7,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `calendar_weekly_off_days` decimal(7,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `calendar_holiday_days` decimal(7,2) NOT NULL DEFAULT 0.00;

-- Table: payroll_run_items
ALTER TABLE `payroll_run_items`
  ADD COLUMN IF NOT EXISTS `calendar_working_days` decimal(7,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `eligible_working_days` decimal(7,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `present_working_days` decimal(7,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `paid_leave_days` decimal(7,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `unpaid_leave_days` decimal(7,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `lop_days` decimal(7,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `weekly_off_days` decimal(7,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `holiday_days` decimal(7,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `off_day_worked_days` decimal(7,2) NOT NULL DEFAULT 0.00;

-- Table: pi_requests
ALTER TABLE `pi_requests`
  ADD COLUMN IF NOT EXISTS `customer_id` bigint(20) UNSIGNED DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `validity_date` date DEFAULT NULL;

-- Table: pi_request_items
ALTER TABLE `pi_request_items`
  ADD COLUMN IF NOT EXISTS `hsn_code` varchar(50) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `price_after_gst` decimal(12,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `discount_percentage` decimal(5,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `discount_amount` decimal(12,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `taxable_amount` decimal(12,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `gst_amount` decimal(12,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `cgst_rate` decimal(5,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `cgst_amount` decimal(12,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `sgst_rate` decimal(5,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `sgst_amount` decimal(12,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `igst_rate` decimal(5,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `igst_amount` decimal(12,2) DEFAULT 0.00;

-- Table: production_plans
ALTER TABLE `production_plans`
  ADD COLUMN IF NOT EXISTS `production_plan_no` varchar(80) DEFAULT NULL;

-- Table: proforma_invoices
ALTER TABLE `proforma_invoices`
  ADD COLUMN IF NOT EXISTS `customer_id` bigint(20) UNSIGNED DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `validity_date` date DEFAULT NULL;

-- Table: quotation_request_items
ALTER TABLE `quotation_request_items`
  ADD COLUMN IF NOT EXISTS `hsn_code` varchar(50) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `price_after_gst` decimal(12,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `discount_percentage` decimal(5,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `discount_amount` decimal(12,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `taxable_amount` decimal(12,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `gst_amount` decimal(12,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `cgst_rate` decimal(5,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `cgst_amount` decimal(12,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `sgst_rate` decimal(5,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `sgst_amount` decimal(12,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `igst_rate` decimal(5,2) DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `igst_amount` decimal(12,2) DEFAULT 0.00;

-- Table: roles
ALTER TABLE `roles`
  ADD COLUMN IF NOT EXISTS `department_id` int(11) DEFAULT NULL;

-- Table: shifts
ALTER TABLE `shifts`
  ADD COLUMN IF NOT EXISTS `company_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `branch_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0;

-- Table: stock_inwards
ALTER TABLE `stock_inwards`
  ADD COLUMN IF NOT EXISTS `receipt_status` tinyint(4) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `invoice_image` text DEFAULT NULL;

-- Table: stock_outward
ALTER TABLE `stock_outward`
  ADD COLUMN IF NOT EXISTS `finished_product_id` int(11) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `planned_batch_size` decimal(20,8) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `planned_batch_unit` int(11) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `dispatched_to` varchar(255) DEFAULT NULL;

-- Table: transfer_ticket
ALTER TABLE `transfer_ticket`
  ADD COLUMN IF NOT EXISTS `workflow_status` varchar(20) NOT NULL DEFAULT 'COMPLETED';

-- =============================================================================
-- SECTION 4: MODIFY COLUMN DEFINITIONS & PRECISION (MATCHING DEV MARIADB 11)
-- =============================================================================

ALTER TABLE `live_stock`
  MODIFY COLUMN `quantity_initial` decimal(20,8) DEFAULT NULL,
  MODIFY COLUMN `quantity_available` decimal(20,8) NOT NULL;

ALTER TABLE `material_requisition`
  MODIFY COLUMN `batch_size` decimal(20,8) DEFAULT NULL;

ALTER TABLE `material_requisition_items`
  MODIFY COLUMN `required_qty` decimal(20,8) DEFAULT NULL,
  MODIFY COLUMN `issued_qty` decimal(20,8) DEFAULT NULL,
  MODIFY COLUMN `returned_qty` decimal(20,8) DEFAULT NULL,
  MODIFY COLUMN `rejected_qty` decimal(20,8) DEFAULT NULL,
  MODIFY COLUMN `short_qty` decimal(20,8) DEFAULT NULL;

ALTER TABLE `production_plans`
  MODIFY COLUMN `batch_size` decimal(20,8) DEFAULT NULL;

ALTER TABLE `stock_outward_items`
  MODIFY COLUMN `issued_quantity` decimal(20,8) NOT NULL;

ALTER TABLE `order_received`
  MODIFY COLUMN `source_type` int(10) NOT NULL DEFAULT 1;

ALTER TABLE `standard_units`
  MODIFY COLUMN `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp();

-- =============================================================================
-- SECTION 5: ADD ALL MISSING INDEXES & UNIQUE KEYS
-- =============================================================================

-- bmr_bpr_request_documents
ALTER TABLE `bmr_bpr_request_documents`
  ADD UNIQUE KEY IF NOT EXISTS `uq_bmr_bpr_request_document` (`request_id`, `form_type`, `document_sequence`),
  ADD KEY IF NOT EXISTS `idx_bmr_bpr_request_document_template` (`template_id`);

-- bmr_template_product_mappings
ALTER TABLE `bmr_template_product_mappings`
  ADD UNIQUE KEY IF NOT EXISTS `uq_bmr_template_product_document` (`product_id`, `form_type`, `document_sequence`),
  ADD KEY IF NOT EXISTS `idx_bmr_template_product_requirements` (`product_id`, `form_type`, `status`, `deleted_at`);

-- fg_coa_generation
ALTER TABLE `fg_coa_generation`
  ADD KEY IF NOT EXISTS `idx_fg_coa_plan_status` (`production_plan_id`, `workflow_status`, `deleted_at`);

-- goods_received_from_production
ALTER TABLE `goods_received_from_production`
  ADD UNIQUE KEY IF NOT EXISTS `uq_goods_received_transfer_ticket` (`transfer_ticket_id`),
  ADD KEY IF NOT EXISTS `idx_goods_received_queue` (`receipt_status`, `created_at`),
  ADD KEY IF NOT EXISTS `idx_goods_received_plan` (`production_plan_id`, `lot_batch_no`),
  ADD KEY IF NOT EXISTS `idx_goods_received_product` (`product_id`, `receipt_status`);

-- hr_annual_calendars
ALTER TABLE `hr_annual_calendars`
  ADD UNIQUE KEY IF NOT EXISTS `uq_ac_company_year_revision` (`company_id`, `calendar_year`, `revision_no`),
  ADD KEY IF NOT EXISTS `idx_ac_authoritative` (`company_id`, `calendar_year`, `lifecycle_status`, `is_finalized`, `status`),
  ADD KEY IF NOT EXISTS `idx_ac_supersedes` (`supersedes_id`);

-- hr_annual_calendar_audit_events
ALTER TABLE `hr_annual_calendar_audit_events`
  ADD KEY IF NOT EXISTS `idx_ac_audit_scope` (`company_id`, `calendar_year`, `revision_no`, `changed_at`),
  ADD KEY IF NOT EXISTS `idx_ac_audit_calendar` (`calendar_id`, `changed_at`),
  ADD KEY IF NOT EXISTS `idx_ac_audit_request` (`request_id`);

-- hr_annual_calendar_custom_offs
ALTER TABLE `hr_annual_calendar_custom_offs`
  ADD UNIQUE KEY IF NOT EXISTS `uq_ac_custom_off` (`calendar_id`, `off_date`),
  ADD KEY IF NOT EXISTS `idx_ac_custom_off_date` (`off_date`);

-- hr_annual_calendar_days
ALTER TABLE `hr_annual_calendar_days`
  ADD UNIQUE KEY IF NOT EXISTS `uq_ac_day_calendar_date` (`calendar_id`, `calendar_date`),
  ADD KEY IF NOT EXISTS `idx_ac_day_company_date` (`company_id`, `calendar_date`, `day_type`);

-- hr_annual_calendar_day_overrides
ALTER TABLE `hr_annual_calendar_day_overrides`
  ADD UNIQUE KEY IF NOT EXISTS `uq_ac_day_override` (`calendar_id`, `override_date`),
  ADD KEY IF NOT EXISTS `idx_ac_day_override_date` (`override_date`);

-- hr_annual_calendar_holidays
ALTER TABLE `hr_annual_calendar_holidays`
  ADD UNIQUE KEY IF NOT EXISTS `uq_ac_holiday_identity` (`calendar_id`, `holiday_date`, `holiday_name`),
  ADD KEY IF NOT EXISTS `idx_ac_holiday_active` (`calendar_id`, `is_enabled`, `deleted_at`, `holiday_date`);

-- hr_shift_policies
ALTER TABLE `hr_shift_policies`
  ADD UNIQUE KEY IF NOT EXISTS `uq_shift_policy_scope` (`shift_id`, `company_id`, `branch_id`, `effective_from`),
  ADD KEY IF NOT EXISTS `idx_shift_policy_lookup` (`company_id`, `branch_id`, `effective_from`, `effective_to`);

-- ip_coa_generation
ALTER TABLE `ip_coa_generation`
  ADD UNIQUE KEY IF NOT EXISTS `uq_ip_coa_source_request` (`source_bmr_bpr_request_id`),
  ADD KEY IF NOT EXISTS `idx_ip_coa_plan_status` (`production_plan_id`, `workflow_status`, `deleted_at`);

-- live_stock
ALTER TABLE `live_stock`
  ADD KEY IF NOT EXISTS `idx_live_stock_production_receipt` (`production_receipt_id`);

-- order_management_audit
ALTER TABLE `order_management_audit`
  ADD KEY IF NOT EXISTS `idx_order_audit_order` (`order_id`, `created_at`),
  ADD KEY IF NOT EXISTS `idx_order_audit_item` (`order_item_id`, `created_at`),
  ADD KEY IF NOT EXISTS `idx_order_audit_user` (`user_id`, `created_at`);

-- order_received
ALTER TABLE `order_received`
  ADD UNIQUE KEY IF NOT EXISTS `uq_order_received_order_number` (`order_number`),
  ADD UNIQUE KEY IF NOT EXISTS `uq_order_received_source_reference` (`source_type`, `external_reference`),
  ADD UNIQUE KEY IF NOT EXISTS `uq_order_proforma_source` (`proforma_source`, `proforma_invoice_id`),
  ADD KEY IF NOT EXISTS `idx_order_received_customer` (`customer_id`, `deleted_at`),
  ADD KEY IF NOT EXISTS `idx_order_received_proforma` (`proforma_source`, `proforma_invoice_id`),
  ADD KEY IF NOT EXISTS `idx_order_received_received_user` (`received_by_user_id`),
  ADD KEY IF NOT EXISTS `idx_order_lead` (`lead_id`),
  ADD KEY IF NOT EXISTS `idx_order_quote` (`quotation_request_id`);

-- order_received_items
ALTER TABLE `order_received_items`
  ADD KEY IF NOT EXISTS `idx_order_received_items_product` (`product_id`),
  ADD KEY IF NOT EXISTS `idx_order_items_fulfillment` (`order_id`, `fulfillment_status`, `deleted_at`);

-- order_stock_reservations
ALTER TABLE `order_stock_reservations`
  ADD KEY IF NOT EXISTS `idx_order_reservation_order` (`order_id`, `status`),
  ADD KEY IF NOT EXISTS `idx_order_reservation_item` (`order_item_id`, `status`),
  ADD KEY IF NOT EXISTS `idx_order_reservation_stock` (`live_stock_id`, `status`),
  ADD KEY IF NOT EXISTS `idx_order_reservation_product` (`product_id`, `status`);

-- payroll_runs
ALTER TABLE `payroll_runs`
  ADD KEY IF NOT EXISTS `idx_payroll_calendar_revision` (`calendar_revision_id`);

-- pi_requests
ALTER TABLE `pi_requests`
  ADD KEY IF NOT EXISTS `idx_pi_requests_customer` (`customer_id`, `status`);

-- production_plans
ALTER TABLE `production_plans`
  ADD UNIQUE KEY IF NOT EXISTS `uq_production_plans_plan_no` (`production_plan_no`),
  ADD KEY IF NOT EXISTS `idx_production_plans_product` (`product_id`),
  ADD KEY IF NOT EXISTS `idx_production_plans_order_item_active` (`order_item_id`, `deleted_at`);

-- production_plan_bom_backfill_audit
ALTER TABLE `production_plan_bom_backfill_audit`
  ADD UNIQUE KEY IF NOT EXISTS `uq_plan_bom_backfill` (`production_plan_id`, `new_bom_master_id`),
  ADD KEY IF NOT EXISTS `idx_plan_bom_backfill_applied` (`applied_at`);

-- products
ALTER TABLE `products`
  ADD KEY IF NOT EXISTS `idx_products_product_name` (`product_name`(768));

-- proforma_invoices
ALTER TABLE `proforma_invoices`
  ADD KEY IF NOT EXISTS `idx_proforma_customer` (`customer_id`, `deleted_at`),
  ADD KEY IF NOT EXISTS `idx_pi_lead` (`lead_id`),
  ADD KEY IF NOT EXISTS `idx_pi_quote` (`quote_request_id`);

-- purchase_order_final
ALTER TABLE `purchase_order_final`
  ADD KEY IF NOT EXISTS `idx_purchase_order_final_shipment_branch` (`shipment_branch_id`);

-- purchase_order_raw
ALTER TABLE `purchase_order_raw`
  ADD KEY IF NOT EXISTS `idx_purchase_order_raw_shipment_branch` (`shipment_branch_id`);

-- roles
ALTER TABLE `roles`
  ADD KEY IF NOT EXISTS `idx_roles_department_id` (`department_id`);

-- shifts
ALTER TABLE `shifts`
  ADD KEY IF NOT EXISTS `idx_shift_scope` (`company_id`, `branch_id`, `status`);

-- stock_outward
ALTER TABLE `stock_outward`
  ADD KEY IF NOT EXISTS `idx_stock_outward_finished_product` (`finished_product_id`, `deleted_at`);

-- transfer_ticket
ALTER TABLE `transfer_ticket`
  ADD UNIQUE KEY IF NOT EXISTS `uq_transfer_source_fg` (`source_fg_coa_id`),
  ADD KEY IF NOT EXISTS `idx_transfer_plan_status` (`prod_plan_id`, `workflow_status`, `deleted_at`);

-- transfer_ticket_trace_backfill_audit
ALTER TABLE `transfer_ticket_trace_backfill_audit`
  ADD KEY IF NOT EXISTS `idx_transfer_trace_ticket` (`transfer_ticket_id`),
  ADD KEY IF NOT EXISTS `idx_transfer_trace_applied` (`applied_at`);

-- whatsapp_order_log
ALTER TABLE `whatsapp_order_log`
  ADD UNIQUE KEY IF NOT EXISTS `idx_wamid` (`wamid`);

-- whatsapp_sessions
ALTER TABLE `whatsapp_sessions`
  ADD UNIQUE KEY IF NOT EXISTS `from_phone` (`from_phone`);

-- =============================================================================
-- SECTION 6: ADD FOREIGN KEY CONSTRAINTS DYNAMICALLY (IDEMPOTENT)
-- =============================================================================

SET @fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_roles_department'),
  'SELECT 1',
  'ALTER TABLE `roles` ADD CONSTRAINT `fk_roles_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE'
);
PREPARE fk_stmt FROM @fk_sql;
EXECUTE fk_stmt;
DEALLOCATE PREPARE fk_stmt;

SET @fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_bmr_bpr_request_document_request'),
  'SELECT 1',
  'ALTER TABLE `bmr_bpr_request_documents` ADD CONSTRAINT `fk_bmr_bpr_request_document_request` FOREIGN KEY (`request_id`) REFERENCES `bmr_bpr_requests` (`id`)'
);
PREPARE fk_stmt FROM @fk_sql;
EXECUTE fk_stmt;
DEALLOCATE PREPARE fk_stmt;

SET @fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_bmr_bpr_request_document_template'),
  'SELECT 1',
  'ALTER TABLE `bmr_bpr_request_documents` ADD CONSTRAINT `fk_bmr_bpr_request_document_template` FOREIGN KEY (`template_id`) REFERENCES `bmr_templates` (`id`)'
);
PREPARE fk_stmt FROM @fk_sql;
EXECUTE fk_stmt;
DEALLOCATE PREPARE fk_stmt;

SET @fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_ac_custom_off_calendar'),
  'SELECT 1',
  'ALTER TABLE `hr_annual_calendar_custom_offs` ADD CONSTRAINT `fk_ac_custom_off_calendar` FOREIGN KEY (`calendar_id`) REFERENCES `hr_annual_calendars` (`id`) ON DELETE CASCADE ON UPDATE CASCADE'
);
PREPARE fk_stmt FROM @fk_sql;
EXECUTE fk_stmt;
DEALLOCATE PREPARE fk_stmt;

SET @fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_ac_day_calendar'),
  'SELECT 1',
  'ALTER TABLE `hr_annual_calendar_days` ADD CONSTRAINT `fk_ac_day_calendar` FOREIGN KEY (`calendar_id`) REFERENCES `hr_annual_calendars` (`id`) ON UPDATE CASCADE'
);
PREPARE fk_stmt FROM @fk_sql;
EXECUTE fk_stmt;
DEALLOCATE PREPARE fk_stmt;

SET @fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_ac_day_override_calendar'),
  'SELECT 1',
  'ALTER TABLE `hr_annual_calendar_day_overrides` ADD CONSTRAINT `fk_ac_day_override_calendar` FOREIGN KEY (`calendar_id`) REFERENCES `hr_annual_calendars` (`id`) ON DELETE CASCADE ON UPDATE CASCADE'
);
PREPARE fk_stmt FROM @fk_sql;
EXECUTE fk_stmt;
DEALLOCATE PREPARE fk_stmt;

SET @fk_sql = IF(
  EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'fk_shift_policy_shift'),
  'SELECT 1',
  'ALTER TABLE `hr_shift_policies` ADD CONSTRAINT `fk_shift_policy_shift` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE'
);
PREPARE fk_stmt FROM @fk_sql;
EXECUTE fk_stmt;
DEALLOCATE PREPARE fk_stmt;

-- =============================================================================
-- SECTION 7: LEGACY DEV SNAPSHOT TABLES (EMPTY STRUCTURE MATCHING DEV)
-- =============================================================================

CREATE TABLE IF NOT EXISTS `order_received_20260817` LIKE `order_received`;
CREATE TABLE IF NOT EXISTS `purchase_order_final_20260817` LIKE `purchase_order_final`;
CREATE TABLE IF NOT EXISTS `stock_inwards_20260817` LIKE `stock_inwards`;
CREATE TABLE IF NOT EXISTS `suppliers_backup_20260817` LIKE `suppliers`;
CREATE TABLE IF NOT EXISTS `tender_vendors_backup_20260817` LIKE `tender_vendors`;

CREATE TABLE IF NOT EXISTS `_schema_migrations_applied` (
    `migration` VARCHAR(255) PRIMARY KEY,
    `applied_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `_schema_migrations_applied` (`migration`, `applied_at`)
SELECT '2026_09_04_001_complete_schema_sync_pending.sql', NOW()
WHERE NOT EXISTS (
    SELECT 1
    FROM `_schema_migrations_applied`
    WHERE `migration` IN ('2026_09_04_001_complete_schema_sync_pending.sql', '2026_09_04_001_complete_schema_sync.sql')
);

COMMIT;
SET FOREIGN_KEY_CHECKS = 1;
