<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$migrationPath = __DIR__ . '/2026_09_01_002_salary_statutory_rules_pending.sql';
$sql = file_get_contents($migrationPath);
if ($sql === false || trim($sql) === '') {
    fwrite(STDERR, "Salary statutory rules migration is unavailable.\n");
    exit(1);
}

if (!$conn->multi_query($sql)) {
    fwrite(STDERR, 'Salary statutory rules migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}
while (true) {
    if ($result = $conn->store_result()) $result->free();
    if ($conn->errno !== 0) {
        fwrite(STDERR, 'Salary statutory rules migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
    if (!$conn->more_results()) break;
    if (!$conn->next_result()) {
        fwrite(STDERR, 'Salary statutory rules migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
}

$requiredColumns = [
    ['hr_employee_profiles', 'pf_category'],
    ['employee_salaries', 'pf_category'],
    ['employee_salaries', 'pf'],
    ['employee_salaries', 'esi'],
];
foreach ($requiredColumns as [$tableName, $columnName]) {
    $columnCheck = $conn->query("SHOW COLUMNS FROM `{$tableName}` LIKE '{$columnName}'");
    if (!$columnCheck || $columnCheck->num_rows !== 1) {
        fwrite(STDERR, "Salary rule column verification failed for {$tableName}.{$columnName}.\n");
        exit(1);
    }
}

echo "Salary statutory rules migration applied and verified successfully.\n";