<?php

/**
 * Creates and optionally finalizes Annual Calendars for every active company so
 * payroll, leave and attendance have the mandatory master calendar available.
 *
 * Usage:
 *   php bootstrap_annual_calendars.php --years=2025,2026 [--company=3] [--user=1] [--finalize] [--dry-run]
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

if (!isset($conn) || !$conn instanceof mysqli) {
    require_once dirname(__DIR__) . '/db.php';
}

if (!defined('HRMS_CONTEXT')) {
    define('HRMS_CONTEXT', true);
}
require_once dirname(__DIR__) . '/hrms/annual_calendar_common.php';

$options = getopt('', ['years::', 'company::', 'user::', 'finalize', 'dry-run']);
$years = array_values(array_unique(array_filter(
    array_map('intval', explode(',', (string) ($options['years'] ?? date('Y')))),
    static fn(int $year): bool => $year >= 2020 && $year <= 2100
)));
sort($years);
if ($years === []) {
    fwrite(STDERR, "Provide at least one valid year via --years.\n");
    exit(1);
}
$onlyCompanyId = isset($options['company']) ? (int) $options['company'] : 0;
$userId = isset($options['user']) ? (int) $options['user'] : 1;
$shouldFinalize = array_key_exists('finalize', $options);
$dryRun = array_key_exists('dry-run', $options);

if (!acProductionSchemaReady($conn)) {
    fwrite(STDERR, "Annual Calendar production migration has not been applied.\n");
    exit(1);
}

$companySql = 'SELECT id, company_name FROM erp_companies WHERE status = 1 AND deleted_at IS NULL';
if ($onlyCompanyId > 0) {
    $companySql .= ' AND id = ' . $onlyCompanyId;
}
$companySql .= ' ORDER BY id';
$companies = $conn->query($companySql)?->fetch_all(MYSQLI_ASSOC) ?? [];
if ($companies === []) {
    fwrite(STDERR, "No active companies were found.\n");
    exit(1);
}

$legacyHolidaysAvailable = acTableExists($conn, 'holidays');
$legacyTypeMap = [1 => 'national', 2 => 'company', 3 => 'festival', 4 => 'restricted', 5 => 'other'];

/** Legacy holiday rows are global, so every company inherits them as a starting draft. */
$legacyHolidaysForYear = static function (mysqli $conn, int $year) use ($legacyHolidaysAvailable, $legacyTypeMap): array {
    if (!$legacyHolidaysAvailable) {
        return [];
    }
    $first = "{$year}-01-01";
    $last = "{$year}-12-31";
    $stmt = $conn->prepare(
        'SELECT holiday_date, name, type FROM holidays
         WHERE holiday_date BETWEEN ? AND ? AND status = 1 AND deleted_at IS NULL
         ORDER BY holiday_date'
    );
    $stmt->bind_param('ss', $first, $last);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return array_map(
        static fn(array $row): array => [
            'date' => (string) $row['holiday_date'],
            'name' => trim((string) $row['name']) !== '' ? trim((string) $row['name']) : 'Company Holiday',
            'type' => $legacyTypeMap[(int) $row['type']] ?? 'other',
            'source_name' => 'Legacy holidays table migration',
            'source_version' => date('Y-m-d'),
        ],
        $rows
    );
};

$created = 0;
$finalized = 0;
$skipped = 0;

foreach ($companies as $company) {
    $companyId = (int) $company['id'];
    foreach ($years as $year) {
        $existing = acGetCalendarForYear($conn, $companyId, $year);
        if ($existing) {
            $status = $existing['lifecycle_status'];
            echo "SKIP  company={$companyId} year={$year} (existing {$status} revision #{$existing['revision_no']})\n";
            $skipped++;
            continue;
        }
        if ($dryRun) {
            echo "PLAN  company={$companyId} year={$year} would be created"
                . ($shouldFinalize ? ' and finalized' : '') . "\n";
            continue;
        }

        $conn->begin_transaction();
        try {
            $policy = 'all_working';
            $weeklyOffDays = '7';
            $sourceName = 'Bootstrap migration';
            $sourceVersion = date('Y-m-d');
            $hasWeeklyOffColumn = acColumnExists($conn, 'hr_annual_calendars', 'weekly_off_days');
            $insertSql = $hasWeeklyOffColumn
                ? "INSERT INTO hr_annual_calendars
                   (company_id, calendar_year, revision_no, saturday_policy, weekly_off_days, lifecycle_status,
                    status, created_by, created_at, source_name, source_version)
                   VALUES (?, ?, 1, ?, ?, 'draft', 1, ?, NOW(), ?, ?)"
                : "INSERT INTO hr_annual_calendars
                   (company_id, calendar_year, revision_no, saturday_policy, lifecycle_status,
                    status, created_by, created_at, source_name, source_version)
                   VALUES (?, ?, 1, ?, 'draft', 1, ?, NOW(), ?, ?)";
            $stmt = $conn->prepare($insertSql);
            if ($hasWeeklyOffColumn) {
                $stmt->bind_param('iississ', $companyId, $year, $policy, $weeklyOffDays, $userId, $sourceName, $sourceVersion);
            } else {
                $stmt->bind_param('iisiss', $companyId, $year, $policy, $userId, $sourceName, $sourceVersion);
            }
            if (!$stmt->execute()) {
                throw new RuntimeException('Unable to create the calendar: ' . $conn->error);
            }
            $calendarId = (int) $stmt->insert_id;
            $stmt->close();

            $hasOptionalColumn = acColumnExists($conn, 'hr_annual_calendar_holidays', 'is_optional');
            $insertHoliday = $conn->prepare(
                $hasOptionalColumn
                    ? 'INSERT IGNORE INTO hr_annual_calendar_holidays
                       (calendar_id, holiday_date, holiday_name, holiday_type, source_name, source_version, is_enabled, is_optional, created_by, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, NOW())'
                    : 'INSERT IGNORE INTO hr_annual_calendar_holidays
                       (calendar_id, holiday_date, holiday_name, holiday_type, source_name, source_version, is_enabled, created_by, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, 1, ?, NOW())'
            );

            $imported = 0;
            $seed = array_merge(acGetIndianHolidays($year), $legacyHolidaysForYear($conn, $year));
            foreach ($seed as $holiday) {
                $date = (string) $holiday['date'];
                $name = (string) $holiday['name'];
                $type = (string) $holiday['type'];
                $holidaySource = (string) $holiday['source_name'];
                $holidayVersion = (string) $holiday['source_version'];
                $optional = $type === 'restricted' ? 1 : 0;
                if ($hasOptionalColumn) {
                    $insertHoliday->bind_param('isssssii', $calendarId, $date, $name, $type, $holidaySource, $holidayVersion, $optional, $userId);
                } else {
                    $insertHoliday->bind_param('isssssi', $calendarId, $date, $name, $type, $holidaySource, $holidayVersion, $userId);
                }
                $insertHoliday->execute();
                $imported += max(0, $insertHoliday->affected_rows);
            }
            $insertHoliday->close();

            $totals = acRecalculateWorkingDays($conn, $calendarId);
            acLogAudit(
                $conn,
                $calendarId,
                'bootstrap',
                null,
                null,
                'draft revision 1',
                $userId,
                "Bootstrapped from reference and legacy holiday data ({$imported} holiday(s)). HR must verify before finalization."
            );
            $conn->commit();
            $created++;
            echo "CREATE company={$companyId} year={$year} calendar={$calendarId} holidays={$imported}"
                . " working_days={$totals['total_working_days']}\n";
        } catch (Throwable $error) {
            $conn->rollback();
            fwrite(STDERR, "FAIL  company={$companyId} year={$year}: " . $error->getMessage() . "\n");
            continue;
        }

        if ($shouldFinalize) {
            try {
                $result = acFinalizeCalendar($conn, $calendarId, $userId);
                $finalized++;
                echo "FINAL company={$companyId} year={$year} calendar={$calendarId}"
                    . " working_days={$result['totals']['total_working_days']} hash={$result['content_hash']}\n";
            } catch (Throwable $error) {
                fwrite(STDERR, "FAIL  finalize company={$companyId} year={$year}: " . $error->getMessage() . "\n");
            }
        }
    }
}

echo "\nDone. created={$created} finalized={$finalized} skipped={$skipped}\n";
if (!$shouldFinalize && !$dryRun) {
    echo "Drafts were created but NOT finalized. HR must review and finalize before payroll can run.\n";
}
