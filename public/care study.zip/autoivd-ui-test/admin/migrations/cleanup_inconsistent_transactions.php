<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') exit("CLI only.\n");
chdir(dirname(__DIR__));
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../constant.php';
require_once __DIR__ . '/../functions.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$execute = in_array('--execute', $argv, true);
$conn->set_charset('utf8mb4');
$conn->query("CREATE TABLE IF NOT EXISTS transaction_cleanup_archive (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, cleanup_run_id CHAR(36) NOT NULL, source_table VARCHAR(80) NOT NULL, source_id BIGINT NOT NULL, row_json LONGTEXT NOT NULL, deleted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY idx_cleanup_run (cleanup_run_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$roots=[];
$res=$conn->query("SELECT DISTINCT o.id FROM order_received o JOIN order_received_items i ON i.order_id=o.id AND i.deleted_at IS NULL WHERE o.deleted_at IS NULL AND ((o.status=13 AND i.shortfall_quantity>0) OR (i.fulfillment_status IN ('stock_available','ready_for_dispatch') AND i.shortfall_quantity>0)) ORDER BY o.id");
while($row=$res->fetch_assoc())$roots[]=(int)$row['id'];
$orphans=[];
$res=$conn->query("SELECT ls.id FROM low_stocks ls WHERE ls.deleted_at IS NULL AND NOT EXISTS (SELECT 1 FROM products p WHERE p.id=ls.product_id) ORDER BY ls.id");
while($row=$res->fetch_assoc())$orphans[]=(int)$row['id'];
echo 'Inconsistent order roots: '.count($roots).PHP_EOL;
echo 'Orphan active low-stock rows: '.count($orphans).PHP_EOL;
if(!$execute){echo 'Dry run only. IDs: '.($roots?implode(',',$roots):'(none)').PHP_EOL;exit(0);}
$runId=date('YmdHis').'-'.bin2hex(random_bytes(4));
$conn->begin_transaction();
try{
 $archive=$conn->prepare('INSERT INTO transaction_cleanup_archive (cleanup_run_id,source_table,source_id,row_json) VALUES (?,?,?,?)');
 $remove=static function(mysqli $db,mysqli_stmt $archive,string $table,string $where,string $types,array $params)use($runId):int{
  $s=$db->prepare("SELECT * FROM `$table` WHERE $where FOR UPDATE");$s->bind_param($types,...$params);$s->execute();$rows=$s->get_result()->fetch_all(MYSQLI_ASSOC);$s->close();
  foreach($rows as $row){$id=(int)($row['id']??0);$json=json_encode($row,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);$archive->bind_param('ssis',$runId,$table,$id,$json);$archive->execute();}
  if(!$rows)return 0;$d=$db->prepare("DELETE FROM `$table` WHERE $where");$d->bind_param($types,...$params);$d->execute();$n=$d->affected_rows;$d->close();return $n;
 };
 $deleted=0;
 foreach($roots as $orderId){
  $c=$conn->prepare('SELECT purchase_invoice FROM order_received WHERE id=? FOR UPDATE');$c->bind_param('i',$orderId);$c->execute();$invoice=(string)($c->get_result()->fetch_assoc()['purchase_invoice']??'');$c->close();
  if($invoice!=='')throw new RuntimeException("Order {$orderId} has finance reference {$invoice}; cleanup stopped.");
  $deleted+=$remove($conn,$archive,'order_stock_reservations','order_id=?','i',[$orderId]);
  $deleted+=$remove($conn,$archive,'stock_outward_items','order_item_id IN (SELECT id FROM order_received_items WHERE order_id=?)','i',[$orderId]);
  $deleted+=$remove($conn,$archive,'order_management_audit','order_id=?','i',[$orderId]);
  $deleted+=$remove($conn,$archive,'order_received_items','order_id=?','i',[$orderId]);
  $deleted+=$remove($conn,$archive,'order_received','id=?','i',[$orderId]);
 }
 foreach($orphans as $id)$deleted+=$remove($conn,$archive,'low_stocks','id=?','i',[$id]);
 $archive->close();$conn->commit();echo "Cleanup committed. Run {$runId}; deleted rows: {$deleted}.\n";
}catch(Throwable $e){$conn->rollback();fwrite(STDERR,'Cleanup rolled back: '.$e->getMessage().PHP_EOL);exit(1);}