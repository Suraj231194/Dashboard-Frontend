-- Additive support for more than one required BMR/BPR document per product.

ALTER TABLE `bmr_template_product_mappings`
    ADD COLUMN IF NOT EXISTS `document_sequence` INT UNSIGNED NOT NULL DEFAULT 1,
    ADD COLUMN IF NOT EXISTS `required_quantity` INT UNSIGNED NOT NULL DEFAULT 1;

CREATE UNIQUE INDEX IF NOT EXISTS `uq_bmr_template_product_document`
    ON `bmr_template_product_mappings` (`product_id`, `form_type`, `document_sequence`);

DROP INDEX IF EXISTS `uq_bmr_template_product_form`
    ON `bmr_template_product_mappings`;

CREATE INDEX IF NOT EXISTS `idx_bmr_template_product_requirements`
    ON `bmr_template_product_mappings`
       (`product_id`, `form_type`, `status`, `deleted_at`);
