CREATE TABLE IF NOT EXISTS template_snapshots (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    snapshot_uuid CHAR(36) NOT NULL,
    document_type ENUM('BMR', 'BPR', 'IP_COA', 'FG_COA') NOT NULL,
    source_template_id BIGINT NOT NULL,
    template_code VARCHAR(100) NOT NULL,
    template_name VARCHAR(255) NOT NULL,
    document_no VARCHAR(100) DEFAULT NULL,
    version_no VARCHAR(50) DEFAULT NULL,
    issue_no VARCHAR(50) DEFAULT NULL,
    effective_date DATE DEFAULT NULL,
    product_id INT DEFAULT NULL,
    product_name VARCHAR(255) NOT NULL,
    batch_number VARCHAR(100) DEFAULT NULL,
    lot_number VARCHAR(100) DEFAULT NULL,
    pack_size VARCHAR(100) DEFAULT NULL,
    family_key VARCHAR(100) DEFAULT NULL,
    profile_name VARCHAR(255) DEFAULT NULL,
    selection_source ENUM('PREMAPPED', 'RECOMMENDED', 'MANUAL_OVERRIDE') NOT NULL DEFAULT 'PREMAPPED',
    renderer VARCHAR(50) NOT NULL,
    renderer_variant VARCHAR(50) DEFAULT NULL,
    schema_version INT UNSIGNED NOT NULL DEFAULT 1,
    layout_json LONGTEXT NOT NULL,
    profile_json LONGTEXT NOT NULL,
    metadata_json LONGTEXT DEFAULT NULL,
    checksum CHAR(64) NOT NULL,
    created_by_user_id INT NOT NULL,
    created_by_user_name VARCHAR(255) NOT NULL,
    created_by_user_email VARCHAR(255) DEFAULT NULL,
    created_at_ist VARCHAR(50) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_template_snapshot_uuid (snapshot_uuid),
    KEY idx_template_snapshot_document (document_type, source_template_id),
    KEY idx_template_snapshot_product (product_id),
    KEY idx_template_snapshot_batch (batch_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE bmr_bpr_request_documents
    ADD COLUMN IF NOT EXISTS template_snapshot_id BIGINT UNSIGNED DEFAULT NULL AFTER template_id,
    ADD KEY IF NOT EXISTS idx_bmr_request_document_snapshot (template_snapshot_id);

ALTER TABLE bmr_bpr_work_items
    ADD COLUMN IF NOT EXISTS template_snapshot_id BIGINT UNSIGNED DEFAULT NULL AFTER template_id,
    ADD KEY IF NOT EXISTS idx_bmr_work_item_snapshot (template_snapshot_id);

ALTER TABLE ip_coa_generation
    ADD COLUMN IF NOT EXISTS template_snapshot_id BIGINT UNSIGNED DEFAULT NULL AFTER coa_template_id,
    ADD COLUMN IF NOT EXISTS family_key VARCHAR(100) DEFAULT NULL AFTER template_snapshot_id,
    ADD KEY IF NOT EXISTS idx_ip_coa_snapshot (template_snapshot_id);

ALTER TABLE fg_coa_generation
    ADD COLUMN IF NOT EXISTS template_snapshot_id BIGINT UNSIGNED DEFAULT NULL AFTER coa_template_id,
    ADD COLUMN IF NOT EXISTS family_key VARCHAR(100) DEFAULT NULL AFTER template_snapshot_id,
    ADD KEY IF NOT EXISTS idx_fg_coa_snapshot (template_snapshot_id);

ALTER TABLE bmr_bpr_request_documents
    ADD CONSTRAINT fk_bmr_request_document_snapshot
    FOREIGN KEY (template_snapshot_id) REFERENCES template_snapshots(id);
ALTER TABLE bmr_bpr_work_items
    ADD CONSTRAINT fk_bmr_work_item_snapshot
    FOREIGN KEY (template_snapshot_id) REFERENCES template_snapshots(id);
ALTER TABLE ip_coa_generation
    ADD CONSTRAINT fk_ip_coa_snapshot
    FOREIGN KEY (template_snapshot_id) REFERENCES template_snapshots(id);
ALTER TABLE fg_coa_generation
    ADD CONSTRAINT fk_fg_coa_snapshot
    FOREIGN KEY (template_snapshot_id) REFERENCES template_snapshots(id);
