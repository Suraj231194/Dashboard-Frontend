-- Procurement flow completion: quantity precision and idempotent goods receipts.
-- Existing production data was checked for duplicate request-to-PO links before
-- these constraints were introduced.

CREATE TABLE IF NOT EXISTS `procurement_settings` (
    `id` TINYINT UNSIGNED NOT NULL,
    `low_stock_aging_days` TINYINT UNSIGNED NOT NULL DEFAULT 30,
    `updated_by` INT NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT `chk_procurement_aging_days` CHECK (`low_stock_aging_days` IN (30, 60))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `procurement_settings` (`id`, `low_stock_aging_days`)
VALUES (1, 30)
ON DUPLICATE KEY UPDATE
    `low_stock_aging_days` = IF(`low_stock_aging_days` IN (30, 60), `low_stock_aging_days`, 30);

ALTER TABLE `low_stocks`
    MODIFY COLUMN `required_qty` DECIMAL(20,8) NOT NULL;

ALTER TABLE `stock_inwards`
    MODIFY COLUMN `prod_quantity` DECIMAL(20,8) NULL,
    ADD COLUMN IF NOT EXISTS `receipt_submission_token` VARCHAR(64) NULL AFTER `receipt_status`;

ALTER TABLE `purchase_order_final`
    MODIFY COLUMN `quantity_required` DECIMAL(20,8) NULL;

ALTER TABLE `purchase_order_raw_items`
    ADD COLUMN IF NOT EXISTS `quantity_required_decimal` DECIMAL(20,8) NULL AFTER `quantity_required`;

UPDATE `purchase_order_raw_items`
SET `quantity_required_decimal` = CAST(TRIM(`quantity_required`) AS DECIMAL(20,8))
WHERE `quantity_required_decimal` IS NULL
  AND TRIM(`quantity_required`) REGEXP '^[0-9]+([.][0-9]+)?$';

ALTER TABLE `coa_rm_pm_table`
    MODIFY COLUMN `batch_qty` DECIMAL(20,8) NULL;

UPDATE `live_stock` AS `stock`
INNER JOIN `standard_units` AS `unit` ON `unit`.`id` = `stock`.`quantity_unit`
SET `stock`.`unit_factor` = `unit`.`factor`
WHERE `unit`.`factor` > 0
  AND ABS(`stock`.`unit_factor` - `unit`.`factor`) > 0.00000001;

ALTER TABLE `coa_templates`
    ADD COLUMN IF NOT EXISTS `product_id` INT NULL AFTER `prod_categ_id`;

CREATE INDEX IF NOT EXISTS `idx_coa_templates_product`
    ON `coa_templates` (`product_id`, `status`, `deleted_at`);

CREATE UNIQUE INDEX IF NOT EXISTS `uq_stock_inward_submission_item`
    ON `stock_inwards` (`receipt_submission_token`, `po_type`, `po_id`);

CREATE UNIQUE INDEX IF NOT EXISTS `uq_coa_inbound_stock_inward`
    ON `coa_inbound_queue` (`stock_inward_id`);

CREATE UNIQUE INDEX IF NOT EXISTS `uq_purchase_order_final_request`
    ON `purchase_order_final` (`low_stock_id`);

CREATE UNIQUE INDEX IF NOT EXISTS `uq_purchase_order_raw_item_request`
    ON `purchase_order_raw_items` (`low_stock_id`);
