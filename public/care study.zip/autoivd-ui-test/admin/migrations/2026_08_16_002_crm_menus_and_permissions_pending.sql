-- =============================================================================
-- Sales & CRM Module – Menus & Permissions Migration
-- Created: 2026-08-16
-- Description: Adds CRM sidebar menus and permission slugs.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. Parent Menu: Sales & CRM
-- ---------------------------------------------------------------------------
INSERT INTO `menus` (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`, `created_by`, `created_at`)
SELECT 'Sales & CRM', '#', 'ti ti-briefcase', 0, 45, NULL, 1, 1, 1, NOW()
WHERE NOT EXISTS (
  SELECT 1 FROM `menus` WHERE `name` = 'Sales & CRM' AND `parent_id` = 0 AND `deleted_at` IS NULL
);

UPDATE `menus`
SET `status` = 1, `showmenu` = 1, `deleted_at` = NULL, `deleted_by` = NULL
WHERE `name` = 'Sales & CRM' AND `parent_id` = 0;

-- ---------------------------------------------------------------------------
-- 2. Child Menus
-- ---------------------------------------------------------------------------
INSERT INTO `menus` (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`, `created_by`, `created_at`)
SELECT 'Lead Management', 'index.php?page=lead-management', 'ti ti-user-plus', id, 10, 'crm_lead_management_menu_list', 1, 1, 1, NOW()
FROM `menus` parent
WHERE parent.`name` = 'Sales & CRM'
  AND NOT EXISTS (SELECT 1 FROM `menus` child WHERE child.`route` = 'index.php?page=lead-management')
LIMIT 1;

INSERT INTO `menus` (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`, `created_by`, `created_at`)
SELECT 'Salesperson Master', 'index.php?page=salesperson-master', 'ti ti-id-badge-2', id, 20, 'crm_salesperson_master_menu_list', 1, 1, 1, NOW()
FROM `menus` parent
WHERE parent.`name` = 'Sales & CRM'
  AND NOT EXISTS (SELECT 1 FROM `menus` child WHERE child.`route` = 'index.php?page=salesperson-master')
LIMIT 1;

INSERT INTO `menus` (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`, `showmenu`, `status`, `created_by`, `created_at`)
SELECT 'CRM Quotes', 'index.php?page=crm-quote-management', 'ti ti-file-text', id, 30, 'crm_quote_menu_list', 1, 1, 1, NOW()
FROM `menus` parent
WHERE parent.`name` = 'Sales & CRM'
  AND NOT EXISTS (SELECT 1 FROM `menus` child WHERE child.`route` = 'index.php?page=crm-quote-management')
LIMIT 1;

-- ---------------------------------------------------------------------------
-- 3. Permissions
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO `permissions` (`name`, `slug`, `status`, `created_by`, `created_at`)
VALUES
  -- Lead Management
  ('CRM Lead Management Menu', 'crm_lead_management_menu_list', 1, 1, NOW()),
  ('CRM Lead Add', 'crm_lead_add', 1, 1, NOW()),
  ('CRM Lead Edit', 'crm_lead_edit', 1, 1, NOW()),
  ('CRM Lead Delete', 'crm_lead_delete', 1, 1, NOW()),
  ('CRM Lead Accept', 'crm_lead_accept', 1, 1, NOW()),
  ('CRM Lead Reject', 'crm_lead_reject', 1, 1, NOW()),
  ('CRM Lead Assign', 'crm_lead_assign', 1, 1, NOW()),
  -- Salesperson
  ('CRM Salesperson Master Menu', 'crm_salesperson_master_menu_list', 1, 1, NOW()),
  ('CRM Salesperson Add', 'crm_salesperson_add', 1, 1, NOW()),
  ('CRM Salesperson Edit', 'crm_salesperson_edit', 1, 1, NOW()),
  ('CRM Salesperson Delete', 'crm_salesperson_delete', 1, 1, NOW()),
  -- CRM Quotes
  ('CRM Quote Menu', 'crm_quote_menu_list', 1, 1, NOW()),
  ('CRM Quote Add', 'crm_quote_add', 1, 1, NOW()),
  ('CRM Quote Edit', 'crm_quote_edit', 1, 1, NOW()),
  ('CRM Quote Delete', 'crm_quote_delete', 1, 1, NOW()),
  -- Sales Order / PI
  ('CRM Sales Order Download', 'crm_sales_order_download', 1, 1, NOW()),
  ('CRM PI Convert to Order', 'crm_pi_convert_to_order', 1, 1, NOW());

-- Grant the Sales & CRM permissions to existing administrator and sales roles.
-- Other roles remain opt-in through User/Role Management.
INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT r.`id`, p.`id`, 1
FROM `roles` r
CROSS JOIN `permissions` p
WHERE r.`deleted_at` IS NULL
  AND r.`name` IN (
    'Super Administrator', 'Administrator', 'Senior Administrator',
    'Sales and Marketing', 'Production + Ops /Admin + Sales & Billing',
    'Sales & Marketting + Sales & Billing'
  )
  AND p.`slug` LIKE 'crm\_%';
