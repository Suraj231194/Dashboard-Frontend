-- =============================================================================
-- Migration: 2026_09_05_001_low_stock_aging_pending.sql
-- Purpose: Add low_stock_entered_at column to products to track low-stock aging
-- Standard: Idempotent, non-destructive
-- =============================================================================

SET @products_low_stock_entered_at_exists := (
    SELECT COUNT(*)
    FROM `information_schema`.`COLUMNS`
    WHERE `TABLE_SCHEMA` = DATABASE()
      AND `TABLE_NAME` = 'products'
      AND `COLUMN_NAME` = 'low_stock_entered_at'
);

SET @products_low_stock_entered_at_sql := IF(
    @products_low_stock_entered_at_exists = 1,
    'SELECT ''products.low_stock_entered_at already exists'' AS migration_status',
    'ALTER TABLE `products` ADD COLUMN `low_stock_entered_at` DATETIME NULL DEFAULT NULL AFTER `reorder_level`'
);

PREPARE products_low_stock_stmt FROM @products_low_stock_entered_at_sql;
EXECUTE products_low_stock_stmt;
DEALLOCATE PREPARE products_low_stock_stmt;

INSERT INTO `_schema_migrations_applied` (`migration`, `applied_at`)
SELECT '2026_09_05_001_low_stock_aging_pending.sql', NOW()
WHERE NOT EXISTS (
    SELECT 1
    FROM `_schema_migrations_applied`
    WHERE `migration` IN ('2026_09_05_001_low_stock_aging_pending.sql', '2026_09_05_001_low_stock_aging.sql')
);
