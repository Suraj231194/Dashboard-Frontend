<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$apply = in_array('--apply', $argv, true);
$actorId = 1;

function normalizeProductionProductName(string $value): string
{
    $value = mb_strtolower(trim($value));
    return preg_replace('/\s+/u', ' ', $value) ?: $value;
}

function productionPlanBomBackfillCandidates(mysqli $conn): array
{
    $productsById = [];
    $productIdsByName = [];
    $productResult = $conn->query(
        "SELECT id, product_name
         FROM products
         WHERE status = 1 AND deleted_at IS NULL"
    );
    if (!$productResult) {
        throw new RuntimeException('Unable to load active products: ' . $conn->error);
    }
    while ($product = $productResult->fetch_assoc()) {
        $productId = (int) $product['id'];
        $productsById[$productId] = $product;
        $nameKey = normalizeProductionProductName((string) $product['product_name']);
        if ($nameKey !== '') {
            $productIdsByName[$nameKey][] = $productId;
        }
    }

    // Production uses the latest active BOM. Requiring at least one active,
    // valid material line prevents linking a plan to an empty BOM shell.
    $validBomsByProduct = [];
    $bomResult = $conn->query(
        "SELECT bom.id, bom.finished_product_id
         FROM bom_master bom
         WHERE bom.status = 1
           AND bom.deleted_at IS NULL
           AND EXISTS (
               SELECT 1
               FROM bom_items item
               INNER JOIN products raw_product
                   ON raw_product.id = item.raw_product_id
                  AND raw_product.status = 1
                  AND raw_product.deleted_at IS NULL
               WHERE item.bom_id = bom.id
                 AND item.status = 1
                 AND item.deleted_at IS NULL
           )
         ORDER BY bom.id DESC"
    );
    if (!$bomResult) {
        throw new RuntimeException('Unable to load active BOMs: ' . $conn->error);
    }
    while ($bom = $bomResult->fetch_assoc()) {
        $productId = (int) $bom['finished_product_id'];
        if (!isset($validBomsByProduct[$productId])) {
            $validBomsByProduct[$productId] = (int) $bom['id'];
        }
    }

    $planResult = $conn->query(
        "SELECT plan.id, plan.production_plan_no, plan.product_id, plan.name,
                plan.bom_master_id, plan.updated_by, plan.updated_at
         FROM production_plans plan
         LEFT JOIN bom_master current_bom ON current_bom.id = plan.bom_master_id
         WHERE plan.status != 3
           AND (
               plan.bom_master_id IS NULL
               OR plan.bom_master_id = 0
               OR current_bom.id IS NULL
               OR current_bom.finished_product_id <> plan.product_id
               OR current_bom.status <> 1
               OR current_bom.deleted_at IS NOT NULL
           )
         ORDER BY plan.id ASC"
    );
    if (!$planResult) {
        throw new RuntimeException('Unable to load Production Plans: ' . $conn->error);
    }

    $candidates = [];
    $unresolved = [
        'missing_or_ambiguous_product' => 0,
        'no_valid_active_bom' => 0,
    ];
    $inspected = 0;
    while ($plan = $planResult->fetch_assoc()) {
        $inspected++;
        $oldProductId = (int) ($plan['product_id'] ?? 0);
        $productId = $oldProductId;
        $matchMethod = 'existing_product_id';

        if ($productId <= 0 || !isset($productsById[$productId])) {
            $nameKey = normalizeProductionProductName((string) ($plan['name'] ?? ''));
            $matchingProductIds = $productIdsByName[$nameKey] ?? [];
            if (count($matchingProductIds) !== 1) {
                $unresolved['missing_or_ambiguous_product']++;
                continue;
            }
            $productId = (int) $matchingProductIds[0];
            $matchMethod = 'exact_normalized_product_name';
        }

        $bomId = (int) ($validBomsByProduct[$productId] ?? 0);
        if ($bomId <= 0) {
            $unresolved['no_valid_active_bom']++;
            continue;
        }

        $candidates[] = [
            'production_plan_id' => (int) $plan['id'],
            'production_plan_no' => (string) ($plan['production_plan_no'] ?? ''),
            'old_product_id' => $oldProductId ?: null,
            'new_product_id' => $productId,
            'old_bom_master_id' => (int) ($plan['bom_master_id'] ?? 0),
            'new_bom_master_id' => $bomId,
            'old_updated_by' => isset($plan['updated_by']) ? (int) $plan['updated_by'] : null,
            'old_updated_at' => $plan['updated_at'] ?? null,
            'match_method' => $matchMethod,
        ];
    }

    return [
        'inspected' => $inspected,
        'candidates' => $candidates,
        'unresolved' => $unresolved,
    ];
}

try {
    $analysis = productionPlanBomBackfillCandidates($conn);
    if (!$apply) {
        echo json_encode([
            'mode' => 'preview',
            'inspected' => $analysis['inspected'],
            'eligible' => count($analysis['candidates']),
            'unresolved' => $analysis['unresolved'],
            'candidates' => $analysis['candidates'],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), PHP_EOL;
        exit;
    }

    $conn->query(
        "CREATE TABLE IF NOT EXISTS production_plan_bom_backfill_audit (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            production_plan_id int(11) NOT NULL,
            production_plan_no varchar(80) DEFAULT NULL,
            old_product_id int(11) DEFAULT NULL,
            new_product_id int(11) NOT NULL,
            old_bom_master_id int(11) DEFAULT NULL,
            new_bom_master_id int(11) NOT NULL,
            old_updated_by int(11) DEFAULT NULL,
            old_updated_at datetime DEFAULT NULL,
            match_method varchar(60) NOT NULL,
            applied_by int(11) NOT NULL,
            applied_at datetime NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (id),
            UNIQUE KEY uq_plan_bom_backfill (production_plan_id, new_bom_master_id),
            KEY idx_plan_bom_backfill_applied (applied_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
    if ($conn->errno) {
        throw new RuntimeException('Unable to create the BOM backfill audit table: ' . $conn->error);
    }

    $auditStmt = $conn->prepare(
        "INSERT INTO production_plan_bom_backfill_audit
            (production_plan_id, production_plan_no, old_product_id, new_product_id,
             old_bom_master_id, new_bom_master_id, old_updated_by, old_updated_at,
             match_method, applied_by, applied_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())"
    );
    $updateStmt = $conn->prepare(
        "UPDATE production_plans
         SET product_id = ?, bom_master_id = ?, updated_by = ?, updated_at = NOW()
         WHERE id = ?"
    );
    $verifyStmt = $conn->prepare(
        "SELECT 1
         FROM production_plans plan
         INNER JOIN products product
             ON product.id = plan.product_id
            AND product.status = 1
            AND product.deleted_at IS NULL
         INNER JOIN bom_master bom
             ON bom.id = plan.bom_master_id
            AND bom.finished_product_id = plan.product_id
            AND bom.status = 1
            AND bom.deleted_at IS NULL
         WHERE plan.id = ?
           AND EXISTS (
               SELECT 1 FROM bom_items item
               INNER JOIN products raw_product
                   ON raw_product.id = item.raw_product_id
                  AND raw_product.status = 1
                  AND raw_product.deleted_at IS NULL
               WHERE item.bom_id = bom.id
                 AND item.status = 1
                 AND item.deleted_at IS NULL
           )"
    );
    if (!$auditStmt || !$updateStmt || !$verifyStmt) {
        throw new RuntimeException('Unable to prepare the BOM backfill statements: ' . $conn->error);
    }

    $conn->begin_transaction();
    $updated = 0;
    foreach ($analysis['candidates'] as $candidate) {
        $planId = (int) $candidate['production_plan_id'];
        $planNo = (string) $candidate['production_plan_no'];
        $oldProductId = $candidate['old_product_id'];
        $newProductId = (int) $candidate['new_product_id'];
        $oldBomId = $candidate['old_bom_master_id'];
        $newBomId = (int) $candidate['new_bom_master_id'];
        $oldUpdatedBy = $candidate['old_updated_by'];
        $oldUpdatedAt = $candidate['old_updated_at'];
        $matchMethod = (string) $candidate['match_method'];

        $auditStmt->bind_param(
            'isiiiiissi',
            $planId,
            $planNo,
            $oldProductId,
            $newProductId,
            $oldBomId,
            $newBomId,
            $oldUpdatedBy,
            $oldUpdatedAt,
            $matchMethod,
            $actorId
        );
        if (!$auditStmt->execute()) {
            throw new RuntimeException('Unable to audit Production Plan ' . $planId . ': ' . $auditStmt->error);
        }

        $updateStmt->bind_param('iiii', $newProductId, $newBomId, $actorId, $planId);
        if (!$updateStmt->execute() || $updateStmt->affected_rows !== 1) {
            throw new RuntimeException('Unable to update Production Plan ' . $planId . '.');
        }

        $verifyStmt->bind_param('i', $planId);
        $verifyStmt->execute();
        if (!$verifyStmt->get_result()->fetch_row()) {
            throw new RuntimeException('Verification failed for Production Plan ' . $planId . '.');
        }
        $updated++;
    }
    $conn->commit();

    $auditStmt->close();
    $updateStmt->close();
    $verifyStmt->close();

    echo json_encode([
        'mode' => 'applied',
        'inspected' => $analysis['inspected'],
        'updated' => $updated,
        'unresolved' => $analysis['unresolved'],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), PHP_EOL;
} catch (Throwable $exception) {
    if ($conn->errno || $conn->thread_id) {
        try {
            $conn->rollback();
        } catch (Throwable) {
        }
    }
    fwrite(STDERR, 'Production Plan BOM backfill failed: ' . $exception->getMessage() . PHP_EOL);
    exit(1);
}

