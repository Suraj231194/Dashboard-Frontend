-- Shift Management is temporarily available to every authenticated application user.
-- Authentication, tenant scope, CSRF validation and request validation remain enforced.

UPDATE `menus`
SET `permission_slug` = NULL,
    `updated_by` = 1,
    `updated_at` = NOW()
WHERE `route` = 'index.php?page=shift-management'
  AND `deleted_at` IS NULL;
