-- Additive Product Master fields required by Live Inventory Add/Edit.
-- Existing product CAT numbers are preserved; the sequence is used only for new products.

ALTER TABLE `products`
  ADD COLUMN IF NOT EXISTS `hsn_code` varchar(20) DEFAULT NULL AFTER `product_code`;

CREATE TABLE IF NOT EXISTS `product_cat_sequences` (
  `company_code` varchar(20) NOT NULL,
  `financial_year_start` smallint(5) unsigned NOT NULL,
  `last_sequence` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`company_code`, `financial_year_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
