-- =============================================================================
-- Sales & CRM Requirements Completion
-- Created: 2026-08-17
-- Description: Adds the distinct territory master field and the separate
--              salesperson product-responsibility mapping required by the
--              Sales & CRM functional requirements.
-- =============================================================================

ALTER TABLE `crm_leads`
  ADD COLUMN IF NOT EXISTS `territory` VARCHAR(100) DEFAULT NULL AFTER `source_reference_table`;

ALTER TABLE `salesperson_territories`
  MODIFY COLUMN `territory_type` ENUM('Territory','State','City','Region') NOT NULL DEFAULT 'City';

CREATE TABLE IF NOT EXISTS `salesperson_product_responsibility` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `salesperson_id` INT UNSIGNED NOT NULL,
  `category_name` VARCHAR(150) DEFAULT NULL,
  `product_id` INT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_salesperson_responsibility` (`salesperson_id`),
  UNIQUE KEY `uq_salesperson_product_responsibility` (`salesperson_id`, `product_id`),
  CONSTRAINT `fk_responsibility_salesperson` FOREIGN KEY (`salesperson_id`) REFERENCES `salesperson_masters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_responsibility_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
