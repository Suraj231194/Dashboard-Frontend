SET @has_invoice_number = (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'stock_inwards'
      AND COLUMN_NAME = 'invoice_number'
);
SET @sql = IF(
    @has_invoice_number = 0,
    'ALTER TABLE `stock_inwards` ADD COLUMN `invoice_number` VARCHAR(255) DEFAULT NULL AFTER `remark`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @has_invoice_date = (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'stock_inwards'
      AND COLUMN_NAME = 'invoice_date'
);
SET @sql = IF(
    @has_invoice_date = 0,
    'ALTER TABLE `stock_inwards` ADD COLUMN `invoice_date` DATE DEFAULT NULL AFTER `invoice_number`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
