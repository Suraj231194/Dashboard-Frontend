-- Raise the application default without overwriting custom user selections.
ALTER TABLE `user_appearance_settings`
  MODIFY COLUMN `base_font_size` TINYINT(3) UNSIGNED NOT NULL DEFAULT 15;

-- Existing rows at the former application default receive the new readable default.
UPDATE `user_appearance_settings`
SET `base_font_size` = 15
WHERE `base_font_size` = 14;
