ALTER TABLE `coa_inbound_queue`
    MODIFY COLUMN `goods_type` ENUM('RM','PM','FG') NOT NULL DEFAULT 'RM' COMMENT 'Auto-filled from product category; editable';

ALTER TABLE `coa_rm_pm_table`
    MODIFY COLUMN `type` ENUM('RM','PM','FG') NOT NULL DEFAULT 'RM';

ALTER TABLE `product_cat_sequences`
    ADD COLUMN `sequence_scope` VARCHAR(32) NOT NULL DEFAULT 'CAT' AFTER `financial_year_start`;

ALTER TABLE `product_cat_sequences`
    DROP PRIMARY KEY,
    ADD PRIMARY KEY (`company_code`, `financial_year_start`, `sequence_scope`);

DROP INDEX IF EXISTS `uq_production_plans_plan_no` ON `production_plans`;
