-- Emergency rollback for 2026_09_04_002_hr_calendar_compatibility.sql.
-- Run only if post-deployment verification requires rollback.
-- The affected tables were empty at the pre-deployment audit.

ALTER TABLE `hr_attendance_daily`
    MODIFY COLUMN `classification`
    ENUM('on_time','late','half_day','full_day','absent','incomplete')
    NOT NULL DEFAULT 'incomplete';

ALTER TABLE `hr_annual_calendars`
    MODIFY COLUMN `saturday_policy`
    ENUM('all_working','all_off','2nd_4th_off','alternate_off')
    NOT NULL DEFAULT 'all_working';

ALTER TABLE `payroll_runs`
    DROP FOREIGN KEY `fk_payroll_run_calendar_revision`;

-- Keep the migration-ledger record as immutable deployment history.
