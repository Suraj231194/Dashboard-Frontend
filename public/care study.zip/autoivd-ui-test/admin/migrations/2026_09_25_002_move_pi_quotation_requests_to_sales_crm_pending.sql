-- Move PI Requests and Quotation Requests menu items under Sales & CRM
SET @sales_crm_parent_id = (
  SELECT `id` FROM `menus`
  WHERE `name` = 'Sales & CRM' AND `parent_id` = 0 AND `deleted_at` IS NULL
  LIMIT 1
);

UPDATE `menus`
SET `parent_id` = @sales_crm_parent_id,
    `sort_order` = 40,
    `showmenu` = 1,
    `status` = 1
WHERE `route` = 'index.php?page=pi-requests'
  AND @sales_crm_parent_id IS NOT NULL;

UPDATE `menus`
SET `parent_id` = @sales_crm_parent_id,
    `sort_order` = 50,
    `showmenu` = 1,
    `status` = 1
WHERE `route` = 'index.php?page=quotation-requests'
  AND @sales_crm_parent_id IS NOT NULL;
