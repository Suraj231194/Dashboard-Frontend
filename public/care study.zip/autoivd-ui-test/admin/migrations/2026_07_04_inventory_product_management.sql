ALTER TABLE `product_categories`
    ADD COLUMN `inventory_group` tinyint(4) NOT NULL DEFAULT 1 AFTER `sort_order`;

ALTER TABLE `products` ADD COLUMN `inventory_group` tinyint(4) DEFAULT NULL AFTER `category_id`;
ALTER TABLE `products` ADD COLUMN `subcategory_id` int(11) DEFAULT NULL AFTER `inventory_group`;
ALTER TABLE `products` ADD COLUMN `description` TEXT DEFAULT NULL;
ALTER TABLE `products` ADD COLUMN `gst_rate` DECIMAL(5,2) DEFAULT NULL;
ALTER TABLE `products` ADD COLUMN `reorder_level` decimal(12,3) DEFAULT 0.000 AFTER `unit_id`;
ALTER TABLE `products`
    ADD COLUMN `product_image` varchar(255) DEFAULT NULL;

CREATE TABLE IF NOT EXISTS `product_pack_sizes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `pack_size` varchar(100) NOT NULL,
  `pack_unit_id` int(11) DEFAULT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_product_pack_sizes_product` (`product_id`),
  KEY `idx_product_pack_sizes_unit` (`pack_unit_id`),
  CONSTRAINT `fk_product_pack_sizes_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

UPDATE `product_categories` SET `inventory_group` = 1 WHERE `name` IN ('Rapid', 'Elisa', 'Clia');
UPDATE `product_categories` SET `inventory_group` = 2 WHERE `name` IN ('Accessories', 'Cassettes', 'Bottle / Container', 'Pouch', 'Box', 'Carton(s)', 'Miscellaneous');
UPDATE `product_categories` SET `inventory_group` = 3 WHERE `name` IN ('Antibody', 'Chemicals', 'Uncut Sheet', 'Membrane');
UPDATE `product_categories` SET `inventory_group` = 4 WHERE `name` IN ('IVD Plasticware', 'Buffer', 'Dropper');

INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Rapid', 1, 10, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Rapid');
INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Elisa', 1, 20, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Elisa');
INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Clia', 1, 30, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Clia');

INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Accessories', 2, 10, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Accessories');
INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Cassettes', 2, 20, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Cassettes');
INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Bottle / Container', 2, 30, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Bottle / Container');
INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Pouch', 2, 40, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Pouch');
INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Box', 2, 50, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Box');
INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Carton(s)', 2, 60, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Carton(s)');
INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Miscellaneous', 2, 70, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Miscellaneous');

INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Antibody', 3, 10, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Antibody');
INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Chemicals', 3, 20, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Chemicals');
INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Uncut Sheet', 3, 30, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Uncut Sheet');
INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Membrane', 3, 40, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Membrane');

INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'IVD Plasticware', 4, 10, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'IVD Plasticware');
INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Buffer', 4, 20, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Buffer');
INSERT INTO `product_categories` (`name`, `inventory_group`, `sort_order`, `status`, `created_at`)
SELECT 'Dropper', 4, 30, 1, NOW() WHERE NOT EXISTS (SELECT 1 FROM `product_categories` WHERE `name` = 'Dropper');

UPDATE `products` prod
LEFT JOIN `product_categories` cat ON prod.`category_id` = cat.`id`
SET prod.`inventory_group` = COALESCE(cat.`inventory_group`, prod.`inventory_group`, 1)
WHERE prod.`inventory_group` IS NULL;

ALTER TABLE `low_stocks` ADD COLUMN `pack_size_id` int(11) DEFAULT NULL AFTER `product_id`;
ALTER TABLE `low_stocks` ADD COLUMN `procurement_source` varchar(50) DEFAULT NULL AFTER `expected_delivery_date`;
ALTER TABLE `low_stocks` ADD COLUMN `branch_id` bigint(20) unsigned DEFAULT NULL AFTER `procurement_source`;
ALTER TABLE `low_stocks` ADD COLUMN `warehouse_id` bigint(20) unsigned DEFAULT NULL AFTER `branch_id`;
ALTER TABLE `low_stocks` ADD COLUMN `current_stock` decimal(12,3) DEFAULT NULL AFTER `warehouse_id`;
ALTER TABLE `low_stocks` ADD COLUMN `reorder_level_snapshot` decimal(12,3) DEFAULT NULL AFTER `current_stock`;
ALTER TABLE `low_stocks` ADD COLUMN `currency_type` int(11) DEFAULT NULL AFTER `reorder_level_snapshot`;
ALTER TABLE `low_stocks` ADD COLUMN `price_value` varchar(255) DEFAULT NULL AFTER `currency_type`;