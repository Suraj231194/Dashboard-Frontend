-- Repair Product Master CAT sequence installations that were created before
-- category/stage-specific sequence scopes were introduced.

ALTER TABLE `product_cat_sequences`
    ADD COLUMN IF NOT EXISTS `sequence_scope` VARCHAR(32) NOT NULL DEFAULT 'CAT'
    AFTER `financial_year_start`;

UPDATE `product_cat_sequences`
SET `sequence_scope` = 'CAT'
WHERE `sequence_scope` IS NULL OR TRIM(`sequence_scope`) = '';

-- The previous key allowed only one counter per company/financial year.
-- Rebuild it so every category/stage scope owns an independent locked row.
ALTER TABLE `product_cat_sequences`
    DROP PRIMARY KEY;

ALTER TABLE `product_cat_sequences`
    ADD PRIMARY KEY (`company_code`, `financial_year_start`, `sequence_scope`);

