-- Migration: 2026_09_23_003_cleanup_legacy_live_stock_columns.sql
-- Description: Drop obsolete legacy columns (quantity_initial, reserved_quantity, quantity_in_base, unit_factor)
--              and compatibility triggers from live_stock, keeping reserved_qty as the 8-decimal source of truth.

-- 1. Drop compatibility triggers
DROP TRIGGER IF EXISTS `trg_live_stock_reserved_compat_bi`;
DROP TRIGGER IF EXISTS `trg_live_stock_reserved_compat_bu`;

-- 2. Drop obsolete columns
ALTER TABLE `live_stock`
    DROP COLUMN IF EXISTS `quantity_initial`,
    DROP COLUMN IF EXISTS `reserved_quantity`,
    DROP COLUMN IF EXISTS `quantity_in_base`,
    DROP COLUMN IF EXISTS `unit_factor`;
