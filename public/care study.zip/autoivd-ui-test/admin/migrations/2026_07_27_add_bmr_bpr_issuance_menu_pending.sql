-- Additive QA/QC navigation registration for the BMR/BPR Issuance page.
-- Existing menus, permissions, and role assignments are not changed.

INSERT INTO `permissions` (`name`, `slug`, `status`, `created_by`, `created_at`)
SELECT
    'QA/QC BMR/BPR Issuance View',
    'qa_qc_bmr_bpr_issuance_view',
    1,
    1,
    NOW()
WHERE NOT EXISTS (
    SELECT 1
    FROM `permissions`
    WHERE `slug` = 'qa_qc_bmr_bpr_issuance_view'
);

INSERT INTO `menus`
    (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`,
     `showmenu`, `status`, `created_by`, `created_at`)
SELECT
    'BMR/BPR Issuance',
    'index.php?page=bmr-bpr-issuance',
    'ti ti-file-check',
    qa_menu.id,
    9,
    'qa_qc_bmr_bpr_issuance_view',
    1,
    1,
    1,
    NOW()
FROM `menus` qa_menu
WHERE qa_menu.id = 72
  AND qa_menu.name = 'QA & QC'
  AND qa_menu.status = 1
  AND qa_menu.deleted_at IS NULL
  AND NOT EXISTS (
      SELECT 1
      FROM `menus` existing_menu
      WHERE existing_menu.route = 'index.php?page=bmr-bpr-issuance'
        AND existing_menu.deleted_at IS NULL
  );

-- Inherit the same role access as the existing QA/QC parent menu.
INSERT INTO `role_permissions` (`role_id`, `permission_id`, `status`)
SELECT DISTINCT
    qa_role.role_id,
    issuance_permission.id,
    1
FROM `role_permissions` qa_role
INNER JOIN `permissions` qa_permission
    ON qa_permission.id = qa_role.permission_id
   AND qa_permission.slug = 'qa_qc_menu'
INNER JOIN `permissions` issuance_permission
    ON issuance_permission.slug = 'qa_qc_bmr_bpr_issuance_view'
WHERE qa_role.status = 1
  AND NOT EXISTS (
      SELECT 1
      FROM `role_permissions` existing_assignment
      WHERE existing_assignment.role_id = qa_role.role_id
        AND existing_assignment.permission_id = issuance_permission.id
  );
