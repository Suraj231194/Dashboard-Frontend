-- Migration: 2026_09_20_001_unique_active_product_name.sql
-- Description: Add virtual generated column active_product_name and unique index to physically reject duplicate active products

-- 1. Add active_product_name virtual generated column
-- Note: Evaluates to LOWER(TRIM(product_name)) for active products (deleted_at IS NULL and status != 3), and NULL for soft-deleted products.
ALTER TABLE `products` 
ADD COLUMN `active_product_name` VARCHAR(191) 
GENERATED ALWAYS AS (
    CASE 
        WHEN `deleted_at` IS NULL AND `status` != 3 
        THEN LOWER(TRIM(SUBSTRING(`product_name`, 1, 191))) 
        ELSE NULL 
    END
) VIRTUAL;

-- 2. Add UNIQUE index on active_product_name
ALTER TABLE `products` 
ADD UNIQUE INDEX `uq_products_active_name` (`active_product_name`);
