<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$migrationPath = __DIR__ . '/2026_09_02_001_annual_calendar_module_pending.sql';
$sql = file_get_contents($migrationPath);
if ($sql === false || trim($sql) === '') {
    fwrite(STDERR, "Annual calendar module migration SQL is unavailable.\n");
    exit(1);
}

if (!$conn->multi_query($sql)) {
    fwrite(STDERR, 'Annual calendar module migration failed: ' . $conn->error . PHP_EOL);
    exit(1);
}
while (true) {
    if ($result = $conn->store_result()) $result->free();
    if ($conn->errno !== 0) {
        fwrite(STDERR, 'Annual calendar module migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
    if (!$conn->more_results()) break;
    if (!$conn->next_result()) {
        fwrite(STDERR, 'Annual calendar module migration failed: ' . $conn->error . PHP_EOL);
        exit(1);
    }
}

$requiredTables = [
    'hr_annual_calendars',
    'hr_annual_calendar_holidays',
    'hr_annual_calendar_audit_log',
];
foreach ($requiredTables as $tableName) {
    $tableCheck = $conn->query("SHOW TABLES LIKE '{$tableName}'");
    if (!$tableCheck || $tableCheck->num_rows !== 1) {
        fwrite(STDERR, "Annual calendar module verification failed: table {$tableName} not found.\n");
        exit(1);
    }
}

echo "Annual Calendar & Working Days module migration applied and verified successfully.\n";
