<?php

declare(strict_types=1);

/**
 * Migration: align the seeded BOM catalogue with the six approved workbooks.
 *
 * Runs the deterministic importer in admin/tools/bom. Dry run by default.
 *
 *   php admin/migrations/2026_09_16_repair_bom_workbook_alignment.php
 *   php admin/migrations/2026_09_16_repair_bom_workbook_alignment.php --apply
 *
 * The apply step is transactional, snapshots every touched row into
 * bom_repair_backup, and refuses to run while any sheet, component or unit is
 * unresolved. Re-running after a successful apply reports zero changes.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$tools = dirname(__DIR__) . '/tools/bom';
$apply = in_array('--apply', $argv, true);

$steps = [
    'Validate before' => [$tools . '/validate.php', []],
    ($apply ? 'Apply repair' : 'Plan repair') => [$tools . '/apply_repair.php', $apply ? ['--apply'] : []],
    'Regenerate seeders' => [$tools . '/generate_seeders.php', []],
    'Validate after' => [$tools . '/validate.php', []],
];

$exitCode = 0;

foreach ($steps as $label => [$script, $args]) {
    echo str_repeat('=', 72), PHP_EOL;
    echo $label, PHP_EOL;
    echo str_repeat('=', 72), PHP_EOL;

    $command = escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($script);

    foreach ($args as $arg) {
        $command .= ' ' . escapeshellarg($arg);
    }

    passthru($command, $status);
    echo PHP_EOL;

    // The first validation is expected to fail on an unrepaired database.
    if ($status !== 0 && $label !== 'Validate before') {
        $exitCode = $status;
    }
}

exit($exitCode);
