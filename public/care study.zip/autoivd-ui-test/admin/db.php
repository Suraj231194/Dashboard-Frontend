<?php

declare(strict_types=1);

$envPath = dirname(__DIR__) . '/.env';
$localEnvPath = dirname(__DIR__) . '/.env.local';

if (!is_readable($envPath) && !is_readable($localEnvPath)) {
    error_log('Database configuration file is missing or unreadable.');
    http_response_code(500);
    exit('Application configuration error.');
}

$loadEnv = static function (string $path): array {
    $values = [];
    $lines = file($path, FILE_IGNORE_NEW_LINES);

    if ($lines === false) {
        return $values;
    }

    foreach ($lines as $line) {
        $line = trim($line);

        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        $separator = strpos($line, '=');
        if ($separator === false) {
            continue;
        }

        $key = trim(substr($line, 0, $separator));
        $value = trim(substr($line, $separator + 1));

        if ($key === '') {
            continue;
        }

        $length = strlen($value);
        if ($length >= 2) {
            $first = $value[0];
            $last = $value[$length - 1];

            if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
                $value = substr($value, 1, -1);
            }
        }

        $values[$key] = $value;
    }

    return $values;
};

$env = [];
if (is_readable($envPath)) {
    $env = $loadEnv($envPath);
}
if (is_readable($localEnvPath)) {
    $localEnv = $loadEnv($localEnvPath);
    $env = array_merge($env, $localEnv);
}

$GLOBALS['env'] = $env;

foreach ($env as $key => $value) {
    if (!defined($key)) {
        define($key, (string)$value);
    }
}

require_once __DIR__ . '/common/Time.php';
mvConfigurePhpTimezone();

$requiredKeys = ['DB_HOST', 'DB_PORT', 'DB_DATABASE', 'DB_USERNAME', 'DB_PASSWORD'];

foreach ($requiredKeys as $requiredKey) {
    if (!array_key_exists($requiredKey, $env)) {
        error_log("Missing required database setting: {$requiredKey}");
        http_response_code(500);
        exit('Application configuration error.');
    }
}

$port = filter_var(
    $env['DB_PORT'],
    FILTER_VALIDATE_INT,
    ['options' => ['min_range' => 1, 'max_range' => 65535]]
);

if ($port === false) {
    error_log('The configured database port is invalid.');
    http_response_code(500);
    exit('Application configuration error.');
}

mysqli_report(MYSQLI_REPORT_OFF);

$conn = null;
$maxAttempts = 4;
$connected = false;
$lastError = '';
$lastErrno = 0;

for ($attempt = 1; $attempt <= $maxAttempts; $attempt++) {
    $conn = mysqli_init();
    if ($conn === false) {
        break;
    }

    $conn->options(MYSQLI_OPT_CONNECT_TIMEOUT, 5);

    if (@$conn->real_connect($env['DB_HOST'], $env['DB_USERNAME'], $env['DB_PASSWORD'], $env['DB_DATABASE'], $port)) {
        if ($conn->set_charset('utf8mb4') && mvConfigureDatabaseTimezone($conn)) {
            $connected = true;
            break;
        }
    }

    $lastErrno = $conn ? $conn->connect_errno : 0;
    $lastError = $conn ? ($conn->error ?: $conn->connect_error) : 'Initialization failed';

    if ($conn) {
        @$conn->close();
    }

    if ($attempt < $maxAttempts) {
        usleep(50000 * (2 ** ($attempt - 1)));
    }
}

if (!$connected || !$conn) {
    error_log("Database connection failed ({$lastErrno}): {$lastError}");
    http_response_code(500);
    exit('Database connection unavailable.');
}
