<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
$_SESSION['user_id'] = 1;
$_SESSION['user_email'] = 'test@test.com';
$_SESSION['role_id'] = 1;
require_once 'db.php';
require_once 'constant.php';
require_once 'functions.php';
echo "=== Before include ===\n";
include 'pages/purchase-management.php';
echo "\n=== After include ===\n";
