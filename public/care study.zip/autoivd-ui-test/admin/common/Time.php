<?php

declare(strict_types=1);

/**
 * Single application clock for ERP PHP and MariaDB connections.
 *
 * APP_TIMEZONE accepts IST / Asia/Kolkata or UTC.  The default remains IST,
 * preserving the ERP's existing business-time behaviour when the setting has
 * not yet been added to an environment file.
 */
function mvConfiguredTimezone(): string
{
    $configured = trim((string) (
        $GLOBALS['env']['APP_TIMEZONE']
        ?? $_ENV['APP_TIMEZONE']
        ?? $_SERVER['APP_TIMEZONE']
        ?? getenv('APP_TIMEZONE')
        ?? 'IST'
    ));
    $normalized = strtolower($configured);

    if ($normalized === '' || $normalized === 'ist' || $normalized === 'asia/kolkata') {
        return 'Asia/Kolkata';
    }
    if ($normalized === 'utc' || $normalized === 'gmt' || $normalized === 'z') {
        return 'UTC';
    }

    try {
        new DateTimeZone($configured);
        return $configured;
    } catch (Throwable $exception) {
        error_log('Invalid APP_TIMEZONE; falling back to Asia/Kolkata.');
        return 'Asia/Kolkata';
    }
}

function mvConfigurePhpTimezone(): string
{
    $timezone = mvConfiguredTimezone();
    date_default_timezone_set($timezone);
    return $timezone;
}

function mvNow(string $format = 'Y-m-d H:i:s'): string
{
    return (new DateTimeImmutable('now', new DateTimeZone(mvConfiguredTimezone())))->format($format);
}

function mvToday(): string
{
    return mvNow('Y-m-d');
}

/**
 * MariaDB on shared hosting may not have named timezone tables installed.
 * A numeric offset is universally supported and matches the selected PHP
 * timezone for the current request.
 */
function mvDatabaseTimezoneOffset(): string
{
    $now = new DateTimeImmutable('now', new DateTimeZone(mvConfiguredTimezone()));
    $offset = $now->getOffset();
    $sign = $offset < 0 ? '-' : '+';
    $offset = abs($offset);

    return sprintf('%s%02d:%02d', $sign, intdiv($offset, 3600), intdiv($offset % 3600, 60));
}

function mvConfigureDatabaseTimezone(mysqli $conn): bool
{
    $offset = mvDatabaseTimezoneOffset();
    return $conn->query("SET time_zone = '" . $conn->real_escape_string($offset) . "'") === true;
}
