<?php

declare(strict_types=1);

error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
ini_set('display_errors', '0');
date_default_timezone_set('Asia/Kolkata');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

require_once __DIR__ . '/db.php';
define('HRMS_CONTEXT', true);
require_once __DIR__ . '/hrms/hrms_common.php';

$respond = static function (array $payload, int $statusCode = 200): never {
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
};

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    $respond(['status' => 'error', 'message' => 'Only POST requests are accepted.'], 405);
}

$contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($contentLength > 5 * 1024 * 1024) {
    $respond(['status' => 'error', 'message' => 'The biometric payload is too large.'], 413);
}

$columnCheck = $conn->query("SHOW COLUMNS FROM hr_biometric_devices LIKE 'ingest_token_hash'");
$batchTableCheck = $conn->query("SHOW TABLES LIKE 'hr_biometric_ingest_batches'");
if (!$columnCheck || $columnCheck->num_rows !== 1 || !$batchTableCheck || $batchTableCheck->num_rows !== 1) {
    $respond(['status' => 'error', 'message' => 'Biometric push ingestion is not configured.'], 503);
}

$rawBody = file_get_contents('php://input');
$payload = json_decode((string) $rawBody, true);
if (!is_array($payload)) {
    $respond(['status' => 'error', 'message' => 'Provide a valid JSON request body.'], 400);
}
$events = $payload['events'] ?? null;
if (!is_array($events) || $events === [] || count($events) > 5000) {
    $respond(['status' => 'error', 'message' => 'Provide between 1 and 5000 biometric events.'], 422);
}

$authorization = trim((string) ($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? ''));
if (!preg_match('/^Bearer\s+([^\s]+)$/i', $authorization, $authorizationMatch)) {
    $respond(['status' => 'error', 'message' => 'Device authentication is required.'], 401);
}
$deviceToken = $authorizationMatch[1];
$deviceCode = strtoupper(trim((string) ($_SERVER['HTTP_X_DEVICE_CODE'] ?? $payload['device_code'] ?? '')));
if ($deviceCode === '' || strlen($deviceCode) > 100 || strlen($deviceToken) < 32 || strlen($deviceToken) > 200) {
    $respond(['status' => 'error', 'message' => 'Device authentication is invalid.'], 401);
}

$tokenHash = hash('sha256', $deviceToken);
$deviceStmt = $conn->prepare(
    'SELECT id, company_id, branch_id, device_code, timezone, ingest_rate_limit
     FROM hr_biometric_devices
     WHERE device_code = ? AND ingest_token_hash = ? AND ingest_enabled = 1 AND status = 1 LIMIT 1'
);
$deviceStmt->bind_param('ss', $deviceCode, $tokenHash);
$deviceStmt->execute();
$device = $deviceStmt->get_result()->fetch_assoc();
$deviceStmt->close();
if (!$device) {
    $respond(['status' => 'error', 'message' => 'Device authentication is invalid.'], 401);
}

$deviceId = (int) $device['id'];
$rateLimit = max(1, (int) ($device['ingest_rate_limit'] ?? 120));
$rateStmt = $conn->prepare('SELECT COUNT(*) total FROM hr_biometric_ingest_batches WHERE device_id = ? AND received_at >= DATE_SUB(NOW(), INTERVAL 1 MINUTE)');
$rateStmt->bind_param('i', $deviceId);
$rateStmt->execute();
$recentBatches = (int) ($rateStmt->get_result()->fetch_assoc()['total'] ?? 0);
$rateStmt->close();
if ($recentBatches >= $rateLimit) {
    $respond(['status' => 'error', 'message' => 'Device ingestion rate limit exceeded.'], 429);
}

$batchKey = trim((string) ($_SERVER['HTTP_X_INGEST_BATCH_ID'] ?? $payload['batch_id'] ?? ''));
if ($batchKey === '') {
    $batchKey = hash('sha256', $deviceCode . '|' . (string) $rawBody);
}
if (strlen($batchKey) > 150 || !preg_match('/^[A-Za-z0-9._:-]+$/', $batchKey)) {
    $respond(['status' => 'error', 'message' => 'The ingest batch identifier is invalid.'], 422);
}
$remoteIp = filter_var($_SERVER['REMOTE_ADDR'] ?? '', FILTER_VALIDATE_IP) ?: null;
$batchId = 0;

try {
    $conn->begin_transaction();
    $batchStmt = $conn->prepare(
        "INSERT IGNORE INTO hr_biometric_ingest_batches
         (device_id, batch_key, remote_ip, event_count, status)
         VALUES (?, ?, ?, ?, 'processing')"
    );
    $eventCount = count($events);
    $batchStmt->bind_param('issi', $deviceId, $batchKey, $remoteIp, $eventCount);
    $batchStmt->execute();
    if ($batchStmt->affected_rows !== 1) {
        $batchStmt->close();
        $existingStmt = $conn->prepare('SELECT id, imported_count, duplicate_count, unmapped_count, attendance_count, status FROM hr_biometric_ingest_batches WHERE device_id = ? AND batch_key = ? LIMIT 1');
        $existingStmt->bind_param('is', $deviceId, $batchKey);
        $existingStmt->execute();
        $existingBatch = $existingStmt->get_result()->fetch_assoc();
        $existingStmt->close();
        if (($existingBatch['status'] ?? '') !== 'failed') {
            $conn->rollback();
            $respond([
                'status' => 'success',
                'message' => 'This biometric batch was already received.',
                'idempotent' => true,
                'batch_id' => (int) ($existingBatch['id'] ?? 0),
                'imported_count' => (int) ($existingBatch['imported_count'] ?? 0),
                'duplicate_count' => (int) ($existingBatch['duplicate_count'] ?? 0),
                'unmapped_count' => (int) ($existingBatch['unmapped_count'] ?? 0),
                'attendance_count' => (int) ($existingBatch['attendance_count'] ?? 0),
            ]);
        }
        $batchId = (int) $existingBatch['id'];
        $retryStmt = $conn->prepare("UPDATE hr_biometric_ingest_batches SET remote_ip = ?, event_count = ?, imported_count = 0, duplicate_count = 0, unmapped_count = 0, attendance_count = 0, status = 'processing', error_message = NULL, received_at = NOW(), completed_at = NULL WHERE id = ?");
        $retryStmt->bind_param('sii', $remoteIp, $eventCount, $batchId);
        $retryStmt->execute();
        $retryStmt->close();
    } else {
        $batchId = (int) $batchStmt->insert_id;
        $batchStmt->close();
    }
    $conn->commit();
    $conn->begin_transaction();

    $companyId = (int) $device['company_id'];
    $branchId = !empty($device['branch_id']) ? (int) $device['branch_id'] : null;
    $employeeStmt = $conn->prepare(
        "SELECT employee.id FROM employees employee
         LEFT JOIN users user ON user.id = employee.user_id AND user.deleted_at IS NULL
         LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
                 LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
         WHERE employee.emp_code = ? AND employee.deleted_at IS NULL
                     AND COALESCE(profile.company_id, user.company_id, legacy_company.id) = ?
           AND (? IS NULL OR COALESCE(profile.branch_id, user.branch_id) = ?)
         LIMIT 1"
    );
    $insertStmt = $conn->prepare(
        "INSERT IGNORE INTO hr_biometric_punches
         (device_id, external_event_id, employee_code, employee_id, punch_time, punch_type, raw_payload)
         VALUES (?, ?, ?, ?, ?, ?, ?)"
    );
    $timezone = new DateTimeZone(trim((string) ($device['timezone'] ?? '')) ?: 'Asia/Kolkata');
    $imported = 0;
    $duplicates = 0;
    $unmapped = 0;
    $failedEvents = [];
    $dates = [];
    foreach ($events as $index => $event) {
        if (!is_array($event)) {
            $failedEvents[] = ['index' => $index, 'reason' => 'Event must be an object.'];
            continue;
        }
        $employeeCode = trim((string) ($event['employee_code'] ?? $event['employee_id'] ?? ''));
        $rawPunchTime = trim((string) ($event['punch_time'] ?? $event['timestamp'] ?? ''));
        $rawPunchType = strtolower(trim((string) ($event['punch_type'] ?? $event['type'] ?? 'unknown')));
        $punchType = match ($rawPunchType) {
            'in', 'checkin', 'check_in', 'entry', '0' => 'in',
            'out', 'checkout', 'check_out', 'exit', '1' => 'out',
            default => 'unknown',
        };
        if ($employeeCode === '' || strlen($employeeCode) > 100 || $rawPunchTime === '') {
            $failedEvents[] = ['index' => $index, 'reason' => 'Employee code and punch time are required.'];
            continue;
        }
        try {
            $punchDateTime = new DateTimeImmutable($rawPunchTime, $timezone);
            $punchTime = $punchDateTime->setTimezone($timezone)->format('Y-m-d H:i:s');
        } catch (Throwable) {
            $failedEvents[] = ['index' => $index, 'reason' => 'Punch time is invalid.'];
            continue;
        }
        $externalEventId = trim((string) ($event['external_event_id'] ?? $event['event_id'] ?? $event['id'] ?? ''));
        if ($externalEventId === '') {
            $externalEventId = hash('sha256', $deviceCode . '|' . $employeeCode . '|' . $punchTime . '|' . $punchType);
        }
        if (strlen($externalEventId) > 150) {
            $failedEvents[] = ['index' => $index, 'reason' => 'External event identifier is too long.'];
            continue;
        }

        $employeeStmt->bind_param('siii', $employeeCode, $companyId, $branchId, $branchId);
        $employeeStmt->execute();
        $matchedEmployee = $employeeStmt->get_result()->fetch_assoc();
        $employeeId = $matchedEmployee ? (int) $matchedEmployee['id'] : null;
        $rawPayload = json_encode($event, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $insertStmt->bind_param('ississs', $deviceId, $externalEventId, $employeeCode, $employeeId, $punchTime, $punchType, $rawPayload);
        $insertStmt->execute();
        if ($insertStmt->affected_rows === 1) {
            $imported++;
            if ($employeeId === null) {
                $unmapped++;
                if (count($failedEvents) < 100) $failedEvents[] = ['index' => $index, 'reason' => 'Employee code is not mapped in this device scope.'];
            } else {
                $dates[substr($punchTime, 0, 10)] = true;
            }
        } else {
            $duplicates++;
        }
    }
    $employeeStmt->close();
    $insertStmt->close();

    $attendanceCount = 0;
    foreach (array_keys($dates) as $attendanceDate) {
        $attendanceCount += hrmsRecalculateAttendance($conn, $attendanceDate, $companyId, $branchId);
    }
    $batchStatus = ($failedEvents !== [] || $unmapped > 0) ? 'partial' : 'success';
    $errorMessage = $failedEvents !== [] ? mb_substr(json_encode($failedEvents, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 0, 1000) : null;
    $updateBatch = $conn->prepare('UPDATE hr_biometric_ingest_batches SET imported_count = ?, duplicate_count = ?, unmapped_count = ?, attendance_count = ?, status = ?, error_message = ?, completed_at = NOW() WHERE id = ?');
    $updateBatch->bind_param('iiiissi', $imported, $duplicates, $unmapped, $attendanceCount, $batchStatus, $errorMessage, $batchId);
    $updateBatch->execute();
    $updateBatch->close();
    $updateDevice = $conn->prepare('UPDATE hr_biometric_devices SET last_synced_at = NOW(), last_ingested_at = NOW() WHERE id = ?');
    $updateDevice->bind_param('i', $deviceId);
    $updateDevice->execute();
    $updateDevice->close();
    $conn->commit();

    $respond([
        'status' => $batchStatus,
        'message' => $batchStatus === 'success' ? 'Biometric events imported successfully.' : 'Biometric events imported with exceptions.',
        'batch_id' => $batchId,
        'imported_count' => $imported,
        'duplicate_count' => $duplicates,
        'unmapped_count' => $unmapped,
        'attendance_count' => $attendanceCount,
        'failed_events' => $failedEvents,
    ], $batchStatus === 'success' ? 200 : 207);
} catch (Throwable $exception) {
    @$conn->rollback();
    if ($batchId > 0) {
        $error = mb_substr($exception->getMessage(), 0, 1000);
        $failedStmt = $conn->prepare("UPDATE hr_biometric_ingest_batches SET status = 'failed', error_message = ?, completed_at = NOW() WHERE id = ?");
        if ($failedStmt) {
            $failedStmt->bind_param('si', $error, $batchId);
            $failedStmt->execute();
            $failedStmt->close();
        }
    }
    error_log('Biometric push failed: ' . $exception->getMessage());
    $respond(['status' => 'error', 'message' => 'Unable to process the biometric batch.'], 500);
}