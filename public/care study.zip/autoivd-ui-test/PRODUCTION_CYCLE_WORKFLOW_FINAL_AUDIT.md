# Production Cycle Workflow - Comprehensive End-to-End Audit Report

**Date of Audit**: September 23, 2026  
**Audited Against**: `Production_Cycle_Workflow.docx` (Requirements Specification)  
**Database State**: 65 Migrations Applied Cleanly (`live_stock` unified, legacy columns removed, 8-decimal precision enforced)  
**Codebase**: `prateekbiogenix/autoivd` (Branch: `ui-test`)

---

## 1. Executive Summary

This in-depth audit evaluates the entire 13-step production cycle workflow against the requirements specified in `Production_Cycle_Workflow.docx`. Every screen, transition, database schema, transaction boundary, and business rule was analyzed for exception-free operation, data consistency, and edge-case resilience.

### High-Level Verdict:
- **Core Workflow Health**: **EXCELLENT**. The primary end-to-end chain (Steps 1 through 10 and Step 13) is robust, uses strict database transactions (`begin_transaction` / `commit` / `rollback`), prevents race conditions using `FOR UPDATE` and MySQL named locks, and maintains 8-decimal precision (`DECIMAL(20,8)`).
- **Previous Defect Resolution**: **VERIFIED**. The Step 4 $\rightarrow$ Step 5 $\rightarrow$ Step 6 routing defect (skipping Step 5) is completely resolved. Step 4 creates a request in status `UPCOMING`; Step 5 requires mandatory BMR and BPR selection; Step 6 receives the request only upon submission (`status = 'SUBMITTED'`).
- **Gaps & Discrepancies Identified**:
  1. **Route B Entry ("Produce" Button)**: Missing on `stocks.php` / `low-stocks.php`.
  2. **Step 11 & Step 12 Origin Awareness**: In the requirements, Live Inventory origin updates available stock directly at Transfer Ticket (Step 11) and ends the flow, whereas Order Management continues to Step 12. Currently, the code unconditionally routes *all* transfer tickets through Step 12 (`goods-received-production.php`).
  3. **COA Template Pre-mappings**: Out of 217 products with active BOMs, only 7 have pre-mapped COA profiles in `coa_template_product_mappings`. While the UI manual template picker works, bulk auto-mapping will prevent manual picker interruptions in production.

---

## 2. Step-by-Step Deep Audit

```mermaid
flowchart TD
    subgraph Entry ["Entry Routes"]
        R_A["Route A: Order Management (Insufficient Stock)"] --> PP_IN["Step 2: Production Plan Incoming"]
        R_B["Route B: Live Inventory (Low/Out of Stock)"] -.->|"Produce Button (Missing)"| PP_IN
    end

    subgraph Planning ["Planning & Form Request"]
        PP_IN --> PP_SUB["Step 2: Submit Production Plan"]
        PP_SUB --> MR["Step 3: Material Requisition"]
        MR --> GI["Step 4: Goods Issues to Production (Store)"]
        GI -->|"Creates UPCOMING Request"| BMR_REQ["Step 5: BMR & BPR Form Request (Mandatory Searchable Dropdowns)"]
        BMR_REQ -->|"Submits (SUBMITTED)"| BMR_ISS["Step 6: QA/QC BMR & BPR Issuance"]
    end

    subgraph BatchQuality ["Batch Execution & Quality Gates"]
        BMR_ISS -->|"Approve"| BMR_EXEC["Step 7: Production BMR (BPR Locked)"]
        BMR_ISS -->|"Reject"| TERM1["Terminated"]
        BMR_EXEC -->|"Submit BMR"| IP_COA["Step 8: QA/QC IP COA"]
        IP_COA -->|"Approved"| BPR_EXEC["Step 9: Production BPR (Unlocked)"]
        IP_COA -->|"Rejected"| TERM2["Workflow Halted (BPR Locked)"]
        BPR_EXEC -->|"Submit BPR"| FG_COA["Step 10: QA/QC FG COA"]
        FG_COA -->|"Rejected"| TERM3["Workflow Halted (Transfer Blocked)"]
    end

    subgraph TransferCompletion ["Transfer & Origin-Aware Completion"]
        FG_COA -->|"Approved"| TT["Step 11: Production Transfer Ticket"]
        TT -->|"Live Inventory Origin (Requirement)"| LIVE_STOCK["Update Available Stock & Close Flow"]
        TT -->|"Order Origin (Requirement)"| GRP["Step 12: Goods Received from Production (Store)"]
        GRP --> GRR["Step 13: Order Management Goods Received & Reserved"]
        GRR -->|"Send to Dispatch"| DISPATCH["Status: Dispatched, Stock Outward Created"]
        GRR -->|"Cancel"| CANCEL["Status: Cancelled, Stock Released Once"]
    end

    style R_B stroke:#f59e0b,stroke-width:2px,stroke-dasharray: 5 5
    style LIVE_STOCK stroke:#3b82f6,stroke-width:2px
    style GRP stroke:#10b981,stroke-width:2px
```

---

### Step 1: Entry Routes (Route A vs Route B)

#### Route A: Store and SCM Order Management
- **Mechanism**: Triggered via `sendOrderToProduction` in `admin/ajax.php:11603` $\rightarrow$ `mvCreateProductionPlansForOrder` in `admin/functions.php:6428`.
- **Validation**:
  - Validates stock shortfall using `mvGetOrderStockAnalysis`.
  - Rejects if stock is already sufficient (`RuntimeException: Stock is now sufficient`).
  - Resolves active BOM for finished product (`bom_master.bom_status = 'APPROVED'`).
  - Creates production plan with `order_id`, `order_item_id`, `product_id`, `batch_size = shortfall_base`.
  - Sets order status to `Sent_to_Production` (13).
  - Production history recorded with type `PlanCreated`.
- **Audit Result**: **PASS**. Order origin, ID, item ID, and required shortfall quantities are preserved with atomic rollback.

#### Route B: Live Inventory ("Produce" Button)
- **Requirement**: "Origin: Live Inventory. A product is low in stock or out of stock. Admin selects Produce in that inventory widget. Currently, the Produce button is missing and not present on the Live Inventory > Out of Stock or Low in Stock."
- **Audit Findings**:
  - In `admin/pages/stocks.php` (lines 1497-1518), `#widgetLowStockCard` and `#widgetOutOfStockCard` strictly call `openProcurementProductsModal(...)`. This modal initiates purchase requisitions/POs for purchasing raw materials or goods from vendors.
  - There is currently **no "Produce" button** or trigger for manufactured items with active BOMs.
  - In `admin/ajax.php:22580` (`loadNewProductionPlans`), the widget query checks:
    ```sql
    (COALESCE(prodplan.order_id, 0) > 0 OR prodplan.prodplan_remark LIKE '%BOM Shortfall%')
    ```
    If a plan is triggered from Live Inventory with `order_id = NULL`, it would be filtered out of the "New Production Plan!" widget unless an origin flag (e.g. `origin = 'LIVE_INVENTORY'`) is included.

---

### Step 2: Production Plan (`production-plan.php`)
- **Incoming Widget**: `#newProductionPlanWidget` triggers `loadNewProductionPlans`.
- **BOM & Stock Verification**: Operator clicks "Check BOM & Stock" (`#checkBomBtn`). Checks raw material live stock availability against required BOM quantities for the batch size.
- **Submission**: On submit (`#submitPlanBtn`), transitions plan to in-process/accepted (`status = 1` or history action `PlanAccepted`).
- **Audit Result**: **PASS**. Form validation, CSRF, and multi-product batching work as expected.

---

### Step 3: Material Requisition (`material-requisition.php`)
- **Incoming Widget**: `loadNewProductionPlans` with `context = 'material_requisition'` queries accepted plans.
- **MR Generation**: Pre-populates finished product, lot/batch number, batch size, and BOM raw/packaging items.
- **Submission**: Generates slip number and inserts `material_requisition` and `material_requisition_items`. Status transitions to 1 (Submitted).
- **Audit Result**: **PASS**. Raw material lines correctly record `required_qty`, `unit_id`, and link back to `prod_plan_id`.

---

### Step 4: Goods Issues to Production (`goods-issuance.php`)
- **Incoming Widget**: `loadUpcomingIssuances` displays pending MRs.
- **Stock Issuance**: Store issues each item with batch/lot allocation. Stock is deducted via `inventoryDeductStock` in `admin/functions.php`.
- **Handoff to Step 5**:
  - In `admin/ajax.php:23168` (`issueBomItems`), when all items are issued, it executes:
    ```php
    bmrBprEnsureRequestForMaterialRequisition($conn, $reqId, $userId);
    ```
  - Creates a record in `bmr_bpr_requests` with:
    - `material_requisition_id = $reqId`
    - `production_plan_id = $planId`
    - `product_id = $productId`
    - `status = 'UPCOMING'` (Initial draft state)
  - Returns `redirect_url => 'index.php?page=bmr-bpr-form-request'`.
- **Audit Result**: **PASS**. Physical stock is deducted before advancing.

---

### Step 5: BMR and BPR Form Request (`bmr-bpr-form-request.php`)
- **Incoming Widget**: `#upcomingBmrBprWidget` displays requests with `status = 'UPCOMING'`.
- **Form Selection**:
  - Two mandatory dropdowns: BMR Template and BPR Template.
  - Select2 searchable dropdowns initialized with AJAX template catalog search.
- **Submission**:
  - Action `submit_request` in `admin/workflow/bmr_bpr_actions.php:214`:
    - Validates request is currently `UPCOMING`.
    - Validates `bmrTemplateId` and `bprTemplateId` are selected.
    - Snapshots product document requirements.
    - Updates `bmr_bpr_requests.status = 'SUBMITTED'`.
- **Routing Defect Fix**: **VERIFIED**. Step 6 (`bmr-bpr-issuance.php`) queries only requests with `status_code === 'SUBMITTED'`. A record created at Step 4 *cannot* appear in Step 6 until Step 5 is completed and submitted.
- **Audit Result**: **PASS**.

---

### Step 6: QA & QC BMR and BPR Issuance (`bmr-bpr-issuance.php`)
- **Incoming Widget**: `issuance_list` loads only `status = 'SUBMITTED'`. Displays selected BMR and BPR templates.
- **Review Decisions**:
  - **Approve**:
    - Updates `bmr_bpr_requests.status = 'APPROVED'`.
    - Spawns work items in `bmr_bpr_work_items` for BMR and BPR (`status = 'DRAFT'`).
    - Creates immutable template snapshots in `bmr_template_snapshots` / `bpr_template_snapshots`.
    - Advances to Step 7.
  - **Reject**:
    - Updates `bmr_bpr_requests.status = 'REJECTED'`.
    - Terminates the record; no work items are created.
- **Audit Result**: **PASS**. Rejection cleanly halts the workflow.

---

### Step 7 & Step 9: Production BMR & BPR (`production-bmr-bpr.php`)
- **Widgets**: Incoming BMR (`#incomingBmrWidget`) and Incoming BPR (`#incomingBprWidget`).
- **Quality Gating Enforcement**:
  - BPR is visible in the incoming queue, but editing and submission are locked.
  - In `admin/workflow/bmr_bpr_common.php:2079`:
    ```php
    $canOpen = ($formType === 'BMR') || ($bmrStatus === 'COMPLETE' && $ipCoaApproved);
    ```
  - If an operator bypasses the frontend and attempts to open or submit BPR before IP COA is approved:
    ```php
    throw new DomainException('An approved In-Process COA is required before opening the BPR.');
    ```
- **Step 7 (BMR Completion)**:
  - Operator fills in production logs, checks, and submits BMR.
  - Work item status transitions to `COMPLETE`.
  - Advances record to Step 8 (`ip-coa-generation.php`).
- **Step 9 (BPR Completion)**:
  - Once Step 8 (IP COA) is approved, BPR is automatically unlocked.
  - Operator completes packaging and labeling logs and submits BPR.
  - Work item status transitions to `COMPLETE`.
  - Advances record to Step 10 (`fg-coa-generation.php`).
- **Audit Result**: **PASS**. Quality gate is strictly enforced in both backend API and frontend UI.

---

### Step 8: QA & QC IP COA (`ip-coa-generation.php`)
- **Incoming Widget**: `#ipCoaUpcomingWidget` queries `ip_queue_list`.
- **Template Resolution**:
  - If product has a pre-mapped template in `coa_template_product_mappings`, loads the structured template immediately.
  - If not pre-mapped, `renderIpCoaTemplatePicker` displays the manual template selector with optgroups for all active IP templates and product families.
  - User selection auto-saves the mapping for future runs.
- **Decisions**:
  - Operator enters test parameters and sets `approval.decision` (`APPROVED` or `REJECTED`).
  - **Approved**: `workflow_status = 'COMPLETED'`. BPR in Step 9 is unlocked (`bmrBprRequestHasApprovedIpCoa` returns true).
  - **Rejected**: `workflow_status = 'REJECTED'`. BPR remains locked; workflow terminates.
- **Audit Result**: **PASS**.

---

### Step 10: QA & QC FG COA (`fg-coa-generation.php`)
- **Incoming Widget**: `#fgCoaUpcomingWidget` queries `fg_queue_list`.
- **Prerequisites Checked**:
  - IP COA must be completed and approved (`bmrBprCoaRecordIsApproved`).
  - BPR packing must have started or completed (`bmrBprRequestPackingStarted`).
  - Sample Advice (SA) if present must be approved.
- **Decisions & Rejection Gate**:
  - Requires `approval.decision` (`APPROVED` or `REJECTED`).
  - **Approved**:
    - `workflow_status = 'COMPLETED'`.
    - Executes `bmrBprEnsurePendingTransferTicketForRequest`.
    - Advances record to Step 11 (`transfer-ticket.php`).
  - **Rejected**:
    - `workflow_status = 'REJECTED'`.
    - Does *not* create a transfer ticket.
    - `transfer_queue_list` checks `if (!bmrBprCoaRecordIsApproved($row)) continue;`, completely blocking the rejected batch from entering Step 11.
- **Audit Result**: **PASS**. Rejection gate behavior is fully verified.

---

### Step 11: Production Transfer Ticket (`transfer-ticket.php`)
- **Incoming Widget**: `#incomingTransferTicketsWidget` queries `transfer_queue_list`.
- **Transfer Creation**:
  - Operator completes transferred quantity, manufacturing date, expiry date, and QC sampler.
  - Executes `create_transfer_ticket` in `admin/workflow/bmr_bpr_actions.php:1561`.
- **Discrepancy vs Requirements**:
  - **Requirement**:
    > "For a Live Inventory origin, update available inventory with the produced quantity and close this flow. For an Order Management origin, continue to Step 12 without adding the reserved output to available inventory."
  - **Actual Implementation**:
    > `create_transfer_ticket` unconditionally inserts a pending row into `goods_received_from_production` (`receipt_status = 'PENDING'`) and notifies Store SCM, regardless of origin.
    > Store SCM must then open `goods-received-production.php` (Step 12) and click "Acknowledge" before *any* stock is credited to `live_stock`.
- **Audit Result**: **ACTION REQUIRED**. See Architectural Recommendations below.

---

### Step 12: Store and SCM Goods Received from Production (`goods-received-production.php`)
- **Incoming Widget**: Displays pending transfer tickets.
- **Receipt Acknowledgement**:
  - Store enters actual received quantity (must be $\le$ transferred quantity) and remarks.
  - Calls `acknowledgeGoodsReceivedProduction` in `admin/ajax.php:477`.
  - Credits finished goods to `live_stock` via `inventoryAddStock`.
  - Links `live_stock_id` to `transfer_ticket` and `fg_coa_generation`.
  - If linked `production_plans.order_id > 0`, executes `mvRecalculateOrderFulfillmentLocked`:
    - Releases previous reservations.
    - Reserves the produced stock for the order via `inventoryReserveStock` (`reserved_qty += qty`).
    - Creates entries in `order_stock_reservations`.
    - Updates order item fulfillment status to `ready_for_dispatch` or `stock_available`.
    - Updates order status to `Ready_for_Dispatch` (if 100% fulfilled).
- **Audit Result**: **PASS**. Reservation math and stock crediting are safe and transactional.

---

### Step 13: Order Management Goods Received and Reserved (`order-received.php`)
- **Top Widget**: `#goodsReceivedReservedBanner` displays count of completed records ready for dispatch.
- **Modal & Actions**: Clicking a record in `#goodsReceivedReservedModal` presents two options:
  1. **Send to Dispatch**:
     - Calls `mvDispatchReservedOrderRecord`.
     - Consumes the reserved stock (`inventoryConsumeReservedStock`).
     - Inserts parent record into `stock_outward` and line items into `stock_outward_items`.
     - Updates order item status to `dispatched` (8) or `partial_delivered` (11).
     - Sets order status to `Dispatched` (8).
  2. **Cancel Order**:
     - Calls `mvCancelReservedOrderRecord`.
     - Sets order status to `Cancelled` (3).
     - Closes reservation in `order_stock_reservations` (`status = 0`, `closed_reason = 'cancelled'`).
     - Calls `mvSyncLiveStockReservedQuantity($conn)`:
       - Recalculates `live_stock.reserved_qty` from active reservations.
       - Since `unreserved_qty` is a generated column (`quantity_available - reserved_qty`), reducing `reserved_qty` immediately makes the stock available for other orders.
- **Audit Result**: **PASS**. Stock is posted once and released cleanly without duplicate adjustments.

---

## 3. Template Catalog & Migration Audit (Step 8 & Step 10)

### Current Database State:
- `coa_document_templates`: 10 active structured templates (5 IP, 5 FG):
  - Biochemistry IP / FG (29 product families each)
  - Serology IP / FG (4 product families each)
  - Rapid Test IP / FG (24 product families each)
  - Urine Strip IP / FG (4 product families each)
  - ADA CareIO IP / FG (1 product family each)
  - **Total**: 62 distinct product families per COA type (124 total).
- `coa_template_product_mappings`: 252 active mappings.
- **Manufactured Products with Active BOMs**: 217 products.
  - **Pre-mapped**: 7 products.
  - **Unmapped**: 210 products (e.g. Albumin 50 mL, Calcium 100 mL, etc.).
- **Impact & Behavior**:
  - The fallback mechanism works: unmapped products trigger `renderIpCoaTemplatePicker` / `renderFgCoaTemplatePicker`, allowing the operator to select the family (e.g. "Albumin") and saving the mapping permanently upon submit.
  - However, to ensure zero-friction operation without requiring manual template selection on the first batch of each product variation, a reconciliation script should map all products matching existing profile families by name prefix.

---

## 4. Concurrency, Precision & Data Integrity Audit

| Integrity Dimension | Specification | Actual Implementation | Status |
|:---|:---|:---|:---|
| **Decimal Precision** | Exact 8 decimals for all stock & batch sizes | `live_stock.reserved_qty` is `DECIMAL(20,8)`. `batch_size` in `production_plans` and `material_requisition` is `DECIMAL(20,8)`. | **VERIFIED** |
| **Stock Source of Truth** | Single record per product in `live_stock` | Enforced by unique index `idx_live_stock_product_id`. Verified 1 row per product. | **VERIFIED** |
| **Row Locking** | Concurrency safety under high throughput | Explicit `FOR UPDATE` queries used in order reservation, stock deduction, and receipt acknowledgement. | **VERIFIED** |
| **Document Numbering** | No duplicate sequence numbers | Protected by MySQL named locks (`GET_LOCK`) and unique table constraints. | **VERIFIED** |
| **Stock Double-Dipping** | Output cannot be claimed twice | Stock is either reserved for an order (`reserved_qty`) or available (`unreserved_qty`). Cancellation releases it exactly once. | **VERIFIED** |

---

## 5. Answers to Requirements & Confirmations Needed

### 1. Partial Stock Rule (Table 1 Item 4)
- **Question**: Does Step 13 reserve only newly produced quantity or combine it with existing available quantity?
- **Finding**: In `mvRecalculateOrderFulfillmentLocked`, the system combines existing unreserved stock with the newly produced batch to fulfill up to 100% of the customer's required quantity. If 20 units were available and 80 were produced for an order requiring 100, all 100 are reserved, marking the order `Ready_for_Dispatch`.

### 2. FG COA Rejection Rule (Table 1 Item 5)
- **Question**: Does Step 10 have an approve/reject decision, and what does rejection do?
- **Finding**: Step 10 enforces `approval.decision` (`APPROVED` vs `REJECTED`). If rejected, `workflow_status` is set to `REJECTED`, transfer ticket generation is skipped, and the transfer ticket incoming queue blocks the record. The batch is quarantined and cannot be transferred or credited to inventory.

### 3. Dispatch Status Timing (Table 1 Item 6)
- **Question**: Does "Send to Dispatch" in Step 13 mark the order `Dispatched` immediately or wait for Goods Dispatched outward completion?
- **Finding**: In `mvDispatchReservedOrderRecord`, clicking "Confirm Dispatch" in Step 13 automatically creates the `stock_outward` and `stock_outward_items` records, consumes the reserved stock, and marks the order row status `Dispatched` (8) immediately. It does not require a second confirmation step in `stock-outwards.php`.

---

## 6. Actionable Recommendations for Final Sign-Off

1. **Add "Produce" Button on Live Inventory (`stocks.php` / `low-stocks.php`)**:
   - For products in the Low Stock and Out of Stock widgets that have an active BOM (`bom_master.status = 1 AND bom_status = 'APPROVED'`), add a "Produce" button alongside the existing "Procure" button.
   - Clicking "Produce" should trigger `production_plans` creation with `order_id = NULL` and `origin = 'LIVE_INVENTORY'`.
2. **Implement Origin-Aware Split at Transfer Ticket (Step 11)**:
   - In `create_transfer_ticket`:
     - Check if the linked production plan has `order_id > 0`.
     - If `order_id IS NULL` or `0` (Live Inventory origin): Call `inventoryAddStock` directly at Step 11, mark `transfer_ticket.workflow_status = 'RECEIVED'`, and close the production flow.
     - If `order_id > 0` (Order Management origin): Continue to Step 12 (`goods_received_from_production`) for Store receipt acknowledgement and order reservation.
3. **Execute Bulk COA Template Mapping Seeder**:
   - Run a reconciliation script to map the remaining 210 manufactured products with active BOMs to their matching biochemistry/serology/rapid/urine profile families.
