# Email-to-Order Processing Pipeline: Production Setup Guide (Hostinger)

This guide provides the complete, production-grade instructions for setting up and maintaining the automated **Email-to-Order processing pipeline** for `suraj@biogenix.in` hosted on **Hostinger**.

---

## 1. Architecture Overview

```
                          Customer sends order email
                                      │
                                      ▼
                        Hostinger Mailbox (INBOX)
                           suraj@biogenix.in
                                      │
                                      │ (Every 2 minutes via Hostinger Cron)
                                      ▼
                       admin/cron_email_orders.php
                                      │
               ┌──────────────────────┴──────────────────────┐
               ▼                                             ▼
     EmailPollerService                            EmailConfigService
     • Connects via IMAP                           • Reads .env configuration
     • Searches for UNSEEN emails                  • Host: imap.hostinger.com:993
               │
               ▼
      EmailParserService
      • Extracts sender info, client name, delivery address
      • Parses product list & quantities (format: Name | Qty | Unit)
               │
               ▼
      OrderEmailService
      • Resolves / creates customer
      • Matches product catalog & packaging units
      • Inserts into `order_received` & `order_received_items` (source_type = 2)
      • Logs full execution trace into `email_order_log`
               │
               ▼
     EmailResponderService (Outbound SMTP via PHPMailer)
      ├── If Success: Sends branded Order Confirmation with Order #
      └── If Failure: Sends rejection email with correct format guide
               │
               ▼
         EmailPollerService marks email as \Seen in IMAP mailbox
```

---

## 2. Prerequisites & Server Configuration

### A. Hostinger Email Account
1. Log in to **Hostinger hPanel** → **Emails** → **Email Accounts**.
2. Select domain **`biogenix.in`**.
3. Verify that the email account **`suraj@biogenix.in`** exists and is active.
4. Retrieve or reset the mailbox password.
5. Hostinger default server endpoints:
   - **Incoming (IMAP)**: `imap.hostinger.com` | Port: `993` | Encryption: `SSL`
   - **Outgoing (SMTP)**: `smtp.hostinger.com` | Port: `465` | Encryption: `SSL`

### B. Enable PHP `imap` Extension in Hostinger
The poller requires the native PHP `imap` extension (`imap_open`, `imap_search`, `imap_fetchstructure`, etc.).

1. In **Hostinger hPanel**, navigate to **Advanced** → **PHP Configuration**.
2. Select your active PHP version (**PHP 8.1** or **PHP 8.2**).
3. Click on the **PHP Extensions** tab.
4. Locate the **`imap`** extension and check the box to **enable** it.
5. Ensure the following standard extensions are also checked/enabled:
   - `openssl`
   - `mbstring`
   - `mysqli`
   - `json`
   - `curl`
6. Click **Save** at the bottom of the page.

---

## 3. Production Environment Configuration (`.env`)

Add or verify the following configuration block in the production root `.env` file:

```env
# ── Email Order Processing (IMAP - Inbound Mailbox) ──
MAIL_IMAP_HOST=imap.hostinger.com
MAIL_IMAP_PORT=993
MAIL_IMAP_ENCRYPTION=ssl
MAIL_IMAP_USERNAME=suraj@biogenix.in
MAIL_IMAP_PASSWORD=YourStrongHostingerMailPassword
MAIL_IMAP_FOLDER=INBOX

# ── Email Order Processing (SMTP - Outbound Auto-responder) ──
MAIL_SMTP_HOST=smtp.hostinger.com
MAIL_SMTP_PORT=465
MAIL_SMTP_ENCRYPTION=ssl
MAIL_SMTP_USERNAME=suraj@biogenix.in
MAIL_SMTP_PASSWORD=YourStrongHostingerMailPassword
MAIL_FROM_NAME=Biogenix IVD
MAIL_FROM_ADDRESS=suraj@biogenix.in
```

> **Security Note:** Never commit plain-text passwords to git. Ensure `.env` is listed in `.gitignore`.

---

## 4. File Permissions & Directory Structure

The email cron requires write permissions for runtime locking and file logging:

- **Lock File**: `admin/api/logs/email_cron.lock` (prevents overlapping cron executions)
- **Log File**: `admin/api/logs/email_orders.log` (detailed parser & order traces)

Ensure the directory exists with appropriate permissions on your production server:

```bash
mkdir -p admin/api/logs
chmod 755 admin/api/logs
```

---

## 5. Testing & Verification (Before Enabling Cron)

Before creating the scheduled cron job, verify that both the IMAP connection and the parsing pipeline work correctly.

### Method 1: Web Browser / HTTP Verification (Fastest)

Visit the following test URL in your browser:
```text
https://your-domain.com/admin/cron_email_orders.php?test
```
*(or via the master cron controller: `https://your-domain.com/admin/cronjob.php?processEmailOrders=1&test=1`)*

**Expected JSON Response:**
```json
{
  "status": true,
  "message": "[2026-09-07 12:00:00] CONNECTION TEST: {\"success\":true,\"message\":\"IMAP connection successful.\",\"mailbox\":\"{imap.hostinger.com:993/imap/ssl/novalidate-cert}INBOX\",\"messages\":5,\"unread\":0}",
  "data": {
    "success": true,
    "message": "IMAP connection successful.",
    "mailbox": "{imap.hostinger.com:993/imap/ssl/novalidate-cert}INBOX",
    "unread": 0
  }
}
```

### Method 2: SSH / Command Line Verification

```bash
# 1. Test IMAP connectivity only
php admin/cron_email_orders.php --test-connection

# 2. Dry run (parses unread emails but does NOT write orders or send replies)
php admin/cron_email_orders.php --dry-run

# 3. Live run (processes unread emails, creates orders, sends confirmations)
php admin/cron_email_orders.php
```

---

## 6. Hostinger Cron Job Setup

To process incoming order emails automatically in near real-time, configure a recurring cron job in Hostinger.

1. In **Hostinger hPanel**, go to **Advanced** → **Cron Jobs**.
2. Select **Custom**.
3. Set the schedule to run **every 2 minutes**:
   - Minute: `*/2`
   - Hour: `*`
   - Day: `*`
   - Month: `*`
   - Weekday: `*`
4. Enter the command:

### Option A: PHP CLI Command (Recommended)
```bash
/usr/bin/php /home/uXXXXXX/public_html/admin/cron_email_orders.php >> /home/uXXXXXX/public_html/admin/api/logs/email_cron.log 2>&1
```
*(Replace `/home/uXXXXXX/public_html/` with your actual Hostinger account path, which can be found in hPanel under **Hosting Details**).*

### Option B: Wget / Web Cron (Alternative if CLI is restricted)
```bash
wget -q -O - "https://your-domain.com/admin/cron_email_orders.php" > /dev/null 2>&1
```

5. Click **Save**.

---

## 7. Client Email Order Format & Syntax

For the automated parser (`EmailParserService.php`) to extract order lines reliably, the customer's email should follow this standard format:

```text
Subject: New Order — [Client or Hospital Name]

Client Name: ABC Diagnostics Pvt Ltd
Delivery Address: Plot 42, Sector 18, MIDC, Mahape, Navi Mumbai 400710
Order Type: Product Order
Payment Terms: Credit 30 Days
Dispatch Timeline: Immediate

Products:
1. Dengue NS1 Antigen Rapid Test | 100 | Kits
2. Malaria Pf/Pv Antigen Test | 50 | Kits
3. HIV 1/2 Triline Rapid Card | 200 | Kits

Remarks: Please ensure batch validity is greater than 18 months.
```

### Format Specifications:
- **Products section**: Prefaced by `Products:` or `Items:`.
- **Product line syntax**: `[Line Number]. [Product Name] | [Quantity] | [Pack/Unit]` (pipe `|` separated).
- **Auto-matching**:
  - The customer is automatically matched by `from_email` or `Client Name`. If not found, a new customer record is auto-provisioned.
  - Products are matched against the active `products` catalog with fallback tolerance for common aliases.

---

## 8. Database Tracking & Schema

Every incoming email is audited in the `email_order_log` table:

```sql
SELECT 
    id,
    message_id,
    from_email,
    from_name,
    subject,
    processing_status,
    order_id,
    response_sent,
    response_type,
    created_at
FROM email_order_log 
ORDER BY id DESC 
LIMIT 20;
```

### Status Codes (`processing_status`):
- `success`: Order created and confirmation email sent.
- `duplicate`: Email `Message-ID` already processed (safely skipped).
- `parse_error`: Required fields missing; guide email automatically dispatched.
- `validation_error`: Invalid products, missing quantities, or bad data.
- `system_error`: Database or network error during order insertion.

---

## 9. Troubleshooting & Common Issues

| Symptom | Cause | Solution |
| :--- | :--- | :--- |
| `PHP IMAP extension is not installed or enabled` | Hostinger PHP configuration missing `imap` module. | Go to hPanel → **PHP Configuration** → **PHP Extensions** and enable `imap`. |
| `IMAP connection failed: [AUTHENTICATIONFAILED]` | Incorrect email password in `.env`. | Verify webmail login at `mail.hostinger.com` using the credentials in `.env`. |
| `Another instance is already running` | Stale lock file left by interrupted execution. | Delete `admin/api/logs/email_cron.lock` or wait for timeout. |
| `No unseen emails found` | Emails were already opened/marked as read. | Mark test emails as **Unread** in webmail before triggering the cron. |
| Confirmation email not received by customer | SMTP credentials or SPF/DKIM issue. | Check `admin/api/logs/email_orders.log` for PHPMailer exceptions; verify SPF/DKIM records for `biogenix.in`. |
