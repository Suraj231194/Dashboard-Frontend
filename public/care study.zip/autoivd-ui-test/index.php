<?php
    date_default_timezone_set('Asia/Kolkata');
    ob_start();
    session_start();
    require_once 'admin/db.php';
    require_once 'admin/functions.php';
    // $hash = password_hash('password123', PASSWORD_DEFAULT);
    $appearanceSettings = getUserAppearanceSettings($conn, 0);
    $appearanceAccent = htmlspecialchars($appearanceSettings['accent_color'], ENT_QUOTES, 'UTF-8');
?>
<!doctype html>

<html lang="en" style="--appearance-accent: <?= $appearanceAccent ?>; --color-primary-50: color-mix(in srgb, <?= $appearanceAccent ?> 8%, #ffffff); --color-primary-100: color-mix(in srgb, <?= $appearanceAccent ?> 18%, #ffffff); --color-primary-200: color-mix(in srgb, <?= $appearanceAccent ?> 32%, #ffffff); --color-primary-500: color-mix(in srgb, <?= $appearanceAccent ?> 88%, #ffffff); --color-primary-600: <?= $appearanceAccent ?>; --color-primary-700: color-mix(in srgb, <?= $appearanceAccent ?> 78%, #000000); --color-primary-800: color-mix(in srgb, <?= $appearanceAccent ?> 60%, #000000); --color-primary-900: color-mix(in srgb, <?= $appearanceAccent ?> 42%, #000000);">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Auto</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/logo3.jpeg" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Sora:wght@400;500;600;700;800&display=swap" rel="stylesheet" />

    <!-- Icons -->
    <link rel="stylesheet" href="<?= asset('assets/vendor/fonts/fontawesome.css') ?>" />
    <link rel="stylesheet" href="<?= asset('assets/vendor/fonts/tabler-icons.css') ?>" />
    <link rel="stylesheet" href="<?= asset('assets/vendor/fonts/flag-icons.css') ?>" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="<?= asset('assets/css/tailwind.css') ?>" />
    <link rel="stylesheet" href="<?= asset('assets/css/theme.css') ?>" />
    
    <style>
        body {
            font-family: 'Manrope', sans-serif;
            background-color: #f8fafc;
            background-image: radial-gradient(at 0% 0%, hsla(158, 82%, 91%, 1) 0, transparent 50%), radial-gradient(at 100% 100%, hsla(158, 82%, 91%, 1) 0, transparent 50%);
            min-height: 100vh;
        }
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Sora', sans-serif;
        }
        
        /* Custom Theme Overrides for Login */
        .login-btn {
            background-color: var(--color-primary-600);
            border: 1px solid var(--color-primary-700);
        }
        .login-btn:hover {
            background-color: var(--color-primary-700);
        }
        .login-btn:focus {
            outline: none;
            box-shadow: 0 0 0 4px rgba(36, 122, 66, 0.3); /* ring-primary-500/30 */
        }
        
        .login-input:focus {
            border-color: var(--color-primary-500);
            box-shadow: 0 0 0 2px rgba(36, 122, 66, 0.2); /* ring-primary-500/20 */
        }
        
        .login-icon:hover {
            color: var(--color-primary-600);
        }
        
        .bg-blur-1 {
            background-color: rgba(163, 224, 187, 0.3); /* primary-200/30 */
        }
        .bg-blur-2 {
            background-color: rgba(163, 224, 187, 0.2); /* primary-200/20 */
        }
    </style>
</head>

<body>
    <!-- Content -->

    <div class="flex min-h-[100dvh] items-center justify-center p-4">
        <!-- Decorative background blur elements -->
        <div class="absolute inset-0 overflow-hidden pointer-events-none">
            <div class="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] rounded-full bg-blur-1 blur-[100px]"></div>
            <div class="absolute top-[60%] -right-[10%] w-[60%] h-[60%] rounded-full bg-blur-2 blur-[120px]"></div>
        </div>

        <div class="relative w-full max-w-md overflow-hidden rounded-[2rem] border border-white/60 bg-white/70 p-8 shadow-[0_8px_30px_rgb(0,0,0,0.04)] backdrop-blur-xl sm:p-10">
            <!-- Logo -->
            <div class="mb-8 flex justify-center">
                <div class="inline-flex items-center justify-center rounded-2xl bg-white p-3 shadow-sm ring-1 ring-slate-900/5">
                    <img src="assets/img/logo3.jpeg" alt="Biogenix" class="h-12 w-auto object-contain mix-blend-multiply">
                </div>
            </div>
            
            <!-- Header -->
            <div class="mb-8 text-center">
                <h4 class="mb-2 text-2xl font-bold tracking-tight text-slate-900">Welcome back 🚀</h4>
                <p class="text-sm font-medium text-slate-500">Please sign in to your account</p>
            </div>

            <!-- PHP Auth Logic -->
            <?php                       
                $error = '';
                if (isset($_POST['loginbtn'])) {
                    $email = trim($_POST['email']);
                    $password = $_POST['password'];

                    if (empty($email) || empty($password)) {
                        $error = "Email and Password are required.";
                    } else {
                        // $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1");
                        $stmt = $conn->prepare("SELECT u.*, r.name AS role_name, c.company_name AS company_name, b.branch_name AS branch_name FROM users u LEFT JOIN roles r ON u.role_id = r.id LEFT JOIN erp_companies c ON u.company_id = c.id LEFT JOIN erp_branches b ON u.branch_id = b.id WHERE u.email = ? AND u.is_active = 1");
                        
                        if ($stmt === false) {
                            $error = "Database Error: " . htmlspecialchars($conn->error);
                        } else {
                            $stmt->bind_param("s", $email);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            $user = $result->fetch_assoc();

                            if ($user) {
                                $enteredPassword = md5($_POST['password']);
                                if (!empty($user['password']) && $enteredPassword === $user['password']) {
                                    $_SESSION['user_id'] = $user['id'];
                                    $_SESSION['user_name'] = $user['name'];
                                    $_SESSION['user_email'] = $user['email'];
                                    $_SESSION['role_id'] = $user['role_id'];
                                    $_SESSION['role_name']     = $user['role_name'];
                                    $_SESSION['company_id']    = $user['company_id'];
                                    $_SESSION['company_name']  = $user['company_name'];
                                    $_SESSION['branch_id']     = $user['branch_id'];
                                    $_SESSION['branch_name']   = $user['branch_name'];
                                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                                    header("Location: admin/index.php");
                                    exit;
                                } else {
                                    $error = "Invalid email or password.";
                                }
                            } else {
                                $error = "User not found or inactive.";
                            }
                            $stmt->close();
                        }
                    }
                }
            ?>

            <!-- Error Alert -->
            <?php if (!empty($error)) : ?>
                <div class="mb-6 overflow-hidden rounded-xl border border-rose-200 bg-rose-50/80 p-4 shadow-sm backdrop-blur-sm">
                    <div class="flex items-center gap-3">
                        <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-rose-100 text-rose-600">
                            <i class="ti ti-alert-circle text-lg"></i>
                        </div>
                        <p class="m-0 text-sm font-semibold text-rose-700"><?= htmlspecialchars($error) ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="POST" class="flex flex-col gap-5">                            
                <div>
                    <label for="email" class="mb-1.5 block text-sm font-bold text-slate-700">Email Address</label>
                    <div class="relative">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4">
                            <i class="ti ti-mail text-lg text-slate-400"></i>
                        </div>
                        <input type="email" id="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" 
                            class="h-12 w-full rounded-xl border border-slate-200 bg-white/80 py-2 pl-11 pr-4 text-sm font-semibold text-slate-800 shadow-sm outline-none transition-all placeholder:text-slate-400 hover:border-slate-300 login-input focus:bg-white" 
                            placeholder="name@biogenix.in" required />
                    </div>
                </div>
                
                <div>
                    <div class="mb-1.5 flex items-center justify-between">
                        <label for="password" class="text-sm font-bold text-slate-700">Password</label>
                        <!-- <a href="#" class="text-xs font-bold text-emerald-600 transition-colors hover:text-emerald-700">Forgot Password?</a> -->
                    </div>
                    <div class="relative">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4">
                            <i class="ti ti-lock text-lg text-slate-400"></i>
                        </div>
                        <input type="password" id="password" name="password" 
                            class="h-12 w-full rounded-xl border border-slate-200 bg-white/80 py-2 pl-11 pr-12 text-sm font-semibold text-slate-800 shadow-sm outline-none transition-all placeholder:text-slate-400 hover:border-slate-300 login-input focus:bg-white" 
                            placeholder="••••••••••••" required />
                        <button type="button" class="seePassword absolute inset-y-0 right-0 flex items-center px-4 text-slate-400 transition-colors login-icon focus:outline-none">
                            <i class="ti ti-eye-off text-lg"></i>
                        </button>
                    </div>
                </div>
                
                <div class="mt-4">
                    <button type="submit" name="loginbtn" 
                        class="group relative flex h-12 w-full items-center justify-center gap-2 overflow-hidden rounded-xl login-btn px-4 text-sm font-bold text-white shadow-md transition-all active:scale-[0.98]">
                        <span class="relative z-10">Sign In</span>
                        <i class="ti ti-arrow-right relative z-10 text-lg transition-transform group-hover:translate-x-1"></i>
                    </button>
                </div>
            </form>                        
        </div>
    </div>

    <!-- / Content -->

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->

    <script src="<?= asset('assets/vendor/libs/jquery/jquery.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/popper/popper.js') ?>"></script>
    <script src="<?= asset('assets/vendor/js/bootstrap.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/node-waves/node-waves.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/hammer/hammer.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/i18n/i18n.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/typeahead-js/typeahead.js') ?>"></script>
    <script src="<?= asset('assets/vendor/js/menu.js') ?>"></script>

    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="<?= asset('assets/vendor/libs/@form-validation/popular.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/@form-validation/bootstrap5.js') ?>"></script>
    <script src="<?= asset('assets/vendor/libs/@form-validation/auto-focus.js') ?>"></script>

    <!-- Helpers and theme config, which main.js reads on load -->
    <script src="<?= asset('assets/vendor/js/helpers.js') ?>"></script>
    <script src="<?= asset('assets/js/config.js') ?>"></script>

    <!-- Main JS -->
    <script src="<?= asset('assets/js/main.js') ?>"></script>

    <!-- Page JS -->
    <script src="<?= asset('assets/js/pages-auth.js') ?>"></script>
    <script>
        $(document).ready(function() {
            $('.seePassword').on('click', function() {
                const input = $("#password");
                const icon = $(this).find('i');

                if (input.attr('type') === 'password') {
                    input.attr('type', 'text');
                    icon.removeClass('ti-eye-off').addClass('ti-eye');
                } else {
                    input.attr('type', 'password');
                    icon.removeClass('ti-eye').addClass('ti-eye-off');
                }
            });
        });
    </script>
</body>

</html>