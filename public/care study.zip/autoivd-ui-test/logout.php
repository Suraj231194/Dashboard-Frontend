<?php
session_start();

// Destroy all session data
session_unset();
session_destroy();

// Optional: remove session cookie
if (ini_get("session.use_cookies")) {
    setcookie(session_name(), '', time() - 3600, '/');
}

// Redirect to login page
header("Location: index.php");
exit;
