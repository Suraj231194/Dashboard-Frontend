import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { StocksScreen } from "@/modules/inventory/StocksScreen";

export default async function StocksPage() {
  const { user, allowed } = await getPageAccess("stocks");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    add: "stocks_add",
    edit: "stocks_edit",
    // The Produce action raises a Production Plan, so it is gated on the
    // production permission rather than on stock editing.
    produce: "operations_admin_production_plan_add",
  });
  // The procurement dialog reports against the signed-in user's email, as today.
  return <StocksScreen permissions={permissions} reportingOfficer={user.email} />;
}
