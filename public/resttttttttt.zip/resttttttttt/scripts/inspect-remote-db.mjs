import mysql from "mysql2/promise";

const connection = await mysql.createConnection({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USERNAME,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_DATABASE,
  connectTimeout: 10000,
  ssl: { rejectUnauthorized: true },
});

try {
  const [[server]] = await connection.query("SELECT VERSION() AS version, @@sql_mode AS sql_mode");
  console.log(JSON.stringify(server));
  const [rows] = await connection.execute(
    `SELECT COUNT(*) AS object_count,
            ROUND(SUM(COALESCE(data_length, 0) + COALESCE(index_length, 0)) / 1024 / 1024, 2) AS estimated_mb
     FROM information_schema.tables WHERE table_schema = ?`,
    [process.env.DB_DATABASE],
  );
  console.log(JSON.stringify(rows[0]));
  const [types] = await connection.execute(
    `SELECT table_type, COALESCE(engine, 'N/A') AS engine, COUNT(*) AS object_count
     FROM information_schema.tables WHERE table_schema = ? GROUP BY table_type, engine`,
    [process.env.DB_DATABASE],
  );
  console.log(JSON.stringify(types));
  const [extras] = await connection.execute(
    `SELECT
      (SELECT COUNT(*) FROM information_schema.triggers WHERE trigger_schema = ?) AS trigger_count,
      (SELECT COUNT(*) FROM information_schema.routines WHERE routine_schema = ?) AS routine_count,
      (SELECT COUNT(*) FROM information_schema.events WHERE event_schema = ?) AS event_count`,
    [process.env.DB_DATABASE, process.env.DB_DATABASE, process.env.DB_DATABASE],
  );
  console.log(JSON.stringify(extras[0]));
  const [processes] = await connection.query("SHOW PROCESSLIST");
  console.log(JSON.stringify(processes.filter((entry) => entry.User === process.env.DB_USERNAME).map(({ Command, Time, State }) => ({ Command, Time, State }))));
} finally {
  await connection.end();
}
