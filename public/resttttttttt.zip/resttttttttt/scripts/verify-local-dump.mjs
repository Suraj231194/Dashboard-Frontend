import { createReadStream } from "node:fs";
import { readdir, stat } from "node:fs/promises";
import { join } from "node:path";
import { createGunzip } from "node:zlib";
import { createInterface } from "node:readline";
import { createHash } from "node:crypto";

const directory = join(process.env.LOCALAPPDATA, "AutoIVD-Migration");
const files = (await readdir(directory)).filter((name) => /^autoivd-staging-.*\.sql\.gz$/.test(name)).sort();
if (files.length === 0) throw new Error("No local staging dump found");
const path = join(directory, files.at(-1));

const hash = createHash("sha256");
for await (const chunk of createReadStream(path)) hash.update(chunk);

const counts = { tables: 0, inserts: 0, triggers: 0, finalMarker: false };
const lines = createInterface({ input: createReadStream(path).pipe(createGunzip()), crlfDelay: Infinity });
for await (const line of lines) {
  if (line.startsWith("DROP TABLE IF EXISTS ")) counts.tables++;
  if (line.startsWith("INSERT INTO ")) counts.inserts++;
  if (line === "DELIMITER $$") counts.triggers++;
  if (line === "SET FOREIGN_KEY_CHECKS=1;") counts.finalMarker = true;
}
if (!counts.finalMarker || counts.tables === 0) throw new Error("Dump is incomplete");
console.log(JSON.stringify({ path, compressedBytes: (await stat(path)).size, sha256: hash.digest("hex"), ...counts }));
