import mysql from "mysql2/promise";
const c = await mysql.createConnection({host:process.env.DB_HOST,port:+process.env.DB_PORT,user:process.env.DB_USERNAME,password:process.env.DB_PASSWORD,database:process.env.DB_DATABASE});
const [p] = await c.execute("SELECT id,slug FROM permissions WHERE slug LIKE '%issuance%'");
console.log("ISSUANCE PERMS", p);
for (const t of ["stock_inwards","stock_outward","stock_outward_items","goods_received_from_production"]) {
  const [cols] = await c.execute(`SHOW COLUMNS FROM \`${t}\``);
  console.log("==", t, cols.map(x=>`${x.Field}:${x.Type}${x.Null==='NO'?'!':''}${x.Extra?'/'+x.Extra:''}`).join(", "));
}
await c.end();
