import mysql from "mysql2/promise";
const c = await mysql.createConnection({host:process.env.DB_HOST,port:+process.env.DB_PORT,user:process.env.DB_USERNAME,password:process.env.DB_PASSWORD,database:process.env.DB_DATABASE});
const [menus] = await c.execute("SELECT id, name, route, permission_slug FROM menus WHERE route LIKE '%stock-inward%' OR route LIKE '%stock-outward%' OR route LIKE '%goods-issuance%' OR route LIKE '%goods-received-production%'");
console.log("MENUS", menus);
const [perms] = await c.execute("SELECT id, name, slug FROM permissions WHERE slug LIKE 'store_stock_inwards%' OR slug LIKE 'store_stock_outwards%' OR slug LIKE 'store_goods%'");
console.log("PERMS", perms);
for (const t of ["stock_inwards","stock_outward","stock_outward_items","goods_received_from_production","coa_inbound_queue","erp_warehouses","receiver_emp","material_requisition","material_requisition_items","transfer_ticket"]) {
  const [[r]] = await c.execute(`SELECT COUNT(*) total FROM \`${t}\``);
  console.log(t, r.total);
}
await c.end();
