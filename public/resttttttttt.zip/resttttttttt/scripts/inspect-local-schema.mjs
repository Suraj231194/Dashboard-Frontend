import { readFile } from "node:fs/promises";
import { join } from "node:path";
import mysql from "mysql2/promise";
import mysqlFormat from "mysql2";

const config = JSON.parse(await readFile(join(process.env.LOCALAPPDATA, "AutoIVD-Migration", "local-db-connection.json"), "utf8"));
if (config.host !== "127.0.0.1" || config.port !== 3307) throw new Error("Refusing non-local database");
const db = await mysql.createConnection({ host: config.host, port: config.port,
  user: config.appUser, password: config.appPassword, database: config.database });
try {
  for (const name of ["users", "roles", "permissions", "role_permissions", "user_permissions", "user_appearance_settings"]) {
    const [rows] = await db.query(`SHOW CREATE TABLE ${mysqlFormat.escapeId(name)}`);
    console.log(`${name}:\n${rows[0]["Create Table"]}\n`);
  }
  const [counts] = await db.query("SELECT COUNT(*) AS count FROM roles");
  console.log(`Roles: ${counts[0].count}`);
} finally { await db.end(); }
