import { readFile } from "node:fs/promises";
import { join } from "node:path";
import mysql from "mysql2/promise";

const directory = join(process.env.LOCALAPPDATA, "AutoIVD-Migration");
const config = JSON.parse(await readFile(join(directory, "local-db-connection.json"), "utf8"));
if (config.host !== "127.0.0.1" || config.port !== 3307 || config.database !== "autoivd_staging") {
  throw new Error("Refusing to migrate a non-staging database");
}
const sql = await readFile(new URL("../migrations/001_next_sessions.sql", import.meta.url), "utf8");
const db = await mysql.createConnection({ host: config.host, port: config.port,
  user: config.appUser, password: config.appPassword, database: config.database });
try {
  await db.query(sql);
  console.log("Applied next_sessions migration to local staging database");
} finally { await db.end(); }
