import { spawn } from "node:child_process";
import { createReadStream } from "node:fs";
import { readFile, readdir } from "node:fs/promises";
import { join } from "node:path";
import { pipeline } from "node:stream/promises";
import { Transform } from "node:stream";
import { StringDecoder } from "node:string_decoder";
import { createGunzip } from "node:zlib";
import mysql from "mysql2/promise";
import mysqlFormat from "mysql2";

const directory = join(process.env.LOCALAPPDATA, "AutoIVD-Migration");
const config = JSON.parse(await readFile(join(directory, "local-db-connection.json"), "utf8"));
const files = (await readdir(directory)).filter((name) => /^autoivd-staging-.*\.sql\.gz$/.test(name)).sort();
if (files.length === 0) throw new Error("No staging dump found");
const archive = join(directory, files.at(-1));
const client = join(directory, "mariadb-11.8.9-winx64", "bin", "mariadb.exe");

// Restore only to the dedicated loopback database. The source archive remains unchanged.
if (config.host !== "127.0.0.1" || config.port !== 3307 || config.database !== "autoivd_staging") {
  throw new Error("Refusing to restore to a non-staging destination");
}

const connection = await mysql.createConnection({ host: config.host, port: config.port,
  user: config.appUser, password: config.appPassword, database: config.database });
await connection.end();

class RemoveRemoteDefiners extends Transform {
  decoder = new StringDecoder("utf8");
  remainder = "";

  _transform(chunk, _encoding, callback) {
    try {
      const text = this.remainder + this.decoder.write(chunk);
      const lines = text.split("\n");
      this.remainder = lines.pop();
      for (const line of lines) this.push(this.rewrite(line) + "\n");
      callback();
    } catch (error) { callback(error); }
  }

  _flush(callback) {
    try {
      const last = this.remainder + this.decoder.end();
      if (last) this.push(this.rewrite(last));
      callback();
    } catch (error) { callback(error); }
  }

  rewrite(line) {
    return line.replace(/^(CREATE\s+)DEFINER\s*=\s*(?:`[^`]+`|'[^']+'|[^\s@]+)@(?:`[^`]+`|'[^']+'|[^\s]+)\s+(TRIGGER\s+)/i, "$1$2");
  }
}

const child = spawn(client, [
  "--host=127.0.0.1", "--port=3307", `--user=${config.appUser}`,
  "--init-command=SET SESSION sql_mode='IGNORE_SPACE,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'",
  "--default-character-set=utf8mb4", "--binary-mode", config.database,
], { env: { ...process.env, MYSQL_PWD: config.appPassword }, stdio: ["pipe", "ignore", "pipe"], windowsHide: true });
const closePromise = new Promise((resolve) => child.on("close", resolve));

let errorOutput = "";
child.stderr.setEncoding("utf8");
child.stderr.on("data", (chunk) => { errorOutput = (errorOutput + chunk).slice(-8000); });
let streamError;
try {
  await pipeline(createReadStream(archive), createGunzip(), new RemoveRemoteDefiners(), child.stdin);
} catch (error) {
  streamError = error;
  child.kill();
}
const exitCode = await closePromise;
if (streamError || exitCode !== 0) {
  const summary = [...errorOutput.matchAll(/ERROR\s+\d+[^\r\n]*/g)].map((match) => match[0].slice(0, 180));
  throw new Error(`Staging restore failed (exit ${exitCode}): ${summary.join("; ") || "see local error output"}`);
}

const verify = await mysql.createConnection({ host: config.host, port: config.port,
  user: config.appUser, password: config.appPassword, database: config.database });
try {
  const [tables] = await verify.query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'");
  let rows = 0;
  for (const table of tables) {
    const name = Object.values(table)[0];
    const [[count]] = await verify.query(`SELECT COUNT(*) AS total FROM ${mysqlFormat.escapeId(name)}`);
    rows += Number(count.total);
  }
  const [triggers] = await verify.query("SHOW TRIGGERS");
  console.log(JSON.stringify({ database: config.database, tables: tables.length, rows, triggers: triggers.length }));
} finally {
  await verify.end();
}
