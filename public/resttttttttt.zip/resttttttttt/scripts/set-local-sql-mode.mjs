import { readFile } from "node:fs/promises";
import { join } from "node:path";
import mysql from "mysql2/promise";

const config = JSON.parse(await readFile(join(process.env.LOCALAPPDATA, "AutoIVD-Migration", "local-db-connection.json"), "utf8"));
if (config.host !== "127.0.0.1" || config.port !== 3307) throw new Error("Refusing non-local database");
const connection = await mysql.createConnection({ host: config.host, port: config.port,
  user: config.rootUser, password: config.rootPassword });
try {
  await connection.query("SET GLOBAL sql_mode = 'IGNORE_SPACE,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'");
  console.log("Local SQL mode matched to production");
} finally { await connection.end(); }
