import { readFile } from "node:fs/promises";
import { join } from "node:path";
import mysql from "mysql2/promise";

const directory = join(process.env.LOCALAPPDATA, "AutoIVD-Migration");
const account = JSON.parse(await readFile(join(directory, "local-test-account.json"), "utf8"));
const config = JSON.parse(await readFile(join(directory, "local-db-connection.json"), "utf8"));
const origin = "http://127.0.0.1:3000";
const assert = (condition, message) => { if (!condition) throw new Error(message); };

const invalid = await fetch(`${origin}/api/auth/login`, {
  method: "POST", redirect: "manual", headers: { Origin: origin },
  body: new URLSearchParams({ email: account.email, password: "wrong-password" }),
});
assert(invalid.status === 303 && invalid.headers.get("location")?.includes("error=invalid"), "Invalid password was accepted");

const login = await fetch(`${origin}/api/auth/login`, {
  method: "POST", redirect: "manual", headers: { Origin: origin },
  body: new URLSearchParams({ email: account.email, password: account.password }),
});
assert(login.status === 303 && login.headers.get("location")?.endsWith("/dashboard"), "Login failed");
const cookie = login.headers.get("set-cookie")?.split(";")[0];
assert(cookie?.startsWith("autoivd_session="), "Session cookie missing");

const dashboard = await fetch(`${origin}/dashboard`, { headers: { Cookie: cookie } });
assert(dashboard.status === 200 && (await dashboard.text()).includes("Migration Test"), "Authenticated dashboard failed");

const appearance = await fetch(`${origin}/appearance`, { headers: { Cookie: cookie } });
assert(appearance.status === 200 && (await appearance.text()).includes("Appearance Settings"), "Appearance page failed");

const update = await fetch(`${origin}/api/settings/appearance`, {
  method: "POST", headers: { Origin: origin, Cookie: cookie },
  body: new URLSearchParams({ theme_mode: "dark", accent_color: "#05745D", font_family: "Inter", base_font_size: "16" }),
});
const result = await update.json();
assert(update.status === 200 && result.status === "success", "Appearance update failed");

const db = await mysql.createConnection({ host: config.host, port: config.port,
  user: config.appUser, password: config.appPassword, database: config.database });
try {
  const [[saved]] = await db.execute("SELECT theme_mode, accent_color, font_family, base_font_size FROM user_appearance_settings WHERE user_id = ?", [account.id]);
  assert(saved?.theme_mode === "dark" && saved.accent_color === "#05745D" && saved.font_family === "Inter" && saved.base_font_size === 16,
    "Appearance settings were not saved as expected");
} finally { await db.end(); }

const logout = await fetch(`${origin}/api/auth/logout`, {
  method: "POST", redirect: "manual", headers: { Origin: origin, Cookie: cookie },
});
assert(logout.status === 303, "Logout failed");
const afterLogout = await fetch(`${origin}/dashboard`, { redirect: "manual", headers: { Cookie: cookie } });
assert(afterLogout.status === 307, "Logged-out session still works");

console.log("Local staging checks passed: invalid login, login, dashboard, appearance read/write, logout");
