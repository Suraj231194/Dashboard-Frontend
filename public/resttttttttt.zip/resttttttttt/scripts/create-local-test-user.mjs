import { createHash, randomBytes } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import mysql from "mysql2/promise";

const directory = join(process.env.LOCALAPPDATA, "AutoIVD-Migration");
const config = JSON.parse(await readFile(join(directory, "local-db-connection.json"), "utf8"));
if (config.host !== "127.0.0.1" || config.port !== 3307 || config.database !== "autoivd_staging") {
  throw new Error("Refusing to create a test user outside local staging");
}
const output = join(directory, "local-test-account.json");
const db = await mysql.createConnection({ host: config.host, port: config.port,
  user: config.appUser, password: config.appPassword, database: config.database });
try {
  const [roles] = await db.query("SELECT id FROM roles WHERE status = 1 ORDER BY id LIMIT 1");
  if (!roles.length) throw new Error("No active role in staging copy");
  const password = randomBytes(24).toString("hex");
  const email = `migration-check-${randomBytes(6).toString("hex")}@example.invalid`;
  const [result] = await db.execute(
    "INSERT INTO users (name, email, password, role_id, is_active) VALUES (?, ?, ?, ?, 1)",
    ["Migration Test", email, createHash("md5").update(password).digest("hex"), roles[0].id],
  );
  await writeFile(output, JSON.stringify({ id: result.insertId, email, password }, null, 2), { mode: 0o600 });
  console.log("Created isolated test account in local staging database");
} finally { await db.end(); }
