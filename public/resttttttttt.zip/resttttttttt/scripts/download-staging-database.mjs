import { createWriteStream } from "node:fs";
import { mkdir, rm, stat } from "node:fs/promises";
import { join } from "node:path";
import { once } from "node:events";
import { finished } from "node:stream/promises";
import { createGzip } from "node:zlib";
import mysql from "mysql2/promise";
import mysqlFormat from "mysql2";

for (const key of ["DB_HOST", "DB_DATABASE", "DB_USERNAME", "DB_PASSWORD"]) {
  if (!process.env[key]) throw new Error(`Missing ${key}`);
}
if (!process.env.LOCALAPPDATA) throw new Error("LOCALAPPDATA is required for the local backup path");

const outputDir = join(process.env.LOCALAPPDATA, "AutoIVD-Migration");
await mkdir(outputDir, { recursive: true });
const stamp = new Date().toISOString().replaceAll(":", "-").replaceAll(".", "-");
const outputPath = join(outputDir, `autoivd-staging-${stamp}.sql.gz`);
const gzip = createGzip({ level: 6 });
const file = createWriteStream(outputPath, { flags: "wx", mode: 0o600 });
gzip.pipe(file);

let completed = false;
let connection;
async function write(value) {
  if (!gzip.write(value)) await once(gzip, "drain");
}

try {
  connection = await mysql.createConnection({
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATABASE,
    connectTimeout: 10000,
    ssl: { rejectUnauthorized: true },
    dateStrings: true,
    supportBigNumbers: true,
    bigNumberStrings: true,
    charset: "utf8mb4",
  });

  const [objects] = await connection.execute(
    `SELECT table_name AS name FROM information_schema.tables
     WHERE table_schema = ? AND table_type = 'BASE TABLE' ORDER BY table_name`,
    [process.env.DB_DATABASE],
  );
  const [triggers] = await connection.execute(
    `SELECT trigger_name AS name FROM information_schema.triggers
     WHERE trigger_schema = ? ORDER BY trigger_name`,
    [process.env.DB_DATABASE],
  );

  await connection.query("SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ");
  await connection.query("SET TRANSACTION READ ONLY");
  await connection.query("START TRANSACTION WITH CONSISTENT SNAPSHOT");
  await write(`-- AutoIVD read-only staging snapshot created ${new Date().toISOString()}\n`);
  await write("SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\nSET UNIQUE_CHECKS=0;\n\n");

  let totalRows = 0;
  for (const [index, object] of objects.entries()) {
    const name = object.name;
    const identifier = mysqlFormat.escapeId(name);
    const [definitions] = await connection.query(`SHOW CREATE TABLE ${identifier}`);
    const definition = definitions[0]?.["Create Table"];
    if (!definition) throw new Error(`Cannot read definition for ${name}`);
    await write(`-- Table ${identifier}\nDROP TABLE IF EXISTS ${identifier};\n${definition};\n\n`);

    const [columnRows] = await connection.query(`SHOW COLUMNS FROM ${identifier}`);
    const columns = columnRows.filter((column) => !/\bGENERATED\b/i.test(column.Extra));
    if (columns.length === 0) continue;
    const columnNames = columns.map((column) => mysqlFormat.escapeId(column.Field)).join(", ");
    let offset = 0;
    const batchSize = 200;
    while (true) {
      const [rows] = await connection.query(
        `SELECT ${columnNames} FROM ${identifier} LIMIT ? OFFSET ?`, [batchSize, offset],
      );
      if (rows.length === 0) break;
      const values = rows.map((row) => `(${columns.map((column) => {
        const value = row[column.Field];
        // mysql2 parses JSON columns into objects; SQL escaping an object would emit
        // identifier assignments instead of a JSON string literal.
        return mysqlFormat.escape(value !== null && typeof value === "object" && !Buffer.isBuffer(value)
          ? JSON.stringify(value) : value);
      }).join(", ")})`);
      await write(`INSERT INTO ${identifier} (${columnNames}) VALUES\n${values.join(",\n")};\n`);
      offset += rows.length;
      totalRows += rows.length;
      if (rows.length < batchSize) break;
    }
    await write("\n");
    if ((index + 1) % 20 === 0 || index + 1 === objects.length) {
      console.log(`Exported ${index + 1}/${objects.length} tables`);
    }
  }

  for (const trigger of triggers) {
    const [definitions] = await connection.query(`SHOW CREATE TRIGGER ${mysqlFormat.escapeId(trigger.name)}`);
    const definition = definitions[0]?.["SQL Original Statement"] ?? definitions[0]?.["Create Trigger"];
    if (!definition) throw new Error(`Cannot read trigger definition for ${trigger.name}`);
    await write(`DELIMITER $$\n${definition}$$\nDELIMITER ;\n\n`);
  }
  await write("SET UNIQUE_CHECKS=1;\nSET FOREIGN_KEY_CHECKS=1;\n");
  await connection.query("COMMIT");
  gzip.end();
  await finished(file);
  completed = true;
  const result = await stat(outputPath);
  console.log(JSON.stringify({ path: outputPath, tables: objects.length, triggers: triggers.length, rows: totalRows, compressedBytes: result.size }));
} finally {
  if (connection) await connection.end().catch(() => {});
  if (!completed) {
    gzip.destroy();
    file.destroy();
    await rm(outputPath, { force: true }).catch(() => {});
  }
}
