import { readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";

const source = resolve(import.meta.dirname, "../../admin/ajax.php");
const destination = resolve(import.meta.dirname, "../legacy-ajax-actions.csv");
const lines = readFileSync(source, "utf8").split(/\r?\n/);
const entries = [];
const knownModules = new Map([
  ["saveAppearanceSettings", { module: "settings/appearance", status: "implemented-unverified" }],
]);

for (const [index, line] of lines.entries()) {
  // This is an initial inventory of direct top-level POST dispatch branches.
  // Nested branches, aliases, and dynamic dispatch are reviewed per module.
  if (!/^if\s*\(/.test(line)) continue;
  const actions = [...line.matchAll(/\$_POST\s*\[\s*['"]([^'"]+)['"]\s*\]/g)].map(
    (match) => match[1],
  );
  if (actions.length === 0) continue;
  for (const action of new Set(actions)) {
    entries.push({ line: index + 1, action });
  }
}

const quote = (value) => `"${String(value).replaceAll('"', '""')}"`;
const rows = ["source,line,action,module,status", ...entries.map(({ line, action }) =>
  ["admin/ajax.php", line, action, knownModules.get(action)?.module ?? "", knownModules.get(action)?.status ?? "unreviewed"].map(quote).join(","),
)];
writeFileSync(destination, `${rows.join("\n")}\n`);
console.log(`Wrote ${entries.length} action references to ${destination}`);
