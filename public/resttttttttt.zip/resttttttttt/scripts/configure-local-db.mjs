import { randomBytes } from "node:crypto";
import { writeFile } from "node:fs/promises";
import { join } from "node:path";
import mysql from "mysql2/promise";
import mysqlFormat from "mysql2";

const configPath = join(process.env.LOCALAPPDATA, "AutoIVD-Migration", "local-db-connection.json");
const rootPassword = randomBytes(32).toString("hex");
const appPassword = randomBytes(32).toString("hex");
const config = {
  host: "127.0.0.1",
  port: 3307,
  database: "autoivd_staging",
  rootUser: "root",
  rootPassword,
  appUser: "autoivd_app",
  appPassword,
};

const connection = await mysql.createConnection({ host: config.host, port: config.port, user: "root" });
try {
  const [accounts] = await connection.query("SELECT Host AS host FROM mysql.user WHERE User = 'root'");
  // Persist the generated secret before changing accounts so it remains recoverable after an error.
  await writeFile(configPath, JSON.stringify(config, null, 2), { mode: 0o600 });
  for (const { host } of accounts) {
    await connection.query(`ALTER USER 'root'@${mysqlFormat.escape(host)} IDENTIFIED BY ${mysqlFormat.escape(rootPassword)}`);
  }
  await connection.query("CREATE DATABASE IF NOT EXISTS autoivd_staging CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
  for (const host of ["localhost", "127.0.0.1"]) {
    await connection.query(`CREATE USER IF NOT EXISTS 'autoivd_app'@${mysqlFormat.escape(host)} IDENTIFIED BY ${mysqlFormat.escape(appPassword)}`);
    await connection.query(`GRANT ALL PRIVILEGES ON autoivd_staging.* TO 'autoivd_app'@${mysqlFormat.escape(host)}`);
  }
  console.log("Local root and staging app credentials configured in AppData");
} finally {
  await connection.end();
}
