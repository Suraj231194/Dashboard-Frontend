import { chromium } from "playwright";

const browser = await chromium.launch({ channel: "chrome", headless: true });
const page = await browser.newPage({ viewport: { width: 1600, height: 1000 } });
await page.goto("http://localhost:3000/login");
await page.getByLabel("Email Address").fill("externaldev@biogenix.in");
await page.getByLabel("Password").fill("123456789");
await Promise.all([
  page.waitForURL("**/dashboard"),
  page.getByRole("button", { name: "Sign In" }).click(),
]);
await page.goto("http://localhost:3000/ip-coa-generation");
await page.getByRole("button", { name: /Incoming I\.P COA Generation Form!/ }).click();
const fillButtons = page.getByRole("button", { name: "Fill Form" });
if (await fillButtons.count() > 0) {
  await fillButtons.first().click();
} else {
  await page.keyboard.press("Escape");
  const drafts = page.getByRole("button", { name: /Continue the draft/ });
  if (await drafts.count() === 0) throw new Error("No controlled IP COA is available for the UI check.");
  await drafts.first().click();
}
await page.getByRole("heading", { name: "IP COA Template" }).waitFor();
const dialog = page.getByRole("dialog");
const counts = {};
for (const label of ["IP COA No.", "Department", "Testing Date", "Remarks"]) {
  counts[label] = await dialog.getByText(label, { exact: true }).count();
}
counts.templateDocument = await dialog.getByText("TITLE: CERTIFICATE OF ANALYSIS", { exact: true }).count();
console.log(JSON.stringify(counts));
await browser.close();
