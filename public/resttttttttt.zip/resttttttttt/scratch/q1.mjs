import mysql from "mysql2/promise";
const c = await mysql.createConnection({host:process.env.DB_HOST,port:+process.env.DB_PORT,user:process.env.DB_USERNAME,password:process.env.DB_PASSWORD,database:process.env.DB_DATABASE});
const [menus] = await c.query("SELECT id,name,route,permission_slug,parent_id,status FROM menus WHERE route LIKE '%purchase%' OR name LIKE '%urchase%'");
console.log(JSON.stringify(menus,null,1));
const [perms] = await c.query("SELECT slug FROM permissions WHERE slug LIKE '%purchase%' OR slug LIKE '%_po_%' OR slug LIKE '%low_stock%' ORDER BY slug");
console.log(JSON.stringify(perms.map(p=>p.slug)));
for (const t of ['low_stocks','purchase_order_final','purchase_order_raw','purchase_order_raw_items']) {
  const [cols] = await c.query(`SHOW COLUMNS FROM \`${t}\``);
  console.log("== "+t+": "+cols.map(x=>x.Field+":"+x.Type+(x.Null==='NO'?'!':'')+(x.Default!==null?`=${x.Default}`:'')+(x.Extra?` [${x.Extra}]`:'')).join(", "));
}
const [cnt] = await c.query("SELECT (SELECT COUNT(*) FROM low_stocks) ls,(SELECT COUNT(*) FROM purchase_order_final) pof,(SELECT COUNT(*) FROM purchase_order_raw) por,(SELECT COUNT(*) FROM purchase_order_raw_items) pori");
console.log(JSON.stringify(cnt));
await c.end();
