import mysql from "mysql2/promise";
const c = await mysql.createConnection({host:process.env.DB_HOST,port:+process.env.DB_PORT,user:process.env.DB_USERNAME,password:process.env.DB_PASSWORD,database:process.env.DB_DATABASE});
const unionSql = `
        SELECT 'PM' AS type, po.id AS po_item_id, po.id AS po_id, po.po_order_num, po.vendor_name_po,
            po.material_name COLLATE utf8mb4_unicode_ci AS product_name, pc.name AS category_name,
            p.product_code AS cat_no, po.quantity_required COLLATE utf8mb4_unicode_ci AS quantity_required,
            ls.critical_item, po.status, po.created_at, user.email AS created_by_user
        FROM purchase_order_final po
        LEFT JOIN low_stocks ls ON po.low_stock_id = ls.id
        LEFT JOIN product_categories pc ON ls.category_id = pc.id
        LEFT JOIN products p ON ls.product_id = p.id
        LEFT JOIN users user ON po.created_by = user.id
        WHERE po.status != 3
        UNION ALL
        SELECT 'RM' AS type, pri.id AS po_item_id, por.id AS po_id, por.po_order_num, por.vendor_name_po,
            pri.product_name, pc.name AS category_name, p.product_code AS cat_no, pri.quantity_required,
            ls.critical_item, por.status, por.created_at, user.email AS created_by_user
        FROM purchase_order_raw_items pri
        JOIN purchase_order_raw por ON pri.po_raw_id = por.id
        LEFT JOIN low_stocks ls ON pri.low_stock_id = ls.id
        LEFT JOIN product_categories pc ON ls.category_id = pc.id
        LEFT JOIN products p ON ls.product_id = p.id
        LEFT JOIN users user ON por.created_by = user.id
        WHERE por.status != 3 AND pri.status != 3`;
try {
  const [r] = await c.query(`SELECT COUNT(*) total FROM (${unionSql}) combined`);
  console.log("union ok", JSON.stringify(r));
  const [r2] = await c.query(`SELECT * FROM (${unionSql}) combined ORDER BY created_at DESC, po_id DESC, po_item_id DESC LIMIT 0, 3`);
  console.log(JSON.stringify(r2, null, 1));
} catch(e) { console.log("ERR", e.message); }
await c.end();
