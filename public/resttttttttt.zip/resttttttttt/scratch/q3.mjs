import mysql from "mysql2/promise";
const c = await mysql.createConnection({host:process.env.DB_HOST,port:+process.env.DB_PORT,user:process.env.DB_USERNAME,password:process.env.DB_PASSWORD,database:process.env.DB_DATABASE,timezone:"+05:30"});
const [r] = await c.query("SELECT id, created_at, DATE(created_at) d, date_report FROM low_stocks WHERE date_report IS NOT NULL ORDER BY id DESC LIMIT 2");
for (const row of r) console.log(row.id, typeof row.created_at, row.created_at instanceof Date, JSON.stringify(row));
const [r2] = await c.query("SELECT po_order_num, DATE(created_at) created_date FROM purchase_order_final ORDER BY id DESC LIMIT 2");
console.log(JSON.stringify(r2));
await c.end();
