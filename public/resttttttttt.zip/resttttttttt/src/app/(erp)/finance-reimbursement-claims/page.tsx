import { Forbidden } from "@/components/layout/Forbidden";
import { canAny } from "@/modules/access/permissions";
import { getPageAccess } from "@/modules/access/page-access";
import { ReimbursementClaimsScreen } from "@/modules/finance/ReimbursementClaimsScreen";

export default async function FinanceReimbursementClaimsPage() {
  const { user, allowed } = await getPageAccess("finance-reimbursement-claims");
  if (!allowed) return <Forbidden />;
  const canManage = await canAny(user, ["payroll_reimbursements_manage", "finance_reimbursement_claims_manage"]);
  return <ReimbursementClaimsScreen canManage={canManage} />;
}
