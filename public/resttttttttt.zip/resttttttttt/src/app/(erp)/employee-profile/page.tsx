import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { EmployeeProfileScreen } from "@/modules/hr/EmployeeProfileScreen";

export default async function Page() {
  const { allowed, user } = await getPageAccess("employee-profile");
  if (!allowed) return <Forbidden />;
  // The HR Workspace tiles are each gated by their own slug. Note that
  // `hrms_attendance_view` is created by no migration, so the attendance tile
  // is effectively never shown — kept as the reference has it.
  const workspace = await canAll(user, {
    employeeMaster: "hrms_employee_master_view",
    leave: "hrms_leave_manage",
    offboarding: "hrms_offboarding_manage",
    attendance: "hrms_attendance_view",
    shifts: "hrms_shift_manage",
  });
  return <EmployeeProfileScreen workspace={workspace} />;
}
