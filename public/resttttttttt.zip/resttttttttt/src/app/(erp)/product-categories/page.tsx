import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { ProductCategoriesScreen } from "@/modules/inventory/ProductCategoriesScreen";

export default async function ProductCategoriesPage() {
  const { user, allowed } = await getPageAccess("product-categories");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    add: "product_category_add",
    edit: "product_category_edit",
    remove: "product_category_delete",
  });
  return <ProductCategoriesScreen permissions={permissions} />;
}
