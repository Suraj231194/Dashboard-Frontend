import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { PriceListScreen } from "@/modules/finance/PriceListScreen";
import { listActivePriceCategories } from "@/modules/finance/price-list";

export default async function PriceListCatalogPage() {
  const { allowed } = await getPageAccess("pricelist-catalog");
  if (!allowed) return <Forbidden />;
  return <PriceListScreen categories={await listActivePriceCategories()} />;
}
