import { Forbidden } from "@/components/layout/Forbidden";
import { can } from "@/modules/access/permissions";
import { getPageAccess } from "@/modules/access/page-access";
import { PayrollPayRunsScreen } from "@/modules/payroll/PayrollPayRunsScreen";

export default async function PayrollPayRunsPage() {
  const { user, allowed } = await getPageAccess("payroll-pay-runs");
  if (!allowed) return <Forbidden />;
  return <PayrollPayRunsScreen canManage={await can(user, "payroll_pay_runs_manage")} />;
}
