import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { FinanceRegisterScreen } from "@/modules/finance/FinanceRegisterScreen";

/**
 * The current application serves this screen from `finance-page.php` with
 * `$financeView = 'trade_receivables'` (finance-trade-receivables.php).
 */
export default async function Page() {
  const { user, allowed } = await getPageAccess("finance-trade-receivables");
  if (!allowed) return <Forbidden />;
  const canManage = await can(user, "finance_trade_receivables_manage");
  return <FinanceRegisterScreen view="trade_receivables" canManage={canManage} />;
}
