import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { SuppliersScreen } from "@/modules/inventory/SuppliersScreen";

export default async function SuppliersPage() {
  const { user, allowed } = await getPageAccess("suppliers");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    add: "store_supplier_add",
    edit: "store_supplier_edit",
    remove: "store_supplier_delete",
  });
  return <SuppliersScreen permissions={permissions} />;
}
