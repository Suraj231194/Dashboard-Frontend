import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { BMR_PERMISSIONS } from "@/modules/production/bmr-constants";
import { BmrFormRequestScreen } from "@/modules/production/BmrFormRequestScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("bmr-bpr-form-request");
  if (!allowed) return <Forbidden />;
  // Viewing the queue and submitting a request are separate permissions, so the
  // action buttons are resolved here rather than assumed from page access.
  const { submit } = await canAll(user, { submit: BMR_PERMISSIONS.submitRequest });
  return <BmrFormRequestScreen canManage={submit} />;
}
