import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { menuRouteToPath } from "@/modules/navigation/routes";
import { getMyProfile } from "@/modules/profile/my-profile";
import { ProfileScreen, type ProfileLinks } from "@/modules/profile/ProfileScreen";

export default async function ProfilePage() {
  const { user, allowed } = await getPageAccess("profile");
  if (!allowed) return <Forbidden />;

  // $navbar_claim_href: a linked employee claims through their own profile,
  // otherwise the payroll screen shows only with the reimbursement permission.
  const { employee } = await getMyProfile(user.user_id);
  const claimRoute = employee
    ? "index.php?page=employee-profile"
    : (await can(user, "payroll_reimbursements_view")) ? "index.php?page=payroll-reimbursements" : "";

  // The shortcuts only link to screens that exist here yet; the rest are shown
  // greyed out rather than sending anyone to a page that has not been built.
  const links: ProfileLinks = {
    accountSettings: "/account-settings",
    salaryAccount: menuRouteToPath("index.php?page=salary-account"),
    claimReimbursement: claimRoute === "" ? null : menuRouteToPath(claimRoute),
    appearance: menuRouteToPath("index.php?page=appearance"),
  };
  return <ProfileScreen links={links} claimHidden={claimRoute === ""} />;
}
