import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { BMR_PERMISSIONS } from "@/modules/production/bmr-constants";
import { ProductionBmrBprScreen } from "@/modules/production/ProductionBmrBprScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("bpr");
  if (!allowed) {
    const fallback = await getPageAccess("production-bmr-bpr");
    if (!fallback.allowed) return <Forbidden />;
  }
  const { manage } = await canAll(user, { manage: BMR_PERMISSIONS.manageWorkItem });
  return <ProductionBmrBprScreen canManage={manage} />;
}

