import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { CustomerManagementScreen } from "@/modules/sync/CustomerManagementScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("customer-management");
  if (!allowed) return <Forbidden />;
  // The current save action is guarded by the same slug that guards the screen.
  const canManage = await can(user, "sync_users_view");
  return <CustomerManagementScreen canManage={canManage} />;
}
