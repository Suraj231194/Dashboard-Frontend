import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { AiAssistanceScreen } from "@/modules/assistant/AiAssistanceScreen";

export default async function Page() {
  const { allowed } = await getPageAccess("ai-assistance");
  if (!allowed) return <Forbidden />;
  return <AiAssistanceScreen />;
}
