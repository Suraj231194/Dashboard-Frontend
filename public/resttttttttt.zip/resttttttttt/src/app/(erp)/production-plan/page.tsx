import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";
import { ProductionPlanScreen } from "@/modules/production/ProductionPlanScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("production-plan");
  if (!allowed) return <Forbidden />;
  // Add, view, edit and delete are separate permissions on the current screen,
  // so the controls are resolved here rather than assumed from page access.
  const permissions = await canAll(user, {
    add: PRODUCTION_PERMISSIONS.planAdd,
    view: PRODUCTION_PERMISSIONS.planView,
    edit: PRODUCTION_PERMISSIONS.planEdit,
    remove: PRODUCTION_PERMISSIONS.planDelete,
  });
  return <ProductionPlanScreen permissions={permissions} />;
}
