import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { menuRouteToPath } from "@/modules/navigation/routes";
import { AccountSettingsScreen } from "@/modules/profile/AccountSettingsScreen";

export default async function AccountSettingsPage() {
  const { allowed } = await getPageAccess("account-settings");
  if (!allowed) return <Forbidden />;

  // The resignation card links to the offboarding screen with its resign panel
  // open, and is shown disabled until that screen has been converted.
  const offboarding = menuRouteToPath("index.php?page=offboarding");
  return <AccountSettingsScreen resignHref={offboarding ? `${offboarding}?open=resign` : null} />;
}
