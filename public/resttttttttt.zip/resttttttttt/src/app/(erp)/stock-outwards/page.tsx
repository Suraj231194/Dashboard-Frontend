import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { StockOutwardsScreen } from "@/modules/warehouse/StockOutwardsScreen";

export default async function StockOutwardsPage() {
  const { user, allowed } = await getPageAccess("stock-outwards");
  if (!allowed) return <Forbidden />;

  const permissions = await canAll(user, {
    add: "store_stock_outwards_add",
    edit: "store_stock_outwards_edit",
    view: "store_stock_outwards_view",
    remove: "store_stock_outwards_delete",
  });

  return <StockOutwardsScreen permissions={permissions} />;
}
