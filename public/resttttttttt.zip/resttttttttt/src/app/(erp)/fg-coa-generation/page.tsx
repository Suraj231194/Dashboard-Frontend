import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import { CoaDocumentScreen } from "@/modules/production/CoaDocumentScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("fg-coa-generation");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    add: COA_PERMISSIONS.fgAdd,
    view: COA_PERMISSIONS.fgView,
    edit: COA_PERMISSIONS.fgEdit,
    remove: COA_PERMISSIONS.fgDelete,
  });
  return <CoaDocumentScreen coaType="FG" permissions={permissions} />;
}
