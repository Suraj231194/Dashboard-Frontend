import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { TenderDashboardScreen } from "@/modules/tenders/TenderDashboardScreen";
import { TENDER_DASHBOARD_PAGE } from "@/modules/tenders/tender-constants";

export default async function TenderDashboardPage() {
  const { allowed } = await getPageAccess(TENDER_DASHBOARD_PAGE);
  if (!allowed) return <Forbidden />;
  return <TenderDashboardScreen />;
}
