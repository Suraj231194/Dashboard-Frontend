import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { AdvanceSalaryScreen } from "@/modules/hr/AdvanceSalaryScreen";

export default async function Page() {
  const { allowed, user } = await getPageAccess("advance-salary");
  if (!allowed) return <Forbidden />;
  const flags = await canAll(user, {
    canAdd: "hr_advance_salary_add",
    canDelete: "hr_advance_salary_delete",
  });
  return <AdvanceSalaryScreen {...flags} />;
}
