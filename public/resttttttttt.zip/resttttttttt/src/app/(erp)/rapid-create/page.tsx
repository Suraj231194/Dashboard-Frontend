import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { RapidCreateScreen } from "@/modules/production/RapidCreateScreen";

/** The create form has no action permission of its own; page access is the gate. */
export default async function Page() {
  const { allowed } = await getPageAccess("rapid-create");
  if (!allowed) return <Forbidden />;
  return <RapidCreateScreen />;
}
