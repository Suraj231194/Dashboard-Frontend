import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { OrderReceivedScreen } from "@/modules/sales/OrderReceivedScreen";

export default async function OrderReceivedPage() {
  const { user, allowed } = await getPageAccess("order-received");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    view: "store_order_received_view",
    download: "crm_sales_order_download",
    add: "store_order_received_add",
    edit: "store_order_received_edit",
    remove: "store_order_received_delete",
  });
  return <OrderReceivedScreen permissions={permissions} />;
}
