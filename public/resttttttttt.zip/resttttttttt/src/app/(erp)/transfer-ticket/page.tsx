import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { TransferTicketScreen } from "@/modules/procurement/TransferTicketScreen";

export default async function TransferTicketPage() {
  const { user, allowed } = await getPageAccess("transfer-ticket");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    add: "transfer_ticket_add",
    edit: "transfer_ticket_edit",
    remove: "transfer_ticket_delete",
    view: "transfer_ticket_view",
    pdf: "transfer_ticket_generate_pdf",
  });
  return <TransferTicketScreen permissions={permissions} />;
}
