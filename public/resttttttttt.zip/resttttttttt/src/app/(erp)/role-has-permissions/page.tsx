import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { RolePermissionsScreen } from "@/modules/access/RolePermissionsScreen";

export default async function RoleHasPermissionsPage() {
  const { user, allowed } = await getPageAccess("role-has-permissions");
  if (!allowed) return <Forbidden />;
  return <RolePermissionsScreen canEdit={await can(user, "role_has_permission_edit")} />;
}
