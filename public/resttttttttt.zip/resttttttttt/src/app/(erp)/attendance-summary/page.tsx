import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { AttendanceSummaryScreen } from "@/modules/hr/AttendanceSummaryScreen";

export default async function Page() {
  const { allowed } = await getPageAccess("attendance-summary");
  if (!allowed) return <Forbidden />;
  // The reference screen is read-only: no add, edit, delete or modal.
  return <AttendanceSummaryScreen />;
}
