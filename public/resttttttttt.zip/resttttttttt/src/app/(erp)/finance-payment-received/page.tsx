import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { FinanceRegisterScreen } from "@/modules/finance/FinanceRegisterScreen";

/**
 * The current application serves this screen from `finance-page.php` with
 * `$financeView = 'payment_received'` (finance-payment-received.php).
 */
export default async function Page() {
  const { user, allowed } = await getPageAccess("finance-payment-received");
  if (!allowed) return <Forbidden />;
  const canManage = await can(user, "finance_payment_received_manage");
  return <FinanceRegisterScreen view="payment_received" canManage={canManage} />;
}
