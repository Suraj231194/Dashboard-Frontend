import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";
import { RapidScreen } from "@/modules/production/RapidScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("rapid-show");
  if (!allowed) {
    const fallback = await getPageAccess("rapid");
    if (!fallback.allowed) return <Forbidden />;
  }
  const { pdf } = await canAll(user, { pdf: PRODUCTION_PERMISSIONS.rapidPdf });
  return <RapidScreen canGeneratePdf={pdf} />;
}

