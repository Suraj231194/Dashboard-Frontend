import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { readOrderDetail } from "@/modules/sales/order-detail";
import { OrderDetailScreen } from "@/modules/sales/OrderDetailScreen";

/** The Order Detail screen the list links to, reached as ?id=<order>. */
export default async function OrderDetailPage({ searchParams }: PageProps<"/order-detail">) {
  // No menu row records a slug for this screen, so a signed-in session is
  // all the current router asks for.
  const { user, allowed } = await getPageAccess("order-detail");
  if (!allowed) return <Forbidden />;

  const params = await searchParams;
  const raw = Array.isArray(params.id) ? params.id[0] : params.id;
  const orderId = Number.parseInt(String(raw ?? ""), 10) || 0;
  if (orderId <= 0) return <Notice message="Invalid Order ID." />;

  const detail = await readOrderDetail(orderId);
  if (!detail) return <Notice message="Order not found." />;

  const resolveMapping = await can(user, "store_order_received_edit");
  return <OrderDetailScreen detail={detail} permissions={{ resolveMapping }} />;
}

function Notice({ message }: { message: string }) {
  return (
    <div className="rounded-2xl border border-rose-200 bg-rose-50 p-4 text-sm font-semibold text-rose-700">
      {message}
    </div>
  );
}
