import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import { SaGenerationScreen } from "@/modules/production/SaGenerationScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("sa-generation");
  if (!allowed) return <Forbidden />;
  // The PDF button carries its own permission, so it is resolved here.
  const { pdf } = await canAll(user, { pdf: COA_PERMISSIONS.saPdf });
  return <SaGenerationScreen canGeneratePdf={pdf} />;
}
