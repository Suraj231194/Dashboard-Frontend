import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { FinanceRegisterScreen } from "@/modules/finance/FinanceRegisterScreen";

/**
 * The current application serves this screen from `finance-page.php` with
 * `$financeView = 'bill_generation'` (finance-bill-generation.php).
 */
export default async function Page() {
  const { user, allowed } = await getPageAccess("finance-bill-generation");
  if (!allowed) return <Forbidden />;
  const canManage = await can(user, "finance_bill_generation_manage");
  return <FinanceRegisterScreen view="bill_generation" canManage={canManage} />;
}
