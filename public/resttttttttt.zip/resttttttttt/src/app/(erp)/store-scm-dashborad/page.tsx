import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { workforceHeadcount } from "@/modules/workforce/headcount";
import { WorkforceDashboardScreen } from "@/modules/workforce/WorkforceDashboardScreen";

/**
 * The slug keeps the current spelling ("dashborad") so the stored menu route
 * still resolves. Renaming it would unlink the menu entry.
 */
export default async function Page() {
  const { allowed } = await getPageAccess("store-scm-dashborad");
  if (!allowed) return <Forbidden />;
  return <WorkforceDashboardScreen cards={await workforceHeadcount()} />;
}
