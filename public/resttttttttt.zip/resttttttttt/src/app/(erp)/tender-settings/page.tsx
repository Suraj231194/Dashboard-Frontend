import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { TenderSettingsScreen } from "@/modules/tenders/TenderSettingsScreen";
import { TENDER_SETTINGS_PAGE } from "@/modules/tenders/tender-constants";

export default async function TenderSettingsPage() {
  const { allowed } = await getPageAccess(TENDER_SETTINGS_PAGE);
  if (!allowed) return <Forbidden />;
  // Every handler behind this screen has its permission checks commented out,
  // so the page guard is the only check there is.
  return <TenderSettingsScreen />;
}
