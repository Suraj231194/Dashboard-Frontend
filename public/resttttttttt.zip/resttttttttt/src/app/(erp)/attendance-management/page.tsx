import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { AttendanceManagementScreen } from "@/modules/hr/AttendanceManagementScreen";

export default async function Page() {
  const { allowed, user } = await getPageAccess("attendance-management");
  if (!allowed) return <Forbidden />;
  // The reference gates the marking panel and the device tools on their own
  // permissions, and resolves them server-side.
  const flags = await canAll(user, {
    canMark: "hrms_attendance_mark",
    canConfigureBiometrics: "hrms_biometric_manage",
    canManageShifts: "hrms_shift_manage",
  });
  return <AttendanceManagementScreen {...flags} />;
}
