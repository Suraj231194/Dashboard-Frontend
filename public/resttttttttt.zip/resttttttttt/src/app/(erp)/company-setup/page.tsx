import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { CompanySetupScreen } from "@/modules/company/CompanySetupScreen";

export default async function CompanySetupPage() {
  const { user, allowed } = await getPageAccess("company-setup");
  if (!allowed) return <Forbidden />;
  // The directory itself is gated by company_setup_view on its endpoint, the
  // same way the current handler checks it rather than the page.
  const permissions = await canAll(user, {
    add: "company_add",
    edit: "company_edit",
  });
  return <CompanySetupScreen permissions={permissions} />;
}
