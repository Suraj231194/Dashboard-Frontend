import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { DashboardScreen } from "@/modules/dashboard/DashboardScreen";
import { getDashboardOverview, getDashboardProduction } from "@/modules/dashboard/dashboard";
import { dashboardVisibility } from "@/modules/dashboard/visibility";

export default async function DashboardPage() {
  const { user, allowed } = await getPageAccess("dashboard");
  if (!allowed) return <Forbidden />;
  // Resolved here so a block the signed-in user cannot see is never rendered
  // and its figures are never queried.
  const visibility = await dashboardVisibility(user);
  const [overview, production] = await Promise.all([
    getDashboardOverview(visibility),
    getDashboardProduction(),
  ]);
  return (
    <DashboardScreen userName={user.name} visibility={visibility}
      overview={overview} production={production} />
  );
}
