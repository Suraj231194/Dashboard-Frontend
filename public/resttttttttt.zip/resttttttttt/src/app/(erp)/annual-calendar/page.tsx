import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { AnnualCalendarScreen } from "@/modules/hr/AnnualCalendarScreen";

export default async function Page() {
  const { allowed } = await getPageAccess("annual-calendar");
  if (!allowed) return <Forbidden />;
  // The manage, finalize, reopen and export flags travel with the payload, so
  // they cannot drift from the checks the endpoints themselves perform.
  return <AnnualCalendarScreen />;
}
