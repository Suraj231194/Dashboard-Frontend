import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { SyncDashboardScreen } from "@/modules/sync/SyncDashboardScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("sync");
  if (!allowed) return <Forbidden />;
  // Viewing, managing and retrying are three separate permissions, so the
  // controls are resolved here rather than assumed from page access.
  const { manage, retry } = await canAll(user, {
    manage: "sync_settings_manage",
    retry: "sync_failures_retry",
  });
  return <SyncDashboardScreen canManage={manage} canRetry={retry} />;
}
