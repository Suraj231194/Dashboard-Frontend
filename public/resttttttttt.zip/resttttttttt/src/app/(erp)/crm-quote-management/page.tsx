import { Suspense } from "react";
import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { CrmQuoteManagementScreen } from "@/modules/crm/CrmQuoteManagementScreen";
import { buildProductCatalog } from "@/modules/crm/leads";

/** `admin/pages/crm-quote-management.php` — commercial quotations raised from CRM. */
export default async function CrmQuoteManagementPage() {
  const { user, allowed } = await getPageAccess("crm-quote-management");
  if (!allowed) return <Forbidden />;
  const [permissions, products] = await Promise.all([
    canAll(user, {
      add: "crm_quote_add",
      edit: "crm_quote_edit",
      remove: "crm_quote_delete",
    }),
    buildProductCatalog(),
  ]);
  return (
    // The screen reads `?lead_id=` to open the prefilled dialog.
    <Suspense>
      <CrmQuoteManagementScreen permissions={permissions} products={products} />
    </Suspense>
  );
}
