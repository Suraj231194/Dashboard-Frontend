import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { MenusScreen } from "@/modules/access/MenusScreen";

export default async function MenusPage() {
  const { user, allowed } = await getPageAccess("menus");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    add: "menus_add",
    edit: "menus_edit",
    remove: "menus_delete",
  });
  return <MenusScreen permissions={permissions} />;
}
