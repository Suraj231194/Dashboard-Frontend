import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { LeaveManagementScreen } from "@/modules/hr/LeaveManagementScreen";

export default async function Page() {
  const { allowed, user } = await getPageAccess("leave-management");
  if (!allowed) return <Forbidden />;
  const canManage = await can(user, "hrms_leave_manage");
  return <LeaveManagementScreen canManage={canManage} />;
}
