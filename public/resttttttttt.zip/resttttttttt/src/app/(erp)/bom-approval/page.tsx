import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { BOM_APPROVAL_PERMISSION } from "@/modules/store/bom-approval";
import { BomApprovalScreen } from "@/modules/store/BomApprovalScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("bom-approval");
  if (!allowed) return <Forbidden />;
  // Reviewing and deciding are the same permission in the reference, but the
  // screen resolves it here so the buttons can say why they are unusable.
  const { approve } = await canAll(user, { approve: BOM_APPROVAL_PERMISSION });
  return <BomApprovalScreen canApprove={approve} />;
}
