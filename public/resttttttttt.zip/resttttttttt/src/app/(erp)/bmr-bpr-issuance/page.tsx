import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { BMR_PERMISSIONS } from "@/modules/production/bmr-constants";
import { BmrIssuanceScreen } from "@/modules/production/BmrIssuanceScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("bmr-bpr-issuance");
  if (!allowed) return <Forbidden />;
  // Viewing the issuance queue and deciding a request are separate permissions.
  const { review } = await canAll(user, { review: BMR_PERMISSIONS.reviewRequest });
  return <BmrIssuanceScreen canReview={review} />;
}
