import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { QuotationRequestsScreen } from "@/modules/sync/QuotationRequestsScreen";

export default async function Page() {
  const { allowed } = await getPageAccess("quotation-requests");
  if (!allowed) return <Forbidden />;
  return <QuotationRequestsScreen />;
}
