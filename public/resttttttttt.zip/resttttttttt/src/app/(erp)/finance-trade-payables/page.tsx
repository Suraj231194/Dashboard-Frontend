import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { FinanceRegisterScreen } from "@/modules/finance/FinanceRegisterScreen";

/**
 * The current application serves this screen from `finance-page.php` with
 * `$financeView = 'trade_payables'` (finance-trade-payables.php).
 */
export default async function Page() {
  const { user, allowed } = await getPageAccess("finance-trade-payables");
  if (!allowed) return <Forbidden />;
  const canManage = await can(user, "finance_trade_payables_manage");
  return <FinanceRegisterScreen view="trade_payables" canManage={canManage} />;
}
