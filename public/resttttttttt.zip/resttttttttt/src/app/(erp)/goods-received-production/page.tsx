import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { GoodsReceivedProductionScreen } from "@/modules/warehouse/GoodsReceivedProductionScreen";

export default async function GoodsReceivedProductionPage() {
  const { user, allowed } = await getPageAccess("goods-received-production");
  if (!allowed) return <Forbidden />;
  const canManage = await can(user, "store_goods_received_production_manage");
  return <GoodsReceivedProductionScreen canManage={canManage} />;
}
