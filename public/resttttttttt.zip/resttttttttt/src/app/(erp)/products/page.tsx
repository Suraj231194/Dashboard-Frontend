import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { ProductsScreen } from "@/modules/inventory/ProductsScreen";

export default async function ProductsPage() {
  const { user, allowed } = await getPageAccess("products");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    add: "store_product_add",
    edit: "store_product_edit",
    remove: "store_product_delete",
  });
  return <ProductsScreen permissions={permissions} />;
}
