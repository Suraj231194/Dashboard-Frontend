import { Forbidden } from "@/components/layout/Forbidden";
import { can } from "@/modules/access/permissions";
import { getPageAccess } from "@/modules/access/page-access";
import { PayrollAdvancesScreen } from "@/modules/payroll/PayrollAdvancesScreen";

export default async function PayrollAdvancesPage() {
  const { user, allowed } = await getPageAccess("payroll-advances");
  if (!allowed) return <Forbidden />;
  return <PayrollAdvancesScreen canManage={await can(user, "payroll_advances_manage")} />;
}
