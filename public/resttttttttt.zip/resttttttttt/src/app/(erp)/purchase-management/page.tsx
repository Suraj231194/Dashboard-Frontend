import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { PurchaseManagementScreen } from "@/modules/purchasing/PurchaseManagementScreen";

export default async function PurchaseManagementPage() {
  const { user, allowed } = await getPageAccess("purchase-management");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    view: "operations_admin_purchase_mgmt_view",
    edit: "operations_admin_purchase_mgmt_edit",
  });
  return <PurchaseManagementScreen permissions={permissions} />;
}
