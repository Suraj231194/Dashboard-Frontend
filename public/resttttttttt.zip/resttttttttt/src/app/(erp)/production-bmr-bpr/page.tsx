import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { BMR_PERMISSIONS } from "@/modules/production/bmr-constants";
import { ProductionBmrBprScreen } from "@/modules/production/ProductionBmrBprScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("production-bmr-bpr");
  if (!allowed) return <Forbidden />;
  // Opening a record and saving it share one permission, separate from viewing.
  const { manage } = await canAll(user, { manage: BMR_PERMISSIONS.manageWorkItem });
  return <ProductionBmrBprScreen canManage={manage} />;
}
