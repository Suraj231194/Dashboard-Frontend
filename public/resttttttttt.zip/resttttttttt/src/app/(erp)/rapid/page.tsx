import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";
import { RapidScreen } from "@/modules/production/RapidScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("rapid");
  if (!allowed) return <Forbidden />;
  // Generate PDF sits behind its own permission, so it is resolved here.
  const { pdf } = await canAll(user, { pdf: PRODUCTION_PERMISSIONS.rapidPdf });
  return <RapidScreen canGeneratePdf={pdf} />;
}
