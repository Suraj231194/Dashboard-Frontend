import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { PermissionsScreen } from "@/modules/access/PermissionsScreen";

export default async function PermissionsPage() {
  const { allowed } = await getPageAccess("permissions");
  if (!allowed) return <Forbidden />;
  return <PermissionsScreen />;
}
