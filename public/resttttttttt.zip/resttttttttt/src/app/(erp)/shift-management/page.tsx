import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { ShiftManagementScreen } from "@/modules/hr/ShiftManagementScreen";

export default async function Page() {
  const { allowed } = await getPageAccess("shift-management");
  if (!allowed) return <Forbidden />;
  // The current shift actions carry no permission check of their own, so the
  // screen's own access decides who may write.
  return <ShiftManagementScreen canManage={allowed} />;
}
