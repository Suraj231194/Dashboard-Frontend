import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { PI_PERMISSIONS } from "@/modules/crm/pi-constants";
import { PiRequestsScreen } from "@/modules/crm/PiRequestsScreen";

/**
 * PI Generator / Proforma Invoice Management.
 * Aliased route for `?page=pi-generator`.
 */
export default async function Page() {
  const { user, allowed } = await getPageAccess("pi-generator");
  if (!allowed) {
    const fallbackAccess = await getPageAccess("pi-requests");
    if (!fallbackAccess.allowed) return <Forbidden />;
  }
  const flags = await canAll(user, {
    view: PI_PERMISSIONS.view,
    syncView: PI_PERMISSIONS.syncView,
    add: PI_PERMISSIONS.add,
    edit: PI_PERMISSIONS.edit,
    remove: PI_PERMISSIONS.delete,
    duplicate: PI_PERMISSIONS.duplicate,
    convert: PI_PERMISSIONS.convert,
  });
  return (
    <PiRequestsScreen permissions={{
      view: flags.view || flags.syncView,
      create: flags.add || flags.syncView,
      add: flags.add,
      edit: flags.edit,
      remove: flags.remove,
      duplicate: flags.duplicate,
      convert: flags.convert || flags.edit,
    }} />
  );
}
