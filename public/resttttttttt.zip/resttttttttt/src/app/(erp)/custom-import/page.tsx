import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { CustomImportScreen } from "@/modules/imports/CustomImportScreen";

export default async function Page() {
  const { allowed } = await getPageAccess("custom-import");
  if (!allowed) return <Forbidden />;
  return <CustomImportScreen />;
}
