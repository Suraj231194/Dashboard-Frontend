import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { SettingsScreen } from "@/modules/settings/SettingsScreen";

export default async function SettingsPage() {
  const { allowed } = await getPageAccess("settings");
  if (!allowed) return <Forbidden />;
  return <SettingsScreen />;
}
