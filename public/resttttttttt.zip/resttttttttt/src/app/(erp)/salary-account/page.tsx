import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { SalaryAccountScreen } from "@/modules/payroll/SalaryAccountScreen";

export default async function SalaryAccountPage() {
  const { allowed } = await getPageAccess("salary-account");
  if (!allowed) return <Forbidden />;
  return <SalaryAccountScreen />;
}
