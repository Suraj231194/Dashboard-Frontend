import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { QuizActivityFeedScreen } from "@/modules/sync/QuizActivityFeedScreen";
import { SYNC_PERMISSIONS } from "@/modules/sync/sync-constants";

export default async function Page() {
  const { user, allowed } = await getPageAccess("quiz-activity-feed");
  if (!allowed) return <Forbidden />;
  // The current handler guards the status write with the same view slug.
  const canManage = await can(user, SYNC_PERMISSIONS.quiz);
  return <QuizActivityFeedScreen canManage={canManage} />;
}
