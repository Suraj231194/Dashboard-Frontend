import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { StocksScreen } from "@/modules/inventory/StocksScreen";

export default async function StocksPage() {
  const { user, allowed } = await getPageAccess("stocks");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    add: "stocks_add",
    edit: "stocks_edit",
  });
  // The procurement dialog reports against the signed-in user's email, as today.
  return <StocksScreen permissions={permissions} reportingOfficer={user.email} />;
}
