import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { LeadManagementScreen } from "@/modules/crm/LeadManagementScreen";
import { listLeadFormOptions } from "@/modules/crm/leads";

/** `admin/pages/lead-management.php` — the CRM lead pipeline. */
export default async function LeadManagementPage() {
  const { user, allowed } = await getPageAccess("lead-management");
  if (!allowed) return <Forbidden />;
  const [permissions, options] = await Promise.all([
    canAll(user, {
      add: "crm_lead_add",
      edit: "crm_lead_edit",
      remove: "crm_lead_delete",
      accept: "crm_lead_accept",
      reject: "crm_lead_reject",
      quoteAdd: "crm_quote_add",
    }),
    listLeadFormOptions(),
  ]);
  return (
    <LeadManagementScreen permissions={permissions}
      products={options.products} salespersons={options.salespersons} />
  );
}
