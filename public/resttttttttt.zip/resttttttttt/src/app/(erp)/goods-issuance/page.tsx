import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { GoodsIssuanceScreen } from "@/modules/warehouse/GoodsIssuanceScreen";

export default async function GoodsIssuancePage() {
  const { user, allowed } = await getPageAccess("goods-issuance");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    add: "store_stock_outwards_add",
    edit: "store_stock_outwards_edit",
    view: "store_stock_outwards_view",
    remove: "store_stock_outwards_delete",
  });
  return <GoodsIssuanceScreen permissions={permissions} />;
}
