import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import { CoaGenerationScreen } from "@/modules/production/CoaGenerationScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("coa-generation");
  if (!allowed) return <Forbidden />;
  const { pdf } = await canAll(user, { pdf: COA_PERMISSIONS.coaPdf });
  return <CoaGenerationScreen canGeneratePdf={pdf} />;
}
