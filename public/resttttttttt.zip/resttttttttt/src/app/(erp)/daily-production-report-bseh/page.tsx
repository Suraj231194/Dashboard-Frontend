import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";
import { DailyProductionReportScreen } from "@/modules/production/DailyProductionReportScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("daily-production-report-bseh");
  if (!allowed) return <Forbidden />;
  // Add, view and delete are separate permissions on the current screen, so the
  // controls are resolved here rather than assumed from page access.
  const permissions = await canAll(user, {
    add: PRODUCTION_PERMISSIONS.bsehAdd,
    view: PRODUCTION_PERMISSIONS.bsehView,
    remove: PRODUCTION_PERMISSIONS.bsehDelete,
  });
  return <DailyProductionReportScreen permissions={permissions} />;
}
