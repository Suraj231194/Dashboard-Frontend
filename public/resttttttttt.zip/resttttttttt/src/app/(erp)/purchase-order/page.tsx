import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { PurchaseOrderScreen } from "@/modules/purchasing/PurchaseOrderScreen";

export default async function PurchaseOrderPage() {
  const { user, allowed } = await getPageAccess("purchase-order");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    finalPrint: "operations_admin_po_printpdf",
    finalDelete: "operations_admin_po_delete",
    rawAdd: "operations_admin_po_raw_add",
    rawPrint: "operations_admin_po_raw_printpdf",
    rawEdit: "operations_admin_po_raw_edit",
    rawDelete: "operations_admin_po_raw_delete",
  });
  return <PurchaseOrderScreen permissions={permissions} />;
}
