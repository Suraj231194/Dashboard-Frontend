import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import { CoaDocumentScreen } from "@/modules/production/CoaDocumentScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("ip-coa-generation");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    add: COA_PERMISSIONS.ipAdd,
    view: COA_PERMISSIONS.ipView,
    edit: COA_PERMISSIONS.ipEdit,
    remove: COA_PERMISSIONS.ipDelete,
  });
  return <CoaDocumentScreen coaType="IP" permissions={permissions} />;
}
