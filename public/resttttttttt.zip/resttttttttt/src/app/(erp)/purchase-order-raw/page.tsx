import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { PurchaseOrderRawScreen } from "@/modules/purchasing/PurchaseOrderRawScreen";

export default async function PurchaseOrderRawPage() {
  const { user, allowed } = await getPageAccess("purchase-order-raw");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    rawAdd: "operations_admin_po_raw_add",
    rawPrint: "operations_admin_po_raw_printpdf",
    rawEdit: "operations_admin_po_raw_edit",
    rawDelete: "operations_admin_po_raw_delete",
  });
  return <PurchaseOrderRawScreen permissions={permissions} />;
}
