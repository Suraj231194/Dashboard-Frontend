import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { MaterialRequestScreen } from "@/modules/procurement/MaterialRequestScreen";

export default async function MaterialRequestPage() {
  const { user, allowed } = await getPageAccess("material-request");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    view: "store_material_request_view",
    edit: "store_material_request_edit",
  });
  return <MaterialRequestScreen permissions={permissions} />;
}
