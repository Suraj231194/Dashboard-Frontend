import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { SalespersonsScreen } from "@/modules/crm/SalespersonsScreen";
import { listSalespersonOptions } from "@/modules/crm/salespersons";

export default async function SalespersonMasterPage() {
  const { user, allowed } = await getPageAccess("salesperson-master");
  if (!allowed) return <Forbidden />;
  const [permissions, options] = await Promise.all([
    canAll(user, {
      add: "crm_salesperson_add",
      edit: "crm_salesperson_edit",
      remove: "crm_salesperson_delete",
    }),
    listSalespersonOptions(),
  ]);
  return <SalespersonsScreen permissions={permissions} {...options} />;
}
