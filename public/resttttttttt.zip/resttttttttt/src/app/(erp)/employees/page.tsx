import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { EmployeesScreen } from "@/modules/hr/EmployeesScreen";

export default async function Page() {
  const { allowed, user } = await getPageAccess("employees");
  if (!allowed) return <Forbidden />;
  // The current handlers carry no permission check of their own; only the row
  // buttons are gated, so the same slugs decide what the screen offers.
  const access = await canAll(user, {
    add: "hr_employees_add",
    edit: "hr_employees_edit",
    remove: "hr_employees_delete",
  });
  return <EmployeesScreen access={access} />;
}
