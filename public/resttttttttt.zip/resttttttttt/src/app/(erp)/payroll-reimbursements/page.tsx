import { Forbidden } from "@/components/layout/Forbidden";
import { can } from "@/modules/access/permissions";
import { getPageAccess } from "@/modules/access/page-access";
import { PayrollReimbursementsScreen } from "@/modules/payroll/PayrollReimbursementsScreen";

export default async function PayrollReimbursementsPage() {
  const { user, allowed } = await getPageAccess("payroll-reimbursements");
  if (!allowed) return <Forbidden />;
  return <PayrollReimbursementsScreen canManage={await can(user, "payroll_reimbursements_manage")} />;
}
