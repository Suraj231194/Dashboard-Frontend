import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { FinalPurchaseOrdersScreen } from "@/modules/purchasing/FinalPurchaseOrdersScreen";

export default async function FinalPurchaseOrdersPage() {
  const { user, allowed } = await getPageAccess("final-purchase-orders");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    finalPrint: "operations_admin_po_printpdf",
    finalDelete: "operations_admin_po_delete",
    rawAdd: "operations_admin_po_raw_add",
    rawPrint: "operations_admin_po_raw_printpdf",
    rawEdit: "operations_admin_po_raw_edit",
    rawDelete: "operations_admin_po_raw_delete",
  });
  return <FinalPurchaseOrdersScreen permissions={permissions} />;
}
