import { requireSession } from "@/modules/auth/session";
import { AppearanceForm } from "@/modules/settings/AppearanceForm";
import { getAppearance } from "@/modules/settings/appearance";

export default async function AppearancePage() {
  const user = await requireSession();
  return <AppearanceForm initial={await getAppearance(user.user_id)} />;
}
