import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import { CoaTemplatesScreen } from "@/modules/production/CoaTemplatesScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("coa-templates");
  if (!allowed) return <Forbidden />;
  // Each row action is gated separately, as the current buttons are.
  const permissions = await canAll(user, {
    add: COA_PERMISSIONS.templatesAdd,
    view: COA_PERMISSIONS.templatesView,
    edit: COA_PERMISSIONS.templatesEdit,
    remove: COA_PERMISSIONS.templatesDelete,
  });
  return <CoaTemplatesScreen permissions={permissions} />;
}
