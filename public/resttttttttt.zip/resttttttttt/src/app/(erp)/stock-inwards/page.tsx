import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { StockInwardsScreen } from "@/modules/warehouse/StockInwardsScreen";

export default async function StockInwardsPage() {
  const { user, allowed } = await getPageAccess("stock-inwards");
  if (!allowed) return <Forbidden />;

  const permissions = await canAll(user, {
    add: "store_stock_inwards_add",
    edit: "store_stock_inwards_edit",
    view: "store_stock_inwards_view",
    remove: "store_stock_inwards_delete",
  });

  return <StockInwardsScreen permissions={permissions} />;
}
