import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { MeetingRequestsScreen } from "@/modules/sync/MeetingRequestsScreen";

export default async function Page() {
  const { allowed } = await getPageAccess("meeting-requests");
  if (!allowed) return <Forbidden />;
  return <MeetingRequestsScreen />;
}
