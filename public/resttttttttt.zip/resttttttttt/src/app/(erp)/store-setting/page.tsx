import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { BomSettingsScreen } from "@/modules/store/BomSettingsScreen";
import {
  listBomCategoryOptions,
  listFinishedProductOptions,
  listQtyUnitOptions,
} from "@/modules/store/bom";

export default async function StoreSettingPage() {
  const { user, allowed } = await getPageAccess("store-setting");
  if (!allowed) return <Forbidden />;

  const [permissions, categories, products, units] = await Promise.all([
    canAll(user, {
      add: "store_settings_bom_add",
      edit: "store_settings_bom_edit",
      remove: "store_settings_bom_delete",
    }),
    listBomCategoryOptions(),
    listFinishedProductOptions(),
    listQtyUnitOptions(),
  ]);

  return (
    <BomSettingsScreen
      permissions={permissions}
      categories={categories}
      products={products}
      units={units}
    />
  );
}
