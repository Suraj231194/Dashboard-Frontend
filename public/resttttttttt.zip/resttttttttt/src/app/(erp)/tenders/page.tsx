import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canDoThis } from "@/modules/access/permissions";
import { TendersScreen } from "@/modules/tenders/TendersScreen";
import { TENDER_PERMISSIONS, TENDERS_PAGE } from "@/modules/tenders/tender-constants";

export default async function TendersPage() {
  const { user, allowed } = await getPageAccess(TENDERS_PAGE);
  if (!allowed) return <Forbidden />;
  // The list gates its controls with canDoThis(), which lets the three
  // administrative roles through whatever the permission table says.
  const [add, view, edit, remove] = await Promise.all([
    canDoThis(user, TENDER_PERMISSIONS.add),
    canDoThis(user, TENDER_PERMISSIONS.view),
    canDoThis(user, TENDER_PERMISSIONS.edit),
    canDoThis(user, TENDER_PERMISSIONS.remove),
  ]);
  return <TendersScreen permissions={{ add, view, edit, remove }} />;
}
