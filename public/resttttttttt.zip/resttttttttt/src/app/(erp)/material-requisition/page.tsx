import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { MaterialRequisitionScreen } from "@/modules/procurement/MaterialRequisitionScreen";

export default async function MaterialRequisitionPage() {
  const { user, allowed } = await getPageAccess("material-requisition");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    add: "production_material_requisition_add",
    edit: "production_material_requisition_edit",
    remove: "production_material_requisition_delete",
    view: "production_material_requisition_view",
  });
  return <MaterialRequisitionScreen permissions={permissions} />;
}
