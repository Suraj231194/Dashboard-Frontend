import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { FinanceRegisterScreen } from "@/modules/finance/FinanceRegisterScreen";

/**
 * Master Finance Page.
 * In AutoIVD, `finance-page.php` is the master controller for all finance registers.
 */
export default async function Page() {
  const { user, allowed } = await getPageAccess("finance-page");
  if (!allowed) {
    const fallback = await getPageAccess("finance-invoice-generation");
    if (!fallback.allowed) return <Forbidden />;
  }
  const canManage = await can(user, "finance_invoice_generation_manage");
  return <FinanceRegisterScreen view="invoice_generation" canManage={canManage} />;
}
