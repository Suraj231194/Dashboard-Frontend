import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAny } from "@/modules/access/permissions";
import { EmployeeMasterScreen } from "@/modules/hr/EmployeeMasterScreen";

export default async function Page() {
  const { allowed, user } = await getPageAccess("employee-master");
  if (!allowed) return <Forbidden />;
  // `$canManageEmployeeMaster` is any-of these three slugs.
  const manage = await canAny(user, [
    "hrms_employee_master_manage", "hr_employees_edit", "hr_employees_add",
  ]);
  return <EmployeeMasterScreen access={{ manage }} />;
}
