import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";
import { RawPackingMaterialScreen } from "@/modules/production/RawPackingMaterialScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("raw-material-packing-material");
  if (!allowed) return <Forbidden />;
  // Add, view and edit are separate permissions on the current screen, so the
  // controls are resolved here rather than assumed from page access.
  const permissions = await canAll(user, {
    add: PRODUCTION_PERMISSIONS.rmpmAdd,
    view: PRODUCTION_PERMISSIONS.rmpmView,
    edit: PRODUCTION_PERMISSIONS.rmpmEdit,
  });
  return <RawPackingMaterialScreen permissions={permissions} />;
}
