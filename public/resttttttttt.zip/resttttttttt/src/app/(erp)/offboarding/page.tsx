import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { OffboardingScreen } from "@/modules/hr/OffboardingScreen";

export default async function Page() {
  const { allowed, user } = await getPageAccess("offboarding");
  if (!allowed) return <Forbidden />;
  const canManage = await can(user, "hrms_offboarding_manage");
  return <OffboardingScreen canManage={canManage} />;
}
