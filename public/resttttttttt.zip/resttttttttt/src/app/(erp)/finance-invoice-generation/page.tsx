import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { FinanceRegisterScreen } from "@/modules/finance/FinanceRegisterScreen";

/**
 * The current application serves this screen from `finance-page.php` with
 * `$financeView = 'invoice_generation'` (finance-invoice-generation.php).
 */
export default async function Page() {
  const { user, allowed } = await getPageAccess("finance-invoice-generation");
  if (!allowed) return <Forbidden />;
  const canManage = await can(user, "finance_invoice_generation_manage");
  return <FinanceRegisterScreen view="invoice_generation" canManage={canManage} />;
}
