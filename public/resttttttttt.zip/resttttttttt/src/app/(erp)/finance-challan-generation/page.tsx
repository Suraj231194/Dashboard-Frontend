import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { can } from "@/modules/access/permissions";
import { FinanceRegisterScreen } from "@/modules/finance/FinanceRegisterScreen";

/**
 * The current application serves this screen from `finance-page.php` with
 * `$financeView = 'challan_generation'` (finance-challan-generation.php).
 */
export default async function Page() {
  const { user, allowed } = await getPageAccess("finance-challan-generation");
  if (!allowed) return <Forbidden />;
  const canManage = await can(user, "finance_delivery_challan_generation_manage");
  return <FinanceRegisterScreen view="challan_generation" canManage={canManage} />;
}
