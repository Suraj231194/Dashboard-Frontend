import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { LabelsScreen } from "@/modules/labels/LabelsScreen";

export default async function LabelsPage() {
  const { allowed } = await getPageAccess("labels");
  if (!allowed) return <Forbidden />;
  return <LabelsScreen />;
}
