import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { PayrollManualScreen } from "@/modules/payroll/PayrollManualScreen";

export default async function PayrollManualPage() {
  const { allowed } = await getPageAccess("payroll-manual");
  if (!allowed) return <Forbidden />;
  return <PayrollManualScreen />;
}
