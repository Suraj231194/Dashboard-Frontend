import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { WorkerAttendanceScreen } from "@/modules/hr/WorkerAttendanceScreen";

/** The roles the reference hard-codes for the daily attendance strip. */
const DASHBOARD_ROLE_IDS = [1, 6, 12];

export default async function Page() {
  const { allowed, user } = await getPageAccess("worker-attendance");
  if (!allowed) return <Forbidden />;
  const flags = await canAll(user, {
    canAdd: "worker_attendance_add",
    canDelete: "worker_attendance_delete",
  });
  return <WorkerAttendanceScreen {...flags}
    showDashboard={DASHBOARD_ROLE_IDS.includes(user.role_id)} />;
}
