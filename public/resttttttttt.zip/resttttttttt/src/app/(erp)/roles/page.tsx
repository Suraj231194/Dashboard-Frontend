import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { RolesScreen } from "@/modules/access/RolesScreen";

export default async function RolesPage() {
  const { user, allowed } = await getPageAccess("roles");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    add: "roles_add",
    edit: "roles_edit",
    remove: "roles_delete",
  });
  return <RolesScreen permissions={permissions} />;
}
