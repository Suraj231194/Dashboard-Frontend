import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll, canDoThis } from "@/modules/access/permissions";
import { UsersScreen } from "@/modules/users/UsersScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("create_user");
  if (!allowed) {
    const fallback = await getPageAccess("users");
    if (!fallback.allowed) return <Forbidden />;
  }
  const [flags, assignPermissions, roleWorkflow] = await Promise.all([
    canAll(user, {
      add: "user_add",
      edit: "user_edit",
      remove: "user_delete",
      changePassword: "user_change_password",
    }),
    canDoThis(user, "user_assign_extra_permission"),
    canAll(user, {
      createRole: "roles_add",
      assignRolePermissions: "role_has_permission_add",
      assignRoleUsers: "user_edit",
    }),
  ]);
  return <UsersScreen permissions={{ ...flags, assignPermissions,
    createRole: roleWorkflow.createRole && roleWorkflow.assignRolePermissions && roleWorkflow.assignRoleUsers }} />;
}

