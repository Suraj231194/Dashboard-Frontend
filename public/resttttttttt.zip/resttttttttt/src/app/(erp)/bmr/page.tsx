import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { BmrTemplatesScreen } from "@/modules/production/BmrTemplatesScreen";

export default async function Page() {
  const { user, allowed } = await getPageAccess("bmr");
  if (!allowed) return <Forbidden />;
  // The current page gates Add New and the row actions on the advance-salary
  // permissions it was copied from, so the same two slugs are resolved here.
  const { add, act } = await canAll(user, {
    add: "hr_advance_salary_add",
    act: "hr_advance_salary_delete",
  });
  return <BmrTemplatesScreen canAdd={add} canAct={act} />;
}
