import { NextRequest, NextResponse } from "next/server";
import { authenticate, createSession } from "@/modules/auth/session";
import { isSameOrigin } from "@/lib/http/same-origin";
import { redirectTo } from "@/lib/http/redirect";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  if (!isSameOrigin(request)) {
    return new NextResponse("Invalid request origin", { status: 403 });
  }
  const data = await request.formData();
  const email = String(data.get("email") ?? "").trim();
  const password = String(data.get("password") ?? "");
  if (!email || !password || email.length > 150) {
    return redirectTo("/login?error=invalid");
  }
  try {
    const user = await authenticate(email, password);
    if (!user) return redirectTo("/login?error=invalid");
    await createSession(user.id);
    return redirectTo("/dashboard");
  } catch (error) {
    console.error("Login failed", error);
    return redirectTo("/login?error=unavailable");
  }
}
