import { NextRequest, NextResponse } from "next/server";
import { destroySession } from "@/modules/auth/session";
import { isSameOrigin } from "@/lib/http/same-origin";
import { redirectTo } from "@/lib/http/redirect";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  if (!isSameOrigin(request)) {
    return new NextResponse("Invalid request origin", { status: 403 });
  }
  await destroySession();
  return redirectTo("/login");
}
