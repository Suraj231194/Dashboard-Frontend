import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { AssistantError, askAssistant } from "@/modules/assistant/assistant";

export const runtime = "nodejs";

/** `chatGptInputValData`: stores the question, asks the model, stores the answer. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "ai-assistance");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await askAssistant({
      userId: guard.user.user_id,
      question: String(data.get("question") ?? ""),
      conversationId: Number.parseInt(String(data.get("conversation_id") ?? "0"), 10) || 0,
    });
    return apiSuccess(result);
  } catch (error) {
    if (error instanceof AssistantError) return apiError(error.message, 422);
    console.error("The assistant could not answer", error);
    return apiError("The assistant could not answer. Try again.", 500);
  }
}
