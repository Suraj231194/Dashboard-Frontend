import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { AssistantError, listConversations } from "@/modules/assistant/assistant";

export const runtime = "nodejs";

/** `loadAiChatMessage`: the signed-in user's conversations, newest first. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "ai-assistance");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const result = await listConversations(
      guard.user.user_id,
      Number.parseInt(params.get("limit") ?? "10", 10) || 10,
      Number.parseInt(params.get("offset") ?? "0", 10) || 0,
    );
    return apiSuccess(result);
  } catch (error) {
    if (error instanceof AssistantError) return apiError(error.message, 422);
    console.error("Unable to load the assistant conversations", error);
    return apiError("Unable to load your chats.", 500);
  }
}
