import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { AssistantError, deleteConversation, listMessages } from "@/modules/assistant/assistant";

export const runtime = "nodejs";

type Context = { params: Promise<{ id: string }> };

/** `loadOldChatAIMessages`: one page of a thread, oldest first within the page. */
export async function GET(request: NextRequest, context: Context) {
  const guard = await requireApiPageAccess(request, "ai-assistance");
  if (!guard.ok) return guard.response;
  try {
    const { id } = await context.params;
    const page = Number.parseInt(request.nextUrl.searchParams.get("page") ?? "1", 10) || 1;
    const messages = await listMessages(guard.user.user_id, Number.parseInt(id, 10) || 0, page);
    return apiSuccess({ messages });
  } catch (error) {
    if (error instanceof AssistantError) return apiError(error.message, 422);
    console.error("Unable to load the conversation", error);
    return apiError("Unable to open this conversation.", 500);
  }
}

/** `deleteChatAiTitleRecord`, scoped to the owner. */
export async function DELETE(request: NextRequest, context: Context) {
  const guard = await requireApiPageAccess(request, "ai-assistance");
  if (!guard.ok) return guard.response;
  try {
    const { id } = await context.params;
    const result = await deleteConversation(guard.user.user_id, Number.parseInt(id, 10) || 0);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof AssistantError) return apiError(error.message, 422);
    console.error("Unable to remove the conversation", error);
    return apiError("Failed to remove the chat.", 500);
  }
}
