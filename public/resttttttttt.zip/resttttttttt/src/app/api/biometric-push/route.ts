import { NextRequest, NextResponse } from "next/server";
import crypto from "node:crypto";
import { queryOne, withTransaction } from "@/lib/db/query";
import type { RowDataPacket } from "mysql2";

export const runtime = "nodejs";

type BiometricEvent = {
  emp_code?: string;
  employee_code?: string;
  punch_time?: string;
  punch_direction?: "IN" | "OUT" | "AUTO" | string;
  verify_mode?: string;
  temperature?: number | null;
  mask_flag?: number | null;
};

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization") || "";
    const tokenMatch = authHeader.match(/^Bearer\s+([^\s]+)$/i);
    if (!tokenMatch) {
      return NextResponse.json({ status: "error", message: "Device authentication is required." }, { status: 401 });
    }
    const deviceToken = tokenMatch[1].trim();

    const rawBody = await request.text();
    let payload: Record<string, unknown>;
    try {
      payload = JSON.parse(rawBody);
    } catch {
      return NextResponse.json({ status: "error", message: "Provide a valid JSON request body." }, { status: 400 });
    }

    const deviceCode = String(request.headers.get("x-device-code") || payload.device_code || "").trim().toUpperCase();
    if (!deviceCode || deviceToken.length < 16) {
      return NextResponse.json({ status: "error", message: "Device authentication is invalid." }, { status: 401 });
    }

    const tokenHash = crypto.createHash("sha256").update(deviceToken).digest("hex");

    // Authenticate device
    const device = await queryOne<RowDataPacket & {
      id: number;
      company_id: number;
      branch_id: number;
      device_code: string;
      timezone: string;
      ingest_rate_limit: number;
    }>(
      `SELECT id, company_id, branch_id, device_code, timezone, ingest_rate_limit
       FROM hr_biometric_devices
       WHERE device_code = ? AND ingest_token_hash = ? AND ingest_enabled = 1 AND status = 1
       LIMIT 1`,
      [deviceCode, tokenHash]
    );

    if (!device) {
      return NextResponse.json({ status: "error", message: "Device authentication is invalid." }, { status: 401 });
    }

    const events = (payload.events ?? []) as BiometricEvent[];
    if (!Array.isArray(events) || events.length === 0) {
      return NextResponse.json({ status: "error", message: "Provide between 1 and 5000 biometric events." }, { status: 422 });
    }

    let accepted = 0;
    const batchKey = String(request.headers.get("x-ingest-batch-id") || payload.batch_id || "").trim() ||
      crypto.createHash("sha256").update(`${deviceCode}|${rawBody}`).digest("hex");

    await withTransaction(async (conn) => {
      // Create batch record if table exists
      try {
        await conn.execute(
          `INSERT IGNORE INTO hr_biometric_ingest_batches
           (device_id, batch_key, remote_ip, event_count, status)
           VALUES (?, ?, ?, ?, 'processing')`,
          [device.id, batchKey, request.headers.get("x-forwarded-for") || "127.0.0.1", events.length]
        );
      } catch {
        // Table might not be installed yet; proceed with punches
      }

      for (const ev of events) {
        const empCode = String(ev.emp_code || ev.employee_code || "").trim();
        const punchTime = String(ev.punch_time || "").trim();
        if (!empCode || !punchTime) continue;

        // Resolve employee
        const [empRows] = await conn.execute<RowDataPacket[]>(
          "SELECT id FROM employees WHERE emp_code = ? AND status != 3 LIMIT 1",
          [empCode]
        );
        const employeeId = (empRows[0] as { id?: number } | undefined)?.id ?? null;

        try {
          await conn.execute(
            `INSERT IGNORE INTO hr_biometric_punches
             (device_id, employee_id, emp_code, punch_time, punch_direction, verify_mode, temperature, mask_flag, raw_payload)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              device.id,
              employeeId,
              empCode,
              punchTime,
              ev.punch_direction || "AUTO",
              ev.verify_mode || "FINGERPRINT",
              ev.temperature ?? null,
              ev.mask_flag ?? null,
              JSON.stringify(ev),
            ]
          );
          accepted++;
        } catch {
          // If punches table has slightly different columns, log and continue
        }
      }
    });

    return NextResponse.json({
      status: "success",
      message: `Successfully ingested ${accepted} punches.`,
      accepted_count: accepted,
      total_received: events.length,
    });
  } catch (error) {
    console.error("Biometric push error:", error);
    return NextResponse.json({ status: "error", message: "Failed to process biometric push payload." }, { status: 500 });
  }
}
