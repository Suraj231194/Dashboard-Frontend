import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { canAny } from "@/modules/access/permissions";
import { PULLABLE_ENTITIES } from "@/modules/sync/sync-settings";
import { pullAndSyncEntity } from "@/modules/sync/website-pull";

export const runtime = "nodejs";

/**
 * `triggerEntitySync`. Managing sync allows any module; otherwise the module's
 * own screen permission is enough to pull it, as the current handler allows.
 */
const ENTITY_PERMISSIONS: Record<string, string[]> = {
  pi: ["sync_pi_view", "sales_billing_pi_generate_view"],
  quotations: ["sync_quotations_view", "crm_quote_menu_list"],
  users: ["sync_users_view", "customer_menu_list"],
  meetings: ["sync_meetings_view"],
  quiz: ["sync_quiz_view"],
};

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "sync");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const entity = String(data.get("entity") ?? "").trim();
    if (!(PULLABLE_ENTITIES as readonly string[]).includes(entity)) {
      return apiError("Only Website-to-ERP pull modules support this manual action.", 422);
    }
    const allowed = await canAny(
      guard.user, ["sync_settings_manage", ...(ENTITY_PERMISSIONS[entity] ?? [])]);
    if (!allowed) return apiError("You do not have permission to run a manual sync.", 403);

    const result = await pullAndSyncEntity(entity);
    if (!result.success) return apiError(result.message, result.disabled ? 409 : 422);
    return apiSuccess({ synced_count: result.synced_count }, result.message);
  } catch (error) {
    console.error("Unable to run the manual sync", error);
    return apiError("Unable to run the manual sync.", 500);
  }
}
