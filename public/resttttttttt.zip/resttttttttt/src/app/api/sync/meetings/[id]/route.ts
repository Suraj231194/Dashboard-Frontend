import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { SYNC_PERMISSIONS } from "@/modules/sync/sync-constants";
import { getMeetingRequest } from "@/modules/sync/sync-lists";

export const runtime = "nodejs";

/**
 * `getMeetingDetails`. The current endpoint returns no message when the row is
 * missing and its screen has no failure branch, so a missing meeting leaves
 * the dialog closed and nothing visibly happens. This reports the miss.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/sync/meetings/[id]">) {
  const guard = await requireApiPermission(
    request, SYNC_PERMISSIONS.meetings, "You do not have permission to view meeting requests.",
  );
  if (!guard.ok) return guard.response;
  try {
    const meeting = await getMeetingRequest(readId((await context.params).id));
    if (!meeting) return apiError("Meeting request was not found.", 404);
    return apiSuccess({ meeting });
  } catch (error) {
    console.error("Unable to read the meeting request", error);
    return apiError("Meeting details are unavailable.", 500);
  }
}
