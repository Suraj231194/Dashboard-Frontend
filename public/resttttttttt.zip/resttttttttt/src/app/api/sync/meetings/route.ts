import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { SYNC_PERMISSIONS } from "@/modules/sync/sync-constants";
import { listMeetingRequests, MEETING_SORT_COLUMNS } from "@/modules/sync/sync-lists";

export const runtime = "nodejs";

/** `loadMeetingsGrid` (`admin/ajax.php:45672-45724`). */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, SYNC_PERMISSIONS.meetings, "You do not have permission to view meeting requests.",
  );
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, MEETING_SORT_COLUMNS, "id", "DESC");
    return apiSuccess(await listMeetingRequests(query, {
      date: (params.get("date") ?? "").trim(),
      status: (params.get("status") ?? "").trim(),
    }));
  } catch (error) {
    console.error("Unable to list meeting requests", error);
    return apiError("Failed to load meeting requests.", 500);
  }
}
