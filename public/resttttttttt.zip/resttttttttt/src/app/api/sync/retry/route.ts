import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { hasTable, syncLogById } from "@/modules/sync/sync-settings";
import { retryFromLog } from "@/modules/sync/website-push";

export const runtime = "nodejs";

/** `retrySyncLog`: replays one failed outbound push from its stored payload. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "sync_failures_retry", "You do not have permission to retry sync failures.");
  if (!guard.ok) return guard.response;
  try {
    if (!(await hasTable("sync_logs"))) {
      return apiError("Sync migrations have not been applied.", 409);
    }
    const data = await request.formData();
    const logId = Number.parseInt(String(data.get("log_id") ?? "0"), 10) || 0;
    const log = await syncLogById(logId);
    if (!log) return apiError("Sync log not found.", 404);

    if (log.entity_type !== "orders" && log.entity_type !== "inventory") {
      return apiError("This record uses Pull/Upsert/ACK; run its module pull instead.", 422);
    }
    const result = await retryFromLog(log.entity_type, logId);
    if (!result.success) return apiError(result.message, result.disabled ? 409 : 422);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to retry the sync failure", error);
    return apiError("Unable to retry the sync failure.", 500);
  }
}
