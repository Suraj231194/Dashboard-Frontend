import { NextRequest } from "next/server";
import type { RowDataPacket } from "mysql2";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { queryRows } from "@/lib/db/query";
import { isSyncEnabled } from "@/modules/sync/sync-settings";
import { pushProductStockToWebsite } from "@/modules/sync/website-push";

export const runtime = "nodejs";

/** `triggerInventorySync`: up to twenty products whose stock is still pending. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "sync_settings_manage", "You do not have permission to run a manual sync.");
  if (!guard.ok) return guard.response;
  try {
    if (!(await isSyncEnabled("inventory"))) {
      return apiError("Inventory sync is disabled.", 409);
    }
    const pending = await queryRows<RowDataPacket>(
      `SELECT DISTINCT ls.product_id
         FROM live_stock ls
         INNER JOIN products p ON p.id = ls.product_id
           AND p.website_sync = 1 AND p.deleted_at IS NULL
         INNER JOIN product_categories c ON c.id = p.category_id
           AND c.website_sync = 1
        WHERE ls.sync_pending = 1 AND ls.deleted_at IS NULL
        ORDER BY ls.product_id ASC
        LIMIT 20`,
    );

    let processed = 0;
    let failed = 0;
    // One blocking call per product, as the current run does, so the website is
    // not hit with twenty at once.
    for (const row of pending) {
      const result = await pushProductStockToWebsite(Number(row.product_id));
      if (result.success) processed += 1;
      else failed += 1;
    }
    const message = `Inventory run complete: ${processed} processed, ${failed} failed.`;
    if (failed > 0) return apiError(message, 422);
    return apiSuccess({ processed, failed }, message);
  } catch (error) {
    console.error("Unable to run the inventory sync", error);
    return apiError("Unable to run the inventory sync.", 500);
  }
}
