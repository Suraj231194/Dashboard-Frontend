import { NextRequest } from "next/server";
import { apiError, apiForbidden, apiSuccess } from "@/lib/http/json";
import { requireApiSession } from "@/lib/http/guard";
import { canAny } from "@/modules/access/permissions";
import { readListQuery } from "@/lib/pagination";
import { SYNC_PERMISSIONS } from "@/modules/sync/sync-constants";
import { listQuotationRequests, quotationProductOptions, QUOTATION_SORT_COLUMNS } from "@/modules/sync/sync-lists";

export const runtime = "nodejs";

/** The quotation screens accept either the sync slug or the CRM one. */
const QUOTATION_SLUGS = [SYNC_PERMISSIONS.quotations, SYNC_PERMISSIONS.quotationsCrm];

/** `loadQuotationGrid` (`admin/ajax.php:45923-45960`). */
export async function GET(request: NextRequest) {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  if (!(await canAny(guard.user, QUOTATION_SLUGS))) {
    return apiForbidden("You do not have permission to view this synchronized feed.");
  }
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, QUOTATION_SORT_COLUMNS, "created_at", "DESC");
    const result = await listQuotationRequests(query, {
      product: (params.get("product") ?? "").trim(),
      from: (params.get("from") ?? "").trim(),
      to: (params.get("to") ?? "").trim(),
    });
    return apiSuccess({ ...result, products: await quotationProductOptions() });
  } catch (error) {
    console.error("Unable to list quotation requests", error);
    return apiError("Failed to load quotations.", 500);
  }
}
