import { NextRequest } from "next/server";
import { apiError, apiForbidden, apiSuccess } from "@/lib/http/json";
import { readId, requireApiSession } from "@/lib/http/guard";
import { canAny } from "@/modules/access/permissions";
import { SYNC_PERMISSIONS } from "@/modules/sync/sync-constants";
import { getQuotationRequest } from "@/modules/sync/sync-lists";

export const runtime = "nodejs";

const QUOTATION_SLUGS = [SYNC_PERMISSIONS.quotations, SYNC_PERMISSIONS.quotationsCrm];

/** `getQuoteDetails`, with its line items. */
export async function GET(request: NextRequest, context: RouteContext<"/api/sync/quotations/[id]">) {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  if (!(await canAny(guard.user, QUOTATION_SLUGS))) {
    return apiForbidden("You do not have permission to view this synchronized feed.");
  }
  try {
    const detail = await getQuotationRequest(readId((await context.params).id));
    if (!detail) return apiError("Quotation details are unavailable.", 404);
    return apiSuccess(detail);
  } catch (error) {
    console.error("Unable to read the quotation", error);
    return apiError("Quotation details are unavailable.", 500);
  }
}
