import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { configurationStatus } from "@/lib/sync/sync-manager";
import { setSyncEnabled } from "@/modules/sync/sync-settings";

export const runtime = "nodejs";

/** `updateSyncSetting`: a module may not be enabled without its credentials. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "sync_settings_manage", "You do not have permission to manage sync settings.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const entity = String(data.get("entity") ?? "").trim();
    const enabled = ["1", "true", "on", "yes"].includes(String(data.get("enabled") ?? "").toLowerCase());

    if (enabled) {
      const configuration = configurationStatus();
      if (!configuration.website_url || !configuration.website_token) {
        return apiError("Configure WEBSITE_SYNC_BASE_URL and WEBSITE_SYNC_TOKEN before enabling sync.", 409);
      }
    }
    const result = await setSyncEnabled(entity, enabled, guard.user.user_id);
    if (!result.success) return apiError(result.message, 422);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update the sync module", error);
    return apiError("Unable to update the sync module.", 500);
  }
}
