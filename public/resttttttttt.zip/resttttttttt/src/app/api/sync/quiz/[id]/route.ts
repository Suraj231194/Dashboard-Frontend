import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { SYNC_PERMISSIONS, readQuizProfile } from "@/modules/sync/sync-constants";
import { getQuizLead, updateQuizLeadStatus } from "@/modules/sync/sync-lists";

export const runtime = "nodejs";

/** `getQuizDetails`: the lead, its decoded profiling data and its answers. */
export async function GET(request: NextRequest, context: RouteContext<"/api/sync/quiz/[id]">) {
  const guard = await requireApiPermission(
    request, SYNC_PERMISSIONS.quiz, "You do not have permission to view this synchronized feed.",
  );
  if (!guard.ok) return guard.response;
  try {
    const detail = await getQuizLead(readId((await context.params).id));
    if (!detail) return apiError("Quiz lead was not found.", 404);
    return apiSuccess({
      lead: detail.lead,
      profile: readQuizProfile(detail.lead.profiling_data),
      answers: detail.answers,
    });
  } catch (error) {
    console.error("Unable to read the quiz lead", error);
    return apiError("Lead details are unavailable.", 500);
  }
}

/**
 * `updateQuizLeadStatus`. The view permission also grants this write, as it
 * does today: the current handler checks the same single slug for both.
 */
export async function PUT(request: NextRequest, context: RouteContext<"/api/sync/quiz/[id]">) {
  const guard = await requireApiPermission(
    request, SYNC_PERMISSIONS.quiz, "You do not have permission to view this synchronized feed.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await updateQuizLeadStatus(
      readId((await context.params).id),
      String(data.get("lead_status") ?? ""),
    );
    if (!result.ok) return apiError(result.message, result.status);
    return apiSuccess({}, "Lead status updated.");
  } catch (error) {
    console.error("Unable to update the quiz lead status", error);
    return apiError("Status update failed.", 500);
  }
}
