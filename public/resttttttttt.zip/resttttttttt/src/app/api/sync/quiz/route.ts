import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { SYNC_PERMISSIONS } from "@/modules/sync/sync-constants";
import { listQuizLeads, quizSegmentCounts, QUIZ_SORT_COLUMNS } from "@/modules/sync/sync-lists";

export const runtime = "nodejs";

/** `loadQuizGrid` (`admin/ajax.php:45778-45815`), with the segment counters. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, SYNC_PERMISSIONS.quiz, "You do not have permission to view this synchronized feed.",
  );
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, QUIZ_SORT_COLUMNS, "submitted_at", "DESC");
    const result = await listQuizLeads(query, {
      segment: (params.get("segment") ?? "").trim(),
      status: (params.get("status") ?? "").trim(),
    });
    // The counters cover every lead, not the page on screen.
    return apiSuccess({ ...result, counts: await quizSegmentCounts() });
  } catch (error) {
    console.error("Unable to list quiz leads", error);
    return apiError("Failed to load quiz leads.", 500);
  }
}
