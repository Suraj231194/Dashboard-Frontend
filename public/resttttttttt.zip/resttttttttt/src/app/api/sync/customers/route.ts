import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import {
  customerCounts, CUSTOMER_SORT_COLUMNS, listCustomers, readCustomerInput, saveCustomer,
} from "@/modules/sync/customers";

export const runtime = "nodejs";

const PERMISSION = "sync_users_view";
const DENIED = "You do not have permission to manage customers.";

/** `loadCustomersGrid` (`admin/ajax.php:45523-45563`), with the five counters. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(request, PERMISSION, DENIED);
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, CUSTOMER_SORT_COLUMNS, "id", "DESC");
    const result = await listCustomers(query, {
      userType: (params.get("user_type") ?? "").trim(),
      status: (params.get("status") ?? "").trim(),
    });
    // The counters cover every customer, as the current tiles do — they do not
    // react to the search or the filters.
    return apiSuccess({ ...result, counts: await customerCounts() });
  } catch (error) {
    console.error("Unable to list customers", error);
    return apiError("Failed to load customers.", 500);
  }
}

/** `saveCustomer`: one endpoint for both insert and update, as today. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, PERMISSION, DENIED);
  if (!guard.ok) return guard.response;
  try {
    const result = await saveCustomer(readCustomerInput(await request.formData()));
    if (!result.ok) {
      return Response.json(
        { status: "error", message: result.message, errors: result.errors ?? [] },
        { status: result.status },
      );
    }
    return apiSuccess({ id: result.id }, "Customer saved successfully.");
  } catch (error) {
    console.error("Unable to save the customer", error);
    return apiError("Failed to save customer.", 500);
  }
}
