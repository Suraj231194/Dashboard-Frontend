import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { getCustomer } from "@/modules/sync/customers";

export const runtime = "nodejs";

/**
 * `getCustomerDetails`. The current endpoint answers 200 with no message when
 * the row is missing, so the screen shows a generic alert; this returns 404
 * with the reason.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/sync/customers/[id]">) {
  const guard = await requireApiPermission(
    request, "sync_users_view", "You do not have permission to manage customers.",
  );
  if (!guard.ok) return guard.response;
  try {
    const customer = await getCustomer(readId((await context.params).id));
    if (!customer) return apiError("Customer details could not be loaded.", 404);
    return apiSuccess({ customer });
  } catch (error) {
    console.error("Unable to read the customer", error);
    return apiError("Customer details could not be loaded.", 500);
  }
}
