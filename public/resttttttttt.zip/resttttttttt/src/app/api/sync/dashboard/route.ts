import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readSyncDashboard } from "@/modules/sync/sync-dashboard";

export const runtime = "nodejs";

/** `getSyncDashboard`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "sync");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    return apiSuccess(await readSyncDashboard({
      status: params.get("status") ?? "",
      entityType: params.get("entity") ?? "",
    }));
  } catch (error) {
    console.error("Unable to load the sync dashboard", error);
    return apiError("Unable to load sync activity.", 500);
  }
}
