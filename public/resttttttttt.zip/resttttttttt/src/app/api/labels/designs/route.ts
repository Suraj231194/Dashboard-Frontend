import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createLabelDesign, listLabelDesigns } from "@/modules/labels/labels";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "labels");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, ["id", "name"], "id", "DESC");
    return apiSuccess(await listLabelDesigns(query));
  } catch (error) {
    console.error("Unable to list label designs", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "labels");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createLabelDesign({
      labelSizeId: Number.parseInt(String(data.get("labelSizeOption") ?? "0"), 10) || 0,
      name: String(data.get("labelName") ?? ""),
      content: {
        html: String(data.get("labelHtml") ?? ""),
        width: String(data.get("labelWidth") ?? "100mm"),
        height: String(data.get("labelHeight") ?? "50mm"),
      },
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Label designed successfully.");
  } catch (error) {
    console.error("Unable to save the label design", error);
    return apiError("Error in creating label.", 500);
  }
}
