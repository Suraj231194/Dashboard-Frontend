import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { deleteLabelDesign, getLabelDesignPreview } from "@/modules/labels/labels";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/labels/designs/[id]">) {
  const guard = await requireApiPageAccess(request, "labels");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const preview = await getLabelDesignPreview(id);
    if (preview === null) return apiError("No record found.", 404);
    if (preview === "invalid") return apiError("Invalid content format.", 422);
    return apiSuccess({ preview });
  } catch (error) {
    console.error("Unable to read the label design", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext<"/api/labels/designs/[id]">) {
  const guard = await requireApiPageAccess(request, "labels");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteLabelDesign(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Label deleted successfully.");
  } catch (error) {
    console.error("Unable to delete the label design", error);
    return apiError("Server error occurred.", 500);
  }
}
