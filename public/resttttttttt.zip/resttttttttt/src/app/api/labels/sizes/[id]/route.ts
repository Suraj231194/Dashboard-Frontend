import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { deleteLabelSize, findLabelSize, updateLabelSize } from "@/modules/labels/labels";
import { readLabelSizeInput } from "@/modules/labels/label-input";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/labels/sizes/[id]">) {
  const guard = await requireApiPageAccess(request, "labels");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const record = await findLabelSize(id);
    if (!record) return apiError("No data found...!!", 404);
    return apiSuccess({ record });
  } catch (error) {
    console.error("Unable to read the label size", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/labels/sizes/[id]">) {
  const guard = await requireApiPageAccess(request, "labels");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateLabelSize(id, readLabelSizeInput(data, "Edit"), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Label size updated successfully.");
  } catch (error) {
    console.error("Unable to update the label size", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext<"/api/labels/sizes/[id]">) {
  const guard = await requireApiPageAccess(request, "labels");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteLabelSize(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Label deleted successfully.");
  } catch (error) {
    console.error("Unable to delete the label size", error);
    return apiError("Server error occurred.", 500);
  }
}
