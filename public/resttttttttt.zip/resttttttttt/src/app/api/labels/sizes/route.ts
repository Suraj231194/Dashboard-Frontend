import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createLabelSize, listLabelSizes } from "@/modules/labels/labels";
import { readLabelSizeInput } from "@/modules/labels/label-input";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "labels");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, ["label_name"], "label_name", "ASC");
    return apiSuccess(await listLabelSizes(query));
  } catch (error) {
    console.error("Unable to list label sizes", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "labels");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createLabelSize(readLabelSizeInput(data, ""), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Label size added successfully.");
  } catch (error) {
    console.error("Unable to add a label size", error);
    return apiError("Failed to add label size.", 500);
  }
}
