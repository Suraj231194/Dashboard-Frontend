import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listLabelSizeOptions } from "@/modules/labels/labels";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "labels");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ options: await listLabelSizeOptions() });
  } catch (error) {
    console.error("Unable to list label sizes", error);
    return apiError("Error loading data.", 500);
  }
}
