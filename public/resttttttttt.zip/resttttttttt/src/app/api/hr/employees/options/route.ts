import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { employeeFormOptions } from "@/modules/hr/employees";

export const runtime = "nodejs";

/** `loadDesignationsOptions` and the bank list the account tab fills. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "employees");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await employeeFormOptions());
  } catch (error) {
    console.error("Unable to load the employee form options", error);
    return apiError("Error loading data.", 500);
  }
}
