import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { buildEmployeeExport, EMPLOYEE_SORT_COLUMNS } from "@/modules/hr/employees";

export const runtime = "nodejs";

/** The filter arrays arrive JSON-stringified, as the current form posts them. */
function readIdList(value: FormDataEntryValue | null): number[] {
  const raw = String(value ?? "").trim();
  if (raw === "") return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed.map((entry) => Number.parseInt(String(entry), 10)).filter(Number.isInteger);
    }
  } catch {
    // Not JSON: fall through to the comma-separated form.
  }
  return raw.split(",").map((entry) => Number.parseInt(entry.trim(), 10)).filter(Number.isInteger);
}

/** `exportEmployeeDetails`. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "employees");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);

    const requestedSort = String(data.get("sort_column") ?? "");
    const direction = String(data.get("sort_order") ?? data.get("sort_direction") ?? "DESC")
      .toUpperCase() === "ASC" ? "ASC" : "DESC";
    const perPage = Number.parseInt(String(data.get("per_page") ?? data.get("perPage") ?? "10"), 10) || 10;

    const result = await buildEmployeeExport({
      search: String(data.get("search") ?? "").trim(),
      filters: {
        categories: readIdList(data.get("categoryType")),
        statuses: readIdList(data.get("selectedStatus")),
        companies: readIdList(data.get("selectedCompany")),
      },
      sortColumn: (EMPLOYEE_SORT_COLUMNS as readonly string[]).includes(requestedSort)
        ? requestedSort : "first_name",
      sortDirection: direction,
      // The reference forces page 1 and still honours the page size, so an
      // export only covers the first page unless "All items" is chosen.
      page: 1,
      perPage,
      columns: data.getAll("listOfColumns[]").map((value) => String(value)),
    });
    if (!result.ok) return apiError(result.message, 404);

    return await tableExportResponse({
      format,
      title: "Employee Details",
      filePrefix: "employee_details",
      headers: result.columns,
      rows: result.rows,
    });
  } catch (error) {
    console.error("Unable to export the employee list", error);
    return apiError("Server error occurred.", 500);
  }
}
