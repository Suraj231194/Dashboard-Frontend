import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import {
  employeeRecord, updateEmployeeAccount, updateEmployeePersonal,
} from "@/modules/hr/employees";
import { readDetails } from "../route";

export const runtime = "nodejs";

const PAGE = "employees";

/** `fetchEmployeeRecord`: the row plus the option lists the dialog needs. */
export async function GET(request: NextRequest, context: RouteContext<"/api/hr/employees/[id]">) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id <= 0) return apiError("Something went wrong with this record..!!", 400);
  try {
    const record = await employeeRecord(id);
    if (!record) return apiError("No data found...!!", 404);
    return apiSuccess(record);
  } catch (error) {
    console.error("Unable to load the employee record", error);
    return apiError("Error loading data.", 500);
  }
}

/** The two edit-dialog tabs that save: Personal Info and Account Details. */
export async function POST(request: NextRequest, context: RouteContext<"/api/hr/employees/[id]">) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const action = String(data.get("action") ?? "");
    const text = (key: string) => String(data.get(key) ?? "").trim();
    const number = (key: string) => Number.parseInt(text(key), 10) || 0;

    if (action === "updatePersonalEmployeeDetails") {
      const result = await updateEmployeePersonal(id, readDetails(data), guard.user.user_id);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    if (action === "updateAccountEmployeeDetails") {
      const result = await updateEmployeeAccount(id, {
        bankId: number("empBank"),
        accountNumber: text("employeeAccNum"),
        ifscCode: text("employeeIfscCode"),
        branchName: text("employeeBankBranch"),
        accountType: number("accountType"),
        aadhar: text("employeeAadhar"),
        pan: text("employeePan"),
        uan: text("employeeUan"),
        esic: text("employeeEsic"),
        isPfAllowed: text("isPfAllowed") === "1" ? 1 : 0,
        isEsicAllowed: text("isEsicAllowed") === "1" ? 1 : 0,
      }, guard.user.user_id);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    return apiError("Missing or invalid input.", 400);
  } catch (error) {
    console.error("Unable to update the employee record", error);
    return apiError("Server error occurred.", 500);
  }
}
