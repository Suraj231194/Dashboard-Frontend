import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { can } from "@/modules/access/permissions";
import { hrScope } from "@/modules/hr/hr-scope";
import {
  OffboardingError, deleteExitQuestion, ensureOffboardingSettings, loadOffboarding,
  reorderExitQuestions, reviewResignation, saveExitQuestion, saveOffboardingSettings,
  submitExitInterview, submitResignation,
} from "@/modules/hr/offboarding";

export const runtime = "nodejs";

const PAGE = "offboarding";
const MANAGE = "hrms_offboarding_manage";
const DENIED = "You do not have permission to perform this action.";

/** The employee's own requests plus, for a manager, the setup and the queue. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const scope = await hrScope(guard.user.user_id);
    const canManage = await can(guard.user, MANAGE);
    const companyId = Number.parseInt(String(params.get("company_id") ?? ""), 10) || 0;
    const rawBranch = String(params.get("branch_id") ?? "");
    const branchId = rawBranch === "" ? null : (Number.parseInt(rawBranch, 10) || null);
    return apiSuccess(await loadOffboarding(
      { companyId: companyId > 0 ? companyId : null, branchId },
      guard.user.user_id, scope, canManage));
  } catch (error) {
    console.error("Unable to load offboarding", error);
    return apiError("Error loading data.", 500);
  }
}

/** The seven offboarding actions, selected by `action`. */
export async function POST(request: NextRequest) {
  const session = await requireApiPageAccess(request, PAGE);
  if (!session.ok) return session.response;
  const data = await request.formData();
  const action = String(data.get("action") ?? "");
  if (action === "") return apiError("No HRMS action was supplied.", 400);

  // The two self-service actions carry no permission of their own.
  const selfService = ["submit_resignation", "submit_exit_interview"].includes(action);
  const guard = selfService ? session : await requireApiPermission(request, MANAGE, DENIED);
  if (!guard.ok) return guard.response;

  const text = (key: string) => String(data.get(key) ?? "").trim();
  const number = (key: string) => Number.parseInt(String(data.get(key) ?? ""), 10) || 0;
  const answers = (): Record<string, unknown> => {
    try {
      const parsed: unknown = JSON.parse(text("answers") || "{}");
      return parsed !== null && typeof parsed === "object" && !Array.isArray(parsed)
        ? parsed as Record<string, unknown>
        : {};
    } catch { return {}; }
  };
  const userId = guard.user.user_id;

  try {
    const scope = await hrScope(userId);

    if (action === "submit_resignation") {
      const result = await submitResignation({
        reason: text("reason"),
        resignationDate: text("resignation_date"),
        answers: answers(),
      }, userId);
      return apiSuccess(
        { requestNo: result.requestNo, thankYouMessage: result.thankYouMessage }, result.message);
    }

    if (action === "submit_exit_interview") {
      const result = await submitExitInterview(
        { requestId: number("request_id"), answers: answers() }, userId);
      return apiSuccess({ documentsGenerated: result.documentsGenerated }, result.message);
    }

    if (action === "review_resignation") {
      const result = await reviewResignation({
        requestId: number("request_id"),
        decision: text("decision"),
        note: text("note"),
        approvedLastWorkingDate: text("approved_last_working_date"),
      }, scope, userId);
      return apiSuccess({}, result.message);
    }

    if (action === "ensure_offboarding_settings") {
      const branch = text("branch_id") === "" ? null : number("branch_id") || null;
      const settings = await ensureOffboardingSettings(number("company_id"), branch, scope, userId);
      return apiSuccess({ settingsId: settings.id }, "Offboarding preferences are ready.");
    }

    if (action === "save_offboarding_settings") {
      const branch = text("branch_id") === "" ? null : number("branch_id") || null;
      const result = await saveOffboardingSettings({
        companyId: number("company_id"),
        branchId: branch,
        noticePeriodDays: number("notice_period_days"),
        approverUserId: number("approver_user_id"),
        hrPartnerUserId: number("hr_partner_user_id"),
        interviewIntro: text("interview_intro"),
        thankYouMessage: text("thank_you_message"),
        sendExperienceLetter: data.get("send_experience_letter") !== null,
        sendRelievingLetter: data.get("send_relieving_letter") !== null,
      }, scope, userId);
      return apiSuccess({ settingsId: result.settingsId }, result.message);
    }

    if (action === "save_exit_question") {
      const result = await saveExitQuestion({
        questionId: number("question_id"),
        settingsId: number("settings_id"),
        questionText: text("question_text"),
        questionType: text("question_type"),
        options: String(data.get("options") ?? ""),
        isRequired: data.get("is_required") !== null,
      }, scope, userId);
      return apiSuccess({}, result.message);
    }

    if (action === "delete_exit_question") {
      const result = await deleteExitQuestion(number("question_id"), scope, userId);
      return apiSuccess({}, result.message);
    }

    if (action === "reorder_exit_questions") {
      let ids: number[] = [];
      try {
        const parsed: unknown = JSON.parse(text("question_ids") || "[]");
        if (Array.isArray(parsed)) ids = parsed.map((value) => Number.parseInt(String(value), 10));
      } catch { ids = []; }
      const result = await reorderExitQuestions(number("settings_id"), ids, scope, userId);
      return apiSuccess({}, result.message);
    }

    return apiError("Unsupported HRMS action.", 400);
  } catch (error) {
    if (error instanceof OffboardingError) return apiError(error.message, error.status);
    console.error("Unable to complete the offboarding action", error);
    return apiError("Unable to complete the HRMS request.", 500);
  }
}
