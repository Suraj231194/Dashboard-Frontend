import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { hrScope } from "@/modules/hr/hr-scope";
import { OffboardingError, buildOffboardingExport } from "@/modules/hr/offboarding";

export const runtime = "nodejs";

/** The resignation queue as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "hrms_offboarding_manage",
    "You do not have permission to export resignation requests.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const scope = await hrScope(guard.user.user_id);
    const result = await buildOffboardingExport({
      search: String(data.get("search") ?? ""),
      columns: data.getAll("listOfColumns[]").map(String),
    }, guard.user.user_id, scope);
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "Resignation Requests", filePrefix: "offboarding_requests",
      headers: result.columns, rows: result.rows,
    });
  } catch (error) {
    if (error instanceof OffboardingError) return apiError(error.message, error.status);
    console.error("Unable to build the offboarding export", error);
    return apiError("Server error occurred.", 500);
  }
}
