import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { AttendanceSummaryError, buildSummaryExport } from "@/modules/hr/attendance-summary";

export const runtime = "nodejs";

/** Reads a JSON array of ids posted by the filter dropdowns. */
function readIdList(value: FormDataEntryValue | null): number[] {
  try {
    const parsed: unknown = JSON.parse(String(value ?? "[]"));
    return Array.isArray(parsed)
      ? parsed.map((item) => Number.parseInt(String(item), 10)).filter(Number.isInteger)
      : [];
  } catch {
    return [];
  }
}

/** The month grid as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "attendance-summary");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const month = String(data.get("month") ?? "").trim();
    const direction = String(data.get("sort_direction") ?? "").toUpperCase() === "DESC" ? "DESC" : "ASC";
    const result = await buildSummaryExport({
      month,
      search: String(data.get("search") ?? ""),
      companies: readIdList(data.get("companies")),
      categories: readIdList(data.get("categories")),
      statuses: readIdList(data.get("statuses")),
      sortBy: String(data.get("sort_column") ?? ""),
      sortDirection: direction,
      columns: data.getAll("listOfColumns[]").map(String),
      includeDays: String(data.get("include_days") ?? "") === "1",
    });
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "Attendance Summary", filePrefix: "attendance_summary",
      headers: result.columns, rows: result.rows,
      subtitle: `${month} · ${result.rows.length} record(s)`,
    });
  } catch (error) {
    if (error instanceof AttendanceSummaryError) return apiError(error.message, error.status);
    console.error("Unable to build the attendance summary export", error);
    return apiError("Server error occurred.", 500);
  }
}
