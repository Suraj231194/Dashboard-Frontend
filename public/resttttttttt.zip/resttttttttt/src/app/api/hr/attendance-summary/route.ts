import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { DEFAULT_PER_PAGE, ALL_ITEMS_PER_PAGE } from "@/lib/pagination";
import { AttendanceSummaryError, loadAttendanceSummary } from "@/modules/hr/attendance-summary";

export const runtime = "nodejs";

/** Reads a repeated numeric query parameter such as `companies=1&companies=2`. */
function readIdList(params: URLSearchParams, key: string): number[] {
  return params.getAll(key)
    .flatMap((value) => String(value).split(","))
    .map((value) => Number.parseInt(value.trim(), 10))
    .filter((value) => Number.isInteger(value));
}

/** `loadAttendanceSummary`: the month grid, one row per employee. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "attendance-summary");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const rawPerPage = Number.parseInt(String(params.get("per_page") ?? ""), 10);
    const perPage = Number.isInteger(rawPerPage) && rawPerPage > 0
      ? Math.min(rawPerPage, ALL_ITEMS_PER_PAGE)
      : DEFAULT_PER_PAGE;
    const direction = String(params.get("sort_direction") ?? "").toUpperCase() === "DESC" ? "DESC" : "ASC";
    return apiSuccess(await loadAttendanceSummary({
      month: String(params.get("month") ?? "").trim(),
      search: String(params.get("search") ?? ""),
      page: Number.parseInt(String(params.get("page") ?? "1"), 10) || 1,
      perPage,
      companies: readIdList(params, "companies"),
      categories: readIdList(params, "categories"),
      statuses: readIdList(params, "statuses"),
      sortBy: String(params.get("sort_column") ?? ""),
      sortDirection: direction,
    }));
  } catch (error) {
    if (error instanceof AttendanceSummaryError) return apiError(error.message, error.status);
    console.error("Unable to load the attendance summary", error);
    return apiError("Error loading data.", 500);
  }
}
