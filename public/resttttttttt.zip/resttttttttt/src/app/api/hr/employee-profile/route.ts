import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { hrToday } from "@/modules/hr/attendance-engine";
import { employeeProfileData, submitReimbursementClaim } from "@/modules/hr/employee-profile";

export const runtime = "nodejs";

const PAGE = "employee-profile";

/** The whole self-service screen in one payload. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await employeeProfileData(guard.user.user_id, hrToday()));
  } catch (error) {
    console.error("Unable to load the employee profile", error);
    return apiError("Error loading data.", 500);
  }
}

/** `submit_reimbursement`: no permission slug, only a linked employee record. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    if (String(data.get("action") ?? "") !== "submit_reimbursement") {
      return apiError("No HRMS action was supplied.", 400);
    }
    const text = (key: string) => String(data.get(key) ?? "").trim();
    const amount = Number.parseFloat(text("amount"));
    const receipt = data.get("receipt");
    const result = await submitReimbursementClaim({
      expenseName: text("expense_name"),
      expenseDate: text("expense_date"),
      merchant: text("merchant"),
      category: text("category"),
      amount: Number.isFinite(amount) ? amount : 0,
      description: text("description"),
      receipt: receipt instanceof File ? receipt : null,
    }, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to submit the reimbursement claim", error);
    return apiError("Unable to complete the HRMS request.", 500);
  }
}
