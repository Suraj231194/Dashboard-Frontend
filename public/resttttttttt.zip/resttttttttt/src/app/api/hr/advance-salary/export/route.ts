import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { buildAdvanceSalaryExport } from "@/modules/hr/advance-salary";

export const runtime = "nodejs";

/** The advance salary list as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "advance-salary");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const month = String(data.get("month") ?? "").trim();
    const direction = String(data.get("sort_direction") ?? "").toUpperCase() === "DESC" ? "DESC" : "ASC";
    const result = await buildAdvanceSalaryExport({
      month,
      search: String(data.get("search") ?? ""),
      sortColumn: String(data.get("sort_column") ?? "employee_name"),
      sortDirection: direction,
      columns: data.getAll("listOfColumns[]").map(String),
    });
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "Advance Salary", filePrefix: "advance_salary",
      headers: result.columns, rows: result.rows,
      subtitle: `${month || "All months"} · ${result.rows.length} record(s)`,
    });
  } catch (error) {
    console.error("Unable to build the advance salary export", error);
    return apiError("Server error occurred.", 500);
  }
}
