import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { AdvanceSalaryError, deleteAdvanceSalary } from "@/modules/hr/advance-salary";

export const runtime = "nodejs";

/** `deleteAdvanceSalaryRecord`: a soft delete to status 3. */
export async function DELETE(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(request, "hr_advance_salary_delete",
    "You do not have permission to remove an advance salary record.");
  if (!guard.ok) return guard.response;
  try {
    const { id } = await context.params;
    const result = await deleteAdvanceSalary(readId(id), guard.user.user_id);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof AdvanceSalaryError) return apiError(error.message, error.status);
    console.error("Unable to remove the advance salary record", error);
    return apiError("Server error occurred.", 500);
  }
}
