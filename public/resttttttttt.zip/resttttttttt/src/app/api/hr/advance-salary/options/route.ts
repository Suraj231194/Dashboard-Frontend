import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { advanceEmployeeOptions } from "@/modules/hr/advance-salary";

export const runtime = "nodejs";

/** `loadEmployeesListOption`: the employee picker on the advance dialog. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "advance-salary");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ employees: await advanceEmployeeOptions() });
  } catch (error) {
    console.error("Unable to load the advance salary employee list", error);
    return apiError("Error loading data.", 500);
  }
}
