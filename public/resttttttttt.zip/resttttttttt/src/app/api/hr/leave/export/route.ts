import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { hrScope } from "@/modules/hr/hr-scope";
import { LeaveError, buildLeaveExport } from "@/modules/hr/leave";

export const runtime = "nodejs";

/** The application queue or the allocation table as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "hrms_leave_manage",
    "You do not have permission to export leave records.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const dataset = String(data.get("dataset") ?? "applications") === "allocations"
      ? "allocations" : "applications";
    const scope = await hrScope(guard.user.user_id);
    const result = await buildLeaveExport({
      dataset,
      search: String(data.get("search") ?? ""),
      columns: data.getAll("listOfColumns[]").map(String),
    }, guard.user.user_id, scope);
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format,
      title: dataset === "allocations" ? "Leave Allocations" : "Leave Applications",
      filePrefix: dataset === "allocations" ? "leave_allocations" : "leave_applications",
      headers: result.columns, rows: result.rows,
    });
  } catch (error) {
    if (error instanceof LeaveError) return apiError(error.message, error.status);
    console.error("Unable to build the leave export", error);
    return apiError("Server error occurred.", 500);
  }
}
