import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { can } from "@/modules/access/permissions";
import { hrScope } from "@/modules/hr/hr-scope";
import {
  LeaveError, leaveBalancesForEmployee, loadLeaveManagement, reviewLeave,
  saveLeaveAllocation, saveLeaveType, submitLeave,
} from "@/modules/hr/leave";

export const runtime = "nodejs";

const PAGE = "leave-management";
const MANAGE = "hrms_leave_manage";
const DENIED = "You do not have permission to perform this action.";

/** Everything the leave screen shows: balances, the three tables and the pickers. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  try {
    const scope = await hrScope(guard.user.user_id);
    const canManage = await can(guard.user, MANAGE);
    return apiSuccess({
      ...await loadLeaveManagement(guard.user.user_id, scope, canManage),
      canManage,
    });
  } catch (error) {
    console.error("Unable to load leave management", error);
    return apiError("Error loading data.", 500);
  }
}

/** The five leave actions, selected by `action`. */
export async function POST(request: NextRequest) {
  const session = await requireApiPageAccess(request, PAGE);
  if (!session.ok) return session.response;
  const data = await request.formData();
  const action = String(data.get("action") ?? "");
  if (action === "") return apiError("No HRMS action was supplied.", 400);

  // `submit_leave` needs no permission of its own; the manage right only
  // unlocks acting for another employee.
  const needsManage = ["get_leave_balances", "review_leave", "save_leave_type",
    "save_leave_allocation"].includes(action);
  const guard = needsManage
    ? await requireApiPermission(request, MANAGE, DENIED)
    : session;
  if (!guard.ok) return guard.response;

  const text = (key: string) => String(data.get(key) ?? "").trim();
  const number = (key: string) => Number.parseInt(String(data.get(key) ?? ""), 10) || 0;
  const decimal = (key: string, fallback = 0) => {
    const value = Number.parseFloat(String(data.get(key) ?? ""));
    return Number.isFinite(value) ? value : fallback;
  };
  const userId = guard.user.user_id;

  try {
    const scope = await hrScope(userId);

    if (action === "get_leave_balances") {
      return apiSuccess({ balances: await leaveBalancesForEmployee(number("employee_id"), scope) });
    }

    if (action === "submit_leave") {
      const canManage = await can(guard.user, MANAGE);
      const result = await submitLeave({
        employeeId: number("employee_id"),
        leaveTypeId: number("leave_type_id"),
        teamEmail: text("team_email"),
        reason: text("reason"),
        leaveDays: text("leave_days"),
      }, scope, userId, canManage);
      return apiSuccess({ applicationNo: result.applicationNo }, result.message);
    }

    if (action === "review_leave") {
      const result = await reviewLeave({
        applicationId: number("application_id"),
        decision: text("decision"),
        note: text("note"),
      }, scope, userId);
      return apiSuccess({}, result.message);
    }

    if (action === "save_leave_type") {
      const result = await saveLeaveType({
        leaveTypeId: number("leave_type_id"),
        code: text("code"),
        name: text("name"),
        description: text("description"),
        color: text("color"),
        genderEligibility: text("gender_eligibility") || "all",
        isPaid: text("is_paid") === "1",
        allowNegativeBalance: data.get("allow_negative_balance") !== null,
        status: data.get("status") !== null,
        companyId: number("company_id"),
      }, scope, userId);
      return apiSuccess({}, result.message);
    }

    if (action === "save_leave_allocation") {
      const result = await saveLeaveAllocation({
        employeeId: number("employee_id"),
        leaveTypeId: number("leave_type_id"),
        leaveYear: number("leave_year"),
        allocatedDays: decimal("allocated_days", Number.NaN),
        carriedForwardDays: decimal("carried_forward_days"),
        adjustmentDays: decimal("adjustment_days"),
      }, scope, userId);
      return apiSuccess({}, result.message);
    }

    return apiError("Unsupported HRMS action.", 400);
  } catch (error) {
    if (error instanceof LeaveError) return apiError(error.message, error.status);
    console.error("Unable to complete the leave action", error);
    return apiError("Unable to complete the HRMS request.", 500);
  }
}
