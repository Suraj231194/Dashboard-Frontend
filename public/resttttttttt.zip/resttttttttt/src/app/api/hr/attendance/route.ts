import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { hrScope } from "@/modules/hr/hr-scope";
import {
  AttendanceError, configureBiometricPush, importBiometricPunches, loadAttendance,
  markPresentAttendance, recalculateAttendanceForDate, saveBiometricDevice,
} from "@/modules/hr/attendance";

export const runtime = "nodejs";

const PAGE = "attendance-management";

function readNumber(value: FormDataEntryValue | string | null): number {
  return Number.parseInt(String(value ?? ""), 10) || 0;
}

/** Everything the biometric attendance screen shows for one date and slice. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const companyId = readNumber(params.get("company_id"));
    const branchId = readNumber(params.get("branch_id"));
    const scope = await hrScope(guard.user.user_id);
    return apiSuccess(await loadAttendance({
      date: String(params.get("attendance_date") ?? "").trim(),
      companyId: companyId > 0 ? companyId : null,
      branchId: branchId > 0 ? branchId : null,
    }, scope));
  } catch (error) {
    console.error("Unable to load attendance management", error);
    return apiError("Error loading data.", 500);
  }
}

/** The five writes the screen performs, selected by `action`. */
export async function POST(request: NextRequest) {
  const session = await requireApiPageAccess(request, PAGE);
  if (!session.ok) return session.response;
  const data = await request.formData();
  const action = String(data.get("action") ?? "");
  if (action === "") return apiError("No HRMS action was supplied.", 400);

  const biometric = ["save_biometric_device", "configure_biometric_push",
    "import_biometric_punches", "recalculate_attendance"].includes(action);
  const guard = biometric
    ? await requireApiPermission(request, "hrms_biometric_manage",
      "You do not have permission to perform this action.")
    : action === "mark_present_attendance"
      ? await requireApiPermission(request, "hrms_attendance_mark",
        "You do not have permission to perform this action.")
      : session;
  if (!guard.ok) return guard.response;

  const text = (key: string) => String(data.get(key) ?? "").trim();
  const number = (key: string) => readNumber(data.get(key));
  const userId = guard.user.user_id;

  try {
    const scope = await hrScope(userId);

    if (action === "save_biometric_device") {
      const result = await saveBiometricDevice({
        deviceId: number("device_id"), companyId: number("company_id"),
        branchId: number("branch_id"), deviceCode: text("device_code"),
        deviceName: text("device_name"), vendor: text("vendor"),
      }, scope, userId);
      return apiSuccess({ deviceId: result.deviceId }, result.message);
    }

    if (action === "configure_biometric_push") {
      const result = await configureBiometricPush({
        deviceId: number("device_id"),
        rateLimit: number("ingest_rate_limit") || 120,
        ingestEnabled: data.get("ingest_enabled") !== null,
        rotateToken: data.get("rotate_token") !== null,
      }, scope, userId);
      return apiSuccess({
        deviceId: result.deviceId, ingestEnabled: result.ingestEnabled,
        ingestToken: result.ingestToken, endpoint: result.endpoint,
      }, result.message);
    }

    if (action === "import_biometric_punches") {
      let events: unknown = null;
      try { events = JSON.parse(text("events")); } catch { events = null; }
      const result = await importBiometricPunches(
        { deviceId: number("device_id"), events }, scope, userId);
      return apiSuccess({ attendanceRows: result.attendanceRows }, result.message);
    }

    if (action === "recalculate_attendance") {
      const companyId = number("company_id");
      const branchId = number("branch_id");
      const result = await recalculateAttendanceForDate({
        date: text("attendance_date"),
        companyId: companyId > 0 ? companyId : null,
        branchId: branchId > 0 ? branchId : null,
      }, scope);
      return apiSuccess({}, result.message);
    }

    if (action === "mark_present_attendance") {
      let ids: number[] = [];
      try {
        const parsed: unknown = JSON.parse(text("employee_ids") || "[]");
        if (Array.isArray(parsed)) ids = parsed.map((value) => Number.parseInt(String(value), 10));
      } catch { ids = []; }
      if (ids.length === 0 && number("employee_id") > 0) ids = [number("employee_id")];
      const result = await markPresentAttendance({
        employeeIds: ids, date: text("attendance_date"),
        classification: text("classification"), note: text("note"),
      }, scope, userId);
      return apiSuccess({}, result.message);
    }

    return apiError("Unsupported HRMS action.", 400);
  } catch (error) {
    if (error instanceof AttendanceError) return apiError(error.message, error.status);
    console.error("Unable to complete the attendance action", error);
    return apiError("Unable to complete the HRMS request.", 500);
  }
}
