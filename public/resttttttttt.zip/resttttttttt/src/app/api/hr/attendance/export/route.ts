import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { hrScope } from "@/modules/hr/hr-scope";
import { AttendanceError, buildAttendanceExport } from "@/modules/hr/attendance";

export const runtime = "nodejs";

/** The attendance grid as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "attendance-management");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const companyId = Number.parseInt(String(data.get("company_id") ?? ""), 10) || 0;
    const branchId = Number.parseInt(String(data.get("branch_id") ?? ""), 10) || 0;
    const scope = await hrScope(guard.user.user_id);
    const date = String(data.get("attendance_date") ?? "").trim();
    const result = await buildAttendanceExport({
      date,
      companyId: companyId > 0 ? companyId : null,
      branchId: branchId > 0 ? branchId : null,
      search: String(data.get("search") ?? ""),
      metric: String(data.get("metric") ?? "all") || "all",
      columns: data.getAll("listOfColumns[]").map(String),
    }, scope);
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "Attendance Register", filePrefix: "attendance_management",
      headers: result.columns, rows: result.rows,
      subtitle: `${date} · ${result.rows.length} record(s)`,
    });
  } catch (error) {
    if (error instanceof AttendanceError) return apiError(error.message, error.status);
    console.error("Unable to build the attendance export", error);
    return apiError("Server error occurred.", 500);
  }
}
