import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { hrToday } from "@/modules/hr/attendance-engine";
import { hrScope } from "@/modules/hr/hr-scope";
import {
  departmentCounts, employeeMasterPage, linkEmployeeUser, masterLookups, masterSchema,
  onboardEmployee, saveEmployeeCompensation, updateEmployeeSection,
} from "@/modules/hr/employee-master";

export const runtime = "nodejs";

const PAGE = "employee-master";
const MANAGE = "hrms_employee_master_manage";
const DENIED = "You do not have permission to perform this action.";

/** The card grid, the department tiles and every option list the modals use. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const rawDepartment = params.get("department_id");
    const departmentId = rawDepartment === null || rawDepartment === "" || rawDepartment === "all"
      ? null
      : Math.max(0, Number.parseInt(rawDepartment, 10) || 0);

    const scope = await hrScope(guard.user.user_id);
    const schema = await masterSchema();
    const [page, counts, lookups] = await Promise.all([
      employeeMasterPage(scope, schema, {
        search: (params.get("master_search") ?? "").trim(),
        departmentId,
        page: Math.max(1, Number.parseInt(params.get("master_page") ?? "1", 10) || 1),
        perPage: Math.max(1, Number.parseInt(params.get("master_per_page") ?? "10", 10) || 10),
      }),
      departmentCounts(scope),
      masterLookups(scope),
    ]);
    return apiSuccess({ ...page, counts, lookups, schema, today: hrToday() });
  } catch (error) {
    console.error("Unable to load Employee Master", error);
    return apiError("Error loading data.", 500);
  }
}

/** The four writes the screen performs, selected by `action`. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, MANAGE, DENIED);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const action = String(data.get("action") ?? "");
    const userId = guard.user.user_id;
    const text = (key: string) => String(data.get(key) ?? "").trim();
    const number = (key: string) => Number.parseInt(text(key), 10) || 0;
    const decimal = (key: string) => {
      const value = Number.parseFloat(text(key));
      return Number.isFinite(value) ? value : 0;
    };

    if (action === "update_employee_section") {
      const values: Record<string, string> = {};
      for (const [key, value] of data.entries()) {
        if (typeof value === "string") values[key] = value;
      }
      const result = await updateEmployeeSection(
        { employeeId: number("employee_id"), section: text("section"), values }, userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    if (action === "link_employee_user") {
      const result = await linkEmployeeUser(number("employee_id"), number("user_id"), userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    if (action === "save_employee_compensation") {
      const scope = await hrScope(userId);
      const amounts: Record<string, number> = {};
      for (const field of ["basic_salary", "hra", "conveyance_allowance",
        "medical_allowance", "special_allowance", "incentives"]) {
        amounts[field] = decimal(field);
      }
      const result = await saveEmployeeCompensation({
        employeeId: number("employee_id"),
        annualCtc: decimal("annual_ctc"),
        monthlyGross: decimal("monthly_gross_salary"),
        effectiveFrom: text("effective_from"),
        pfCategory: text("pf_category"),
        hasPfPayload: data.has("pf_category"),
        hasCustomPayload: data.has("custom_salary_components"),
        customComponentsJson: text("custom_salary_components"),
        amounts,
      }, scope, userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    if (action === "onboard_employee") {
      const scope = await hrScope(userId);
      const resume = data.get("resume");
      const result = await onboardEmployee({
        firstName: text("first_name"), middleName: text("middle_name"), lastName: text("last_name"),
        dateOfJoin: text("date_of_join"), dob: text("dob"),
        workEmail: text("work_email"), personalEmail: text("personal_email"), mobile: text("mobile"),
        gender: number("gender"), companyId: number("company_id"), branchId: number("branch_id"),
        designationId: number("designation_id"), departmentId: number("department_id"),
        workLocation: text("work_location"),
        portalAccess: text("portal_access") === "1", existingUserId: number("existing_user_id"),
        annualCtc: decimal("annual_ctc"), pfCategory: text("pf_category"),
        hasPfPayload: data.has("pf_category"),
        fathersName: text("fathers_name"), panNo: text("pan_no"),
        residentialAddress: text("residential_address"), addressLine2: text("address_line_2"),
        city: text("city"), state: text("state"), postalCode: text("postal_code"),
        differentlyAbled: text("differently_abled") === "1",
        differentlyAbledType: text("differently_abled_type"),
        isDirector: text("is_director") === "1",
        // The extended block is gated on the keys being present at all, which
        // is how the reference decides whether the migration is in use.
        hasExtendedPayload: ["middle_name", "differently_abled_type", "address_line_2",
          "city", "state", "postal_code", "is_director"].some((key) => data.has(key)),
        paymentMode: text("payment_mode"),
        bankId: number("bank_id"), bankHolder: text("bank_account_holder_name"),
        bankAccount: text("bank_account_number"),
        confirmBankAccount: text("confirm_bank_account_number"),
        bankIfsc: text("bank_ifsc_code"), bankAccountType: number("bank_account_type"),
        upiId: text("upi_id"), upiHolder: text("upi_holder_name"),
        chequePayeeName: text("cheque_payee_name"), chequeBankId: number("cheque_bank_id"),
        salaryComponentsJson: text("salary_components"),
        resume: resume instanceof File ? resume : null,
      }, scope, userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess(result.data ?? {}, result.message);
    }

    return apiError("No HRMS action was supplied.", 400);
  } catch (error) {
    console.error("Unable to complete the Employee Master action", error);
    return apiError("Unable to complete the HRMS request.", 500);
  }
}
