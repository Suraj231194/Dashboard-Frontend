import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { formatDateDMY } from "@/lib/format";
import { hrScope } from "@/modules/hr/hr-scope";
import { employeeMasterExportRows, masterSchema } from "@/modules/hr/employee-master";
import {
  EMPLOYEE_MASTER_EXPORT_COLUMNS, MASTER_EMPLOYEE_STATUSES, PAYMENT_MODES,
} from "@/modules/hr/hr-constants";

export const runtime = "nodejs";

/**
 * The Employee Master export. The reference screen has no export at all, so
 * this exposes the same fields its cards show rather than inventing new ones.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "employee-master");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);

    const rawDepartment = String(data.get("department_id") ?? "");
    const departmentId = rawDepartment === "" || rawDepartment === "all"
      ? null : Math.max(0, Number.parseInt(rawDepartment, 10) || 0);

    const scope = await hrScope(guard.user.user_id);
    const schema = await masterSchema();
    const rows = await employeeMasterExportRows(scope, schema, {
      search: String(data.get("search") ?? "").trim(),
      departmentId,
    });
    if (rows.length === 0) return apiError("No records found", 404);

    const requested = data.getAll("listOfColumns[]").map((value) => String(value));
    const headers = (requested.length > 0
      ? EMPLOYEE_MASTER_EXPORT_COLUMNS.filter((column) => requested.includes(column))
      : [...EMPLOYEE_MASTER_EXPORT_COLUMNS]) as string[];
    if (headers.length === 0) return apiError("Select at least one export column.", 422);

    const projected = rows.map((row) => ({
      "Employee Code": String(row.emp_code ?? ""),
      Name: row.full_name ?? "",
      "Work Email": String(row.email ?? ""),
      Mobile: String(row.contact_no ?? ""),
      Designation: String(row.designation_name ?? ""),
      Department: String(row.department_name ?? ""),
      Organization: String(row.company_name ?? ""),
      Branch: String(row.branch_name ?? ""),
      "Work Location": String(row.work_location ?? ""),
      "Date of Joining": formatDateDMY(row.date_of_join),
      Status: MASTER_EMPLOYEE_STATUSES[String(row.status ?? "")] ?? "",
      "Payment Mode": PAYMENT_MODES[String(row.payment_mode ?? "")] ?? "",
      "Annual CTC": String(row.annual_ctc ?? ""),
      "Monthly Gross": String(row.monthly_salary_total ?? 0),
      "Monthly Deductions": String(row.monthly_deduction_total ?? 0),
      "Monthly Net": String(row.monthly_net_total ?? 0),
    } as Record<string, string>));

    return await tableExportResponse({
      format,
      title: "Employee Master",
      filePrefix: "employee_master",
      headers,
      rows: projected.map((row) => Object.fromEntries(headers.map((header) => [header, row[header]]))),
    });
  } catch (error) {
    console.error("Unable to export Employee Master", error);
    return apiError("Server error occurred.", 500);
  }
}
