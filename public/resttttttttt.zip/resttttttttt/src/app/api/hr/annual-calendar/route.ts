import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { can, canAll } from "@/modules/access/permissions";
import { hrScope } from "@/modules/hr/hr-scope";
import {
  CalendarError, addHoliday, calendarMonthlySummary, copyCalendarFromYear, deleteDayOverride,
  deleteHoliday, discardDraft, finalizeCalendar, importDefaultHolidays, importHolidayCsv,
  initializeCalendar, loadAnnualCalendar, reopenCalendar, saveCustomWeeklyOffs, saveDayOverride,
  toggleHoliday, updateHoliday, updateSaturdayPolicy, updateWeeklyOffDays,
} from "@/modules/hr/annual-calendar";
import { hrToday } from "@/modules/hr/attendance-engine";

export const runtime = "nodejs";

const PAGE = "annual-calendar";
const DENIED = "You do not have permission to perform this action.";

/** The calendar payload for one company and year, plus the permission flags. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const scope = await hrScope(guard.user.user_id);
    const year = Number.parseInt(String(params.get("year") ?? ""), 10)
      || Number(hrToday().slice(0, 4));
    let companyId = Number.parseInt(String(params.get("company_id") ?? ""), 10) || 0;
    if (companyId <= 0) companyId = scope.companyId ?? 0;
    const permissions = await canAll(guard.user, {
      canManage: "hrms_calendar_manage",
      canFinalize: "hrms_calendar_finalize",
      canReopen: "hrms_calendar_reopen",
      canExport: "hrms_calendar_export",
    });
    if (companyId <= 0) {
      // No company chosen yet: return the picker so the screen can ask first.
      const payload = await loadAnnualCalendar(1, year, scope).catch(() => null);
      return apiSuccess({
        exists: false, companies: payload?.companies ?? [], company_id: 0, year,
        today: hrToday(), calendar: null, days: [], totals: null, monthly: [],
        payroll_runs: [], audit_events: [], ...permissions,
      });
    }
    return apiSuccess({ ...await loadAnnualCalendar(companyId, year, scope), ...permissions });
  } catch (error) {
    if (error instanceof CalendarError) return apiError(error.message, error.status);
    console.error("Unable to load the annual calendar", error);
    return apiError("Error loading data.", 500);
  }
}

const FINALIZE_ACTIONS = new Set(["finalize_annual_calendar"]);
const REOPEN_ACTIONS = new Set(["unfinalize_annual_calendar"]);
const VIEW_ACTIONS = new Set(["get_calendar_monthly_summary"]);

/** Every calendar mutation, selected by `action`. */
export async function POST(request: NextRequest) {
  const session = await requireApiPageAccess(request, PAGE);
  if (!session.ok) return session.response;
  const data = await request.formData();
  const action = String(data.get("action") ?? "");
  if (action === "") return apiError("No HRMS action was supplied.", 400);

  const slug = FINALIZE_ACTIONS.has(action) ? "hrms_calendar_finalize"
    : REOPEN_ACTIONS.has(action) ? "hrms_calendar_reopen"
      : VIEW_ACTIONS.has(action) ? "hrms_calendar_view"
        : "hrms_calendar_manage";
  const guard = await requireApiPermission(request, slug, DENIED);
  if (!guard.ok) return guard.response;

  const text = (key: string) => String(data.get(key) ?? "").trim();
  const number = (key: string) => Number.parseInt(String(data.get(key) ?? ""), 10) || 0;
  const list = (key: string): unknown[] => {
    try {
      const parsed: unknown = JSON.parse(text(key) || "[]");
      return Array.isArray(parsed) ? parsed : [];
    } catch { return []; }
  };
  const userId = guard.user.user_id;

  try {
    const scope = await hrScope(userId);

    if (action === "initialize_annual_calendar") {
      const result = await initializeCalendar(number("company_id"), number("year"), scope, userId);
      return apiSuccess({ calendarId: result.calendar_id, totals: result.totals }, result.message);
    }
    if (action === "update_saturday_policy") {
      const result = await updateSaturdayPolicy(number("calendar_id"), text("saturday_policy"), scope, userId);
      return apiSuccess({ totals: result.totals }, result.message);
    }
    if (action === "update_weekly_off_days") {
      const days = list("weekly_off_days").map((value) => Number.parseInt(String(value), 10));
      const result = await updateWeeklyOffDays(number("calendar_id"), days, scope, userId);
      return apiSuccess({ totals: result.totals }, result.message);
    }
    if (action === "save_custom_weekly_offs") {
      const dates = list("off_dates").map((value) => String(value));
      const result = await saveCustomWeeklyOffs(number("calendar_id"), dates, scope, userId);
      return apiSuccess({ totals: result.totals }, result.message);
    }
    if (action === "add_calendar_holiday") {
      const result = await addHoliday(number("calendar_id"), {
        date: text("holiday_date"), name: text("holiday_name"), type: text("holiday_type"),
      }, scope, userId);
      return apiSuccess({ totals: result.totals }, result.message);
    }
    if (action === "update_calendar_holiday") {
      const result = await updateHoliday(number("holiday_id"), {
        date: text("holiday_date"), name: text("holiday_name"), type: text("holiday_type"),
      }, scope, userId);
      return apiSuccess({ totals: result.totals }, result.message);
    }
    if (action === "delete_calendar_holiday") {
      const result = await deleteHoliday(number("holiday_id"), scope, userId);
      return apiSuccess({ totals: result.totals }, result.message);
    }
    if (action === "toggle_calendar_holiday") {
      const result = await toggleHoliday(number("holiday_id"), scope, userId);
      return apiSuccess({ totals: result.totals }, result.message);
    }
    if (action === "import_default_holidays") {
      const result = await importDefaultHolidays(number("calendar_id"), scope, userId);
      return apiSuccess({ totals: result.totals }, result.message);
    }
    if (action === "import_holiday_csv") {
      const file = data.get("holiday_file");
      if (!(file instanceof File) || file.size === 0) {
        return apiError("Select a holiday CSV file to import.", 422);
      }
      if (file.size > 1024 * 1024) {
        return apiError("Holiday files must be smaller than 1 MB.", 422);
      }
      if (!file.name.toLowerCase().endsWith(".csv")) {
        return apiError("The holiday list must be a .csv file.", 422);
      }
      const result = await importHolidayCsv({
        calendarId: number("calendar_id"),
        jurisdiction: text("jurisdiction"),
        datasetVersion: text("dataset_version"),
        confirm: text("confirm") === "1",
        text: await file.text(),
      }, scope, userId);
      const { message, ...rest } = result;
      return apiSuccess(rest, message);
    }
    if (action === "save_calendar_day_override") {
      const result = await saveDayOverride(number("calendar_id"), {
        date: text("override_date"), type: text("override_type"), note: text("note"),
      }, scope, userId);
      return apiSuccess({ totals: result.totals }, result.message);
    }
    if (action === "delete_calendar_day_override") {
      const result = await deleteDayOverride(number("override_id"), scope, userId);
      return apiSuccess({ totals: result.totals }, result.message);
    }
    if (action === "copy_calendar_from_year") {
      const result = await copyCalendarFromYear(
        number("company_id"), number("year"), number("source_year"), scope, userId);
      return apiSuccess({ calendarId: result.calendar_id }, result.message);
    }
    if (action === "discard_calendar_draft") {
      const result = await discardDraft(number("calendar_id"), text("reason"), scope, userId);
      return apiSuccess({}, result.message);
    }
    if (action === "finalize_annual_calendar") {
      const lockVersion = text("lock_version") === "" ? null : number("lock_version");
      const result = await finalizeCalendar(number("calendar_id"), lockVersion, scope, userId);
      return apiSuccess({ contentHash: result.content_hash, totals: result.totals }, result.message);
    }
    if (action === "unfinalize_annual_calendar") {
      const canOverrideLock = await can(guard.user, "hrms_calendar_override_locked");
      const result = await reopenCalendar({
        calendarId: number("calendar_id"),
        reason: text("reason"),
        acknowledgePayrollImpact: text("acknowledge_payroll_impact") === "1",
        canOverrideLock,
      }, scope, userId);
      return apiSuccess({ calendarId: result.calendar_id }, result.message);
    }
    if (action === "get_calendar_monthly_summary") {
      return apiSuccess(await calendarMonthlySummary(number("calendar_id"), scope));
    }

    return apiError("Unsupported HRMS action.", 400);
  } catch (error) {
    if (error instanceof CalendarError) {
      const runs = (error as CalendarError & { payrollRuns?: unknown }).payrollRuns;
      if (runs !== undefined) {
        return Response.json(
          { status: "error", message: error.message, payroll_runs: runs },
          { status: error.status });
      }
      return apiError(error.message, error.status);
    }
    console.error("Unable to complete the annual calendar action", error);
    return apiError("Unable to complete the HRMS request.", 500);
  }
}
