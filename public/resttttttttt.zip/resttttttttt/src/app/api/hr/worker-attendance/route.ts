import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import {
  WorkerAttendanceError, WORKER_ATTENDANCE_SORT_COLUMNS, deleteWorkerAttendanceRecord,
  listWorkerAttendance, submitWorkerAttendance,
} from "@/modules/hr/worker-attendance";

export const runtime = "nodejs";

const PAGE = "worker-attendance";

/** `loadWorkerAttendanceTable`: one row per (date, department, creator). */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, WORKER_ATTENDANCE_SORT_COLUMNS, "attendance_date", "DESC");
    return apiSuccess(await listWorkerAttendance(query, {
      fromDate: String(params.get("from_date") ?? "").trim(),
      toDate: String(params.get("to_date") ?? "").trim(),
    }));
  } catch (error) {
    console.error("Unable to list worker attendance", error);
    return apiError("Error loading data.", 500);
  }
}

/**
 * The two writes this screen performs. The reference handlers carry no check
 * at all; these are guarded with the permissions the page uses to show the
 * buttons, which is the one deliberate departure.
 */
export async function POST(request: NextRequest) {
  const data = await request.formData();
  const action = String(data.get("action") ?? "");

  if (action === "submit_worker_attendance") {
    const guard = await requireApiPermission(request, "worker_attendance_add",
      "You do not have permission to record worker attendance.");
    if (!guard.ok) return guard.response;
    try {
      const workerIds = data.getAll("worker_ids")
        .map((value) => Number.parseInt(String(value), 10))
        .filter((value) => Number.isInteger(value) && value > 0);
      const result = await submitWorkerAttendance({
        departmentId: Number.parseInt(String(data.get("departmentsList") ?? ""), 10) || 0,
        workerIds,
      }, guard.user.user_id);
      return apiSuccess({}, result.message);
    } catch (error) {
      if (error instanceof WorkerAttendanceError) return apiError(error.message, error.status);
      console.error("Unable to submit worker attendance", error);
      return apiError("Server error occurred.", 500);
    }
  }

  if (action === "delete_worker_attendance") {
    const guard = await requireApiPermission(request, "worker_attendance_delete",
      "You do not have permission to remove worker attendance.");
    if (!guard.ok) return guard.response;
    try {
      const result = await deleteWorkerAttendanceRecord(
        Number.parseInt(String(data.get("id") ?? ""), 10) || 0, guard.user.user_id);
      return apiSuccess({}, result.message);
    } catch (error) {
      if (error instanceof WorkerAttendanceError) return apiError(error.message, error.status);
      console.error("Unable to remove worker attendance", error);
      return apiError("Server error occurred.", 500);
    }
  }

  return apiError("No HRMS action was supplied.", 400);
}
