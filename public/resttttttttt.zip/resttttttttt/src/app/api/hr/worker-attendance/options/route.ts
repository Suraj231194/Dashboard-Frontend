import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import {
  WorkerAttendanceError, attendanceRoster, departmentOptionList, workerAttendanceDashboard,
  workerAttendanceSessions, workerOptions,
} from "@/modules/hr/worker-attendance";

export const runtime = "nodejs";

/**
 * The lookups the worker attendance dialogs need, selected by `kind`:
 * the department list, the worker checkbox grid, the dashboard strip, the
 * present/absent roster, and the members of one marking session.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "worker-attendance");
  if (!guard.ok) return guard.response;
  const params = request.nextUrl.searchParams;
  const kind = String(params.get("kind") ?? "");
  const number = (key: string) => Number.parseInt(String(params.get(key) ?? ""), 10) || 0;

  try {
    if (kind === "departments") return apiSuccess({ departments: await departmentOptionList() });
    if (kind === "workers") {
      return apiSuccess({
        workers: await workerOptions(number("company_type"), number("employment_category")),
      });
    }
    if (kind === "dashboard") return apiSuccess({ cards: await workerAttendanceDashboard() });
    if (kind === "roster") {
      return apiSuccess(await attendanceRoster(
        number("company_type"), number("category_type"),
        String(params.get("attendance_type") ?? "A")));
    }
    if (kind === "sessions") {
      return apiSuccess({
        sessions: await workerAttendanceSessions({
          createdById: number("created_by_id"), deptId: number("dept_id"),
          createdDate: String(params.get("created_date") ?? "").trim(),
        }),
      });
    }
    return apiError("Select a valid lookup.", 400);
  } catch (error) {
    if (error instanceof WorkerAttendanceError) return apiError(error.message, error.status);
    console.error("Unable to load the worker attendance lookup", error);
    return apiError("Error loading data.", 500);
  }
}
