import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readExportDateRange, readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { buildWorkerAttendanceExport } from "@/modules/hr/worker-attendance";

export const runtime = "nodejs";

/** The worker attendance list as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "worker-attendance");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const range = readExportDateRange(data);
    if (!range.ok) return apiError(range.message, 422);
    // A blank dialog range falls back to the range the list is showing.
    const fromDate = range.fromDate !== "" ? range.fromDate : String(data.get("from_date") ?? "").trim();
    const toDate = range.toDate !== "" ? range.toDate : String(data.get("to_date") ?? "").trim();
    const sortDirection = String(data.get("sort_direction") ?? "DESC").toUpperCase() === "ASC" ? "ASC" : "DESC";
    const result = await buildWorkerAttendanceExport({
      fromDate, toDate,
      search: String(data.get("search") ?? ""),
      sortColumn: String(data.get("sort_column") ?? "attendance_date"),
      sortDirection,
      columns: data.getAll("listOfColumns[]").map(String),
    });
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "Worker Attendance", filePrefix: "worker_attendance",
      headers: result.columns, rows: result.rows,
      subtitle: `${fromDate} to ${toDate} · ${result.rows.length} record(s)`,
    });
  } catch (error) {
    console.error("Unable to build the worker attendance export", error);
    return apiError("Server error occurred.", 500);
  }
}
