import { NextRequest, NextResponse } from "next/server";
import { execute } from "@/lib/db/query";

export const runtime = "nodejs";

const VERIFY_TOKEN = process.env.WHATSAPP_VERIFY_TOKEN || "autoivd_whatsapp_webhook_token";

/**
 * WhatsApp Cloud API Webhook Verification (GET).
 */
export async function GET(request: NextRequest) {
  const mode = request.nextUrl.searchParams.get("hub.mode");
  const token = request.nextUrl.searchParams.get("hub.verify_token");
  const challenge = request.nextUrl.searchParams.get("hub.challenge");

  if (mode === "subscribe" && token === VERIFY_TOKEN) {
    return new Response(challenge ?? "", { status: 200 });
  }

  return NextResponse.json({ status: "error", message: "Verification failed." }, { status: 403 });
}

/**
 * WhatsApp Cloud API Inbound Message Handler (POST).
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const entry = body?.entry?.[0];
    const changes = entry?.changes?.[0];
    const value = changes?.value;
    const messages = value?.messages;

    if (!messages || messages.length === 0) {
      return NextResponse.json({ status: "ignored", message: "No message events found." });
    }

    const message = messages[0];
    const senderPhone = String(message.from || "");
    const messageText = String(message.text?.body || message.button?.text || "").trim();

    // Log the incoming message event
    try {
      await execute(
        `INSERT INTO whatsapp_messages_log
         (phone_number, message_body, raw_payload, direction, status, created_at)
         VALUES (?, ?, ?, 'inbound', 'received', NOW())`,
        [senderPhone, messageText, JSON.stringify(body)]
      );
    } catch {
      // Table might not be installed yet; continue
    }

    return NextResponse.json({ status: "success", received: true });
  } catch (error) {
    console.error("WhatsApp webhook error:", error);
    return NextResponse.json({ status: "error", message: "Failed to process webhook." }, { status: 500 });
  }
}
