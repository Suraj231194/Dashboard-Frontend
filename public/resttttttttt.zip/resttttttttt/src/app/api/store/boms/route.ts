import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { BOM_SORT_COLUMNS, createBom, listBoms } from "@/modules/store/bom";
import { readBomForm } from "./form";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "store-setting");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, BOM_SORT_COLUMNS, "id", "DESC");
    return apiSuccess(await listBoms(query));
  } catch (error) {
    console.error("Unable to list BOMs", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "store_settings_bom_add", "You do not have permission to add a BOM.",
  );
  if (!guard.ok) return guard.response;
  try {
    const result = await createBom(readBomForm(await request.formData()), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to add a BOM", error);
    return apiError("Something went wrong.", 500);
  }
}
