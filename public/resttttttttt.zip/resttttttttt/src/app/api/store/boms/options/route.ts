import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listProductsByCategory } from "@/modules/store/bom";

export const runtime = "nodejs";

/** The raw material picker, refreshed whenever a category is chosen. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "store-setting");
  if (!guard.ok) return guard.response;
  try {
    const categoryId = Number.parseInt(request.nextUrl.searchParams.get("category_id") ?? "0", 10) || 0;
    return apiSuccess({ products: await listProductsByCategory(categoryId) });
  } catch (error) {
    console.error("Unable to list products for a category", error);
    return apiError("Error loading data.", 500);
  }
}
