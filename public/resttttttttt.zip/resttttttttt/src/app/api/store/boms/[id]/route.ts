import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { deleteBom, listBomItems, readBom, updateBom } from "@/modules/store/bom";
import { readBomForm } from "../form";

export const runtime = "nodejs";

export async function GET(
  request: NextRequest, context: RouteContext<"/api/store/boms/[id]">,
) {
  const guard = await requireApiPageAccess(request, "store-setting");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    // The view panel only needs the items; the edit dialog needs the whole record.
    if (request.nextUrl.searchParams.get("view") === "items") {
      return apiSuccess({ items: await listBomItems(id) });
    }
    const bom = await readBom(id);
    if (!bom) return apiError("No data found...!!", 404);
    return apiSuccess(bom);
  } catch (error) {
    console.error("Unable to read the BOM", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(
  request: NextRequest, context: RouteContext<"/api/store/boms/[id]">,
) {
  const guard = await requireApiPermission(
    request, "store_settings_bom_edit", "You do not have permission to edit a BOM.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await updateBom(id, readBomForm(await request.formData()), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update the BOM", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(
  request: NextRequest, context: RouteContext<"/api/store/boms/[id]">,
) {
  const guard = await requireApiPermission(
    request, "store_settings_bom_delete", "You do not have permission to delete a BOM.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteBom(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the BOM", error);
    return apiError("Server error occurred.", 500);
  }
}
