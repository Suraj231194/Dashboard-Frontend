import type { BomInput, BomItemInput } from "@/modules/store/bom";

function whole(data: FormData, name: string): number {
  return Number.parseInt(String(data.get(name) ?? "0"), 10) || 0;
}

/**
 * The BOM dialogs post one array per item column, exactly as the current forms
 * do, so the lines are rebuilt by position.
 */
function readItems(data: FormData): BomItemInput[] {
  const ids = data.getAll("subItemId").map((value) => Number.parseInt(String(value), 10) || 0);
  const categories = data.getAll("rawMaterialCategoryList");
  const products = data.getAll("rawProductsList");
  const quantities = data.getAll("rawProdQuantity");
  const units = data.getAll("rawProdQuantityUnit");
  return products.map((product, index) => ({
    itemId: ids[index] ?? 0,
    categoryId: Number.parseInt(String(categories[index] ?? "0"), 10) || 0,
    product: String(product ?? ""),
    quantity: Number.parseFloat(String(quantities[index] ?? "0")) || 0,
    unitId: Number.parseInt(String(units[index] ?? "0"), 10) || 0,
  }));
}

export function readBomForm(data: FormData): BomInput {
  return {
    name: String(data.get("bomName") ?? ""),
    finishedProductId: whole(data, "finishedGoodId"),
    categoryId: whole(data, "productCategoryId"),
    bomType: whole(data, "bomType"),
    description: String(data.get("bomDescription") ?? "").trim(),
    // The current add handler treats a missing status as active.
    status: data.has("bomStatus") ? whole(data, "bomStatus") : 1,
    items: readItems(data),
  };
}
