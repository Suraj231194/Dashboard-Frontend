import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { deleteBomItem } from "@/modules/store/bom";

export const runtime = "nodejs";

export async function DELETE(
  request: NextRequest, context: RouteContext<"/api/store/bom-items/[id]">,
) {
  const guard = await requireApiPermission(
    request, "store_settings_bom_edit", "You do not have permission to edit a BOM.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteBomItem(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the BOM item", error);
    return apiError("Server error occurred.", 500);
  }
}
