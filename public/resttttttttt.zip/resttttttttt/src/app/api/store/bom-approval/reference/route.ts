import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listReferenceBomItems, listReferenceBoms } from "@/modules/store/bom-approval";

export const runtime = "nodejs";

/**
 * `getReferenceBoms` and `getReferenceBomItems`: the approved bills of
 * materials a new one may be cloned from, and their components.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "store-setting");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const sourceId = Number.parseInt(params.get("bom_id") ?? "0", 10) || 0;
    if (sourceId > 0) return apiSuccess({ items: await listReferenceBomItems(sourceId) });
    return apiSuccess({ rows: await listReferenceBoms(params.get("search") ?? "") });
  } catch (error) {
    console.error("Unable to load the reference BOMs", error);
    return apiError("Unable to load reference BOMs.", 500);
  }
}
