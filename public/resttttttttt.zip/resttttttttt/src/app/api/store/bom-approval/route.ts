import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import {
  BOM_APPROVAL_PERMISSION, listBomsForApproval, pendingBomApprovalCount, submitBomForApproval,
  type BomComponentInput,
} from "@/modules/store/bom-approval";

export const runtime = "nodejs";

/** `loadBomApprovalList` and `getPendingBomApprovalCount`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, BOM_APPROVAL_PERMISSION, "Unauthorized: Permission denied.");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const [rows, pending] = await Promise.all([
      listBomsForApproval({
        search: params.get("search") ?? "",
        status: params.get("status") ?? "",
      }),
      pendingBomApprovalCount(),
    ]);
    return apiSuccess({ rows, pendingCount: pending });
  } catch (error) {
    console.error("Unable to load the BOM approval queue", error);
    return apiError("Unable to load the BOM approval queue.", 500);
  }
}

/**
 * `submitBomForApproval`. Submitting is not the approval, so it needs no
 * `bom_approval`; anyone who may edit a bill of materials may put it forward.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "bom_edit", "You do not have permission to submit a BOM.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const number = (key: string) => Number.parseInt(String(data.get(key) ?? "0"), 10) || 0;
    const sourceType = String(data.get("source_type") ?? "");

    let items: BomComponentInput[] = [];
    try {
      const parsed: unknown = JSON.parse(String(data.get("items") ?? "[]"));
      if (Array.isArray(parsed)) {
        items = parsed.map((entry) => {
          const row = (entry ?? {}) as Record<string, unknown>;
          return {
            rawProductCategoryId: Number(row.raw_product_category_id ?? 0) || 0,
            rawProductId: Number(row.raw_product_id ?? 0) || 0,
            qtyPerUnit: Number(row.qty_per_unit ?? 0) || 0,
            unitId: Number(row.qty_unit_id ?? 0) || 0,
          };
        });
      }
    } catch {
      return apiError("BOM must have at least one component.", 422);
    }

    const result = await submitBomForApproval({
      bomId: number("bom_id") || number("existing_bom_id"),
      finishedProductId: number("finished_product_id"),
      categoryId: number("category_id"),
      bomName: String(data.get("bom_name") ?? "").trim(),
      bomType: number("bom_type") || 4,
      descriptions: String(data.get("descriptions") ?? "").trim(),
      // Anything unrecognised is treated as a clone, as the reference does.
      sourceType: sourceType === "ORIGINAL" || sourceType === "MANUAL" ? sourceType : "CLONED",
      sourceBomId: number("source_bom_id") || null,
      items,
      userId: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 422);
    return apiSuccess({ bomId: result.bomId, resubmitted: result.resubmitted }, result.message);
  } catch (error) {
    console.error("Unable to submit the BOM for approval", error);
    return apiError("Failed to submit BOM.", 500);
  }
}
