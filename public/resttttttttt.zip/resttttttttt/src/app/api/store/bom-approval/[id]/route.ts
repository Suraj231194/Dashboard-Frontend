import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import {
  BOM_APPROVAL_PERMISSION, approveBom, readBomApprovalHistory, rejectBom,
} from "@/modules/store/bom-approval";
import { readBom } from "@/modules/store/bom";

export const runtime = "nodejs";

type Context = { params: Promise<{ id: string }> };

/** `getBomDetailsForReview` and `getBomApprovalHistory`. */
export async function GET(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, BOM_APPROVAL_PERMISSION, "Unauthorized: Permission denied.");
  if (!guard.ok) return guard.response;
  try {
    const bomId = Number.parseInt((await context.params).id, 10) || 0;
    if (bomId <= 0) return apiError("Invalid BOM ID", 422);
    const [detail, history] = await Promise.all([
      readBom(bomId), readBomApprovalHistory(bomId),
    ]);
    if (!detail) return apiError("BOM not found", 404);
    return apiSuccess({ ...detail, history });
  } catch (error) {
    console.error("Unable to read the BOM for review", error);
    return apiError("Unable to read this BOM.", 500);
  }
}

/** `approveBom` and `rejectBom`, both gated on the approval permission. */
export async function POST(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, BOM_APPROVAL_PERMISSION,
    "Unauthorized: You do not have permission to approve BOMs.");
  if (!guard.ok) return guard.response;
  try {
    const bomId = Number.parseInt((await context.params).id, 10) || 0;
    const data = await request.formData();
    const decision = String(data.get("decision") ?? "").toLowerCase();

    const result = decision === "reject"
      ? await rejectBom(bomId, String(data.get("reason") ?? ""), guard.user.user_id)
      : await approveBom(bomId, String(data.get("comments") ?? ""), guard.user.user_id);

    if (!result.ok) return apiError(result.message, result.status ?? 422);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to record the BOM decision", error);
    return apiError("Failed to record the BOM decision.", 500);
  }
}
