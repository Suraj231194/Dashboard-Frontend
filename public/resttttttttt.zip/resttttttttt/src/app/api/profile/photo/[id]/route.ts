import { NextRequest } from "next/server";
import { readId, requireApiSession } from "@/lib/http/guard";
import { checkPermission } from "@/modules/access/permissions";
import { ProfileError, readProfileDocument } from "@/modules/profile/my-profile";

export const runtime = "nodejs";

/**
 * hrms-document.php. The bytes are streamed back with the same private cache
 * and sniffing headers, so a stored photo never becomes a public asset.
 */
export async function GET(_request: NextRequest, context: RouteContext<"/api/profile/photo/[id]">) {
  const guard = await requireApiSession();
  if (!guard.ok) return new Response("Authentication required.", { status: 401 });

  const id = readId((await context.params).id);
  try {
    const canManageEmployees = await checkPermission(
      guard.user.user_id, guard.user.role_id, "hrms_employee_master_view",
    );
    const document = await readProfileDocument(id, { userId: guard.user.user_id, canManageEmployees });
    return new Response(new Uint8Array(document.bytes), {
      status: 200,
      headers: {
        "Content-Type": document.mimeType,
        "Content-Length": String(document.bytes.length),
        "Content-Disposition": `inline; filename="${document.displayName}"`,
        "Cache-Control": "private, no-store, max-age=0",
        Pragma: "no-cache",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "SAMEORIGIN",
      },
    });
  } catch (error) {
    if (error instanceof ProfileError) return new Response(error.message, { status: error.status });
    console.error("Unable to read the profile document", error);
    return new Response("Document file is unavailable.", { status: 500 });
  }
}
