import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { ProfileError, removeProfilePhoto, storeProfilePhoto } from "@/modules/profile/my-profile";

export const runtime = "nodejs";

function readFile(value: FormDataEntryValue | null): File | null {
  return value instanceof File ? value : null;
}

/** upload_profile_photo. Like the current action, a session and a token suffice. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "profile");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const file = readFile(data.get("profile_photo")) ?? readFile(data.get("photo"));
    const stored = await storeProfilePhoto(guard.user.user_id, file);
    return apiSuccess(
      { photo_id: stored.photoId, photo_url: stored.photoUrl },
      "Profile photo updated successfully.",
    );
  } catch (error) {
    if (error instanceof ProfileError) return apiError(error.message, error.status);
    console.error("Unable to store the profile photo", error);
    return apiError("Unable to complete the HRMS request.", 500);
  }
}

/** remove_profile_photo: the avatar falls back to the placeholder afterwards. */
export async function DELETE(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "profile");
  if (!guard.ok) return guard.response;
  try {
    await removeProfilePhoto(guard.user.user_id);
    return apiSuccess({ photo_url: null }, "Profile photo removed successfully.");
  } catch (error) {
    if (error instanceof ProfileError) return apiError(error.message, error.status);
    console.error("Unable to remove the profile photo", error);
    return apiError("Unable to complete the HRMS request.", 500);
  }
}
