import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiSession } from "@/lib/http/guard";
import { getMyProfile, ProfileError, updateMyProfile } from "@/modules/profile/my-profile";

export const runtime = "nodejs";

/** userProfileAllData: the signed-in person's own user and employee rows. */
export async function GET() {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await getMyProfile(guard.user.user_id));
  } catch (error) {
    console.error("Unable to load the account profile", error);
    return apiError("Error loading data.", 500);
  }
}

/**
 * update_my_profile. The current action carries no permission check of its own,
 * only a signed-in session and a request token, so the page guard stands in.
 */
export async function PUT(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "profile");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const text = (key: string) => String(data.get(key) ?? "");
    /** PHP's ?? chain: the first field that was actually posted wins. */
    const first = (...keys: string[]) => String(data.get(keys.find((key) => data.has(key)) ?? "") ?? "");
    const result = await updateMyProfile(guard.user.user_id, {
      name: first("name", "profile_name"),
      firstName: text("first_name"),
      lastName: text("last_name"),
      phone: first("phone", "profile_phone", "contact_no"),
      solutation: text("solutation"),
      dob: text("dob"),
      gender: text("gender"),
      bloodGroup: text("blood_group"),
      fathersName: text("fathers_name"),
      maritalStatus: text("marital_status"),
      husbandName: text("husband_name"),
      altContact: text("alt_contact_no"),
      altContact2: text("alt_contact_no2"),
      localAddress: text("local_address"),
      permanentAddress: text("permanent_address"),
    });
    return apiSuccess({ name: result.name, phone: result.phone }, result.message);
  } catch (error) {
    if (error instanceof ProfileError) return apiError(error.message, error.status);
    console.error("Unable to update the account profile", error);
    return apiError("Unable to complete the HRMS request.", 500);
  }
}
