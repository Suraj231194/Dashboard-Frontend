import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { changeOwnPassword } from "@/modules/profile/account-security";
import { ProfileError } from "@/modules/profile/my-profile";

export const runtime = "nodejs";

/**
 * updatePasswordAccountSetting. The action has no permission slug today, so the
 * account settings page guard stands in and a signed-in person changes their
 * own password only.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "account-settings");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const message = await changeOwnPassword(guard.user.user_id, String(data.get("newPassword") ?? ""));
    return apiSuccess({}, message);
  } catch (error) {
    if (error instanceof ProfileError) return apiError(error.message, error.status);
    console.error("Unable to change the account password", error);
    return apiError("Failed to prepare statement.", 500);
  }
}
