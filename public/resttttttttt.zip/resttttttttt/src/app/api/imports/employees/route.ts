import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { importEmployees, importEmployeeSalaries } from "@/modules/imports/employee-import";

export const runtime = "nodejs";

/**
 * The two spreadsheet imports behind the Custom Import screen
 * (`admin/importajax.php`). `kind` selects which one, matching the two flags
 * the current forms append: `importEmployeesFile` and
 * `importEmployeesSalaryFile`.
 *
 * The current handler runs with no permission check at all; this one is
 * guarded by the screen's own access, since it writes employee and salary rows.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "custom-import");
  if (!guard.ok) return guard.response;

  try {
    const data = await request.formData();
    const kind = String(data.get("kind") ?? "");
    const file = data.get("file");
    if (!(file instanceof File) || file.size === 0) {
      return apiError("No file uploaded or upload error.", 422);
    }

    const result = kind === "salary"
      ? await importEmployeeSalaries(file, guard.user.user_id)
      : kind === "employees"
        ? await importEmployees(file, guard.user.user_id)
        : null;

    if (result === null) return apiError("Select a valid import.", 422);
    if (!result.ok) return apiError(result.message, 422);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to run the import", error);
    return apiError("Server error occurred.", 500);
  }
}
