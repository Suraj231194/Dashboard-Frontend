import { NextRequest } from "next/server";
import { apiError, apiForbidden, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { can } from "@/modules/access/permissions";
import {
  createCompleteRole,
  getRoleDetails,
  getRoleWorkflowOptions,
  updateCompleteRole,
} from "@/modules/users/role-workflow";

export const runtime = "nodejs";

async function guardWorkflow(request: NextRequest) {
  const guard = await requireApiPermission(request, "roles_add", "You do not have permission to create roles.");
  if (!guard.ok) return guard;
  const [assignPermissions, editUsers] = await Promise.all([
    can(guard.user, "role_has_permission_add"),
    can(guard.user, "user_edit"),
  ]);
  if (!assignPermissions || !editUsers) {
    return { ok: false as const, response: apiForbidden("You do not have permission to complete the role workflow.") };
  }
  return guard;
}

export async function GET(request: NextRequest) {
  const guard = await guardWorkflow(request);
  if (!guard.ok) return guard.response;
  try {
    const roleId = Number(request.nextUrl.searchParams.get("role_id"));
    const options = await getRoleWorkflowOptions();
    if (roleId > 0) {
      const details = await getRoleDetails(roleId);
      return apiSuccess({ ...options, roleDetails: details });
    }
    return apiSuccess(options);
  } catch (error) {
    console.error("Unable to load the role workflow", error);
    return apiError("Unable to load role options.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await guardWorkflow(request);
  if (!guard.ok) return guard.response;
  try {
    const form = await request.formData();
    const result = await createCompleteRole({
      departmentId: Number(form.get("department_id")),
      name: String(form.get("rolesName") ?? ""),
      description: String(form.get("rolesDesc") ?? ""),
      permissionIds: form.getAll("permission_ids[]").map(Number),
      userIds: form.getAll("user_ids[]").map(Number),
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status);
    return apiSuccess({ roleId: result.roleId }, "Role, permissions, and users were updated successfully.");
  } catch (error) {
    console.error("Unable to create the complete role", error);
    return apiError("Unable to create the role.", 500);
  }
}

export async function PUT(request: NextRequest) {
  const guard = await guardWorkflow(request);
  if (!guard.ok) return guard.response;
  try {
    const form = await request.formData();
    const roleId = Number(form.get("role_id"));
    const result = await updateCompleteRole({
      roleId,
      departmentId: Number(form.get("department_id")),
      name: String(form.get("rolesName") ?? ""),
      description: String(form.get("rolesDesc") ?? ""),
      permissionIds: form.getAll("permission_ids[]").map(Number),
      userIds: form.getAll("user_ids[]").map(Number),
      updatedBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status);
    return apiSuccess({ roleId: result.roleId }, "Role, permissions, and users were updated successfully.");
  } catch (error) {
    console.error("Unable to update the complete role", error);
    return apiError("Unable to update the role.", 500);
  }
}

