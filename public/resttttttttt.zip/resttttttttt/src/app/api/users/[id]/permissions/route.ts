import { NextRequest } from "next/server";
import { apiError, apiForbidden, apiSuccess } from "@/lib/http/json";
import { readId, requireApiSession } from "@/lib/http/guard";
import { isSameOrigin } from "@/lib/http/same-origin";
import { canDoThis } from "@/modules/access/permissions";
import { getUserPermissions, saveUserPermissions } from "@/modules/users/user-permissions";

export const runtime = "nodejs";

const DENIED = "You do not have permission to assign extra permissions.";

export async function GET(request: NextRequest, context: RouteContext<"/api/users/[id]/permissions">) {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  if (!(await canDoThis(guard.user, "user_assign_extra_permission"))) return apiForbidden(DENIED);
  const userId = readId((await context.params).id);
  const roleId = readId(request.nextUrl.searchParams.get("roleId") ?? "");
  try {
    const detail = await getUserPermissions(userId, roleId);
    if (!detail) return apiError("Something went wrong with this record..!!", 404);
    return apiSuccess(detail);
  } catch (error) {
    console.error("Unable to read user permissions", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/users/[id]/permissions">) {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  if (!isSameOrigin(request)) {
    return apiError("Your session token is invalid. Please refresh the page and try again.", 419);
  }
  if (!(await canDoThis(guard.user, "user_assign_extra_permission"))) return apiForbidden(DENIED);
  const userId = readId((await context.params).id);
  try {
    const data = await request.formData();
    const roleId = readId(String(data.get("role_id") ?? ""));
    const choices = new Map<number, number>();
    for (const [field, value] of data.entries()) {
      const match = /^permission\[(\d+)\]$/.exec(field);
      if (!match) continue;
      const permissionId = Number.parseInt(match[1], 10);
      if (!Number.isInteger(permissionId) || permissionId <= 0) continue;
      choices.set(permissionId, String(value) === "1" ? 1 : 0);
    }
    const result = await saveUserPermissions(userId, roleId, choices);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "User permissions updated successfully");
  } catch (error) {
    console.error("Unable to save user permissions", error);
    return apiError("Failed to update permissions", 500);
  }
}
