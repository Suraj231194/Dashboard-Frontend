import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { deleteUser, findUser } from "@/modules/users/users";
import { findUserProfile, updateUserProfile, UserProfileError } from "@/modules/users/user-profile";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/users/[id]">) {
  const guard = await requireApiPermission(request, "user_edit", "You do not have permission to view employee profiles.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const [account, profile] = await Promise.all([findUser(id), findUserProfile(id)]);
    if (!account || !profile) return apiError("No data found...!!", 404);
    return apiSuccess({ account, profile });
  } catch (error) {
    console.error("Unable to read the user", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/users/[id]">) {
  const guard = await requireApiPermission(request, "user_edit", "You do not have permission to edit users.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    // The personal fields travel only with a linked employee, as the current
    // form disables them otherwise; their presence is what asks for the update.
    const employeeKeys = ["employeeDobEdit", "employeeGenderEdit", "employeeEmergencyContactEdit", "employeeHomeAddressEdit"];
    const hasEmployee = employeeKeys.some((key) => data.has(key));
    const photo = data.get("userProfilePhotoEdit");
    await updateUserProfile({
      userId: id,
      name: String(data.get("userNameEdit") ?? ""),
      email: String(data.get("userEmailEdit") ?? ""),
      roleId: Number.parseInt(String(data.get("userRoleTypeEdit") ?? "0"), 10) || 0,
      employee: hasEmployee ? {
        dob: String(data.get("employeeDobEdit") ?? "").trim(),
        gender: Number.parseInt(String(data.get("employeeGenderEdit") ?? "0"), 10) || 0,
        emergencyContact: String(data.get("employeeEmergencyContactEdit") ?? "").trim(),
        homeAddress: String(data.get("employeeHomeAddressEdit") ?? "").trim(),
      } : null,
      photo: photo instanceof File && photo.size > 0 ? photo : null,
      updatedBy: guard.user.user_id,
    });
    return apiSuccess({}, "Employee profile updated successfully.");
  } catch (error) {
    if (error instanceof UserProfileError) return apiError(error.message, error.status);
    console.error("Unable to update the user", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext<"/api/users/[id]">) {
  const guard = await requireApiPermission(request, "user_delete", "You do not have permission to delete users.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteUser(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "User deleted successfully.");
  } catch (error) {
    console.error("Unable to delete the user", error);
    return apiError("Server error occurred.", 500);
  }
}
