import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { listEmployeeDocuments, UserProfileError } from "@/modules/users/user-profile";

export const runtime = "nodejs";

/** `loadEmployeeDocuments`: the documents panel of Users → Edit. */
export async function GET(request: NextRequest, context: RouteContext<"/api/users/[id]/documents">) {
  const guard = await requireApiPermission(request, "user_edit", "You do not have permission to view employee documents.");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await listEmployeeDocuments(readId((await context.params).id)));
  } catch (error) {
    if (error instanceof UserProfileError) return apiError(error.message, error.status);
    console.error("Unable to list employee documents", error);
    return apiError("Server error occurred.", 500);
  }
}
