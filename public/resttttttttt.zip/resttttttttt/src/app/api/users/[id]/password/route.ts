import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { changeUserPassword } from "@/modules/users/users";

export const runtime = "nodejs";

export async function PUT(request: NextRequest, context: RouteContext<"/api/users/[id]/password">) {
  const guard = await requireApiPermission(
    request,
    "user_change_password",
    "You do not have permission to change passwords.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await changeUserPassword(id, String(data.get("userNewPassword") ?? ""), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Password updated successfully.");
  } catch (error) {
    console.error("Unable to change the password", error);
    return apiError("Failed to update password. Please try again.", 500);
  }
}
