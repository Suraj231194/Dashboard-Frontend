import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission, requireApiSession } from "@/lib/http/guard";
import { queryRows, queryOne, execute } from "@/lib/db/query";
import type { RowDataPacket } from "mysql2";

export const runtime = "nodejs";

export type RoleOverviewItem = {
  id: number;
  name: string;
  description: string;
  department_id: number;
  department_name: string;
  status: number;
  user_count: number;
  users: { id: number; name: string }[];
  permission_count: number;
  can_edit: boolean;
  can_delete: boolean;
  is_system: boolean;
};

export async function GET() {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;

  try {
    const roleRows = await queryRows<RowDataPacket & {
      id: number;
      name: string;
      description: string;
      department_id: number | null;
      status: number;
      department_name: string | null;
    }>(
      `SELECT r.id, r.name, r.description, r.department_id, r.status,
              d.name AS department_name
       FROM roles r
       LEFT JOIN departments d ON d.id = r.department_id
       WHERE r.status != 3 AND r.deleted_at IS NULL
       ORDER BY r.name ASC`
    );

    const userRows = await queryRows<RowDataPacket & {
      id: number;
      name: string;
      role_id: number;
    }>(
      `SELECT id, name, role_id
       FROM users
       WHERE role_id > 0 AND is_active != 3 AND deleted_at IS NULL
       ORDER BY name ASC`
    );

    const permRows = await queryRows<RowDataPacket & {
      role_id: number;
      permission_id: number;
    }>(
      `SELECT rp.role_id, rp.permission_id
       FROM role_permissions rp
       INNER JOIN permissions p ON p.id = rp.permission_id
         AND p.status != 3 AND p.deleted_at IS NULL
       WHERE rp.status = 1`
    ).catch(() => []);

    const totalUsers = await queryOne<RowDataPacket & { total: number }>(
      "SELECT COUNT(*) AS total FROM users WHERE is_active != 3 AND deleted_at IS NULL"
    );

    // Group users by role
    const usersByRole = new Map<number, { id: number; name: string }[]>();
    for (const u of userRows) {
      if (!usersByRole.has(u.role_id)) {
        usersByRole.set(u.role_id, []);
      }
      usersByRole.get(u.role_id)!.push({ id: u.id, name: u.name || "User" });
    }

    // Group permissions by role
    const permsByRole = new Map<number, number>();
    for (const p of permRows) {
      permsByRole.set(p.role_id, (permsByRole.get(p.role_id) ?? 0) + 1);
    }

    const roles: RoleOverviewItem[] = roleRows.map((r) => {
      const assigned = usersByRole.get(r.id) ?? [];
      return {
        id: r.id,
        name: r.name || "Unnamed Role",
        description: r.description || "No description provided.",
        department_id: r.department_id ?? 0,
        department_name: r.department_name || "General",
        status: Number(r.status ?? 1),
        user_count: assigned.length,
        users: assigned,
        permission_count: permsByRole.get(r.id) ?? 0,
        can_edit: true,
        can_delete: r.id !== 1,
        is_system: r.id === 1,
      };
    });

    return apiSuccess({
      roles,
      total_users: Number(totalUsers?.total ?? userRows.length),
      total_roles: roles.length,
    });
  } catch (error) {
    console.error("Unable to load role management overview", error);
    return apiError("Error loading role overview.", 500);
  }
}

export async function DELETE(request: NextRequest) {
  const guard = await requireApiPermission(request, "roles_delete", "You do not have permission to delete roles.");
  if (!guard.ok) return guard.response;

  try {
    const roleId = Number(request.nextUrl.searchParams.get("id"));
    if (!roleId || roleId === 1) {
      return apiError("System or invalid role cannot be deleted.", 400);
    }

    await execute(
      "UPDATE roles SET deleted_at = NOW(), status = 3 WHERE id = ?",
      [roleId]
    );

    return apiSuccess({}, "Role deleted successfully.");
  } catch (error) {
    console.error("Unable to delete role", error);
    return apiError("Failed to delete role.", 500);
  }
}
