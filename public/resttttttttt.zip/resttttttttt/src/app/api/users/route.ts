import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createUser, listUsers, USER_SORT_COLUMNS } from "@/modules/users/users";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "users");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, USER_SORT_COLUMNS, "u.id", "DESC");
    return apiSuccess(await listUsers(query));
  } catch (error) {
    console.error("Unable to list users", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "user_add", "You do not have permission to add users.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const number = (name: string) => Number.parseInt(String(data.get(name) ?? "0"), 10) || 0;
    const result = await createUser({
      name: String(data.get("userName") ?? ""),
      email: String(data.get("userEmail") ?? ""),
      password: String(data.get("userPassword") ?? ""),
      roleId: number("userRoleType"),
      status: number("userStatus"),
      companyId: number("userCompanyType"),
      branchId: number("userBranchType"),
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "User added successfully.");
  } catch (error) {
    console.error("Unable to add a user", error);
    return apiError("Error inserting user.", 500);
  }
}
