import { NextRequest } from "next/server";
import { getSession } from "@/modules/auth/session";
import { roleHasPermission } from "@/modules/access/permissions";
import { readEmployeeDocument, UserProfileError } from "@/modules/users/user-profile";

export const runtime = "nodejs";

const plain = (message: string, status: number) =>
  new Response(message, { status, headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" } });

/**
 * `employee-document.php`: streams an employee document or profile photo for
 * preview, privately, with the type taken from the file's own bytes.
 */
export async function GET(_request: NextRequest, context: RouteContext<"/api/users/documents/[documentId]">) {
  const user = await getSession();
  if (!user || !(await roleHasPermission(user.user_id, user.role_id, "user_edit"))) return plain("Access denied.", 403);
  const raw = (await context.params).documentId;
  const documentId = /^[1-9][0-9]*$/.test(raw) ? Number(raw) : 0;
  try {
    const document = await readEmployeeDocument(documentId);
    return new Response(new Uint8Array(document.bytes), {
      status: 200,
      headers: {
        "Content-Type": document.mimeType,
        "Content-Length": String(document.bytes.length),
        "Content-Disposition": `inline; filename="${document.displayName}"`,
        "Cache-Control": "private, no-store, max-age=0",
        Pragma: "no-cache",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "SAMEORIGIN",
      },
    });
  } catch (error) {
    if (error instanceof UserProfileError) return plain(error.message, error.status);
    console.error("Unable to read the employee document", error);
    return plain("Document file is unavailable.", 500);
  }
}
