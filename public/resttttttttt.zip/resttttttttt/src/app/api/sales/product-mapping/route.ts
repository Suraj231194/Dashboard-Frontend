import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { searchProductsForMapping } from "@/modules/sales/order-detail";

export const runtime = "nodejs";

/** searchActiveProductsForOrderMapping: the Product Master selector on a line. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(request, "store_order_received_edit", "Permission denied.");
  if (!guard.ok) return guard.response;
  try {
    const term = (request.nextUrl.searchParams.get("term") ?? "").trim();
    return apiSuccess({ results: await searchProductsForMapping(term) });
  } catch (error) {
    console.error("Unable to search products for mapping", error);
    return apiError("Error loading data.", 500);
  }
}
