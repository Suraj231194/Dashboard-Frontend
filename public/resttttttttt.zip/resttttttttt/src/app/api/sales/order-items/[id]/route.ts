import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { deleteOrderItem } from "@/modules/sales/orders";

export const runtime = "nodejs";

/** deleteOrderReceivedSubProductRecord: one product off an order. */
export async function DELETE(request: NextRequest, context: RouteContext<"/api/sales/order-items/[id]">) {
  // The current handler carries no permission check of its own.
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteOrderItem(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the order item", error);
    return apiError("Server error occurred.", 500);
  }
}
