import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { describeCustomer, getActiveCustomer } from "@/modules/sales/order-customers";
import { withConnection } from "@/modules/sales/order-sql";

export const runtime = "nodejs";

/** getOrderCustomerDetails: the address, tax and payment fields for one customer. */
export async function GET(request: NextRequest, context: RouteContext<"/api/sales/customers/[id]">) {
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const customer = await withConnection((connection) => getActiveCustomer(connection, id));
    if (!customer) return apiError("Select an active customer from Customer Master.", 404);
    return apiSuccess(describeCustomer(customer));
  } catch (error) {
    console.error("Unable to read the customer", error);
    return apiError("Unable to load customer details.", 500);
  }
}
