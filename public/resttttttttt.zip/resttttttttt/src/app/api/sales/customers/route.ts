import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { searchActiveCustomers } from "@/modules/sales/order-customers";

export const runtime = "nodejs";

/** searchActiveCustomersForOrder: the Customer Master selector on the order form. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const page = Math.max(1, Number.parseInt(params.get("page") ?? "1", 10) || 1);
    const result = await searchActiveCustomers((params.get("term") ?? "").trim(), page);
    return apiSuccess({ results: result.results, pagination: { more: result.more } });
  } catch (error) {
    console.error("Unable to search customers", error);
    return apiError("Error loading data.", 500);
  }
}
