import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createOrder, listOrders, ORDER_SORT_COLUMNS } from "@/modules/sales/orders";
import { readOrderFilters, readOrderForm } from "./form";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  try {
    // The screen opens on "id", which the handler's allow-list does not carry,
    // so the first page arrives ordered by the primary key descending anyway.
    const query = readListQuery(request.nextUrl.searchParams, ORDER_SORT_COLUMNS, "id", "DESC");
    const filters = readOrderFilters(request.nextUrl.searchParams);
    return apiSuccess(await listOrders(query, filters));
  } catch (error) {
    console.error("Unable to list orders", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "store_order_received_add", "You do not have permission to add orders.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    // mvGetSessionUserName(): the signed-in person's name is stored on the order.
    const result = await createOrder(readOrderForm(data), guard.user.user_id, guard.user.name || "System");
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess(result.data ?? {}, result.message);
  } catch (error) {
    console.error("Unable to add an order", error);
    return apiError("Server error occurred.", 500);
  }
}
