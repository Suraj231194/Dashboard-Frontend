import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { deleteOrder, readOrderForEdit, updateOrder } from "@/modules/sales/orders";
import { readOrderEditForm } from "../form";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/sales/orders/[id]">) {
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const detail = await readOrderForEdit(id);
    if (!detail) return apiError("No data found...!!", 404);
    return apiSuccess(detail);
  } catch (error) {
    console.error("Unable to read the order", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/sales/orders/[id]">) {
  const guard = await requireApiPermission(
    request, "store_order_received_edit", "You do not have permission to edit orders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateOrder(readOrderEditForm(data, id), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess(result.data ?? {}, result.message);
  } catch (error) {
    console.error("Unable to update the order", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext<"/api/sales/orders/[id]">) {
  const guard = await requireApiPermission(
    request, "store_order_received_delete", "You do not have permission to delete orders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteOrder(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the order", error);
    return apiError("Server error occurred.", 500);
  }
}
