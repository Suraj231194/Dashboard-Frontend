import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { readMappingInput, resolveOrderItemMapping } from "@/modules/sales/order-detail";

export const runtime = "nodejs";

/** resolveOrderItemMapping: points an order line at a Product Master item. */
export async function PUT(request: NextRequest, context: RouteContext<"/api/sales/orders/[id]/mapping">) {
  const guard = await requireApiPermission(request, "store_order_received_edit", "Permission denied.");
  if (!guard.ok) return guard.response;
  const orderId = readId((await context.params).id);
  try {
    const data = await request.formData();
    const input = readMappingInput({
      order_item_id: data.get("order_item_id"),
      product_id: data.get("product_id"),
      quantity: data.get("quantity"),
    });
    const result = await resolveOrderItemMapping(
      orderId, input.orderItemId, input.productId, input.quantity, guard.user.user_id,
    );
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess(result.data ?? {}, result.message);
  } catch (error) {
    console.error("Unable to update the product mapping", error);
    return apiError("Unable to update the product mapping.", 500);
  }
}
