import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { updateOrderCustomerInfo } from "@/modules/sales/order-detail";

export const runtime = "nodejs";

/** updateOrderCustomerInfo: Save Details on the Order Detail screen. */
export async function PUT(request: NextRequest, context: RouteContext<"/api/sales/orders/[id]/customer-info">) {
  // The current handler carries no permission check of its own.
  const guard = await requireApiPageAccess(request, "order-detail");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const value = (name: string) => String(data.get(name) ?? "");
    const result = await updateOrderCustomerInfo(id, {
      deliveryAddress: value("delivery_address"),
      customerGstin: value("customer_gstin"),
      customerPan: value("customer_pan"),
      customerState: value("customer_state"),
      customerStateCode: value("customer_state_code"),
      customerContactPerson: value("customer_contact_person"),
      customerContactPhone: value("customer_contact_phone"),
      customerEmail: value("customer_email"),
    }, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to save order customer details", error);
    return apiError("An error occurred while saving details.", 500);
  }
}
