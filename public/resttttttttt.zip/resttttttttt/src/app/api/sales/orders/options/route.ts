import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listOrderFormOptions } from "@/modules/sales/orders";

export const runtime = "nodejs";

/** The categories, products and units the Add Order dialog is built from. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await listOrderFormOptions());
  } catch (error) {
    console.error("Unable to load the order form options", error);
    return apiError("Error loading data.", 500);
  }
}
