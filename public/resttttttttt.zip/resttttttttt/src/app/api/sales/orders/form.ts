import type { OrderEditInput, OrderFormInput } from "@/modules/sales/orders";

/** A posted scalar, or null when the field was not sent at all. */
function optional(data: FormData, name: string): string | null {
  const value = data.get(name);
  return value === null ? null : String(value);
}

function required(data: FormData, name: string): string {
  return String(data.get(name) ?? "");
}

function list(data: FormData, name: string): string[] {
  return data.getAll(`${name}[]`).map((value) => String(value));
}

/** Lines up the parallel arrays the product rows post. */
function zip(...columns: string[][]): string[][] {
  const length = Math.max(0, ...columns.map((column) => column.length));
  const rows: string[][] = [];
  for (let index = 0; index < length; index += 1) {
    rows.push(columns.map((column) => column[index] ?? ""));
  }
  return rows;
}

/** Reads the Add Order form. The field names are the ones the current form posts. */
export function readOrderForm(data: FormData): OrderFormInput {
  const items = zip(
    list(data, "productName"),
    list(data, "productCategory"),
    list(data, "productQuantity"),
    list(data, "productUnit"),
  ).map(([productId, categoryId, quantity, unit]) => ({ productId, categoryId, quantity, unit }));

  const destinations = zip(
    list(data, "dest_location_name"),
    list(data, "dest_address"),
    list(data, "dest_contact"),
    list(data, "dest_notes"),
  ).map(([location, address, contact, notes]) => ({ location, address, contact, notes }));

  return {
    dateOfOrderReceived: required(data, "dateOfOrderReceived"),
    customerId: required(data, "customerId"),
    areaCity: required(data, "areaCity"),
    orderType: required(data, "orderType"),
    locationMap: required(data, "locationMap"),
    orderTypeDetails: required(data, "orderTypeDetails"),
    orderValue: required(data, "orderValue"),
    dispatchTimeline: required(data, "dispatchTimeline"),
    paymentStatus: optional(data, "paymentStatus"),
    paymentStatusDetails: optional(data, "paymentStatusDetails"),
    paymentOverrideReason: required(data, "paymentOverrideReason"),
    proformaInvoice: required(data, "proformaInvoice"),
    items,
    destinations,
  };
}

/** Reads the Edit Order / Review & Confirm form. */
export function readOrderEditForm(data: FormData, id: number): OrderEditInput {
  const items = zip(
    list(data, "productIdEdit"),
    list(data, "inventoryProductIdEdit"),
    list(data, "productQuantityEdit"),
    list(data, "productUnitEdit"),
    list(data, "productRemarkEdit"),
  ).map(([rowId, productId, quantity, unit, remark]) => ({ id: rowId, productId, quantity, unit, remark }));

  return {
    id,
    dateOfOrderReceived: required(data, "dateOfOrderReceivedEdit"),
    customerId: required(data, "customerIdEdit"),
    areaCity: required(data, "areaCityEdit"),
    orderType: required(data, "orderTypeEdit"),
    orderTypeDetails: required(data, "orderTypeDetailsEdit"),
    orderValue: required(data, "orderValueEdit"),
    dispatchTimeline: required(data, "dispatchTimelineEdit"),
    paymentStatus: required(data, "paymentStatusEdit"),
    paymentStatusDetails: required(data, "paymentStatusDetailsEdit"),
    paymentOverrideReason: required(data, "paymentOverrideReasonEdit"),
    proformaInvoice: required(data, "proformaInvoiceEdit"),
    confirmReview: Number.parseInt(String(data.get("confirmReview") ?? "0"), 10) === 1,
    items,
  };
}

/** The status and date filters the list toolbar sends alongside paging. */
export function readOrderFilters(params: URLSearchParams): {
  statuses: number[]; fromDate: string; toDate: string;
} {
  const statuses = (params.get("statusType") ?? "")
    .split(",")
    .map((value) => Number.parseInt(value.trim(), 10))
    .filter((value) => Number.isInteger(value));
  return {
    statuses,
    fromDate: (params.get("fromDate") ?? "").trim(),
    toDate: (params.get("toDate") ?? "").trim(),
  };
}
