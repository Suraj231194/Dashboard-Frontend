import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { changeOrderStatus, updateOrderStatus } from "@/modules/sales/orders";

export const runtime = "nodejs";

/** updateOrderReceivedStatusRecord: the Hold / Cancel dialog on the list. */
export async function POST(request: NextRequest, context: RouteContext<"/api/sales/orders/[id]/status">) {
  // The current handler carries no permission check of its own.
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const status = Number.parseInt(String(data.get("orderStatus") ?? ""), 10);
    const result = await updateOrderStatus(id, Number.isInteger(status) ? status : 0, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update the order status", error);
    return apiError("Server error occurred.", 500);
  }
}

/** changeOrderStatusReceived: the Hold / Cancel buttons on the detail screen. */
export async function PUT(request: NextRequest, context: RouteContext<"/api/sales/orders/[id]/status">) {
  const guard = await requireApiPermission(request, "store_order_received_edit", "Permission denied.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const status = Number.parseInt(String(data.get("status") ?? ""), 10);
    const result = await changeOrderStatus(id, Number.isInteger(status) ? status : 0, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to change the order status", error);
    return apiError("Unable to update order status.", 500);
  }
}
