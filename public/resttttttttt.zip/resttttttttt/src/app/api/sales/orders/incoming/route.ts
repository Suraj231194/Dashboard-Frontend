import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { countNewOrders, listNewIncomingOrders } from "@/modules/sales/orders";
import { sendOrdersToDispatch } from "@/modules/sales/order-routing";

export const runtime = "nodejs";

/** loadNewOrdersCount and loadNewIncomingOrdersList, over one request. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  try {
    const wantList = request.nextUrl.searchParams.get("list") === "1";
    const count = await countNewOrders();
    if (!wantList) return apiSuccess({ count, data: [] });
    return apiSuccess({ count, data: await listNewIncomingOrders() });
  } catch (error) {
    console.error("Unable to load the incoming orders", error);
    return apiError("Error loading data.", 500);
  }
}

/** sendOrderToDispatch for the orders selected in the New Orders dialog. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const orderIds = String(data.get("order_ids") ?? "")
      .split(",")
      .map((value) => Number.parseInt(value.trim(), 10))
      .filter((value) => Number.isInteger(value));
    const notes = String(data.get("fulfillment_notes") ?? "").trim();
    const result = await sendOrdersToDispatch(orderIds, notes, guard.user.user_id);
    if (result.status !== "success") return apiError(result.message, 400);
    return apiSuccess(result, result.message);
  } catch (error) {
    console.error("Dispatch routing failed", error);
    return apiError(error instanceof Error ? error.message : "Server error occurred.", 400);
  }
}
