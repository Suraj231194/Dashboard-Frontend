import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { readOrderView } from "@/modules/sales/orders";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/sales/orders/[id]/view">) {
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const view = await readOrderView(id);
    if (!view) return apiError("No data found...!!", 404);
    return apiSuccess(view);
  } catch (error) {
    console.error("Unable to read the order", error);
    return apiError("Server error occurred.", 500);
  }
}
