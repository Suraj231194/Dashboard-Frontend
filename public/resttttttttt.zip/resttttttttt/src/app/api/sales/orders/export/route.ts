import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { exportPeriodSubtitle, readExportDateRange, readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { requireApiPageAccess } from "@/lib/http/guard";
import { ALL_ITEMS_PER_PAGE } from "@/lib/pagination";
import { buildOrderExportRows, ORDER_SORT_COLUMNS } from "@/modules/sales/orders";

export const runtime = "nodejs";

/** `exportOrdMgmtManual`: the chosen columns as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const range = readExportDateRange(data);
    if (!range.ok) return apiError(range.message, 422);
    const value = (name: string) => String(data.get(name) ?? "").trim();
    const perPageText = value("perPage");
    const perPage = perPageText === "all" || perPageText === String(ALL_ITEMS_PER_PAGE)
      ? Number.MAX_SAFE_INTEGER
      : (Number.parseInt(perPageText, 10) || 10);
    const sortColumn = value("sort_column");
    const sortDirection = value("sort_order").toUpperCase() === "ASC" ? "ASC" : "DESC";

    const result = await buildOrderExportRows(
      value("search"),
      {
        statuses: data.getAll("statusType[]")
          .map((entry) => Number.parseInt(String(entry), 10))
          .filter((entry) => Number.isInteger(entry)),
        fromDate: range.fromDate,
        toDate: range.toDate,
      },
      ORDER_SORT_COLUMNS.includes(sortColumn) ? sortColumn : "id",
      sortDirection,
      Number.parseInt(value("page"), 10) || 1,
      perPage,
      data.getAll("listOfColumns[]").map((entry) => String(entry)),
    );
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "Order Management", filePrefix: "order_management",
      headers: result.columns, rows: result.rows,
      subtitle: exportPeriodSubtitle(range.fromDate, range.toDate, result.rows.length),
    });
  } catch (error) {
    console.error("Unable to build the order export", error);
    return apiError("Server error occurred.", 500);
  }
}
