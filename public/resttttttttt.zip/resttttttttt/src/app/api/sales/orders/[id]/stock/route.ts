import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { checkOrderStockAvailability } from "@/modules/sales/order-detail";

export const runtime = "nodejs";

/**
 * checkOrderStockAvailability. It writes — the check reserves stock — so it is
 * a POST even though the screen treats it as a read.
 */
export async function POST(request: NextRequest, context: RouteContext<"/api/sales/orders/[id]/stock">) {
  const guard = await requireApiPageAccess(request, "order-detail");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    return apiSuccess(await checkOrderStockAvailability(id, guard.user.user_id));
  } catch (error) {
    console.error("Unable to check stock availability", error);
    return apiError("Unable to check stock availability.", 500);
  }
}
