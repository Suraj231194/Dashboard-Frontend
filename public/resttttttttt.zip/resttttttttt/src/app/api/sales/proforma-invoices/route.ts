import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { searchCustomerProformaInvoices } from "@/modules/sales/order-customers";
import { withConnection } from "@/modules/sales/order-sql";

export const runtime = "nodejs";

/** searchCustomerProformaInvoices: the PI selector on the order form. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const customerId = Number.parseInt(params.get("customer_id") ?? "0", 10) || 0;
    const term = (params.get("term") ?? "").trim();
    const results = await withConnection(
      (connection) => searchCustomerProformaInvoices(connection, customerId, term),
    );
    return apiSuccess({ results });
  } catch (error) {
    console.error("Unable to search proforma invoices", error);
    return apiError("Error loading data.", 500);
  }
}
