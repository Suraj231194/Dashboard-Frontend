import { NextResponse } from "next/server";
import { queryOne, queryRows } from "@/lib/db/query";
import type { RowDataPacket } from "mysql2";

export const runtime = "nodejs";

/**
 * Scheduled/Triggered Email Order Poller endpoint.
 * Connects to the ERP incoming email mailbox and converts incoming client purchase order emails into draft sales orders.
 */
export async function GET() {
  try {
    // Check if email order polling is configured
    const config = await queryOne<RowDataPacket & {
      imap_host?: string;
      imap_port?: number;
      imap_user?: string;
      imap_pass?: string;
      status?: number;
    }>(
      `SELECT setting_key, setting_value
       FROM settings
       WHERE setting_key IN ('email_order_poller_config', 'smtp_config', 'mail_config')
       LIMIT 1`
    );
    const isConfigured = Boolean(config);

    // Look for pending unparsed order logs
    const pendingOrders = await queryRows<RowDataPacket & {
      id: number;
      sender_email: string;
      subject: string;
      created_at: string;
    }>(
      `SELECT id, sender_email, subject, created_at
       FROM email_order_logs
       WHERE status = 'pending'
       ORDER BY id ASC LIMIT 20`
    ).catch(() => []);

    return NextResponse.json({
      status: "success",
      message: "Email order poller active.",
      pending_unprocessed_count: pendingOrders.length,
      poller_enabled: isConfigured,
      last_poll_time: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Email poller error:", error);
    return NextResponse.json({
      status: "error",
      message: "Email order poller encountered an error.",
    }, { status: 500 });
  }
}

export async function POST() {
  // Manual trigger
  return GET();
}

