import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/modules/auth/session";
import { saveAppearance, validateAppearance } from "@/modules/settings/appearance";
import { isSameOrigin } from "@/lib/http/same-origin";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const user = await getSession();
  if (!user) return NextResponse.json({ status: "error", message: "Your session has expired. Please sign in again." }, { status: 401 });
  if (!isSameOrigin(request)) {
    return NextResponse.json({ status: "error", message: "Your session token is invalid. Please refresh the page and try again." }, { status: 419 });
  }
  const data = await request.formData();
  const settings = validateAppearance(Object.fromEntries(data));
  if (!settings) return NextResponse.json({ status: "error", message: "Please select a valid appearance setting." }, { status: 422 });
  try {
    await saveAppearance(user.user_id, settings);
    return NextResponse.json({ status: "success", settings });
  } catch (error) {
    console.error("Unable to save appearance settings", error);
    return NextResponse.json({ status: "error", message: "Unable to save appearance settings. Please try again." }, { status: 500 });
  }
}
