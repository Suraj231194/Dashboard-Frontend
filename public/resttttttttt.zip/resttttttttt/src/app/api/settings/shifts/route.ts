import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createShift, listShifts } from "@/modules/settings/hr-settings";
import { readShiftInput } from "@/modules/settings/shift-input";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, ["name"], "name", "ASC");
    return apiSuccess(await listShifts(query));
  } catch (error) {
    console.error("Unable to list shifts", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createShift(readShiftInput(data, ""), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Shift and working days added successfully.");
  } catch (error) {
    console.error("Unable to add a record", error);
    return apiError("Failed to add shift.", 500);
  }
}
