import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { deleteDesignation, findDesignation, updateDesignation } from "@/modules/settings/hr-settings";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/settings/designations/[id]">) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const record = await findDesignation(id);
    if (!record) return apiError("No data found...!!", 404);
    return apiSuccess({ record });
  } catch (error) {
    console.error("Unable to read the record", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/settings/designations/[id]">) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateDesignation({
      id,
      name: String(data.get("designationNameEdit") ?? ""),
      shortName: String(data.get("designationShortNameEdit") ?? ""),
      description: String(data.get("designationDescriptionEdit") ?? ""),
      status: Number.parseInt(String(data.get("designationStatusEdit") ?? "0"), 10) || 0,
      updatedBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Designation updated successfully.");
  } catch (error) {
    console.error("Unable to update the record", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext<"/api/settings/designations/[id]">) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteDesignation(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Designation deleted successfully.");
  } catch (error) {
    console.error("Unable to delete the record", error);
    return apiError("Server error occurred.", 500);
  }
}
