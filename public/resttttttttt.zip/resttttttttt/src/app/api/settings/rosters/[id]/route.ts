import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { deleteRoster } from "@/modules/settings/hr-settings";

export const runtime = "nodejs";

/** `deleteRoaster`. */
export async function DELETE(request: NextRequest, context: RouteContext<"/api/settings/rosters/[id]">) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  try {
    const result = await deleteRoster(readId((await context.params).id), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete a shift roster", error);
    return apiError("Server error occurred.", 500);
  }
}
