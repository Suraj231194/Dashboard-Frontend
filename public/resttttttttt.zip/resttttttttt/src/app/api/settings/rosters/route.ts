import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { assignRoster, listRosters } from "@/modules/settings/hr-settings";

export const runtime = "nodejs";

/** `loadShiftRoaster`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, ["id"], "id", "DESC");
    return apiSuccess(await listRosters(query));
  } catch (error) {
    console.error("Unable to list shift rosters", error);
    return apiError("Error loading data.", 500);
  }
}

/**
 * `addEmployeeShiftRoster`. The current handler checks nothing beyond the
 * session; this one asks for the Settings screen, as its siblings do.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const employeeIds = data.getAll("employee_id[]")
      .map((value) => Number.parseInt(String(value), 10))
      .filter((value) => Number.isInteger(value) && value > 0);
    const result = await assignRoster({
      employeeIds,
      shiftId: Number.parseInt(String(data.get("shift_id") ?? ""), 10) || 0,
      rosterType: Number.parseInt(String(data.get("roster_type") ?? "1"), 10) || 1,
      startDate: String(data.get("start_date") ?? "").trim(),
      endDate: String(data.get("end_date") ?? "").trim(),
      shiftDate: String(data.get("shift_date") ?? "").trim(),
    }, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message ?? "Roster assigned.");
  } catch (error) {
    console.error("Unable to assign a shift roster", error);
    return apiError("Server error occurred.", 500);
  }
}
