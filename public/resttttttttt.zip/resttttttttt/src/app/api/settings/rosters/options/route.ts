import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { rosterOptions } from "@/modules/settings/hr-settings";

export const runtime = "nodejs";

/** The employees and shifts the roster dialog offers. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await rosterOptions());
  } catch (error) {
    console.error("Unable to load roster options", error);
    return apiError("Error loading data.", 500);
  }
}
