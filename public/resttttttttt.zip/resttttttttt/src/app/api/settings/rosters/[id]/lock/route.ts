import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { setRosterLock } from "@/modules/settings/hr-settings";

export const runtime = "nodejs";

/** `lockRoaster` / `unlockRoaster`: `action=lock|unlock`. */
export async function POST(request: NextRequest, context: RouteContext<"/api/settings/rosters/[id]/lock">) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const action = String(data.get("action") ?? "") === "unlock" ? "unlock" : "lock";
    const result = await setRosterLock(readId((await context.params).id), action, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to change a shift roster lock", error);
    return apiError("Server error occurred.", 500);
  }
}
