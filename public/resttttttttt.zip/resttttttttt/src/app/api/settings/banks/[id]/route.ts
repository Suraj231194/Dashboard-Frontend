import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { deleteBank } from "@/modules/settings/hr-settings";

export const runtime = "nodejs";

export async function DELETE(request: NextRequest, context: RouteContext<"/api/settings/banks/[id]">) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteBank(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Bank deleted successfully.");
  } catch (error) {
    console.error("Unable to delete the record", error);
    return apiError("Server error occurred.", 500);
  }
}
