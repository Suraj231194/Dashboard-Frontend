import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { deleteHoliday, findHoliday, updateHoliday } from "@/modules/settings/hr-settings";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/settings/holidays/[id]">) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const record = await findHoliday(id);
    if (!record) return apiError("No data found...!!", 404);
    return apiSuccess({ record });
  } catch (error) {
    console.error("Unable to read the record", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/settings/holidays/[id]">) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateHoliday({
      id,
      date: String(data.get("holidayDateEdit") ?? ""),
      name: String(data.get("holidayNameEdit") ?? ""),
      type: Number.parseInt(String(data.get("holidayType") ?? "0"), 10) || 0,
      status: Number.parseInt(String(data.get("holidayStatusEdit") ?? "0"), 10) || 0,
      updatedBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Holiday updated successfully.");
  } catch (error) {
    console.error("Unable to update the record", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext<"/api/settings/holidays/[id]">) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteHoliday(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Holiday deleted successfully.");
  } catch (error) {
    console.error("Unable to delete the record", error);
    return apiError("Server error occurred.", 500);
  }
}
