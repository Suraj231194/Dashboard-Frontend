import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createHoliday, listHolidays } from "@/modules/settings/hr-settings";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, ["name"], "name", "ASC");
    return apiSuccess(await listHolidays(query));
  } catch (error) {
    console.error("Unable to list holidays", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "settings");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createHoliday({
      date: String(data.get("holidayDate") ?? ""),
      name: String(data.get("holidayName") ?? ""),
      type: Number.parseInt(String(data.get("holidayType") ?? "0"), 10) || 0,
      status: Number.parseInt(String(data.get("holidayStatus") ?? "1"), 10) || 0,
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Holiday added successfully.");
  } catch (error) {
    console.error("Unable to add a record", error);
    return apiError("Failed to add holiday.", 500);
  }
}
