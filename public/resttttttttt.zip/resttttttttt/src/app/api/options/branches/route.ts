import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiSession } from "@/lib/http/guard";
import { listBranchOptions } from "@/modules/users/users";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  const companyId = Number.parseInt(request.nextUrl.searchParams.get("company_id") ?? "0", 10) || 0;
  try {
    return apiSuccess({ options: await listBranchOptions(companyId) });
  } catch (error) {
    console.error("Unable to list branches", error);
    return apiError("Error loading data.", 500);
  }
}
