import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiSession } from "@/lib/http/guard";
import { listCompanyOptions } from "@/modules/users/users";

export const runtime = "nodejs";

export async function GET() {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ options: await listCompanyOptions() });
  } catch (error) {
    console.error("Unable to list companies", error);
    return apiError("Error loading data.", 500);
  }
}
