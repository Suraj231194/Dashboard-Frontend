import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiSession } from "@/lib/http/guard";
import { listActiveRoleOptions } from "@/modules/access/roles";

export const runtime = "nodejs";

export async function GET() {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ options: await listActiveRoleOptions() });
  } catch (error) {
    console.error("Unable to list roles", error);
    return apiError("Error loading data.", 500);
  }
}
