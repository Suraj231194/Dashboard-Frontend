import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { DISPATCH_MGMT_EXTERNAL } from "@/modules/warehouse/warehouse-constants";
import {
  createStockOutward, listStockOutwards, OUTWARD_SORT_KEYS, type OutwardItemInput,
} from "@/modules/warehouse/stock-outwards";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stock-outwards");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    // The handler maps its own keys onto SQL expressions and falls back to stkout.id.
    const query = readListQuery(params, OUTWARD_SORT_KEYS, "stkout.id", "DESC");
    const dispatchType = Number.parseInt(params.get("dispatch_type") ?? String(DISPATCH_MGMT_EXTERNAL), 10);
    return apiSuccess(await listStockOutwards(query, {
      fromDate: (params.get("fromDate") ?? "").trim(),
      toDate: (params.get("toDate") ?? "").trim(),
      dispatchType: Number.isInteger(dispatchType) ? dispatchType : 0,
    }));
  } catch (error) {
    console.error("Unable to list goods dispatches", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "store_stock_outwards_add", "You do not have permission to add a goods dispatch.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const list = (key: string) => data.getAll(key).map((value) => String(value));
    const categories = list("materialTypeList[]");
    const products = list("productsList[]");
    const quantities = list("prodQuantity[]");
    const units = list("prodQuantityUnit[]");
    const lotNumbers = list("lotNumber[]");
    const remarks = list("itemRemark[]");

    const items: OutwardItemInput[] = products.map((value, index) => ({
      categoryId: Number.parseInt(categories[index] ?? "0", 10) || 0,
      productId: Number.parseInt(value, 10) || 0,
      quantity: Number.parseFloat(quantities[index] ?? "0") || 0,
      quantityUnit: Number.parseInt(units[index] ?? "0", 10) || 0,
      lotNumber: lotNumbers[index] ?? "",
      remark: (remarks[index] ?? "").trim(),
    }));

    const department = Number.parseInt(String(data.get("manufacturingUnitDepartment") ?? ""), 10);
    const result = await createStockOutward({
      outwardType: Number.parseInt(String(data.get("outwardType") ?? "0"), 10) || 0,
      departmentUsed: data.has("manufacturingUnitDepartment")
        ? (Number.isInteger(department) ? department : 0)
        : null,
      clientName: String(data.get("clientName") ?? "").trim(),
      placeOfDispatch: String(data.get("placeOfDispatch") ?? "").trim(),
      clientReceiverType: Number.parseInt(String(data.get("clientReceiverType") ?? "0"), 10) || 0,
      clientReceiverTypeDetails: String(data.get("clientReceiverTypeDetails") ?? "").trim(),
      typeOfDispatch: Number.parseInt(String(data.get("typeOfDispatch") ?? "0"), 10) || 0,
      typeOfDispatchDetails: String(data.get("typeOfDispatchDetails") ?? "").trim(),
      deliveryMode: Number.parseInt(String(data.get("deliveryMode") ?? "0"), 10) || 0,
      courierTransportService: String(data.get("courierTransportService") ?? "").trim(),
      trackingId: String(data.get("trackingId") ?? "").trim(),
      dispatchedBy: Number.parseInt(String(data.get("dispatchedBy") ?? "0"), 10) || 0,
      dispatchedTo: String(data.get("dispatchedTo") ?? "").trim(),
      remark: String(data.get("remark") ?? "").trim(),
      items,
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess(result.data ?? {}, result.message);
  } catch (error) {
    console.error("Unable to record a goods dispatch", error);
    return apiError("Server error occurred.", 500);
  }
}
