import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listReceiverOptions, listUnitOptions } from "@/modules/warehouse/stock-inwards";
import {
  listDepartmentOptions, listOutwardCategoryOptions, listOutwardProductOptions, lookupClientType,
} from "@/modules/warehouse/stock-outwards";

export const runtime = "nodejs";

/** The option lists the goods dispatch dialogs load. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stock-outwards");
  if (!guard.ok) return guard.response;
  const params = request.nextUrl.searchParams;
  try {
    switch (params.get("list") ?? "") {
      case "categories":
        return apiSuccess({ options: await listOutwardCategoryOptions() });
      case "products":
        return apiSuccess({
          options: await listOutwardProductOptions(Number.parseInt(params.get("materialTypeId") ?? "0", 10) || 0),
        });
      case "departments":
        return apiSuccess({ options: await listDepartmentOptions() });
      case "dispatchers":
        return apiSuccess({ options: await listReceiverOptions(guard.user.name ?? "") });
      case "units":
        return apiSuccess({ options: await listUnitOptions() });
      case "client-type":
        return apiSuccess({ user_type: await lookupClientType((params.get("client_name") ?? "").trim()) });
      default:
        return apiError("Unknown option list.", 422);
    }
  } catch (error) {
    console.error("Unable to load goods dispatch options", error);
    return apiError("Error loading data.", 500);
  }
}
