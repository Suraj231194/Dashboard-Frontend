import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import {
  countDispatchRequests, createStockOutwardFromOrders, getDispatchPrefill, listDispatchRequests,
} from "@/modules/warehouse/stock-outwards";

export const runtime = "nodejs";

/**
 * `loadInboundDispatchesCount` / `loadInboundDispatchesList` /
 * `fetchOrderReceivedAtStockOutwardRecord`, depending on what is asked for.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stock-outwards");
  if (!guard.ok) return guard.response;
  const params = request.nextUrl.searchParams;
  try {
    const ids = parseIds(params.get("ids") ?? "");
    if (ids.length > 0) {
      const result = await getDispatchPrefill(ids);
      if (!result.ok) return apiError(result.message, result.status ?? 400);
      return apiSuccess({ prefill: result.prefill });
    }
    if (params.get("count") === "1") {
      return apiSuccess({ count: await countDispatchRequests() });
    }
    return apiSuccess({ rows: await listDispatchRequests() });
  } catch (error) {
    console.error("Unable to load inbound dispatch requests", error);
    return apiError("Error loading data.", 500);
  }
}

/** `addStockOutwardFromOrders`. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "store_stock_outwards_add", "You do not have permission to process a dispatch request.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const orderIds = parseIds(String(data.get("orderIds") ?? ""));
    if (orderIds.length === 0) {
      const single = Number.parseInt(String(data.get("orderId") ?? "0"), 10);
      if (Number.isInteger(single) && single > 0) orderIds.push(single);
    }

    const itemIds = data.getAll("orderSubItemId[]").map((value) => String(value));
    const quantityValues = data.getAll("prodQuantity[]").map((value) => String(value));
    const quantities: Record<number, number> = {};
    itemIds.forEach((value, index) => {
      const itemId = Number.parseInt(value, 10) || 0;
      if (itemId > 0) quantities[itemId] = Number.parseFloat(quantityValues[index] ?? "0") || 0;
    });

    const destinationIndexes: Record<number, string> = {};
    for (const [key, value] of data.entries()) {
      const match = /^dispatchDestinationIndex\[(\d+)\]$/.exec(key);
      if (match) destinationIndexes[Number(match[1])] = String(value);
    }

    const result = await createStockOutwardFromOrders({
      orderIds,
      quantities,
      destinationIndexes,
      outwardType: Number.parseInt(String(data.get("outwardType") ?? "2"), 10) || 2,
      clientReceiverType: Number.parseInt(String(data.get("clientReceiverType") ?? "0"), 10) || 0,
      clientReceiverTypeDetails: String(data.get("clientReceiverTypeDetails") ?? "").trim(),
      typeOfDispatch: Number.parseInt(String(data.get("typeOfDispatch") ?? "0"), 10) || 0,
      typeOfDispatchDetails: String(data.get("typeOfDispatchDetails") ?? "").trim(),
      deliveryMode: Number.parseInt(String(data.get("deliveryMode") ?? "0"), 10) || 0,
      courierTransportService: String(data.get("courierTransportService") ?? "").trim(),
      courierOther: String(data.get("courier_other") ?? ""),
      trackingId: String(data.get("trackingId") ?? "").trim(),
      dispatchedBy: Number.parseInt(String(data.get("dispatchedBy") ?? "0"), 10) || 0,
      dispatchedTo: String(data.get("dispatchedTo") ?? "").trim(),
      remark: String(data.get("remark") ?? "").trim(),
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to process a dispatch request", error);
    return apiError("Server error occurred.", 500);
  }
}

function parseIds(raw: string): number[] {
  return raw.split(",")
    .map((part) => Number.parseInt(part.trim(), 10))
    .filter((id) => Number.isInteger(id) && id > 0);
}
