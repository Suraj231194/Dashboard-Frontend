import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { exportPeriodSubtitle, readExportDateRange, readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { buildOutwardExport, OUTWARD_SORT_KEYS } from "@/modules/warehouse/stock-outwards";

export const runtime = "nodejs";

/** `exportGoodsDispatched`: the chosen columns as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stock-outwards");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const range = readExportDateRange(data);
    if (!range.ok) return apiError(range.message, 422);
    const requested = String(data.get("sort_column") ?? "");
    const direction = String(data.get("sort_order") ?? "DESC").toUpperCase() === "ASC" ? "ASC" : "DESC";
    const dispatchType = Number.parseInt(String(data.get("dispatch_type") ?? "0"), 10);
    const result = await buildOutwardExport({
      search: String(data.get("search") ?? "").trim(),
      fromDate: range.fromDate,
      toDate: range.toDate,
      dispatchType: Number.isInteger(dispatchType) ? dispatchType : 0,
      sortColumn: OUTWARD_SORT_KEYS.includes(requested) ? requested : "stkout.id",
      sortDirection: direction,
      page: Number.parseInt(String(data.get("page") ?? "1"), 10) || 1,
      perPage: Number.parseInt(String(data.get("perPage") ?? "10"), 10) || 10,
      columns: data.getAll("listOfColumns[]").map((value) => String(value)),
    });
    if (!result.ok) return apiError(result.message, 404);
    return await tableExportResponse({
      format, title: "Goods Dispatched", filePrefix: "goods_dispatched",
      headers: result.columns, rows: result.rows,
      subtitle: exportPeriodSubtitle(range.fromDate, range.toDate, result.rows.length),
    });
  } catch (error) {
    console.error("Unable to export goods dispatches", error);
    return apiError("Server error occurred.", 500);
  }
}

