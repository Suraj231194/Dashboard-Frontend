import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { deleteStockOutward, getStockOutward, updateStockOutward } from "@/modules/warehouse/stock-outwards";

export const runtime = "nodejs";

type Context = { params: Promise<{ id: string }> };

/** The issuance screen reuses the goods dispatch record actions. */
export async function GET(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, "store_stock_outwards_view", "You do not have permission to view an issuance.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const record = await getStockOutward(id);
    if (!record) return apiError("No data found...!!", 404);
    return apiSuccess({ record });
  } catch (error) {
    console.error("Unable to read an issuance", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, "store_stock_outwards_edit", "You do not have permission to edit an issuance.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateStockOutward({
      id,
      courierTransportService: Number.parseInt(String(data.get("courierTransportServiceEdit") ?? "0"), 10) || 0,
      trackingId: String(data.get("trackingIdEdit") ?? "").trim(),
      remark: String(data.get("remarkEdit") ?? "").trim(),
      updatedBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update an issuance", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, "store_stock_outwards_delete", "You do not have permission to delete an issuance.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteStockOutward(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete an issuance", error);
    return apiError("Server error occurred.", 500);
  }
}
