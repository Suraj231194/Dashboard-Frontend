import { NextRequest } from "next/server";
import { requireApiPageAccess } from "@/lib/http/guard";
import { apiError } from "@/lib/http/json";
import { exportPeriodSubtitle, readExportDateRange, readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { buildOutwardExport, OUTWARD_SORT_KEYS } from "@/modules/warehouse/stock-outwards";
import { DISPATCH_MGMT_INTERNAL } from "@/modules/warehouse/warehouse-constants";

export const runtime = "nodejs";

/** The internal-issuance half of `exportGoodsDispatched`, with its date range. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "goods-issuance");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const range = readExportDateRange(data);
    if (!range.ok) return apiError(range.message, 422);
    const requested = String(data.get("sort_column") ?? "");
    const direction = String(data.get("sort_order") ?? "DESC").toUpperCase() === "ASC" ? "ASC" : "DESC";
    const result = await buildOutwardExport({
      search: String(data.get("search") ?? "").trim(),
      fromDate: range.fromDate,
      toDate: range.toDate,
      dispatchType: DISPATCH_MGMT_INTERNAL,
      sortColumn: OUTWARD_SORT_KEYS.includes(requested) ? requested : "stkout.id",
      sortDirection: direction,
      page: Number.parseInt(String(data.get("page") ?? "1"), 10) || 1,
      perPage: Number.parseInt(String(data.get("perPage") ?? "10"), 10) || 10,
      columns: data.getAll("listOfColumns[]").map(String),
    });
    if (!result.ok) return apiError(result.message, 404);
    return await tableExportResponse({
      format, title: "Goods Issuance", filePrefix: "goods_issuance",
      headers: result.columns, rows: result.rows,
      subtitle: exportPeriodSubtitle(range.fromDate, range.toDate, result.rows.length),
    });
  } catch (error) {
    console.error("Unable to export goods issuances", error);
    return apiError("Server error occurred.", 500);
  }
}
