import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { issueRequisitionItems, type IssueItemInput } from "@/modules/warehouse/goods-issuance";

export const runtime = "nodejs";

/** `issueBomItems`: issues one material requisition's lines from live stock. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "store_stock_outwards_add", "You do not have permission to issue goods to production.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const items = parseItems(String(data.get("items") ?? "[]"));
    const result = await issueRequisitionItems({
      reqId: Number.parseInt(String(data.get("req_id") ?? "0"), 10) || 0,
      items,
      userId: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess(result.data ?? {}, result.message);
  } catch (error) {
    console.error("Unable to issue BOM items", error);
    return apiError("Server error while issuing BOM.", 500);
  }
}

function parseItems(raw: string): IssueItemInput[] {
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((entry): entry is Record<string, unknown> => typeof entry === "object" && entry !== null)
      .map((entry) => ({
        mrItemId: Number(entry.mr_item_id ?? 0),
        issuedQty: Number(entry.issued_qty ?? 0),
      }));
  } catch {
    return [];
  }
}
