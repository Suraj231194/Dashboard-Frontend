import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import {
  createManualIssuance, getScaledBom, listFinishedProductsWithBom, type ManualIssueItemInput,
} from "@/modules/warehouse/goods-issuance";

export const runtime = "nodejs";

/** `loadFinishedProductsWithBom`, or `getScaledBomForManualIssuance` with a product. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "goods-issuance");
  if (!guard.ok) return guard.response;
  const params = request.nextUrl.searchParams;
  try {
    const productId = Number.parseInt(params.get("finished_product_id") ?? "0", 10) || 0;
    if (productId > 0) {
      const result = await getScaledBom(productId, Number.parseFloat(params.get("batch_size") ?? "0") || 0);
      if (!result.ok) return apiError(result.message, 400);
      return apiSuccess({ bom: result.bom });
    }
    return apiSuccess({ products: await listFinishedProductsWithBom() });
  } catch (error) {
    console.error("Unable to load the finished-product BOM", error);
    return apiError("Unable to load BOM.", 500);
  }
}

/** `createManualBomIssuance`. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "store_stock_outwards_add", "You do not have permission to issue goods to production.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createManualIssuance({
      finishedProductId: Number.parseInt(String(data.get("finished_product_id") ?? "0"), 10) || 0,
      batchSize: Number.parseFloat(String(data.get("batch_size") ?? "0")) || 0,
      items: parseItems(String(data.get("items") ?? "[]")),
      userId: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess(result.data ?? {}, result.message);
  } catch (error) {
    console.error("Unable to issue BOM materials", error);
    return apiError("Unable to issue BOM materials.", 500);
  }
}

function parseItems(raw: string): ManualIssueItemInput[] {
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((entry): entry is Record<string, unknown> => typeof entry === "object" && entry !== null)
      .map((entry) => ({
        productId: Number(entry.product_id ?? 0),
        issuedQty: Number(entry.issued_qty ?? 0),
      }));
  } catch {
    return [];
  }
}
