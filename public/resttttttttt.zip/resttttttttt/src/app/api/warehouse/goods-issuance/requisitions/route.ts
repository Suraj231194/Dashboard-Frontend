import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listRequisitionItems, listUpcomingIssuances } from "@/modules/warehouse/goods-issuance";

export const runtime = "nodejs";

/** `loadUpcomingIssuances`, or `getMaterialRequisitionItemsForIssuance` with `req_id`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "goods-issuance");
  if (!guard.ok) return guard.response;
  const params = request.nextUrl.searchParams;
  try {
    const reqId = Number.parseInt(params.get("req_id") ?? "0", 10) || 0;
    if (reqId > 0) {
      const result = await listRequisitionItems(reqId);
      if (!result.ok) return apiError(result.message, result.status ?? 400);
      return apiSuccess({ items: result.items });
    }
    return apiSuccess(await listUpcomingIssuances(Number.parseInt(params.get("page") ?? "1", 10) || 1));
  } catch (error) {
    console.error("Unable to load upcoming issuances", error);
    return apiError("Error loading data.", 500);
  }
}
