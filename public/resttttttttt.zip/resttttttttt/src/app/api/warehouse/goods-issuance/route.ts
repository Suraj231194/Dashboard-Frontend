import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { DISPATCH_MGMT_INTERNAL } from "@/modules/warehouse/warehouse-constants";
import { listStockOutwards, OUTWARD_SORT_KEYS } from "@/modules/warehouse/stock-outwards";

export const runtime = "nodejs";

/**
 * `loadStocksOutword` with `dispatch_type` fixed to internal manufacturing, which
 * is what the goods issuance screen lists.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "goods-issuance");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, OUTWARD_SORT_KEYS, "created_at", "DESC");
    return apiSuccess(await listStockOutwards(query, {
      fromDate: (params.get("fromDate") ?? "").trim(),
      toDate: (params.get("toDate") ?? "").trim(),
      dispatchType: DISPATCH_MGMT_INTERNAL,
    }));
  } catch (error) {
    console.error("Unable to list goods issuances", error);
    return apiError("Error loading data.", 500);
  }
}
