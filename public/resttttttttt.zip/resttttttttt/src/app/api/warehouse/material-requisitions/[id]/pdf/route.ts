import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { simpleTablePdf } from "@/lib/pdf/simple-table";
import { queryOne, queryRows } from "@/lib/db/query";
import type { RowDataPacket } from "mysql2";

export const runtime = "nodejs";

/**
 * Material Requisition Slip PDF generator (`pages/material_requisition_template.php`).
 */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, "material_requisition_view", "You do not have permission to view material requisitions."
  );
  if (!guard.ok) return guard.response;

  const { id } = await context.params;
  const reqId = readId(id);
  if (reqId === 0) return apiError("A valid requisition identifier is required.", 400);

  try {
    const requisition = await queryOne<RowDataPacket & {
      id: number;
      requisition_no: string;
      req_date: string;
      department_name: string;
      finished_product_name: string;
      batch_size: string;
      lot_no: string;
      status: string;
      remarks: string;
    }>(
      `SELECT mr.*, 
              COALESCE(p.product_name, '-') AS finished_product_name,
              COALESCE(d.department_name, 'Production') AS department_name
       FROM material_requisitions mr
       LEFT JOIN products p ON p.id = mr.finished_product_id
       LEFT JOIN departments d ON d.id = mr.department_id
       WHERE mr.id = ?
       LIMIT 1`,
      [reqId]
    );

    if (!requisition) {
      return apiError("Material requisition was not found.", 404);
    }

    const items = await queryRows<RowDataPacket & {
      item_name: string;
      required_qty: number | string;
      issued_qty: number | string;
      unit: string;
      status: string;
    }>(
      `SELECT mri.*, 
              COALESCE(p.product_name, mri.raw_material_name) AS item_name,
              COALESCE(su.short_name, 'units') AS unit
       FROM material_requisition_items mri
       LEFT JOIN products p ON p.id = mri.raw_material_id
       LEFT JOIN standard_units su ON su.id = mri.unit_id
       WHERE mri.requisition_id = ?
       ORDER BY mri.id ASC`,
      [reqId]
    ).catch(() => []);

    const rows: string[][] = [
      ["Requisition No.", requisition.requisition_no || String(requisition.id)],
      ["Requisition Date", requisition.req_date || "-"],
      ["Department", requisition.department_name],
      ["Finished Product", requisition.finished_product_name],
      ["Batch Size / Lot", `${requisition.batch_size || ""} (Lot: ${requisition.lot_no || "-"})`],
      ["Status", requisition.status || "Approved"],
      ["Remarks", requisition.remarks || "-"],
    ];

    if (items.length > 0) {
      rows.push(["--- Requisition Line Items ---", ""]);
      for (const item of items) {
        rows.push([
          item.item_name,
          `Required: ${item.required_qty} ${item.unit} | Issued: ${item.issued_qty || 0} ${item.unit} (${item.status || "Pending"})`,
        ]);
      }
    }

    const bytes = simpleTablePdf({
      title: "STORE MATERIAL REQUISITION SLIP",
      subtitle: `${requisition.finished_product_name} · Req #${requisition.requisition_no || requisition.id}`,
      headers: ["Field / Material", "Requirement & Issuance"],
      rows,
    });

    const filename = `Material_Requisition_${requisition.requisition_no || requisition.id}`.replace(/[^A-Za-z0-9_-]+/g, "_");

    return new Response(Uint8Array.from(bytes).buffer as ArrayBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="${filename}.pdf"`,
      },
    });
  } catch (error) {
    console.error("Material requisition PDF error:", error);
    return apiError("Failed to generate material requisition PDF.", 500);
  }
}
