import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listInboundPoItems } from "@/modules/warehouse/stock-inwards";

export const runtime = "nodejs";

/** `fetchInboundPoDetails`: the lines of one purchase order. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stock-inwards");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const items = await listInboundPoItems(
      (params.get("po_number") ?? "").trim(),
      (params.get("type") ?? "").trim(),
    );
    return apiSuccess({ items });
  } catch (error) {
    console.error("Unable to load purchase order items", error);
    return apiError("Failed to load items.", 500);
  }
}
