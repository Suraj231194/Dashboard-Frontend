import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { buildInwardExport, INWARD_SORT_COLUMNS, normaliseConditions } from "@/modules/warehouse/stock-inwards";

export const runtime = "nodejs";

/** `exportGoodsReceived`: the chosen columns as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stock-inwards");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const requested = String(data.get("sort_column") ?? "");
    const direction = String(data.get("sort_order") ?? "DESC").toUpperCase() === "ASC" ? "ASC" : "DESC";
    const result = await buildInwardExport({
      search: String(data.get("search") ?? "").trim(),
      conditions: normaliseConditions(parseConditions(String(data.get("conditions") ?? ""))),
      sortColumn: (INWARD_SORT_COLUMNS as readonly string[]).includes(requested) ? requested : "stkin.id",
      sortDirection: direction,
      page: Number.parseInt(String(data.get("page") ?? "1"), 10) || 1,
      perPage: Number.parseInt(String(data.get("perPage") ?? "10"), 10) || 10,
      columns: data.getAll("listOfColumns[]").map((value) => String(value)),
    });
    if (!result.ok) return apiError(result.message, 404);
    return await tableExportResponse({
      format, title: "Goods Received", filePrefix: "goods_received",
      headers: result.columns, rows: result.rows,
    });
  } catch (error) {
    console.error("Unable to export goods receipts", error);
    return apiError("Server error occurred.", 500);
  }
}

/** The current screen posts the condition codes as a JSON array. */
function parseConditions(raw: string): string {
  if (raw.trim() === "") return "";
  try {
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.map((value) => String(value)).join(",") : raw;
  } catch {
    return raw;
  }
}
