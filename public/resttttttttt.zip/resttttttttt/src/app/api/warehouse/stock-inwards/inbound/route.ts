import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { InvoiceUploadError, invoiceFilesFrom, storeInvoiceUploads } from "@/lib/uploads/invoice-uploads";
import {
  listInboundMaterials, submitInboundVerification, type ReceiptItemInput,
} from "@/modules/warehouse/stock-inwards";

export const runtime = "nodejs";

/** `loadInboundMaterials`: the open purchase orders awaiting receipt. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stock-inwards");
  if (!guard.ok) return guard.response;
  try {
    const inbound = await listInboundMaterials();
    return apiSuccess({ inbound, count: inbound.length });
  } catch (error) {
    console.error("Unable to load inbound materials", error);
    return apiError("Error loading inbound materials.", 500);
  }
}

/** `submitInboundVerification`. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "store_stock_inwards_add", "You do not have permission to receive a purchase order.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const list = (key: string) => data.getAll(key).map((value) => String(value));
    const poItemIds = list("poItemId[]");
    const receivedQtys = list("receivedQty[]");
    const conditions = list("physicalCondition[]");
    const lotNumbers = list("lotNumber[]");
    const mfgDates = list("mfgDate[]");
    const expiryDates = list("expiryDate[]");

    const items: ReceiptItemInput[] = poItemIds.map((value, index) => ({
      poItemId: Number.parseInt(value, 10) || 0,
      receivedQty: Number.parseFloat(receivedQtys[index] ?? "0") || 0,
      physicalCondition: Number.parseInt(conditions[index] ?? "1", 10) || 1,
      lotNumber: lotNumbers[index] ?? "",
      mfgDate: mfgDates[index] ?? "",
      expiryDate: expiryDates[index] ?? "",
    }));

    const warehouse = Number.parseInt(String(data.get("verifyWarehouseId") ?? ""), 10);
    const result = await submitInboundVerification({
      poNumber: String(data.get("verifyPoNumber") ?? "").trim(),
      materialType: String(data.get("verifyMaterialType") ?? "").trim(),
      receiptDate: String(data.get("verifyReceiptDate") ?? "").trim(),
      vendorName: String(data.get("verifyVendorName") ?? "").trim(),
      invoiceNumber: String(data.get("verifyInvoiceNumber") ?? "").trim(),
      invoiceDate: String(data.get("verifyInvoiceDate") ?? "").trim(),
      warehouseId: Number.isInteger(warehouse) && warehouse > 0 ? warehouse : null,
      submissionToken: String(data.get("receiptSubmissionToken") ?? "").trim(),
      invoiceFile: await storeInvoiceUploads(invoiceFilesFrom(data, "verifyInvoiceFile")),
      items,
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof InvoiceUploadError) return apiError(error.message, 422);
    console.error("Unable to submit a goods receipt", error);
    return apiError("Server error occurred.", 500);
  }
}
