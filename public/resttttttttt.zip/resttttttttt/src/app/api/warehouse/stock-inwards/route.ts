import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { InvoiceUploadError, invoiceFilesFrom, storeInvoiceUploads } from "@/lib/uploads/invoice-uploads";
import { readListQuery } from "@/lib/pagination";
import {
  createStockInwards, INWARD_SORT_COLUMNS, listStockInwards, normaliseConditions,
  type InwardItemInput,
} from "@/modules/warehouse/stock-inwards";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stock-inwards");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    // Any column outside the allow-list sorts by stkin.id, as the current handler does.
    const query = readListQuery(params, INWARD_SORT_COLUMNS, "stkin.id", "DESC");
    return apiSuccess(await listStockInwards(query, normaliseConditions(params.get("conditions"))));
  } catch (error) {
    console.error("Unable to list stock inwards", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "store_stock_inwards_add", "You do not have permission to add a goods receipt.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const list = (key: string) => data.getAll(key).map((value) => String(value));
    const materialTypes = list("materialTypeList[]");
    const products = list("productsList[]");
    const quantities = list("prodQuantity[]");
    const units = list("prodQuantityUnit[]");
    const conditions = list("phycalCondition[]");
    const mfgDates = list("mfgDate[]");
    const expiryDates = list("expiaryDate[]");
    const lotNumbers = list("lotNumber[]");
    const remarks = list("remark[]");

    const items: InwardItemInput[] = materialTypes.map((_value, index) => ({
      materialTypeId: Number.parseInt(materialTypes[index] ?? "0", 10) || 0,
      productId: Number.parseInt(products[index] ?? "0", 10) || 0,
      quantity: Number.parseFloat(quantities[index] ?? "0") || 0,
      quantityUnit: Number.parseInt(units[index] ?? "0", 10) || 0,
      physicalCondition: Number.parseInt(conditions[index] ?? "0", 10) || 0,
      mfgDate: mfgDates[index] ?? "",
      expiryDate: expiryDates[index] ?? "",
      lotNumber: lotNumbers[index] ?? "",
      remark: remarks[index] ?? "",
    }));

    const result = await createStockInwards({
      dateOfEntry: String(data.get("do_entry") ?? "").trim(),
      supplierId: Number.parseInt(String(data.get("select2SupplierList") ?? "0"), 10) || 0,
      receivedBy: Number.parseInt(String(data.get("receivedBy") ?? "0"), 10) || 0,
      receiptStatus: Number.parseInt(String(data.get("receiptStatus") ?? "0"), 10) || 0,
      invoiceNumber: String(data.get("invoiceNumber") ?? "").trim(),
      invoiceDate: String(data.get("invoiceDate") ?? "").trim(),
      invoiceFile: await storeInvoiceUploads(invoiceFilesFrom(data, "invoiceImages[]")),
      items,
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof InvoiceUploadError) return apiError(error.message, 422);
    console.error("Unable to record a goods receipt", error);
    return apiError("Something went wrong.", 500);
  }
}
