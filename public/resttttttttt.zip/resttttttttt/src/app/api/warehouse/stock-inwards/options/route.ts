import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import {
  listMaterialTypeOptions, listProductOptions, listReceiverOptions, listSupplierOptions,
  listUnitOptions, listWarehouseOptions,
} from "@/modules/warehouse/stock-inwards";

export const runtime = "nodejs";

/** The option lists the goods receipt dialogs load, one request per list. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stock-inwards");
  if (!guard.ok) return guard.response;
  const params = request.nextUrl.searchParams;
  const list = params.get("list") ?? "";
  try {
    switch (list) {
      case "suppliers":
        return apiSuccess({ options: await listSupplierOptions() });
      case "material-types":
        return apiSuccess({
          options: await listMaterialTypeOptions(params.get("onlyWithProducts") === "1"),
        });
      case "receivers":
        return apiSuccess({ options: await listReceiverOptions(guard.user.name ?? "") });
      case "products":
        return apiSuccess({
          options: await listProductOptions(Number.parseInt(params.get("materialTypeId") ?? "0", 10) || 0),
        });
      case "units":
        return apiSuccess({ options: await listUnitOptions() });
      case "warehouses":
        return apiSuccess({ options: await listWarehouseOptions() });
      default:
        return apiError("Unknown option list.", 422);
    }
  } catch (error) {
    console.error("Unable to load goods receipt options", error);
    return apiError("Error loading data.", 500);
  }
}
