import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { deleteStockInward, getStockInward, updateStockInward } from "@/modules/warehouse/stock-inwards";

export const runtime = "nodejs";

type Context = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, "store_stock_inwards_view", "You do not have permission to view a goods receipt.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const record = await getStockInward(id);
    if (!record) return apiError("No data found...!!", 404);
    return apiSuccess({ record });
  } catch (error) {
    console.error("Unable to read a goods receipt", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, "store_stock_inwards_edit", "You do not have permission to edit a goods receipt.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateStockInward({
      id,
      quantity: String(data.get("prod_quantity") ?? "0").trim(),
      physicalCondition: Number.parseInt(String(data.get("physical_condition") ?? "1"), 10) || 1,
      lotNumber: String(data.get("lot_number") ?? "").trim(),
      remark: String(data.get("remark") ?? "").trim(),
      updatedBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update a goods receipt", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, "store_stock_inwards_delete", "You do not have permission to delete a goods receipt.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteStockInward(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete a goods receipt", error);
    return apiError("Server error occurred.", 500);
  }
}
