import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { acknowledgeProductionReceipt } from "@/modules/warehouse/goods-received-production";

export const runtime = "nodejs";

type Context = { params: Promise<{ id: string }> };

/** `acknowledgeGoodsReceivedProduction`, which checks its own permission today. */
export async function PUT(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, "store_goods_received_production_manage",
    "You do not have permission to acknowledge Production receipts.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await acknowledgeProductionReceipt({
      receiptId: id,
      actualQuantity: Number.parseFloat(String(data.get("actual_received_quantity") ?? "0")) || 0,
      remarks: String(data.get("remarks") ?? "").trim(),
      userId: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess(result.data ?? {}, result.message);
  } catch (error) {
    console.error("Unable to acknowledge a Production receipt", error);
    return apiError("Unable to acknowledge receipt.", 500);
  }
}
