import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { listProductionReceipts } from "@/modules/warehouse/goods-received-production";

export const runtime = "nodejs";

/** `loadGoodsReceivedProduction`, which checks its own permission today. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "store_goods_received_production_view",
    "You do not have permission to view Production receipts.",
  );
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    return apiSuccess(await listProductionReceipts({
      page: Number.parseInt(params.get("page") ?? "1", 10) || 1,
      perPage: Number.parseInt(params.get("per_page") ?? "10", 10) || 10,
      search: (params.get("search") ?? "").trim(),
      receiptStatus: (params.get("receipt_status") ?? "ALL").trim(),
    }));
  } catch (error) {
    console.error("Unable to load Production receipts", error);
    return apiError("Unable to load Production receipts.", 500);
  }
}
