import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { simpleTablePdf } from "@/lib/pdf/simple-table";
import { queryOne } from "@/lib/db/query";
import type { RowDataPacket } from "mysql2";

export const runtime = "nodejs";

/**
 * Transfer Ticket PDF generator (`pages/transfer_ticket_template.php`).
 */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, "transfer_ticket_view", "You do not have permission to download transfer tickets."
  );
  if (!guard.ok) return guard.response;

  const { id } = await context.params;
  const ticketId = readId(id);
  if (ticketId === 0) return apiError("A valid transfer ticket identifier is required.", 400);

  try {
    const ticket = await queryOne<RowDataPacket & {
      id: number;
      transfer_ticket_no: string;
      ticket_date: string;
      from_department: string;
      to_department: string;
      product_name: string;
      batch_no: string;
      mfg_date: string;
      exp_date: string;
      pack_size: string;
      quantity_transferred: string;
      sampled_qa: string;
      fg_coa_no: string;
      remarks: string;
    }>(
      `SELECT t.*, 
              COALESCE(p.product_name, t.product_description, '-') AS product_name
       FROM transfer_ticket t
       LEFT JOIN products p ON p.id = t.product_id
       WHERE t.id = ?
       LIMIT 1`,
      [ticketId]
    );

    if (!ticket) {
      return apiError("Transfer ticket was not found.", 404);
    }

    const rows: string[][] = [
      ["Ticket Number", ticket.transfer_ticket_no || String(ticket.id)],
      ["Date", ticket.ticket_date || "-"],
      ["From Department", ticket.from_department || "Production"],
      ["To Department", ticket.to_department || "Warehouse / QA"],
      ["Product Name", ticket.product_name],
      ["Batch / Lot No.", ticket.batch_no || "-"],
      ["Mfg. Date", ticket.mfg_date || "-"],
      ["Expiry Date", ticket.exp_date || "-"],
      ["Pack Size", ticket.pack_size || "-"],
      ["Quantity Transferred", ticket.quantity_transferred || "-"],
      ["Sampled by QA", ticket.sampled_qa || "-"],
      ["FG COA No.", ticket.fg_coa_no || "-"],
      ["Remarks", ticket.remarks || "Material transferred and verified in good condition."],
    ];

    const bytes = simpleTablePdf({
      title: "INTERNAL STOCK TRANSFER TICKET",
      subtitle: `${ticket.product_name} · Batch: ${ticket.batch_no || "-"} · Ticket #${ticket.transfer_ticket_no || ticket.id}`,
      headers: ["Parameter", "Details"],
      rows,
    });

    const filename = `Transfer_Ticket_${ticket.transfer_ticket_no || ticket.id}`.replace(/[^A-Za-z0-9_-]+/g, "_");

    return new Response(Uint8Array.from(bytes).buffer as ArrayBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="${filename}.pdf"`,
      },
    });
  } catch (error) {
    console.error("Transfer ticket PDF error:", error);
    return apiError("Failed to generate transfer ticket PDF.", 500);
  }
}
