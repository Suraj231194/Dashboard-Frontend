import type {
  CreateFinalPurchaseOrderInput,
  CreateRawPurchaseOrderInput,
  UpdateFinalPurchaseOrderInput,
  UpdateRawPurchaseOrderInput,
} from "@/modules/purchasing/purchase-orders";
import type { FinalisePurchaseOrderLine } from "@/modules/purchasing/purchase-management";

/** PHP's intval() over a form value. */
export function toInt(value: FormDataEntryValue | null | undefined): number {
  return Number.parseInt(String(value ?? ""), 10) || 0;
}

/** PHP's floatval() over a form value. */
export function toFloat(value: FormDataEntryValue | null | undefined): number {
  return Number.parseFloat(String(value ?? "")) || 0;
}

export function text(data: FormData, key: string): string {
  return String(data.get(key) ?? "");
}

export function list(data: FormData, key: string): string[] {
  return data.getAll(key).map((value) => String(value ?? ""));
}

/** The longest of several parallel arrays, which is how the row loops are sized. */
export function rowCount(...columns: string[][]): number {
  return columns.reduce((longest, column) => Math.max(longest, column.length), 0);
}

/** `addPurchaseOrderForm` */
export function readFinalPurchaseOrderForm(
  data: FormData, createdBy: number, companyId: number,
): CreateFinalPurchaseOrderInput {
  const materials = list(data, "poMaterial[]");
  const packSizes = list(data, "poPackSize[]");
  const quantities = list(data, "poQuantity[]");
  const prices = list(data, "poPrice[]");
  const lowStockIds = list(data, "poLowStockId[]");
  return {
    poNumber: text(data, "poNumber").trim(),
    vendorName: text(data, "vendorName").trim(),
    currency: toInt(data.get("poCurrency")),
    shipmentBranchId: toInt(data.get("shipmentBranchId")),
    quantityRequiredUnit: toInt(data.get("quantityRequiredUnit")),
    criticalItem: toInt(data.get("criticalItem")),
    expectedDeliveryDate: text(data, "expectedDeliveryDate").trim(),
    items: materials.map((material, index) => ({
      material: String(material ?? ""),
      // A missing pack size or price is stored as a dash, as it is today.
      packSize: (packSizes[index] ?? "-").trim(),
      quantity: (quantities[index] ?? "").trim(),
      price: (prices[index] ?? "-").trim(),
      lowStockId: toInt(lowStockIds[index]),
    })),
    createdBy,
    companyId,
  };
}

/** `updatePurchaseOrderFinalRecord` */
export function readFinalPurchaseOrderEditForm(
  data: FormData, updatedBy: number,
): UpdateFinalPurchaseOrderInput {
  const ids = list(data, "poFinalId[]");
  const materials = list(data, "poMaterial[]");
  const packSizes = list(data, "poPackSize[]");
  const quantities = list(data, "poQuantity[]");
  const prices = list(data, "poPrice[]");
  return {
    poOrderNum: text(data, "poOrderNumEditPM"),
    vendorName: text(data, "vendorNameEdit"),
    currencyType: toInt(data.get("poCurrencyEdit")),
    items: materials.map((material, index) => ({
      id: toInt(ids[index]),
      material: String(material ?? ""),
      packSize: packSizes[index] ?? "-",
      quantity: quantities[index] ?? "",
      price: prices[index] ?? "",
    })),
    updatedBy,
  };
}

/** `addPurchaseOrderRaw` */
export function readRawPurchaseOrderForm(
  data: FormData, createdBy: number, companyId: number,
): CreateRawPurchaseOrderInput {
  const productNames = list(data, "productName[]");
  const catNos = list(data, "catNo[]");
  const sizes = list(data, "size[]");
  const thicknesses = list(data, "thickness[]");
  const quantities = list(data, "quantity[]");
  const lowStockIds = list(data, "poLowStockId[]");
  return {
    vendorName: text(data, "vendorName").trim(),
    extraNote: text(data, "extraNote").trim(),
    shipmentBranchId: toInt(data.get("shipmentBranchId")),
    quantityRequiredUnit: toInt(data.get("quantityRequiredUnit")),
    criticalItem: toInt(data.get("criticalItem")),
    expectedDeliveryDate: text(data, "expectedDeliveryDate").trim(),
    items: productNames.map((productName, index) => ({
      productName: String(productName ?? ""),
      catNo: (catNos[index] ?? "").trim(),
      size: (sizes[index] ?? "").trim(),
      thickness: (thicknesses[index] ?? "").trim(),
      quantity: (quantities[index] ?? "").trim(),
      lowStockId: toInt(lowStockIds[index]),
    })),
    createdBy,
    companyId,
  };
}

/** `updatePurchaseOrderRawRecord` */
export function readRawPurchaseOrderEditForm(
  data: FormData, id: number, updatedBy: number,
): UpdateRawPurchaseOrderInput {
  const ids = list(data, "subProductIdEdit[]");
  const productNames = list(data, "productName[]");
  const catNos = list(data, "catNo[]");
  const sizes = list(data, "size[]");
  const thicknesses = list(data, "thickness[]");
  const quantities = list(data, "quantity[]");
  return {
    id,
    vendorName: text(data, "vendorNameEdit"),
    extraNote: text(data, "extraNoteEdit").trim(),
    // The current loop walks the item ids, so a row without one is only added
    // when a blank id was posted alongside it.
    items: ids.map((itemId, index) => ({
      id: toInt(itemId),
      productName: productNames[index] ?? "",
      catNo: catNos[index] ?? "",
      size: sizes[index] ?? "",
      thickness: thicknesses[index] ?? "",
      quantity: quantities[index] ?? "",
    })),
    updatedBy,
  };
}

/** `insertPurchaseOrderFinalRecord` */
export function readFinaliseForm(data: FormData): FinalisePurchaseOrderLine[] {
  const lowStockIds = list(data, "lowStockId[]");
  const vendorNames = list(data, "vendorName[]");
  const materialNames = list(data, "materialsName[]");
  const packSizes = list(data, "packSize[]");
  const quantities = list(data, "quatityRequired[]");
  const currencyTypes = list(data, "currencyType[]");
  const priceValues = list(data, "priceInValue[]");
  return lowStockIds.map((lowStockId, index) => ({
    lowStockId: toInt(lowStockId),
    vendorName: vendorNames[index] ?? "",
    materialName: materialNames[index] ?? "",
    packSize: packSizes[index] ?? "",
    quantity: quantities[index] ?? "",
    currencyType: toInt(currencyTypes[index]),
    priceValue: priceValues[index] ?? "",
  }));
}
