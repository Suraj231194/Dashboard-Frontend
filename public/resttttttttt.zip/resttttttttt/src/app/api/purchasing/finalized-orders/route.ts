import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readListQuery } from "@/lib/pagination";
import { normalizeIntList } from "@/modules/inventory/stock-list-sql";
import { PURCHASE_MANAGEMENT_PAGE, requirePurchasingAccess } from "@/modules/purchasing/guard";
import {
  FINALIZED_PO_SORT_KEYS,
  listFinalizedPurchaseOrders,
} from "@/modules/purchasing/purchase-management";

export const runtime = "nodejs";

/** `loadFinalizedPurchaseOrders`: the purchase management list. */
export async function GET(request: NextRequest) {
  const guard = await requirePurchasingAccess(request, [PURCHASE_MANAGEMENT_PAGE]);
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, FINALIZED_PO_SORT_KEYS, "created_date", "DESC");
    const statuses = normalizeIntList(params.get("statuses") ?? "", true);
    return apiSuccess(await listFinalizedPurchaseOrders(query, statuses));
  } catch (error) {
    console.error("Unable to list the finalized purchase orders", error);
    return apiError("Error loading finalized purchase orders.", 500);
  }
}
