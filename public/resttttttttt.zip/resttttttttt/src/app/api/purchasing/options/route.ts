import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { normalizeIntList } from "@/modules/inventory/stock-list-sql";
import { fetchProcurementPrefillItems } from "@/modules/inventory/stocks";
import { requirePurchasingAccess } from "@/modules/purchasing/guard";
import {
  generateUniquePoOrderNum,
  generateUniquePoOrderNumForRaw,
  todayInIst,
} from "@/modules/purchasing/po-numbers";
import { listProductsForPurchaseOrder } from "@/modules/purchasing/purchase-management";
import {
  listErpBranches,
  listPurchaseMaterials,
  listPurchaseSuppliers,
  listShipmentBranches,
} from "@/modules/purchasing/supplier-lookup";

export const runtime = "nodejs";

/**
 * The selector lists both purchasing screens open with, and the two purchase
 * order numbers the current pages render into their forms.
 */
export async function GET(request: NextRequest) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const params = request.nextUrl.searchParams;
  try {
    switch (params.get("list")) {
      case "form": {
        const [suppliers, materials, shipmentBranches, poNumber, poNumberRaw] = await Promise.all([
          listPurchaseSuppliers(),
          listPurchaseMaterials(),
          listShipmentBranches(guard.user.company_id ?? 0),
          generateUniquePoOrderNum(),
          generateUniquePoOrderNumForRaw(),
        ]);
        return apiSuccess({
          suppliers, materials, shipmentBranches, poNumber, poNumberRaw, today: todayInIst(),
        });
      }
      case "branches":
        return apiSuccess({ branches: await listErpBranches() });
      case "po-numbers":
        return apiSuccess({
          poNumber: await generateUniquePoOrderNum(),
          poNumberRaw: await generateUniquePoOrderNumForRaw(),
        });
      case "products": {
        // `fetchProductsDetailsForPO`: the products a stock screen handed over.
        const ids = normalizeIntList(params.get("ids") ?? "");
        if (ids.length === 0) return apiError("No product IDs provided.", 422);
        return apiSuccess({ rows: await listProductsForPurchaseOrder(ids) });
      }
      case "procurement-prefill": {
        // `fetchProcurementPrefillProducts`
        const ids = normalizeIntList(params.get("productIds") ?? "");
        const items = await fetchProcurementPrefillItems(ids, (params.get("procurementSource") ?? "").trim());
        if (items.length === 0) return apiError("No products available for procurement.", 404);
        return apiSuccess({ items });
      }
      default:
        return apiError("Unknown option list.", 422);
    }
  } catch (error) {
    console.error("Unable to load the purchasing options", error);
    return apiError("Error loading data.", 500);
  }
}
