import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { PURCHASE_MANAGEMENT_PAGE, requirePurchasingAccess } from "@/modules/purchasing/guard";
import { getRequestsByVendorAndDate } from "@/modules/purchasing/purchase-management";

export const runtime = "nodejs";

/**
 * `viewPurchaseManagementRecord` and `fetchPurchaseOrderRecord`: the requests a
 * vendor raised on one day, behind the view and finalise dialogs.
 */
export async function GET(request: NextRequest) {
  const guard = await requirePurchasingAccess(request, [PURCHASE_MANAGEMENT_PAGE]);
  if (!guard.ok) return guard.response;
  const params = request.nextUrl.searchParams;
  const vendor = (params.get("vendor") ?? "").trim();
  const createdDate = (params.get("createdDate") ?? "").trim();
  if (vendor === "" || createdDate === "") {
    return apiError("Something went wrong with this record..!!", 422);
  }
  try {
    const rows = await getRequestsByVendorAndDate(vendor, createdDate);
    if (rows.length === 0) return apiError("No data found...!!", 404);
    return apiSuccess({ rows });
  } catch (error) {
    console.error("Unable to read the vendor's purchase requests", error);
    return apiError("Server error occurred.", 500);
  }
}
