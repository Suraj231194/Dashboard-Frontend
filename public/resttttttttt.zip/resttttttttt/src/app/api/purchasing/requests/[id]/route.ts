import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { deleteLowStock } from "@/modules/inventory/low-stocks";
import {
  FINAL_PURCHASE_ORDERS_PAGE, PURCHASE_MANAGEMENT_PAGE, PURCHASE_ORDER_PAGE,
  PURCHASE_ORDER_RAW_PAGE, requirePurchasingAccess,
} from "@/modules/purchasing/guard";
import { getPurchaseRequest, updatePurchaseRequestStatus } from "@/modules/purchasing/purchase-management";

export const runtime = "nodejs";

/** `fetchLowStockRequestById` — every purchase order form prefills from it. */
export async function GET(request: NextRequest, context: RouteContext<"/api/purchasing/requests/[id]">) {
  const guard = await requirePurchasingAccess(request, [
    PURCHASE_MANAGEMENT_PAGE, FINAL_PURCHASE_ORDERS_PAGE, PURCHASE_ORDER_PAGE, PURCHASE_ORDER_RAW_PAGE,
  ]);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Invalid ID.", 422);
  try {
    const row = await getPurchaseRequest(id);
    if (!row) return apiError("No low stock record found.", 404);
    return apiSuccess({ request: row });
  } catch (error) {
    console.error("Unable to read the purchase request", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `updateStatusPurchaseOrderRecord`: the cancel and status transitions. */
export async function PATCH(request: NextRequest, context: RouteContext<"/api/purchasing/requests/[id]">) {
  const guard = await requirePurchasingAccess(request, [PURCHASE_MANAGEMENT_PAGE]);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const statusValue = Number.parseInt(String(data.get("statusValue") ?? ""), 10) || 0;
    const result = await updatePurchaseRequestStatus(id, statusValue, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to change the purchase request status", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `deleteLowStocksRecord` */
export async function DELETE(request: NextRequest, context: RouteContext<"/api/purchasing/requests/[id]">) {
  const guard = await requirePurchasingAccess(request, [PURCHASE_MANAGEMENT_PAGE]);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Invalid or missing low stock request ID.", 422);
  try {
    const result = await deleteLowStock(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message ?? "Low stock request deleted successfully.");
  } catch (error) {
    console.error("Unable to delete the purchase request", error);
    return apiError("Server error occurred.", 500);
  }
}
