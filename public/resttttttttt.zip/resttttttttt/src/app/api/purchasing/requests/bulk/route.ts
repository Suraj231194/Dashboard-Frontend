import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { PURCHASE_MANAGEMENT_PAGE, requirePurchasingAccess } from "@/modules/purchasing/guard";
import { saveBulkPurchaseRequests, type BulkRequestLine } from "@/modules/purchasing/purchase-management";
import { list, toFloat, toInt } from "../../forms";

export const runtime = "nodejs";

/** `saveBulkPurchaseRequests`: the Generate PO step saves its rows first. */
export async function POST(request: NextRequest) {
  const guard = await requirePurchasingAccess(request, [PURCHASE_MANAGEMENT_PAGE]);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const lowStockIds = list(data, "lowStockIds[]");
    const productNames = list(data, "productNames[]");
    const quantities = list(data, "quantities[]");
    const unitIds = list(data, "unitIds[]");

    const lines: BulkRequestLine[] = productNames.map((productName, index) => ({
      lowStockId: toInt(lowStockIds[index]),
      productName,
      quantity: toFloat(quantities[index]),
      unitId: toInt(unitIds[index]),
    }));

    const result = await saveBulkPurchaseRequests({
      reportingPerson: String(data.get("reportingPerson") ?? ""),
      dateOfReport: String(data.get("dateOfReport") ?? ""),
      vendorName: String(data.get("vendorName") ?? ""),
      criticalItem: toInt(data.get("criticalItem")),
      expectedDelivery: String(data.get("expectedDelivery") ?? ""),
      lines,
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess(result.data ?? {}, result.message);
  } catch (error) {
    console.error("Unable to save the bulk purchase requests", error);
    return apiError("Server error occurred.", 500);
  }
}
