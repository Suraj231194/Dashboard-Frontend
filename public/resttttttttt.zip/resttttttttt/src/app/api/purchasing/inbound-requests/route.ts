import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { PURCHASE_MANAGEMENT_PAGE, requirePurchasingAccess } from "@/modules/purchasing/guard";
import { listInboundRequests } from "@/modules/purchasing/purchase-management";

export const runtime = "nodejs";

/** `loadInboundRequests`: the pending purchase requests behind the banner. */
export async function GET(request: NextRequest) {
  const guard = await requirePurchasingAccess(request, [PURCHASE_MANAGEMENT_PAGE]);
  if (!guard.ok) return guard.response;
  try {
    const rows = await listInboundRequests();
    return apiSuccess({ rows, count: rows.length });
  } catch (error) {
    console.error("Unable to list the inbound purchase requests", error);
    return apiError("Error loading pending requests.", 500);
  }
}
