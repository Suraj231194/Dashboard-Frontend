import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { requirePurchasingAccess } from "@/modules/purchasing/guard";
import { buildRawPurchaseOrderExport } from "@/modules/purchasing/purchase-order-documents";
import { toInt } from "../../../../forms";

export const runtime = "nodejs";

/**
 * `purchase_order_raw_template.php?id=<id>&branch_id=<id>&triggerDownload=1`:
 * the printable raw purchase order, returned as the file itself.
 */
export async function POST(
  request: NextRequest, context: RouteContext<"/api/purchasing/orders/raw/[id]/pdf">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Missing purchase order number", 422);
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType") ?? "pdf");
    if (!format) return apiError("Please select an export format.", 422);
    const table = await buildRawPurchaseOrderExport(id, toInt(data.get("branch_id")));
    if (!table) return apiError("No data found...!!", 404);
    return await tableExportResponse({ format, ...table });
  } catch (error) {
    console.error("Unable to build the raw purchase order PDF", error);
    return apiError("Server error occurred.", 500);
  }
}
