import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requirePurchasingAccess } from "@/modules/purchasing/guard";
import {
  deleteFinalPurchaseOrder,
  readFinalPurchaseOrder,
  updateFinalPurchaseOrder,
} from "@/modules/purchasing/purchase-orders";
import { readFinalPurchaseOrderEditForm } from "../../../forms";

export const runtime = "nodejs";

/** `fetchPurchaseOrderFinalRecord`: the item rows behind the edit dialog. */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/purchasing/orders/final/[poNumber]">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const poNumber = decodeURIComponent((await context.params).poNumber ?? "");
  if (poNumber.trim() === "") return apiError("Invalid parameters.", 422);
  try {
    const rows = await readFinalPurchaseOrder(poNumber);
    if (rows.length === 0) return apiError("No purchase order found.", 404);
    return apiSuccess({ rows });
  } catch (error) {
    console.error("Unable to read the purchase order", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `updatePurchaseOrderFinalRecord` */
export async function PUT(
  request: NextRequest, context: RouteContext<"/api/purchasing/orders/final/[poNumber]">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const poNumber = decodeURIComponent((await context.params).poNumber ?? "");
  try {
    const data = await request.formData();
    const input = readFinalPurchaseOrderEditForm(data, guard.user.user_id);
    // The dialog carries the order number in a hidden field; the path wins when
    // that field is missing, which keeps the endpoint addressable on its own.
    if (input.poOrderNum.trim() === "") input.poOrderNum = poNumber;
    const result = await updateFinalPurchaseOrder(input);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update the purchase order", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `deletePOPdfRecord` */
export async function DELETE(
  request: NextRequest, context: RouteContext<"/api/purchasing/orders/final/[poNumber]">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const poNumber = decodeURIComponent((await context.params).poNumber ?? "");
  try {
    const result = await deleteFinalPurchaseOrder(poNumber, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the purchase order", error);
    return apiError("Server error occurred.", 500);
  }
}
