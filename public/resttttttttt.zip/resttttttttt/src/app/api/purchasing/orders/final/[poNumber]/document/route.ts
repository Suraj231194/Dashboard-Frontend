import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requirePurchasingAccess } from "@/modules/purchasing/guard";
import { buildFinalPurchaseOrderDocument } from "@/modules/purchasing/purchase-orders";

export const runtime = "nodejs";

/**
 * `purchaseOrderFinalViewPdfRecord`: the purchase order document's data. The
 * PDF itself (POPdf(), generateAndSavePoPdf() and the supplier email) belongs
 * to the document module; this endpoint stops at the data.
 */
export async function GET(
  request: NextRequest,
  context: RouteContext<"/api/purchasing/orders/final/[poNumber]/document">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const poNumber = decodeURIComponent((await context.params).poNumber ?? "");
  if (poNumber.trim() === "") return apiError("Missing purchase order number", 422);
  try {
    const document = await buildFinalPurchaseOrderDocument(poNumber);
    if (!document) return apiError("No data found...!!", 404);
    return apiSuccess({ document });
  } catch (error) {
    console.error("Unable to build the purchase order document", error);
    return apiError("Server error occurred.", 500);
  }
}
