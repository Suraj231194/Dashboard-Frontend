import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requirePurchasingAccess } from "@/modules/purchasing/guard";
import {
  deleteRawPurchaseOrder,
  readRawPurchaseOrder,
  updateRawPurchaseOrder,
} from "@/modules/purchasing/purchase-orders";
import { readRawPurchaseOrderEditForm } from "../../../forms";

export const runtime = "nodejs";

/** `fetchPurchaseOrderRawRecord`: the order and its items behind the edit dialog. */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/purchasing/orders/raw/[id]">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const detail = await readRawPurchaseOrder(id);
    if (!detail) return apiError("No data found...!!", 404);
    return apiSuccess(detail);
  } catch (error) {
    console.error("Unable to read the raw purchase order", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `updatePurchaseOrderRawRecord` */
export async function PUT(
  request: NextRequest, context: RouteContext<"/api/purchasing/orders/raw/[id]">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    // The dialog posts the id in a hidden field; the path is the fallback.
    const posted = Number.parseInt(String(data.get("pOrderRawIdEdit") ?? ""), 10) || 0;
    const result = await updateRawPurchaseOrder(
      readRawPurchaseOrderEditForm(data, posted > 0 ? posted : id, guard.user.user_id),
    );
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update the raw purchase order", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `deletePurchaseOrderRawRecord` */
export async function DELETE(
  request: NextRequest, context: RouteContext<"/api/purchasing/orders/raw/[id]">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteRawPurchaseOrder(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the raw purchase order", error);
    return apiError("Server error occurred.", 500);
  }
}
