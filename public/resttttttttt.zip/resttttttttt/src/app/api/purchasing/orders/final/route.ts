import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readListQuery } from "@/lib/pagination";
import {
  FINAL_PURCHASE_ORDERS_PAGE, PURCHASE_ORDER_PAGE, requirePurchasingAccess,
} from "@/modules/purchasing/guard";
import {
  createFinalPurchaseOrder,
  FINAL_PO_SORT_KEYS,
  listFinalPurchaseOrders,
} from "@/modules/purchasing/purchase-orders";
import { readFinalPurchaseOrderForm } from "../../forms";

export const runtime = "nodejs";

/** `loadFinalPurchaseOrder`: the grouped purchase order list. */
export async function GET(request: NextRequest) {
  const guard = await requirePurchasingAccess(request, [FINAL_PURCHASE_ORDERS_PAGE, PURCHASE_ORDER_PAGE]);
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, FINAL_PO_SORT_KEYS, "created_date", "DESC");
    return apiSuccess(await listFinalPurchaseOrders(query));
  } catch (error) {
    console.error("Unable to list the final purchase orders", error);
    return apiError("Error loading data.", 500);
  }
}

/** `addPurchaseOrderForm`: creates the packing-material purchase order. */
export async function POST(request: NextRequest) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createFinalPurchaseOrder(
      readFinalPurchaseOrderForm(data, guard.user.user_id, guard.user.company_id ?? 0),
    );
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess(result.data ?? {}, result.message);
  } catch (error) {
    console.error("Unable to add the purchase order", error);
    return apiError("Server error occurred.", 500);
  }
}
