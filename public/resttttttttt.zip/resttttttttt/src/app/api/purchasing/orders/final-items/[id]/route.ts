import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requirePurchasingAccess } from "@/modules/purchasing/guard";
import { deleteFinalPurchaseOrderItem } from "@/modules/purchasing/purchase-orders";

export const runtime = "nodejs";

/** `deletePurchaseOrderFinalSubItem`: hides one material line of an order. */
export async function DELETE(
  request: NextRequest, context: RouteContext<"/api/purchasing/orders/final-items/[id]">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteFinalPurchaseOrderItem(id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the purchase order item", error);
    return apiError("Failed to delete item.", 500);
  }
}
