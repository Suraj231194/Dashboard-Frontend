import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requirePurchasingAccess } from "@/modules/purchasing/guard";
import { buildRawPurchaseOrderDocument } from "@/modules/purchasing/purchase-orders";

export const runtime = "nodejs";

/**
 * `viewPurchaseOrderRawRecord`: the raw purchase order document's data. The PDF
 * itself (PORawPdf(), generateAndSavePoPdf() and the supplier email) belongs to
 * the document module; this endpoint stops at the data.
 */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/purchasing/orders/raw/[id]/document">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Missing purchase order number", 422);
  try {
    const document = await buildRawPurchaseOrderDocument(id);
    if (!document) return apiError("No data found...!!", 404);
    return apiSuccess({ document });
  } catch (error) {
    console.error("Unable to build the raw purchase order document", error);
    return apiError("Server error occurred.", 500);
  }
}
