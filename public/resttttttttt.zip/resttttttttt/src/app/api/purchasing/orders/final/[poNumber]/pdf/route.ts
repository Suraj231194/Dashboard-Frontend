import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { requirePurchasingAccess } from "@/modules/purchasing/guard";
import { buildFinalPurchaseOrderExport } from "@/modules/purchasing/purchase-order-documents";
import { toInt } from "../../../../forms";

export const runtime = "nodejs";

/**
 * `purchase_order_template.php?id=<po>&branch_id=<id>&triggerDownload=1`: the
 * printable purchase order. The template page only ever produces a PDF, so that
 * is the default here, and the file itself is returned.
 */
export async function POST(
  request: NextRequest, context: RouteContext<"/api/purchasing/orders/final/[poNumber]/pdf">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const poNumber = decodeURIComponent((await context.params).poNumber ?? "");
  if (poNumber.trim() === "") return apiError("Missing purchase order number", 422);
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType") ?? "pdf");
    if (!format) return apiError("Please select an export format.", 422);
    const table = await buildFinalPurchaseOrderExport(poNumber, toInt(data.get("branch_id")));
    if (!table) return apiError("No data found...!!", 404);
    return await tableExportResponse({ format, ...table });
  } catch (error) {
    console.error("Unable to build the purchase order PDF", error);
    return apiError("Server error occurred.", 500);
  }
}
