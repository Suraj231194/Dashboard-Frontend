import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readListQuery } from "@/lib/pagination";
import {
  FINAL_PURCHASE_ORDERS_PAGE, PURCHASE_ORDER_PAGE, PURCHASE_ORDER_RAW_PAGE,
  requirePurchasingAccess,
} from "@/modules/purchasing/guard";
import {
  createRawPurchaseOrder,
  listRawPurchaseOrders,
  RAW_PO_SORT_KEYS,
} from "@/modules/purchasing/purchase-orders";
import { readRawPurchaseOrderForm } from "../../forms";

export const runtime = "nodejs";

/** `loadPurchaseOrderRaw`: the raw-material purchase order list. */
export async function GET(request: NextRequest) {
  const guard = await requirePurchasingAccess(request, [
      FINAL_PURCHASE_ORDERS_PAGE, PURCHASE_ORDER_PAGE, PURCHASE_ORDER_RAW_PAGE,
    ]);
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, RAW_PO_SORT_KEYS, "id", "DESC");
    return apiSuccess(await listRawPurchaseOrders(query));
  } catch (error) {
    console.error("Unable to list the raw purchase orders", error);
    return apiError("Error loading data.", 500);
  }
}

/** `addPurchaseOrderRaw`: creates the raw-material purchase order. */
export async function POST(request: NextRequest) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createRawPurchaseOrder(
      readRawPurchaseOrderForm(data, guard.user.user_id, guard.user.company_id ?? 0),
    );
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess(result.data ?? {}, result.message);
  } catch (error) {
    console.error("Unable to add the raw purchase order", error);
    return apiError("Server error occurred.", 500);
  }
}
