import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { PURCHASE_MANAGEMENT_PAGE, requirePurchasingAccess } from "@/modules/purchasing/guard";
import { finalisePurchaseOrder } from "@/modules/purchasing/purchase-management";
import { readFinaliseForm } from "../../../forms";

export const runtime = "nodejs";

/**
 * `insertPurchaseOrderFinalRecord`: the Finalise Purchase Order Request dialog.
 * One order number per vendor, and every request it covers moves to In-Process.
 */
export async function POST(request: NextRequest) {
  const guard = await requirePurchasingAccess(request, [PURCHASE_MANAGEMENT_PAGE]);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await finalisePurchaseOrder(readFinaliseForm(data), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess(result.data ?? {}, result.message);
  } catch (error) {
    console.error("Unable to finalise the purchase order", error);
    return apiError("Server error occurred.", 500);
  }
}
