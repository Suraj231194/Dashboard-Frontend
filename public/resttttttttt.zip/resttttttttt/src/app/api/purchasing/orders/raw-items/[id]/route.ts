import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requirePurchasingAccess } from "@/modules/purchasing/guard";
import { deleteRawPurchaseOrderItem } from "@/modules/purchasing/purchase-orders";

export const runtime = "nodejs";

/** `deletePurchaseOrderRawSubProductRecord`: hides one item of a raw order. */
export async function DELETE(
  request: NextRequest, context: RouteContext<"/api/purchasing/orders/raw-items/[id]">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteRawPurchaseOrderItem(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the raw purchase order item", error);
    return apiError("Server error occurred.", 500);
  }
}
