import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { normalizeIntList } from "@/modules/inventory/stock-list-sql";
import { PURCHASE_MANAGEMENT_PAGE, requirePurchasingAccess } from "@/modules/purchasing/guard";
import { buildPurchaseManagementExport } from "@/modules/purchasing/purchase-management";
import { PURCHASE_EXPORT_SORT_COLUMNS } from "@/modules/purchasing/purchase-list-sql";
import { list, toInt } from "../forms";

export const runtime = "nodejs";

/** `exportPurchaseManagementRecords`: a CSV, an .xlsx or a PDF of the chosen columns. */
export async function POST(request: NextRequest) {
  const guard = await requirePurchasingAccess(request, [PURCHASE_MANAGEMENT_PAGE]);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Please select an export format.", 422);

    const sortColumn = String(data.get("sort_column") ?? "created_date");
    const result = await buildPurchaseManagementExport({
      search: String(data.get("search") ?? "").trim(),
      statuses: normalizeIntList(String(data.get("selectedStatus") ?? ""), true),
      // The export keeps its own allow-list, and falls back to the created date.
      sortColumn: sortColumn in PURCHASE_EXPORT_SORT_COLUMNS ? sortColumn : "created_date",
      sortDirection: String(data.get("sort_order") ?? "DESC").toUpperCase() === "ASC" ? "ASC" : "DESC",
      page: Math.max(1, toInt(data.get("page")) || 1),
      perPage: toInt(data.get("per_page")) || 10,
      selectedColumns: list(data, "listOfColumns[]"),
    });

    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "Purchase Management", filePrefix: "purchase_management",
      headers: result.columns, rows: result.rows,
    });
  } catch (error) {
    console.error("Unable to build the purchase management export", error);
    return apiError("Server error occurred.", 500);
  }
}
