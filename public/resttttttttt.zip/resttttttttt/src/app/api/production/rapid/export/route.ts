import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { buildRapidExport } from "@/modules/production/rapid";
import {
  PRODUCTION_PERMISSIONS, RAPID_SORT_COLUMNS,
} from "@/modules/production/production-constants";

export const runtime = "nodejs";

/**
 * `getCheckedValues()` posts the checked ids to `daily_report_bulk_template.php`
 * and downloads the PDF it renders. The same selection is served here through
 * the shared export writer, so the person still picks rows and gets one file.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.rapidPdf, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const ids = String(data.get("ids") ?? "")
      .split(",")
      .map((value) => Number.parseInt(value.trim(), 10))
      .filter((value) => Number.isInteger(value) && value > 0);
    const requested = String(data.get("sort_column") ?? "");
    const direction = String(data.get("sort_order") ?? "DESC").toUpperCase() === "ASC" ? "ASC" : "DESC";
    const result = await buildRapidExport({
      ids,
      search: String(data.get("search") ?? "").trim(),
      sortColumn: (RAPID_SORT_COLUMNS as readonly string[]).includes(requested) ? requested : "pe.id",
      sortDirection: direction,
      page: Number.parseInt(String(data.get("page") ?? "1"), 10) || 1,
      perPage: Number.parseInt(String(data.get("perPage") ?? "10"), 10) || 10,
      columns: data.getAll("listOfColumns[]").map((value) => String(value)),
    });
    if (result.rows.length === 0) return apiError("Please select at least one record.", 404);
    return await tableExportResponse({
      format, title: "Daily Production Report", filePrefix: "daily_production_reports",
      headers: result.columns, rows: result.rows,
    });
  } catch (error) {
    console.error("Unable to export the rapid entries", error);
    return apiError("Unable to generate the selected Daily Production Reports.", 500);
  }
}
