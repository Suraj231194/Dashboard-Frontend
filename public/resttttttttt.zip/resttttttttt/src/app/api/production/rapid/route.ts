import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import {
  RapidError, createRapidEntry, listRapidEntries, type RapidParticularInput,
} from "@/modules/production/rapid";
import { RAPID_SORT_COLUMNS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `loadRapidData`: the rapid entry list, searched on the batch number. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "rapid");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, RAPID_SORT_COLUMNS, "pe.id", "DESC");
    const result = await listRapidEntries({
      page: query.page,
      perPage: query.perPage,
      search: query.search,
      sortColumn: query.sortColumn,
      sortDirection: query.sortDirection,
    });
    return apiSuccess(result);
  } catch (error) {
    console.error("Unable to load rapid entries", error);
    return apiError("Error loading data.", 500);
  }
}

/** `saveRapidProductionForm`: one entry with its department particulars. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "rapid-create");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    let particulars: RapidParticularInput[] = [];
    try {
      const parsed: unknown = JSON.parse(String(data.get("particulars") ?? "[]"));
      if (Array.isArray(parsed)) particulars = parsed as RapidParticularInput[];
    } catch {
      return apiError("Report submission failed", 422);
    }
    const result = await createRapidEntry({
      date: String(data.get("date") ?? ""),
      monthYear: String(data.get("monthYear") ?? ""),
      totalManPower: String(data.get("totalManPower") ?? ""),
      totalWorkingHours: String(data.get("totalWorkingHours") ?? ""),
      department: String(data.get("department") ?? ""),
      particulars,
    }, guard.user.user_id);
    return apiSuccess({ batch_number: result.batchNumber }, result.message);
  } catch (error) {
    if (error instanceof RapidError) return apiError(error.message, 422);
    console.error("Unable to save the rapid production form", error);
    return apiError("Report submission failed", 500);
  }
}
