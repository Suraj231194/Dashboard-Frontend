import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, readId } from "@/lib/http/guard";
import { RapidError, readRapidEntry } from "@/modules/production/rapid";

export const runtime = "nodejs";

/** `fetchRapidData`: one entry with its production details. */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPageAccess(request, "rapid");
  if (!guard.ok) return guard.response;
  const { id } = await context.params;
  try {
    const entry = await readRapidEntry(readId(id));
    if (!entry) return apiError("No data found...!!", 404);
    return apiSuccess({ entry });
  } catch (error) {
    if (error instanceof RapidError) return apiError(error.message, 422);
    console.error("Unable to read the rapid entry", error);
    return apiError("Invalid server response.", 500);
  }
}
