import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listQtyUnits } from "@/modules/production/rapid";

export const runtime = "nodejs";

/** `getQtyUnits`: the quantity-unit dropdown the rapid entry form uses. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "rapid-create");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ units: await listQtyUnits() });
  } catch (error) {
    console.error("Unable to load the quantity units", error);
    return apiError("Failed to load qty units.", 500);
  }
}
