import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { CoaError, listTemplateFields } from "@/modules/production/coa-generation";

export const runtime = "nodejs";

/** `fetchTemplateFields`: the test parameters a chosen template contributes. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "coa-generation");
  if (!guard.ok) return guard.response;
  try {
    const templateId = Number.parseInt(request.nextUrl.searchParams.get("template_id") ?? "0", 10) || 0;
    return apiSuccess({ fields: await listTemplateFields(templateId) });
  } catch (error) {
    if (error instanceof CoaError) return apiError(error.message, 422);
    console.error("Unable to load the template fields", error);
    return apiError("Server error occurred.", 500);
  }
}
