import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import {
  COA_SORT_COLUMNS, CoaError, listCoaRecords, readCoaApprovalForm, submitCoaApproval,
} from "@/modules/production/coa-generation";

export const runtime = "nodejs";

/** `loadCoaData`: the decided COA records. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "coa-generation");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, COA_SORT_COLUMNS, "id", "DESC");
    return apiSuccess(await listCoaRecords(query, params.get("status_filter") ?? ""));
  } catch (error) {
    console.error("Unable to list COA records", error);
    return apiError("Error loading data.", 500);
  }
}

/** `coaApprovalFrom`: the QC decision, which releases the quarantined receipt. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "coa-generation");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await submitCoaApproval(readCoaApprovalForm(data, guard.user.user_id));
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof CoaError) return apiError(error.message, 422);
    console.error("Unable to submit the COA decision", error);
    return apiError("Server error occurred.", 500);
  }
}
