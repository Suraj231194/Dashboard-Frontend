import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listPendingCoa, pendingCoaCount } from "@/modules/production/coa-generation";

export const runtime = "nodejs";

/** `loadIncomingCoaGenerationWorkflow`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "coa-generation");
  if (!guard.ok) return guard.response;
  try {
    const records = await listPendingCoa();
    return apiSuccess({ records, total: records.length, pending_coa_count: await pendingCoaCount() });
  } catch (error) {
    console.error("Unable to load the pending COA records", error);
    return apiError("Error loading data.", 500);
  }
}
