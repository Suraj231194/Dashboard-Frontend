import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { CoaError, getInboundMaterial, previewCoaNumber } from "@/modules/production/coa-generation";

export const runtime = "nodejs";

/**
 * `fetchInboundMaterialForCoa`, or `previewInboundCoaNumber` when only a goods
 * type is asked for, which is what changing the type in the dialog does.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "coa-generation");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const queueId = Number.parseInt(params.get("id") ?? "0", 10) || 0;
    const stockInwardId = Number.parseInt(params.get("stock_inward_id") ?? "0", 10) || 0;
    const type = params.get("type");
    if (queueId <= 0 && stockInwardId <= 0 && type !== null) {
      return apiSuccess(await previewCoaNumber(type));
    }
    return apiSuccess(await getInboundMaterial(queueId, stockInwardId));
  } catch (error) {
    if (error instanceof CoaError) return apiError(error.message, 422);
    console.error("Unable to read the inbound material", error);
    return apiError("Server error occurred.", 500);
  }
}
