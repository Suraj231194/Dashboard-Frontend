import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import {
  CoaError, createInboundCoa, listInboundMaterials, readInboundCoaForm,
} from "@/modules/production/coa-generation";

export const runtime = "nodejs";

/** `loadInboundMaterialsList`: receipts still waiting for a COA number. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "coa-generation");
  if (!guard.ok) return guard.response;
  try {
    const records = await listInboundMaterials();
    return apiSuccess({ records, total: records.length });
  } catch (error) {
    console.error("Unable to load the inbound materials", error);
    return apiError("Error loading data.", 500);
  }
}

/** `submitInboundCoa`: allocates the COA number and creates the record. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "coa-generation");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createInboundCoa(readInboundCoaForm(data, guard.user.user_id));
    return apiSuccess({ coa_number: result.coa_number, coa_id: result.coa_id }, result.message);
  } catch (error) {
    if (error instanceof CoaError) return apiError(error.message, 422);
    console.error("Unable to generate the inbound COA", error);
    return apiError("Server error occurred.", 500);
  }
}
