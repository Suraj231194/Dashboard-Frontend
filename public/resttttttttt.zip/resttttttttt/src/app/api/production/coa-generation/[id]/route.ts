import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { getCoaRecord } from "@/modules/production/coa-generation";

export const runtime = "nodejs";

/** `fetchCoaDataView`: the record, its templates and any saved observations. */
export async function GET(request: NextRequest, context: RouteContext<"/api/production/coa-generation/[id]">) {
  const guard = await requireApiPageAccess(request, "coa-generation");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const record = await getCoaRecord(id);
    if (!record) return apiError("No data found...!!", 404);
    return apiSuccess({ record });
  } catch (error) {
    console.error("Unable to read the COA record", error);
    return apiError("Server error occurred.", 500);
  }
}
