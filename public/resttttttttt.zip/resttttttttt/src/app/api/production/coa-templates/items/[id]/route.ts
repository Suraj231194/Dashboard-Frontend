import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import { CoaTemplateError, deleteCoaTemplateItem } from "@/modules/production/coa-templates";

export const runtime = "nodejs";

/** `deleteCoaTemplateItemRecord`: one parameter row leaves the template. */
export async function DELETE(
  request: NextRequest, context: RouteContext<"/api/production/coa-templates/items/[id]">,
) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.templatesEdit, "You do not have permission to edit COA templates.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteCoaTemplateItem(id, guard.user.user_id);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof CoaTemplateError) return apiError(error.message, 422);
    console.error("Unable to delete the COA template item", error);
    return apiError("Server error occurred.", 500);
  }
}
