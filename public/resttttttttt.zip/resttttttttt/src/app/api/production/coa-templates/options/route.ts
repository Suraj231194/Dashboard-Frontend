import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listTemplateCategories, listTemplateProducts } from "@/modules/production/coa-templates";

export const runtime = "nodejs";

/**
 * The category list, and the products of one category when `category_id` is
 * given — the pair the dependent dropdowns need.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "coa-templates");
  if (!guard.ok) return guard.response;
  try {
    const categoryId = Number.parseInt(request.nextUrl.searchParams.get("category_id") ?? "0", 10) || 0;
    if (categoryId > 0) return apiSuccess({ products: await listTemplateProducts(categoryId) });
    return apiSuccess({ categories: await listTemplateCategories() });
  } catch (error) {
    console.error("Unable to load the COA template options", error);
    return apiError("Error loading data.", 500);
  }
}
