import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { listCoaTemplateExportRows } from "@/modules/production/coa-templates";

export const runtime = "nodejs";

const COLUMNS = ["Category", "Product / Material", "Name", "Description", "Status"] as const;

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "coa-templates");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (format === null) return apiError("Please choose a valid export format.", 422);

    const selected = data.getAll("columns[]").map((value) => String(value));
    const headers = selected.length > 0
      ? COLUMNS.filter((column) => selected.includes(column))
      : [...COLUMNS];
    if (headers.length === 0) return apiError("Select at least one column to export.", 422);

    const rows = await listCoaTemplateExportRows(String(data.get("search") ?? "").trim());
    if (rows.length === 0) return apiError("No records found", 404);

    return await tableExportResponse({
      format, title: "COA Templates", filePrefix: "coa_templates", headers, rows,
    });
  } catch (error) {
    console.error("Unable to export the COA templates", error);
    return apiError("Server error occurred.", 500);
  }
}
