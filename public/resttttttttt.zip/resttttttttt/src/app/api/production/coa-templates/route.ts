import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import {
  COA_TEMPLATE_SORT_COLUMNS, CoaTemplateError, createCoaTemplate, listCoaTemplates,
  readCoaTemplateForm,
} from "@/modules/production/coa-templates";

export const runtime = "nodejs";

/** `loadCoaTemplates`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "coa-templates");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, COA_TEMPLATE_SORT_COLUMNS, "id", "DESC");
    return apiSuccess(await listCoaTemplates(query));
  } catch (error) {
    console.error("Unable to list COA templates", error);
    return apiError("Error loading data.", 500);
  }
}

/** `addCoaTemplate`. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.templatesAdd, "You do not have permission to add COA templates.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createCoaTemplate(readCoaTemplateForm(data, guard.user.user_id, false));
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof CoaTemplateError) return apiError(error.message, 422);
    console.error("Unable to add the COA template", error);
    return apiError("Server error occurred.", 500);
  }
}
