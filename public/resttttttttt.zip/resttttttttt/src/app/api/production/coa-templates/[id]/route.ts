import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import {
  CoaTemplateError, deleteCoaTemplate, getCoaTemplateForEdit, listTemplateProducts,
  readCoaTemplateForm, updateCoaTemplate, viewCoaTemplate,
} from "@/modules/production/coa-templates";

export const runtime = "nodejs";

/**
 * `viewCoaTemplateRecord` and `fetchCoaTemplateRecord` in one: `?mode=edit`
 * returns the editable record, anything else the read-only one.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/production/coa-templates/[id]">) {
  const edit = request.nextUrl.searchParams.get("mode") === "edit";
  const guard = await requireApiPermission(
    request,
    edit ? COA_PERMISSIONS.templatesEdit : COA_PERMISSIONS.templatesView,
    "You do not have permission to perform this action.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Invalid or missing template ID.", 422);
  try {
    const template = edit ? await getCoaTemplateForEdit(id) : await viewCoaTemplate(id);
    if (!template) return apiError("No data found...!!", 404);
    const products = edit ? await listTemplateProducts(template.prod_categ_id) : [];
    return apiSuccess({ template, products });
  } catch (error) {
    console.error("Unable to read the COA template", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `updateCoaTemplateRecord`. */
export async function PUT(request: NextRequest, context: RouteContext<"/api/production/coa-templates/[id]">) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.templatesEdit, "You do not have permission to edit COA templates.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateCoaTemplate(id, readCoaTemplateForm(data, guard.user.user_id, true));
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof CoaTemplateError) return apiError(error.message, 422);
    console.error("Unable to update the COA template", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `deleteCoaTemplateRecord`. */
export async function DELETE(request: NextRequest, context: RouteContext<"/api/production/coa-templates/[id]">) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.templatesDelete, "You do not have permission to delete COA templates.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteCoaTemplate(id, guard.user.user_id);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof CoaTemplateError) return apiError(error.message, 422);
    console.error("Unable to delete the COA template", error);
    return apiError("Server error occurred.", 500);
  }
}
