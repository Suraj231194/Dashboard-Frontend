import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listParticulars } from "@/modules/production/daily-report";
import { listQtyUnits } from "@/modules/production/rapid";

export const runtime = "nodejs";

/** `getParticularsListBSEH` and `getQtyUnits`, which the add form loads together. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "daily-production-report-bseh");
  if (!guard.ok) return guard.response;
  try {
    const [particulars, units] = await Promise.all([listParticulars(), listQtyUnits()]);
    return apiSuccess({ particulars, units });
  } catch (error) {
    console.error("Unable to load the BSEH form options", error);
    return apiError("Failed to load particulars list.", 500);
  }
}
