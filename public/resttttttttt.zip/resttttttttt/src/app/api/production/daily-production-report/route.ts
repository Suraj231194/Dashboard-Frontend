import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import {
  DailyReportError, createDailyReport, listDailyReports, type DailyReportBlockInput,
} from "@/modules/production/daily-report";
import { BSEH_SORT_COLUMNS, PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `loadDailyProductionBSEH`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "daily-production-report-bseh");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, BSEH_SORT_COLUMNS, "id", "DESC");
    return apiSuccess(await listDailyReports({
      page: query.page,
      perPage: query.perPage,
      search: query.search,
      sortColumn: query.sortColumn,
      sortDirection: query.sortDirection,
    }));
  } catch (error) {
    console.error("Unable to load the BSEH daily production reports", error);
    return apiError("Error loading data.", 500);
  }
}

/** `addDailyProductionBSEH`. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.bsehAdd, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    let blocks: DailyReportBlockInput[] = [];
    try {
      const parsed: unknown = JSON.parse(String(data.get("blocks") ?? "[]"));
      if (Array.isArray(parsed)) blocks = parsed as DailyReportBlockInput[];
    } catch {
      return apiError("Missing required fields", 422);
    }
    const result = await createDailyReport({
      date: String(data.get("dateDpr") ?? ""),
      monthYear: String(data.get("monthYearDpr") ?? ""),
      totalManPower: String(data.get("totalManPower") ?? ""),
      workingHours: String(data.get("workingHours") ?? ""),
      department: String(data.get("department") ?? ""),
      remark: String(data.get("remark") ?? "").trim(),
      blocks,
    }, guard.user.user_id);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof DailyReportError) return apiError(error.message, 422);
    console.error("Unable to save the BSEH daily production report", error);
    return apiError("Server error occurred.", 500);
  }
}
