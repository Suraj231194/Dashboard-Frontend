import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { DailyReportError, deleteDailyReport, readDailyReport } from "@/modules/production/daily-report";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `viewBeshRecord`. */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.bsehView, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  const { id } = await context.params;
  try {
    const report = await readDailyReport(readId(id));
    if (!report) return apiError("No data found...!!", 404);
    return apiSuccess({ report });
  } catch (error) {
    if (error instanceof DailyReportError) return apiError(error.message, 422);
    console.error("Unable to read the BSEH daily production report", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `deleteBESHRecord`. */
export async function DELETE(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.bsehDelete, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  const { id } = await context.params;
  try {
    const result = await deleteDailyReport(readId(id), guard.user.user_id);
    if (!result.ok) return apiError(result.message, 404);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the BSEH daily production report", error);
    return apiError("Failed to prepare statement.", 500);
  }
}
