import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import { CoaDocumentError } from "@/modules/production/coa-documents";
import { coaSortColumns, listCoaRecords } from "@/modules/production/coa-records";
import { addFgCoaRecord, createFgCoaFromIp, FgCoaError, readFgCoaForm } from "@/modules/production/coa-fg";

export const runtime = "nodejs";

/** `loadFgCoaGenerationRecords`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "fg-coa-generation");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, coaSortColumns("FG"), "coa_fg", "DESC");
    return apiSuccess(await listCoaRecords("FG", query, params.get("workflow_status") ?? ""));
  } catch (error) {
    console.error("Unable to list FG COA records", error);
    return apiError("Error loading data.", 500);
  }
}

/**
 * `createFgCoaFromIp` when the form carries an approved IP COA, and
 * `addFgCoaRecord` for the manual, inventory-mapped entry.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.fgAdd, "You do not have permission to add FG COA records.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const input = readFgCoaForm(data, guard.user.user_id);
    if (input.sourceIpCoaId > 0) {
      const result = await createFgCoaFromIp(input);
      return apiSuccess({ id: result.id, coa_number: result.coa_number }, result.message);
    }
    const result = await addFgCoaRecord(input);
    return apiSuccess({ coa_number: result.coa_number }, result.message);
  } catch (error) {
    if (error instanceof FgCoaError || error instanceof CoaDocumentError) {
      return apiError(error.message, 422);
    }
    console.error("Unable to create the FG COA", error);
    return apiError("Server error occurred.", 500);
  }
}
