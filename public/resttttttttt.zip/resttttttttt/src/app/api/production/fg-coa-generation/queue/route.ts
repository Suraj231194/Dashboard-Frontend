import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listDepartments, listQuantityUnits } from "@/modules/production/coa-records";
import { listFgProducts, listFgQueue } from "@/modules/production/coa-fg";

export const runtime = "nodejs";

/** `fg_queue_list`, with the dropdowns the workspace needs. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "fg-coa-generation");
  if (!guard.ok) return guard.response;
  try {
    const [records, departments, units, products] = await Promise.all([
      listFgQueue(), listDepartments(), listQuantityUnits(), listFgProducts(),
    ]);
    return apiSuccess({ records, total: records.length, departments, units, products });
  } catch (error) {
    console.error("Unable to load the FG COA queue", error);
    return apiError("Error loading data.", 500);
  }
}
