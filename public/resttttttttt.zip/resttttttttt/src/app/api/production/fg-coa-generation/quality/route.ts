import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import { CoaRecordError, setCoaQualityStatus } from "@/modules/production/coa-records";

export const runtime = "nodejs";

/** `set_coa_quality_status` for FG. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.fgEdit, "You do not have permission to edit FG COA records.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await setCoaQualityStatus({
      coaType: "FG",
      recordId: Number.parseInt(String(data.get("record_id") ?? "0"), 10) || 0,
      targetStatus: String(data.get("target_status") ?? ""),
      reason: String(data.get("reason") ?? ""),
      userId: guard.user.user_id,
    });
    return apiSuccess(
      { workflow_status: result.workflow_status, workflow_label: result.workflow_label },
      result.message,
    );
  } catch (error) {
    if (error instanceof CoaRecordError) return apiError(error.message, 422);
    console.error("Unable to change the FG COA quality status", error);
    return apiError("Server error occurred.", 500);
  }
}
