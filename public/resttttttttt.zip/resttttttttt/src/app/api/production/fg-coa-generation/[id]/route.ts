import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import { CoaDocumentError } from "@/modules/production/coa-documents";
import { getCoaRecord } from "@/modules/production/coa-records";
import { deleteFgCoaRecord, FgCoaError, readFgCoaForm, updateFgCoaRecord } from "@/modules/production/coa-fg";

export const runtime = "nodejs";

/** `viewFgCoaRecord` / `fetchFgCOARecord`. */
export async function GET(request: NextRequest, context: RouteContext<"/api/production/fg-coa-generation/[id]">) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.fgView, "You do not have permission to view FG COA records.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Invalid or missing FG COA ID.", 422);
  try {
    const record = await getCoaRecord("FG", id);
    if (!record) return apiError("FG COA record not found.", 404);
    return apiSuccess({ record });
  } catch (error) {
    console.error("Unable to read the FG COA", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `updateFGCoaRecord`. */
export async function PUT(request: NextRequest, context: RouteContext<"/api/production/fg-coa-generation/[id]">) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.fgEdit, "You do not have permission to edit FG COA records.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const input = readFgCoaForm(data, guard.user.user_id);
    const result = await updateFgCoaRecord({ ...input, recordId: id });
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof FgCoaError || error instanceof CoaDocumentError) {
      return apiError(error.message, 422);
    }
    console.error("Unable to update the FG COA", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `deleteFgCoaRecord`, which also releases the inventory COA mapping. */
export async function DELETE(request: NextRequest, context: RouteContext<"/api/production/fg-coa-generation/[id]">) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.fgDelete, "You do not have permission to delete FG COA records.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteFgCoaRecord(id, guard.user.user_id);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof FgCoaError) return apiError(error.message, 422);
    console.error("Unable to delete the FG COA", error);
    return apiError("Server error occurred.", 500);
  }
}
