import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { FgCoaError, listFgInventoryBatches } from "@/modules/production/coa-fg";

export const runtime = "nodejs";

/** `loadFgCoaInventoryBatches`: the un-mapped finished-goods batches. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "fg-coa-generation");
  if (!guard.ok) return guard.response;
  try {
    const productId = Number.parseInt(request.nextUrl.searchParams.get("product_id") ?? "0", 10) || 0;
    return apiSuccess({ batches: await listFgInventoryBatches(productId) });
  } catch (error) {
    if (error instanceof FgCoaError) return apiError(error.message, 422);
    console.error("Unable to load the FG inventory batches", error);
    return apiError("Error loading data.", 500);
  }
}
