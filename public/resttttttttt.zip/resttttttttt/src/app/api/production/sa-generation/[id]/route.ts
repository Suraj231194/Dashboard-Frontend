import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { getSaRecord, listSaUnits } from "@/modules/production/coa-sa";

export const runtime = "nodejs";

/** `fetchSaCoaData`: the record behind the view and approval dialog. */
export async function GET(request: NextRequest, context: RouteContext<"/api/production/sa-generation/[id]">) {
  const guard = await requireApiPageAccess(request, "sa-generation");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const record = await getSaRecord(id);
    if (!record) return apiError("No data found...!!", 404);
    return apiSuccess({ record, units: await listSaUnits() });
  } catch (error) {
    console.error("Unable to read the sampling advice", error);
    return apiError("Server error occurred.", 500);
  }
}
