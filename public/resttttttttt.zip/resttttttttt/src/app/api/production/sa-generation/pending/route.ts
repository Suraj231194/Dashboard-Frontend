import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listPendingSa, pendingSaCount } from "@/modules/production/coa-sa";

export const runtime = "nodejs";

/** `loadIncomingSaGenerationWorkflow`: every pending advice, paged in the browser. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "sa-generation");
  if (!guard.ok) return guard.response;
  try {
    const records = await listPendingSa();
    return apiSuccess({ records, total: records.length, pending_sa_count: await pendingSaCount() });
  } catch (error) {
    console.error("Unable to load the pending sampling advices", error);
    return apiError("Error loading data.", 500);
  }
}
