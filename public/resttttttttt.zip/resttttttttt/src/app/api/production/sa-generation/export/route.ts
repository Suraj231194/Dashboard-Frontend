import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import {
  readExportDateRange, readExportFormat, tableExportResponse, exportPeriodSubtitle,
} from "@/lib/export/table-export";
import { listSaExportRows } from "@/modules/production/coa-sa";

export const runtime = "nodejs";

const COLUMNS = [
  "Product Description", "COA Number", "Supplier", "Status", "Created By", "Approval Date",
] as const;

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "sa-generation");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (format === null) return apiError("Please choose a valid export format.", 422);
    const range = readExportDateRange(data);
    if (!range.ok) return apiError(range.message, 422);

    const selected = data.getAll("columns[]").map((value) => String(value));
    const headers = selected.length > 0
      ? COLUMNS.filter((column) => selected.includes(column))
      : [...COLUMNS];
    if (headers.length === 0) return apiError("Select at least one column to export.", 422);

    const rows = await listSaExportRows(
      String(data.get("status_filter") ?? ""), String(data.get("search") ?? "").trim(),
      range.fromDate, range.toDate,
    );
    if (rows.length === 0) return apiError("No records found", 404);

    return await tableExportResponse({
      format,
      title: "SA Generation",
      filePrefix: "sa_generation",
      headers,
      rows,
      subtitle: exportPeriodSubtitle(range.fromDate, range.toDate, rows.length),
    });
  } catch (error) {
    console.error("Unable to export the sampling advices", error);
    return apiError("Server error occurred.", 500);
  }
}
