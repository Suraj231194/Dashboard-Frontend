import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import {
  listSaRecords, readSaApprovalForm, SA_SORT_COLUMNS, SaError, submitSaApproval,
} from "@/modules/production/coa-sa";

export const runtime = "nodejs";

/** `loadSaCoaData`: the processed sampling advices. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "sa-generation");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, SA_SORT_COLUMNS, "coa.id", "DESC");
    return apiSuccess(await listSaRecords(query, params.get("status_filter") ?? ""));
  } catch (error) {
    console.error("Unable to list sampling advices", error);
    return apiError("Error loading data.", 500);
  }
}

/** `saCoaApprovalFrom`: QA approves or rejects the sampling advice. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "sa-generation");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await submitSaApproval(readSaApprovalForm(data, guard.user.user_id));
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof SaError) return apiError(error.message, 422);
    console.error("Unable to submit the sampling advice", error);
    return apiError("Server error occurred.", 500);
  }
}