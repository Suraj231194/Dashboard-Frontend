import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { BMR_PERMISSIONS, ISSUANCE_EXPORT_COLUMNS } from "@/modules/production/bmr-constants";
import { issuanceExportRows, listIssuance } from "@/modules/production/bmr-issuance";

export const runtime = "nodejs";

/**
 * The issuance export. The current screen builds the CSV in the browser from
 * the decided records; the same rows and the same four columns are produced
 * here so the file does not depend on what the table happens to have paged in.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, BMR_PERMISSIONS.issuanceList, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Select a valid export format.", 422);

    const chosen = data.getAll("listOfColumns[]").map((value) => String(value));
    // No column ticked falls back to all four, as the current export does.
    const headers = chosen.length === 0
      ? [...ISSUANCE_EXPORT_COLUMNS]
      : ISSUANCE_EXPORT_COLUMNS.filter((column) => chosen.includes(column));

    const { records } = await listIssuance();
    const rows = issuanceExportRows(records, String(data.get("search") ?? ""));
    if (rows.length === 0) return apiError("No records found to export.", 422);

    return await tableExportResponse({
      format,
      title: "BMR / BPR Issuance Records",
      filePrefix: "bmr_bpr_issuance_records",
      headers,
      rows,
    });
  } catch (error) {
    console.error("Unable to export the BMR/BPR issuance records", error);
    return apiError("Unable to export the BMR/BPR issuance records.", 500);
  }
}
