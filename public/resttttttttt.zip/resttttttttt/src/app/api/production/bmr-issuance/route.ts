import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { BMR_PERMISSIONS } from "@/modules/production/bmr-constants";
import { BmrRequestError } from "@/modules/production/bmr-requests";
import { listIssuance, reviewBmrRequest } from "@/modules/production/bmr-issuance";

export const runtime = "nodejs";

/** `issuance_list`: the pending queue, the decided records and the counters. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, BMR_PERMISSIONS.issuanceList, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await listIssuance());
  } catch (error) {
    console.error("Unable to load BMR/BPR issuance records", error);
    return apiError("Unable to load BMR/BPR issuance records.", 500);
  }
}

/** `review_request`: the final QA/QC decision on a submitted request. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, BMR_PERMISSIONS.reviewRequest, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const requestId = Number.parseInt(String(data.get("request_id") ?? "0"), 10);
    const result = await reviewBmrRequest({
      requestId: Number.isInteger(requestId) && requestId > 0 ? requestId : 0,
      decision: String(data.get("decision") ?? ""),
      comments: String(data.get("comments") ?? "").trim(),
      userId: guard.user.user_id,
    });
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof BmrRequestError) return apiError(error.message, 422);
    console.error("Unable to save the BMR/BPR issuance decision", error);
    return apiError("The BMR/BPR workflow action could not be completed.", 500);
  }
}
