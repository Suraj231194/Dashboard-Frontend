import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listTemplateLookups } from "@/modules/production/bmr-templates";

export const runtime = "nodejs";

/** The department, header and footer dropdowns the create dialog fills. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "bmr");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await listTemplateLookups());
  } catch (error) {
    console.error("Unable to load the BMR template options", error);
    return apiError("Unable to load the BMR template options.", 500);
  }
}
