import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { previewBmrTemplate } from "@/modules/production/bmr-templates";

export const runtime = "nodejs";

/** `previewBMRTemplate`: the generated layout, as data rather than raw HTML. */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPageAccess(request, "bmr");
  if (!guard.ok) return guard.response;
  try {
    const { id } = await context.params;
    const preview = await previewBmrTemplate(readId(id));
    if (!preview) return apiError("The BMR template could not be found.", 404);
    return apiSuccess({ preview });
  } catch (error) {
    console.error("Unable to preview the BMR template", error);
    return apiError("Unable to preview the BMR template.", 500);
  }
}
