import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import {
  BmrTemplateError, TEMPLATE_SORT_COLUMNS, listBmrTemplates, readOptionalId,
  readTemplateSections, saveBmrTemplate,
} from "@/modules/production/bmr-templates";

export const runtime = "nodejs";

/**
 * `loadBmrTemplates`. The current handler carries no permission check of its
 * own, so the endpoint is guarded by the permission that guards the screen.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "bmr");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(
      request.nextUrl.searchParams, TEMPLATE_SORT_COLUMNS, "bmrtmp.product_name", "DESC");
    return apiSuccess(await listBmrTemplates(query));
  } catch (error) {
    console.error("Unable to load the BMR templates", error);
    return apiError("Unable to load the BMR templates.", 500);
  }
}

/** `saveBmrTemplate`: the template, its sections and everything inside them. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "bmr");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await saveBmrTemplate({
      productName: String(data.get("product_name") ?? ""),
      templateName: String(data.get("template_name") ?? ""),
      department: readOptionalId(data.get("department")),
      header: readOptionalId(data.get("header")),
      footer: readOptionalId(data.get("footer")),
      sections: readTemplateSections(data),
      userId: guard.user.user_id,
    });
    return apiSuccess({ id: result.id }, result.message);
  } catch (error) {
    if (error instanceof BmrTemplateError) return apiError(error.message, 422);
    console.error("Unable to save the BMR template", error);
    return apiError("Unable to save the BMR template.", 500);
  }
}
