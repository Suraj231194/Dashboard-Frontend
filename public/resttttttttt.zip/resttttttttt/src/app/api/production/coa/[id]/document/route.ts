import { NextRequest } from "next/server";
import type { RowDataPacket } from "mysql2";
import { queryOne } from "@/lib/db/query";
import { documentError, documentId, documentPage, requireDocumentPermission } from "@/lib/documents/document-page";
import { CoaDocumentError, loadSavedForm, normaliseCoaType } from "@/modules/production/coa-documents";
import { renderCoaDocument, safeDocumentName } from "@/modules/production/coa-render";

export const runtime = "nodejs";

/**
 * The structured IP/FG COA document (`pages/coa_record_template.php`).
 * `?type=IP|FG`; `?download=1` opens the print dialog, where the current
 * template streams a PDF.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/production/coa/[id]/document">) {
  const params = request.nextUrl.searchParams;
  let coaType: "IP" | "FG";
  try {
    coaType = normaliseCoaType(params.get("type") ?? "");
  } catch {
    return documentError("A valid COA type is required.", 422);
  }

  const guard = await requireDocumentPermission([coaType === "IP" ? "ip_coa_generation_view" : "fg_coa_generation_view"]);
  if (!guard.ok) return guard.response;

  const recordId = documentId((await context.params).id);
  if (recordId === 0) return documentError("A valid document ID is required.", 422);

  const table = coaType === "IP" ? "ip_coa_generation" : "fg_coa_generation";
  const existing = await queryOne<RowDataPacket>(
    `SELECT coa_template_id, template_snapshot_id FROM ${table} WHERE id = ? AND deleted_at IS NULL LIMIT 1`,
    [recordId],
  );
  if (!existing) return documentError("COA record not found.", 404);
  if (Number(existing.coa_template_id ?? 0) <= 0 && Number(existing.template_snapshot_id ?? 0) <= 0) {
    return documentError("This record does not contain a structured COA document.", 422);
  }

  let bodyHtml: string;
  let title: string;
  try {
    const form = await loadSavedForm(coaType, recordId);
    bodyHtml = renderCoaDocument(form, false);
    if (bodyHtml === "") throw new CoaDocumentError("The structured COA document could not be rendered.");
    const productName = String(form.profile.product_name ?? "Record");
    const batch = String(form.source_values.batch_number ?? recordId);
    title = safeDocumentName(`${coaType}_COA_${productName}_${batch}`, `${coaType}_COA_Record`);
  } catch (error) {
    if (error instanceof CoaDocumentError) return documentError(error.message, 422);
    console.error(`Unable to render ${coaType} COA ${recordId}`, error);
    // The current template echoes the raw exception; a database message is not
    // something to show a reader, so it is logged and a plain one shown instead.
    return documentError("The structured COA document could not be rendered.", 422);
  }

  return documentPage({ title, bodyHtml, print: params.get("download") === "1" });
}
