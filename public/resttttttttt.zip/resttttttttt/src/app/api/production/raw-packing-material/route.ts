import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import {
  RmPmError, createCoaRecords, listCoaRecords, type BifurcatedInput, type CoaCreateRow,
} from "@/modules/production/raw-packing-material";
import { PRODUCTION_PERMISSIONS, RMPM_SORT_COLUMNS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `loadCoaRmPmTable`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.rmpmView, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, RMPM_SORT_COLUMNS, "c.id", "DESC");
    return apiSuccess(await listCoaRecords({
      page: query.page,
      perPage: query.perPage,
      search: query.search,
      sortColumn: query.sortColumn,
      sortDirection: query.sortDirection,
    }));
  } catch (error) {
    console.error("Unable to load the RM/PM COA records", error);
    return apiError("Error loading data.", 500);
  }
}

/** `createCoaRmPm`: one or more COA rows with their bifurcated sub-products. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.rmpmAdd, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    let rows: CoaCreateRow[] = [];
    try {
      const parsed: unknown = JSON.parse(String(data.get("rows") ?? "[]"));
      if (Array.isArray(parsed)) {
        rows = (parsed as CoaCreateRow[]).map((row) => ({
          ...row,
          bifurcated: Array.isArray(row.bifurcated) ? (row.bifurcated as BifurcatedInput[]) : [],
        }));
      }
    } catch {
      return apiError("Server error occurred.", 422);
    }
    const result = await createCoaRecords(rows, guard.user.user_id);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof RmPmError) return apiError(error.message, 422);
    console.error("Unable to create the RM/PM COA records", error);
    return apiError("Server error occurred.", 500);
  }
}
