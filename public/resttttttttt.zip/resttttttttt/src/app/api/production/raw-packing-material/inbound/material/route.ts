import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readInboundMaterialForCoa } from "@/modules/production/raw-packing-material";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `fetchInboundMaterialForCoa`: the receipt the COA form is filled from. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.rmpmAdd, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const found = await readInboundMaterialForCoa({
      queueId: Number.parseInt(params.get("id") ?? "0", 10) || 0,
      stockInwardId: Number.parseInt(params.get("stock_inward_id") ?? "0", 10) || 0,
    });
    if (!found) return apiError("Material request not found.", 404);
    return apiSuccess(found);
  } catch (error) {
    console.error("Unable to read the inbound material", error);
    return apiError("Unable to fetch inbound material for COA.", 500);
  }
}
