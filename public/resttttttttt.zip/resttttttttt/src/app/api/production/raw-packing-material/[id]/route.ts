import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { RmPmError, readCoaRecord, updateCoaRecord } from "@/modules/production/raw-packing-material";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `fetchRmPmData` / `fetchRecordRmPmData`. */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.rmpmView, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  const { id } = await context.params;
  try {
    const found = await readCoaRecord(readId(id));
    if (!found) return apiError("No data found...!!", 404);
    return apiSuccess(found);
  } catch (error) {
    if (error instanceof RmPmError) return apiError(error.message, 422);
    console.error("Unable to read the RM/PM COA record", error);
    return apiError("Invalid server response.", 500);
  }
}

/** `updateRmPmRecord`. */
export async function PUT(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.rmpmEdit, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  const { id } = await context.params;
  try {
    const data = await request.formData();
    const value = (key: string) => String(data.get(key) ?? "").trim();
    let bifurcated: { id: string; productName: string; packCount: string; packSize: string; packUnit: string }[] = [];
    try {
      const parsed: unknown = JSON.parse(String(data.get("bifurcated") ?? "[]"));
      if (Array.isArray(parsed)) {
        bifurcated = parsed as typeof bifurcated;
      }
    } catch {
      return apiError("Missing or invalid input.", 422);
    }
    const result = await updateCoaRecord({
      id: readId(id),
      productDesc: value("productDesc"),
      batchNumber: value("batchNumber"),
      batchQty: Number.parseFloat(value("batchQty")) || 0,
      batchSize: value("batchSize"),
      batchSizeUnit: Number.parseInt(value("batchSizeUnit"), 10) || 0,
      testingDate: value("testingDate"),
      suplierName: value("suplierName"),
      manufacturerName: value("manufacturerName"),
      invoiceNumber: value("invoiceNumber"),
      invoiceDate: value("invoiceDate"),
      materialCodeNumber: value("materialCodeNumber"),
      receiptDate: value("receiptgDate"),
      numberOfContainerReceived: value("numberOfContainerReceived"),
      mfgDate: value("mfgDate"),
      expiryDate: value("expiryDate"),
      storageCondition: value("storageCondition"),
      remarksOne: value("remarksOne"),
      sampledContainer: value("sampledContainer"),
      qauntitySampled: Number.parseFloat(value("qauntitySampled")) || 0,
      qauntitySampledUnit: Number.parseInt(value("qauntitySampledUnit"), 10) || 0,
      bifurcated,
      updatedBy: guard.user.user_id,
    });
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof RmPmError) return apiError(error.message, 422);
    console.error("Unable to update the RM/PM COA record", error);
    return apiError("Server error occurred.", 500);
  }
}
