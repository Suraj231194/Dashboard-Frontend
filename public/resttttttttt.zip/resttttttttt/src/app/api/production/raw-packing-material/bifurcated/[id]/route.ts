import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { deleteBifurcatedItem } from "@/modules/production/raw-packing-material";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `deleteBifurcationItemsRecord`. */
export async function DELETE(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.rmpmEdit, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  const { id } = await context.params;
  try {
    const result = await deleteBifurcatedItem(readId(id), guard.user.user_id);
    if (!result.ok) return apiError(result.message, 404);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the bifurcated item", error);
    return apiError("Failed to prepare statement.", 500);
  }
}
