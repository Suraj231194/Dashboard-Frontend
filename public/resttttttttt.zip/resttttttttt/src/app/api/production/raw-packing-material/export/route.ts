import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { buildCoaExport } from "@/modules/production/raw-packing-material";
import { PRODUCTION_PERMISSIONS, RMPM_SORT_COLUMNS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** The chosen columns of the COA list as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.rmpmView, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const requested = String(data.get("sort_column") ?? "");
    const direction = String(data.get("sort_order") ?? "DESC").toUpperCase() === "ASC" ? "ASC" : "DESC";
    const result = await buildCoaExport({
      search: String(data.get("search") ?? "").trim(),
      sortColumn: (RMPM_SORT_COLUMNS as readonly string[]).includes(requested) ? requested : "c.id",
      sortDirection: direction,
      page: Number.parseInt(String(data.get("page") ?? "1"), 10) || 1,
      perPage: Number.parseInt(String(data.get("perPage") ?? "10"), 10) || 10,
      columns: data.getAll("listOfColumns[]").map((value) => String(value)),
    });
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "Raw Material / Packing Material", filePrefix: "rm_pm_coa",
      headers: result.columns, rows: result.rows,
    });
  } catch (error) {
    console.error("Unable to export the RM/PM COA records", error);
    return apiError("Server error occurred.", 500);
  }
}
