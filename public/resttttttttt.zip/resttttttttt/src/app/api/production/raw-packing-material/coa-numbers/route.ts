import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import {
  RmPmError, listActiveUnits, previewCoaNumber, readExistingCoaNumbers,
} from "@/modules/production/raw-packing-material";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/**
 * `existingCoaRmPmFetch` and the standard units the Add form needs; a `type`
 * parameter answers `previewInboundCoaNumber` instead.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.rmpmView, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const type = request.nextUrl.searchParams.get("type");
    if (type !== null) return apiSuccess(await previewCoaNumber(type.toUpperCase()));
    const [numbers, units] = await Promise.all([readExistingCoaNumbers(), listActiveUnits()]);
    return apiSuccess({ numbers, units });
  } catch (error) {
    if (error instanceof RmPmError) return apiError(error.message, 422);
    console.error("Unable to read the COA numbers", error);
    return apiError("Server error occurred.", 500);
  }
}
