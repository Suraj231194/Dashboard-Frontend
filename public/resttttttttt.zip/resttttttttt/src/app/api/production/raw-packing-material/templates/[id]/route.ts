import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { RmPmError, listTemplateFields } from "@/modules/production/raw-packing-material";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `fetchTemplateFields`. */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.rmpmAdd, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  const { id } = await context.params;
  try {
    return apiSuccess({ fields: await listTemplateFields(readId(id)) });
  } catch (error) {
    if (error instanceof RmPmError) return apiError(error.message, 404);
    console.error("Unable to read the COA template fields", error);
    return apiError("Unable to load template fields.", 500);
  }
}
