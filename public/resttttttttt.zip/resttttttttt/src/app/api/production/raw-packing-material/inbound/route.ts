import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { RmPmError, listInboundMaterials, submitInboundCoa } from "@/modules/production/raw-packing-material";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `loadQaInboundMaterials`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.rmpmView, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    return apiSuccess(await listInboundMaterials({
      page: Number.parseInt(params.get("page") ?? "1", 10) || 1,
      perPage: Number.parseInt(params.get("per_page") ?? "10", 10) || 10,
      search: params.get("search") ?? "",
    }));
  } catch (error) {
    console.error("Unable to load the inbound materials", error);
    return apiError("Unable to load inbound materials.", 500);
  }
}

/** `submitInboundCoa`. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.rmpmAdd, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const value = (key: string) => String(data.get(key) ?? "").trim();
    let observations: {
      srNo: string; tableHead: string; parameter: string; specification: string; observation: string;
    }[] = [];
    try {
      const parsed: unknown = JSON.parse(String(data.get("observations") ?? "[]"));
      if (Array.isArray(parsed)) observations = parsed as typeof observations;
    } catch {
      return apiError("COA generation failed.", 422);
    }
    const result = await submitInboundCoa({
      queueId: Number.parseInt(value("inbound_queue_id"), 10) || 0,
      stockInwardId: Number.parseInt(value("stock_inward_id"), 10) || 0,
      type: value("type") || "RM",
      name: value("name"),
      batchNumber: value("batch_number"),
      batchQty: Number.parseFloat(value("batch_qty")) || 0,
      batchSize: value("batch_size"),
      batchUnitId: Number.parseInt(value("batch_unit_id"), 10) || 0,
      testingDate: value("testing_date"),
      suplierName: value("suplier_name"),
      manufacturerName: value("manufacturer_name"),
      invoiceNumber: value("invoice_number"),
      invoiceDate: value("invoice_date"),
      materialCodeNo: value("material_code_no"),
      receiptDate: value("receipt_date"),
      numberOfContainerReceived: value("number_of_container_received"),
      mfgDate: value("mfg_date"),
      expiryDate: value("expiry_date"),
      storageCondition: value("storage_condition"),
      remarkOne: value("remark_one"),
      coaTemplateId: Number.parseInt(value("coa_template_id"), 10) || 0,
      observations,
      createdBy: guard.user.user_id,
    });
    return apiSuccess({ coa_number: result.coa_number, coa_id: result.coa_id }, result.message);
  } catch (error) {
    if (error instanceof RmPmError) return apiError(error.message, 422);
    console.error("Unable to generate the inbound COA", error);
    return apiError("COA generation failed.", 500);
  }
}
