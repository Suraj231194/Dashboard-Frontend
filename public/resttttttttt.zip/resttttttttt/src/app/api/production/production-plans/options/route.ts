import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import {
  listPlanProducts, listStandardUnits, searchFinishedProducts,
} from "@/modules/production/production-plans";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/**
 * `loadAllProductsForPlan` and `getQtyUnits`, which the add form loads
 * together. A `term` parameter switches to `getFinishedProductsWithBom`, the
 * search behind the BOM dialog picker.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.planView, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const term = request.nextUrl.searchParams.get("term");
    if (term !== null) {
      return apiSuccess({ results: await searchFinishedProducts(term.trim()) });
    }
    const [products, units] = await Promise.all([listPlanProducts(), listStandardUnits()]);
    return apiSuccess({ products, units });
  } catch (error) {
    console.error("Unable to load the production plan options", error);
    return apiError("Server error occurred.", 500);
  }
}
