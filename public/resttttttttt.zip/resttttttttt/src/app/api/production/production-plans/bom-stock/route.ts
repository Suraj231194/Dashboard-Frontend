import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { checkPlanBomStock } from "@/modules/production/production-plans";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `checkBomStock`: the availability table behind Check BOM and Stock. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.planAdd, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const bomId = Number.parseInt(String(data.get("bom_id") ?? "0"), 10) || 0;
    const batchSize = Number.parseFloat(String(data.get("batch_size") ?? "0")) || 0;
    const result = await checkPlanBomStock(bomId, batchSize);
    return apiSuccess({ check: result }, result.message ?? "");
  } catch (error) {
    console.error("Unable to check the BOM stock", error);
    return apiError("Server error occurred.", 500);
  }
}
