import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import {
  PlanError, deleteProductionPlan, readPlanEditForm, updateProductionPlan,
} from "@/modules/production/production-plans";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `fetchProductionPlanRecord`: the edit form and its dropdowns. */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.planEdit, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  const { id } = await context.params;
  try {
    const plan = await readPlanEditForm(readId(id));
    if (!plan) return apiError("No data found...!!", 404);
    return apiSuccess({ plan });
  } catch (error) {
    if (error instanceof PlanError) return apiError(error.message, 422);
    console.error("Unable to read the production plan", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `updateProductionPlan`. */
export async function PUT(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.planEdit, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  const { id } = await context.params;
  try {
    const data = await request.formData();
    const number = (key: string) => Number.parseFloat(String(data.get(key) ?? "0")) || 0;
    const whole = (key: string) => Number.parseInt(String(data.get(key) ?? "0"), 10) || 0;
    const result = await updateProductionPlan({
      planId: readId(id),
      dateEntry: String(data.get("dateEntryEdit") ?? "").trim(),
      productName: String(data.get("productNameEdit") ?? "").trim(),
      batchSize: number("prodPlanBatchSizeEdit"),
      batchSizeUnit: whole("prodPlanBatchSizeUnitEdit"),
      bomMasterId: whole("prodPlanBomEdit"),
      timelineStatus: whole("timelineStatusEdit"),
      remark: String(data.get("prodPlanRemarkEdit") ?? "").trim(),
      additionalProductId: whole("additionalProductId"),
      additionalBatchSize: number("additionalBatchSize"),
      additionalBatchUnit: whole("additionalBatchUnit"),
      updatedBy: guard.user.user_id,
    });
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof PlanError) return apiError(error.message, 422);
    console.error("Unable to update the production plan", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `deleteProductionPlanRecord`. */
export async function DELETE(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.planDelete, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  const { id } = await context.params;
  try {
    const result = await deleteProductionPlan(readId(id), guard.user.user_id);
    if (!result.ok) return apiError(result.message, 404);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the production plan", error);
    return apiError("Failed to prepare statement.", 500);
  }
}
