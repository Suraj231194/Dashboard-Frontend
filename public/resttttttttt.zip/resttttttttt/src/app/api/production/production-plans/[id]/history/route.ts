import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { PlanError, readPlanHistory } from "@/modules/production/production-plans";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `productionPlanHistoryViewRecord`: the plan timeline. */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.planView, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  const { id } = await context.params;
  try {
    return apiSuccess({ steps: await readPlanHistory(readId(id)) });
  } catch (error) {
    if (error instanceof PlanError) return apiError(error.message, 422);
    console.error("Unable to read the production plan history", error);
    return apiError("Server error occurred.", 500);
  }
}
