import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { PlanError, createProductionPlanFromBom } from "@/modules/production/production-plans";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `addProductionPlanBom`: the plan raised from a checked BOM. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.planAdd, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createProductionPlanFromBom({
      dateEntry: String(data.get("dateEntryBom") ?? "").trim(),
      productName: String(data.get("productNameBom") ?? "").trim(),
      bomId: Number.parseInt(String(data.get("bom_id") ?? "0"), 10) || 0,
      finishedProductId: Number.parseInt(String(data.get("finishedProductId") ?? "0"), 10) || 0,
      batchSize: Number.parseFloat(String(data.get("prodPlanBatchSizeBom") ?? "0")) || 0,
      batchUnit: Number.parseInt(String(data.get("prodPlanBatchSizeUnitBom") ?? "0"), 10) || 0,
      timelineStatus: Number.parseInt(String(data.get("timelineStatusBom") ?? "0"), 10) || 0,
      remark: String(data.get("prodPlanRemarkBom") ?? "").trim(),
      createdBy: guard.user.user_id,
    });
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof PlanError) return apiError(error.message, 422);
    console.error("Unable to create the production plan from the BOM", error);
    return apiError("Server error occurred.", 500);
  }
}
