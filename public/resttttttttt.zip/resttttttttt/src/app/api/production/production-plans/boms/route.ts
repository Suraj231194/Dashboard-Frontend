import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { listApprovedBoms } from "@/modules/production/production-plans";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `loadBomList`: the approved BOMs of one BOM type. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.planView, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const bomType = Number.parseInt(request.nextUrl.searchParams.get("bom_type") ?? "0", 10) || 0;
    return apiSuccess({ boms: await listApprovedBoms(bomType) });
  } catch (error) {
    console.error("Unable to load the BOM list", error);
    return apiError("Server error occurred.", 500);
  }
}
