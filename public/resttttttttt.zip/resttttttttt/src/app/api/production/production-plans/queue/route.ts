import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import {
  PlanError, acceptProductionPlan, listNewProductionPlanQueue,
} from "@/modules/production/production-plans";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `loadNewProductionPlans` with the production context. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.planView, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const page = Number.parseInt(request.nextUrl.searchParams.get("page") ?? "1", 10) || 1;
    return apiSuccess(await listNewProductionPlanQueue(page));
  } catch (error) {
    console.error("Unable to load the new production plan queue", error);
    return apiError("Unable to load new production plans.", 500);
  }
}

/** `acceptProductionPlan`. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.planEdit, "You do not have permission to accept production plans.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await acceptProductionPlan({
      planId: Number.parseInt(String(data.get("plan_id") ?? "0"), 10) || 0,
      planDate: String(data.get("plan_date") ?? "").trim(),
      timeline: Number.parseInt(String(data.get("timeline") ?? "0"), 10) || 0,
      remarks: String(data.get("remarks") ?? "").trim(),
      userId: guard.user.user_id,
    });
    return apiSuccess({ plan_id: result.planId }, result.message);
  } catch (error) {
    if (error instanceof PlanError) return apiError(error.message, 422);
    console.error("Unable to accept the production plan", error);
    return apiError("Server error while accepting the production plan.", 500);
  }
}
