import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listDepartments, listQuantityUnits } from "@/modules/production/coa-records";
import { listIpQueue } from "@/modules/production/coa-ip";

export const runtime = "nodejs";

/** `ip_queue_list`, with the dropdowns the workspace needs. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "ip-coa-generation");
  if (!guard.ok) return guard.response;
  try {
    const [records, departments, units] = await Promise.all([
      listIpQueue(), listDepartments(), listQuantityUnits(),
    ]);
    return apiSuccess({ records, total: records.length, departments, units });
  } catch (error) {
    console.error("Unable to load the IP COA queue", error);
    return apiError("Error loading data.", 500);
  }
}
