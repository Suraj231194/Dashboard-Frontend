import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import { CoaDocumentError } from "@/modules/production/coa-documents";
import { getCoaRecord } from "@/modules/production/coa-records";
import {
  deleteIpCoaRecord, IpCoaError, readIpCoaUpdateForm, updateIpCoaRecord,
} from "@/modules/production/coa-ip";

export const runtime = "nodejs";

/** `viewIpCoaRecord` / `fetchIpCOARecord`. */
export async function GET(request: NextRequest, context: RouteContext<"/api/production/ip-coa-generation/[id]">) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.ipView, "You do not have permission to view IP COA records.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Invalid or missing IP COA ID.", 422);
  try {
    const record = await getCoaRecord("IP", id);
    if (!record) return apiError("IP COA record not found.", 404);
    return apiSuccess({ record });
  } catch (error) {
    console.error("Unable to read the IP COA", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `updateIpCoaRecord`. */
export async function PUT(request: NextRequest, context: RouteContext<"/api/production/ip-coa-generation/[id]">) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.ipEdit, "You do not have permission to edit IP COA records.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const input = readIpCoaUpdateForm(data, guard.user.user_id);
    const result = await updateIpCoaRecord({ ...input, recordId: id });
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof IpCoaError || error instanceof CoaDocumentError) {
      return apiError(error.message, 422);
    }
    console.error("Unable to update the IP COA", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `deleteIpCoaRecord`. */
export async function DELETE(request: NextRequest, context: RouteContext<"/api/production/ip-coa-generation/[id]">) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.ipDelete, "You do not have permission to delete IP COA records.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteIpCoaRecord(id, guard.user.user_id);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof IpCoaError) return apiError(error.message, 422);
    console.error("Unable to delete the IP COA", error);
    return apiError("Server error occurred.", 500);
  }
}
