import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import { CoaDocumentError } from "@/modules/production/coa-documents";
import { IpCoaError, openMappedIpTemplate, openSavedIpTemplate } from "@/modules/production/coa-ip";

export const runtime = "nodejs";

/** `open_saved_template`: the document of a draft being resumed. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.ipEdit, "You do not have permission to edit IP COA records.");
  if (!guard.ok) return guard.response;
  try {
    const recordId = Number.parseInt(request.nextUrl.searchParams.get("record_id") ?? "0", 10) || 0;
    if (recordId <= 0) return apiError("The COA draft is no longer available.", 422);
    return apiSuccess(await openSavedIpTemplate(recordId));
  } catch (error) {
    if (error instanceof IpCoaError || error instanceof CoaDocumentError) {
      return apiError(error.message, 422);
    }
    console.error("Unable to open the saved IP COA document", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `open_mapped_template`: the controlled document for a queued BMR. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.ipAdd, "You do not have permission to add IP COA records.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const raw = (key: string) => String(data.get(key) ?? "").trim();
    return apiSuccess(await openMappedIpTemplate({
      sourceId: Number.parseInt(raw("source_id"), 10) || 0,
      testingDate: raw("testing_date"),
      templateId: Number.parseInt(raw("template_id"), 10) || 0,
      familyKey: raw("family_key"),
      saveMapping: raw("save_mapping") === "1",
      userId: guard.user.user_id,
    }));
  } catch (error) {
    if (error instanceof IpCoaError || error instanceof CoaDocumentError) {
      return apiError(error.message, 422);
    }
    console.error("Unable to open the IP COA document", error);
    return apiError("Server error occurred.", 500);
  }
}
