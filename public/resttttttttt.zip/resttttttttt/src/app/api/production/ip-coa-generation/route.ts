import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { COA_PERMISSIONS } from "@/modules/production/coa-constants";
import { CoaDocumentError } from "@/modules/production/coa-documents";
import { coaSortColumns, listCoaRecords } from "@/modules/production/coa-records";
import {
  addIpCoaRecord, createIpCoaFromBmr, IpCoaError, readIpCoaForm, readIpCoaManualForm,
} from "@/modules/production/coa-ip";

export const runtime = "nodejs";

/** `loadIpCoaGenerationRecords`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "ip-coa-generation");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, coaSortColumns("IP"), "coa_ip", "DESC");
    return apiSuccess(await listCoaRecords("IP", query, params.get("workflow_status") ?? ""));
  } catch (error) {
    console.error("Unable to list IP COA records", error);
    return apiError("Error loading data.", 500);
  }
}

/**
 * `createIpCoaFromBmr` when the form carries a queued BMR work item, and
 * `addIpCoaRecord` for the manual entry the toolbar offers.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, COA_PERMISSIONS.ipAdd, "You do not have permission to add IP COA records.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const sourceId = Number.parseInt(String(data.get("source_work_item_id") ?? "0"), 10) || 0;
    if (sourceId > 0) {
      const result = await createIpCoaFromBmr(readIpCoaForm(data, guard.user.user_id));
      return apiSuccess({ id: result.id, coa_number: result.coa_number }, result.message);
    }
    const result = await addIpCoaRecord(readIpCoaManualForm(data, guard.user.user_id));
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof IpCoaError || error instanceof CoaDocumentError) {
      return apiError(error.message, 422);
    }
    console.error("Unable to create the IP COA", error);
    return apiError("Server error occurred.", 500);
  }
}
