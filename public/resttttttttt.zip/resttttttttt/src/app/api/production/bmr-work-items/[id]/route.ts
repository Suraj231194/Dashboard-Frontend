import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { BMR_PERMISSIONS } from "@/modules/production/bmr-constants";
import { BmrRequestError } from "@/modules/production/bmr-requests";
import { openWorkItem, updateWorkItem } from "@/modules/production/bmr-production";

export const runtime = "nodejs";

type Context = { params: Promise<{ id: string }> };

/** `open_work_item`: claims the record and returns the controlled form. */
export async function POST(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, BMR_PERMISSIONS.manageWorkItem, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const { id } = await context.params;
    return apiSuccess(await openWorkItem(readId(id), guard.user.user_id));
  } catch (error) {
    if (error instanceof BmrRequestError) return apiError(error.message, 422);
    console.error("Unable to open the BMR/BPR work item", error);
    return apiError("The BMR/BPR workflow action could not be completed.", 500);
  }
}

/** `update_work_item`: saves a draft or submits the completed record. */
export async function PUT(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, BMR_PERMISSIONS.manageWorkItem, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const { id } = await context.params;
    const data = await request.formData();
    const result = await updateWorkItem({
      workItemId: readId(id),
      recordAction: String(data.get("record_action") ?? ""),
      formPayload: String(data.get("form_payload") ?? ""),
      userId: guard.user.user_id,
    });
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof BmrRequestError) return apiError(error.message, 422);
    console.error("Unable to update the BMR/BPR work item", error);
    return apiError("The BMR/BPR workflow action could not be completed.", 500);
  }
}
