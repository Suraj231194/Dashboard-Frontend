import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { BMR_PERMISSIONS, PRODUCTION_EXPORT_COLUMNS } from "@/modules/production/bmr-constants";
import { listProductionRows, productionExportRows } from "@/modules/production/bmr-production";

export const runtime = "nodejs";

/**
 * `exportProductionBmrBpr` (`exportajax.php:2764`) — the one export on these
 * three screens that the server builds. The current handler runs with no
 * permission check at all; the list permission is required here instead.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, BMR_PERMISSIONS.productionList, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Select a valid export format.", 422);

    const chosen = data.getAll("listOfColumns[]").map((value) => String(value));
    const headers = chosen.length === 0
      ? [...PRODUCTION_EXPORT_COLUMNS]
      : PRODUCTION_EXPORT_COLUMNS.filter((column) => chosen.includes(column));

    const rows = productionExportRows(
      await listProductionRows(),
      String(data.get("search") ?? ""),
      String(data.get("selectedFormType") ?? ""),
    );
    if (rows.length === 0) return apiError("No records found to export.", 422);

    return await tableExportResponse({
      format,
      title: "Production BMR / BPR Records",
      filePrefix: "production_bmr_bpr",
      headers,
      rows,
    });
  } catch (error) {
    console.error("Unable to export the Production BMR/BPR records", error);
    return apiError("Unable to export the Production BMR/BPR records.", 500);
  }
}
