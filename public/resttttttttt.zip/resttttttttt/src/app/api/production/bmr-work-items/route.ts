import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { BMR_PERMISSIONS } from "@/modules/production/bmr-constants";
import { listProduction } from "@/modules/production/bmr-production";

export const runtime = "nodejs";

/** `production_list`: every work item, the two incoming queues and the counts. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, BMR_PERMISSIONS.productionList, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await listProduction());
  } catch (error) {
    console.error("Unable to load Production BMR/BPR records", error);
    return apiError("Unable to load Production BMR/BPR records.", 500);
  }
}
