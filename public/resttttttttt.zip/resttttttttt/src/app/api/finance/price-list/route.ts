import { NextRequest } from "next/server";
import { requireApiPageAccess } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { listPriceCatalog, savePriceCatalogItem } from "@/modules/finance/price-list";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "pricelist-catalog");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    return apiSuccess(await listPriceCatalog({
      page: Number.parseInt(params.get("page") ?? "1", 10) || 1,
      perPage: Number.parseInt(params.get("per_page") ?? "50", 10) || 50,
      search: (params.get("search") ?? "").trim(),
      categoryId: Number.parseInt(params.get("category_id") ?? "0", 10) || 0,
    }));
  } catch (error) {
    console.error("Unable to load the price catalog", error);
    return apiError("Unable to load catalog.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "pricelist-catalog");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await savePriceCatalogItem({
      productId: Number.parseInt(String(data.get("product_id") ?? "0"), 10) || 0,
      hsnCode: String(data.get("hsn_code") ?? ""),
      sellingRate: Number.parseFloat(String(data.get("selling_rate") ?? "0")) || 0,
      mrp: Number.parseFloat(String(data.get("mrp") ?? "0")) || 0,
      gstRate: Number.parseFloat(String(data.get("gst_rate") ?? "0")) || 0,
      effectiveFrom: String(data.get("effective_from") ?? ""),
      userId: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to save product pricing", error);
    return apiError("Server error occurred.", 500);
  }
}
