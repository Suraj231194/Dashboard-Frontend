import { NextRequest } from "next/server";
import { requireApiPageAccess } from "@/lib/http/guard";
import { apiError } from "@/lib/http/json";
import { serializeCsv } from "@/lib/csv";
import { listAllPriceCatalog } from "@/modules/finance/price-list";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "pricelist-catalog");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const rows = await listAllPriceCatalog(
      (params.get("search") ?? "").trim(),
      Number.parseInt(params.get("category_id") ?? "0", 10) || 0,
    );
    const today = new Date().toISOString().slice(0, 10);
    const lines = [
      ["CAT No", "Product Name", "Category", "HSN Code", "B2B Selling Rate (INR)", "B2C MRP (INR)", "GST %", "Effective Date"],
      ...rows.map((row) => [
        row.product_code, row.product_name, row.category_name || "—", row.hsn_code,
        row.selling_rate.toFixed(2), row.mrp.toFixed(2), row.gst_rate.toFixed(2), row.effective_from || today,
      ]),
    ];
    return new Response(serializeCsv(lines[0], lines.slice(1)), {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="Price_List_Catalog_${today}.csv"`,
      },
    });
  } catch (error) {
    console.error("Unable to export the price catalog", error);
    return apiError("Unable to export the price catalog.", 500);
  }
}
