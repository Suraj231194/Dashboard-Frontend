import { NextRequest } from "next/server";
import { apiError, apiForbidden, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { canAny } from "@/modules/access/permissions";
import {
  listReimbursementClaims, markReimbursementPaid, REIMBURSEMENT_SORT_COLUMNS,
} from "@/modules/finance/reimbursement-claims";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "finance-reimbursement-claims");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, REIMBURSEMENT_SORT_COLUMNS, "id", "DESC");
    return apiSuccess(await listReimbursementClaims(guard.user, query));
  } catch (error) {
    console.error("Unable to list reimbursement claims", error);
    return apiError(error instanceof Error ? error.message : "Unable to load reimbursement claims.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "finance-reimbursement-claims");
  if (!guard.ok) return guard.response;
  if (!(await canAny(guard.user, ["payroll_reimbursements_manage", "finance_reimbursement_claims_manage"]))) {
    return apiForbidden();
  }
  try {
    const data = await request.formData();
    await markReimbursementPaid(guard.user, {
      claimId: Number.parseInt(String(data.get("claim_id") ?? "0"), 10) || 0,
      paymentMode: String(data.get("payment_mode") ?? "").trim(),
      paymentReference: String(data.get("payment_reference") ?? "").trim(),
    });
    return apiSuccess({}, "Reimbursement payment recorded successfully.");
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to record the payment.";
    const validation = message.startsWith("Select ") || message.includes("must not exceed");
    return apiError(message, validation ? 422 : 409);
  }
}
