import { readFile } from "node:fs/promises";
import path from "node:path";
import { NextRequest } from "next/server";
import { requireApiPageAccess, readId } from "@/lib/http/guard";
import { reimbursementReceipt } from "@/modules/finance/reimbursement-claims";

export const runtime = "nodejs";

function safeFileName(value: string): string {
  return value.replace(/[^A-Za-z0-9._-]/g, "_") || "receipt";
}

export async function GET(
  request: NextRequest,
  context: RouteContext<"/api/finance/reimbursement-claims/[id]/receipt">,
) {
  const guard = await requireApiPageAccess(request, "finance-reimbursement-claims");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id <= 0) return new Response("File not found.", { status: 404 });
  try {
    const file = await reimbursementReceipt(guard.user, id);
    if (!file) return new Response("File not found.", { status: 404 });
    const applicationRoot = path.resolve(process.env.LEGACY_APP_ROOT ?? path.resolve(process.cwd(), ".."));
    const adminRoot = path.resolve(process.env.LEGACY_ADMIN_ROOT ?? path.join(applicationRoot, "admin"));
    const payrollRoot = path.resolve(adminRoot, "uploads", "payroll");
    const absolutePath = path.resolve(adminRoot, file.relativePath.replaceAll("/", path.sep));
    if (!absolutePath.startsWith(`${payrollRoot}${path.sep}`)) {
      return new Response("File not found.", { status: 404 });
    }
    const bytes = await readFile(absolutePath);
    const inline = request.nextUrl.searchParams.get("inline") === "1" && file.mimeType === "application/pdf";
    return new Response(bytes, {
      headers: {
        "Content-Type": file.mimeType,
        "Content-Length": String(bytes.byteLength),
        "Content-Disposition": `${inline ? "inline" : "attachment"}; filename="${safeFileName(file.originalName)}"`,
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "SAMEORIGIN",
        "Cache-Control": "private, no-store, max-age=0",
      },
    });
  } catch (error) {
    console.error("Unable to serve reimbursement receipt", error);
    return new Response("The stored file is unavailable.", { status: 404 });
  }
}
