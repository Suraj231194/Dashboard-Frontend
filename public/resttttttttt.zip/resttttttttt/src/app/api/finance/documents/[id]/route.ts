import { NextRequest } from "next/server";
import { apiError, apiForbidden, apiSuccess } from "@/lib/http/json";
import { readId, requireApiSession } from "@/lib/http/guard";
import { canAny } from "@/modules/access/permissions";
import { FINANCE_DOCUMENT_VIEW_PERMISSIONS } from "@/modules/finance/finance-constants";
import { getFinanceDocumentDetail } from "@/modules/finance/finance-documents";

export const runtime = "nodejs";

/**
 * One finance document with its lines (`get_document`,
 * `finance_actions.php:432-456`). A document may be opened from any register
 * that is allowed to see its type, so the guard accepts any one of that type's
 * view permissions rather than a single slug.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/finance/documents/[id]">) {
  const session = await requireApiSession();
  if (!session.ok) return session.response;

  const detail = await getFinanceDocumentDetail(readId((await context.params).id));
  if (!detail) return apiError("Finance document not found.", 404);

  const allowed = FINANCE_DOCUMENT_VIEW_PERMISSIONS[detail.document.document_type] ?? [];
  if (!(await canAny(session.user, allowed))) {
    return apiForbidden("You do not have permission to view this Finance document.");
  }
  return apiSuccess(detail);
}
