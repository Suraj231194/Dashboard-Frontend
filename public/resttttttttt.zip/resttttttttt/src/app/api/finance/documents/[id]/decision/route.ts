import { NextRequest } from "next/server";
import { apiError, apiForbidden, apiSuccess } from "@/lib/http/json";
import { readId, requireApiSession } from "@/lib/http/guard";
import { isSameOrigin } from "@/lib/http/same-origin";
import { roleHasPermission } from "@/modules/access/permissions";
import { FINANCE_DOCUMENT_MANAGE_PERMISSION } from "@/modules/finance/finance-constants";
import { findFinanceDocumentForWrite } from "@/modules/finance/finance-documents";
import {
  classifyVendorBill, financeNumeric, normalisePaymentMode, setDocumentDecision,
} from "@/modules/finance/finance-write";

export const runtime = "nodejs";

/**
 * The decision on one finance document.
 *
 * A vendor bill is classified Paid / Unpaid / Not Sure (`classify_bill`); an
 * invoice or challan is answered Create / Don't / Reopen
 * (`set_document_decision`). Both are guarded by the manage permission of the
 * document's own type, which is what `financeRequireDocumentManage()` does —
 * note that it reads the document first and derives the slug from it, so the
 * order of the checks below matches.
 */
export async function POST(request: NextRequest, context: RouteContext<"/api/finance/documents/[id]/decision">) {
  const session = await requireApiSession();
  if (!session.ok) return session.response;
  if (!isSameOrigin(request)) {
    return apiError("Your session token is invalid. Please refresh the page and try again.", 419);
  }

  const documentId = readId((await context.params).id);
  const document = await findFinanceDocumentForWrite(documentId);
  if (!document) return apiError("Finance document not found.", 404);

  const slug = FINANCE_DOCUMENT_MANAGE_PERMISSION[document.document_type];
  if (!(await roleHasPermission(session.user.user_id, session.user.role_id, slug))) {
    return apiForbidden("You do not have permission to perform this action.");
  }

  const data = await request.formData();
  const decision = String(data.get("decision") ?? "").trim().toUpperCase();

  if (document.document_type === "VENDOR_BILL") {
    if (!["PAID", "UNPAID", "NOT_SURE"].includes(decision)) {
      return apiError("Select Paid, Unpaid or Not Sure.", 422);
    }
    const rawCreditDays = data.get("credit_days");
    const creditDays = rawCreditDays !== null && String(rawCreditDays).trim() !== ""
      && Number.isFinite(Number(rawCreditDays))
      ? Math.max(0, Math.min(365, Number.parseInt(String(rawCreditDays), 10)))
      : null;

    const result = await classifyVendorBill({
      documentId,
      decision: decision as "PAID" | "UNPAID" | "NOT_SURE",
      grandTotal: financeNumeric(data.get("grand_total")),
      documentDate: String(data.get("document_date") ?? "").trim() || null,
      dueDate: String(data.get("due_date") ?? "").trim() || null,
      creditDays,
      notes: String(data.get("notes") ?? "").trim() || null,
      paymentDate: String(data.get("payment_date") ?? "").trim(),
      paymentMode: normalisePaymentMode(data.get("payment_mode")),
      referenceNumber: String(data.get("reference_number") ?? "").trim() || null,
      bankAccountId: Number.parseInt(String(data.get("bank_account_id") ?? "0"), 10) || null,
      userId: session.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status);
    return apiSuccess({ paymentId: result.paymentId }, "Vendor bill classification saved.");
  }

  if (document.document_type !== "SALES_INVOICE" && document.document_type !== "DELIVERY_CHALLAN") {
    return apiError("Invalid document decision.", 422);
  }
  if (!["CREATE", "DONT", "REOPEN"].includes(decision)) {
    return apiError("Invalid document decision.", 422);
  }

  const result = await setDocumentDecision({
    documentId,
    decision: decision as "CREATE" | "DONT" | "REOPEN",
    userId: session.user.user_id,
  });
  if (!result.ok) return apiError(result.message, result.status);
  return apiSuccess({}, "Document decision saved.");
}
