import { NextRequest } from "next/server";
import { apiError, apiForbidden, apiSuccess } from "@/lib/http/json";
import { readId, requireApiSession } from "@/lib/http/guard";
import { isSameOrigin } from "@/lib/http/same-origin";
import { roleHasPermission } from "@/modules/access/permissions";
import { findFinanceDocumentForWrite } from "@/modules/finance/finance-documents";
import {
  financeNumeric, normalisePaymentMode, paymentManagePermission, recordFinancePayment,
} from "@/modules/finance/finance-write";

export const runtime = "nodejs";

/**
 * Records a payment or receipt against one document (`record_payment`,
 * `finance_actions.php:1096-1152`). The permission checked is the register's
 * own — payables for a vendor bill, receivables for a sales invoice — not the
 * bill or invoice generation slug.
 */
export async function POST(request: NextRequest, context: RouteContext<"/api/finance/documents/[id]/payment">) {
  const session = await requireApiSession();
  if (!session.ok) return session.response;
  if (!isSameOrigin(request)) {
    return apiError("Your session token is invalid. Please refresh the page and try again.", 419);
  }

  const documentId = readId((await context.params).id);
  const document = await findFinanceDocumentForWrite(documentId);
  if (!document) return apiError("Finance document not found.", 404);
  if (document.document_type !== "VENDOR_BILL" && document.document_type !== "SALES_INVOICE") {
    return apiError("Payments cannot be allocated to this document.", 422);
  }

  const slug = paymentManagePermission(document.document_type);
  if (!(await roleHasPermission(session.user.user_id, session.user.role_id, slug))) {
    return apiForbidden("You do not have permission to perform this action.");
  }

  const data = await request.formData();
  const result = await recordFinancePayment({
    documentId,
    amount: financeNumeric(data.get("amount")),
    paymentDate: String(data.get("payment_date") ?? "").trim(),
    paymentMode: normalisePaymentMode(data.get("payment_mode")),
    referenceNumber: String(data.get("reference_number") ?? "").trim() || null,
    bankAccountId: Number.parseInt(String(data.get("bank_account_id") ?? "0"), 10) || null,
    notes: String(data.get("notes") ?? "").trim() || null,
    userId: session.user.user_id,
  });
  if (!result.ok) return apiError(result.message, result.status);
  return apiSuccess({ paymentId: result.paymentId }, "Payment recorded successfully.");
}
