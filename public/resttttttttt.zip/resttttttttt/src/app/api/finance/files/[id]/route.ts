import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import type { RowDataPacket } from "mysql2";
import { NextRequest } from "next/server";
import { queryOne } from "@/lib/db/query";
import { readId, requireApiSession } from "@/lib/http/guard";
import { canAny } from "@/modules/access/permissions";
import { FINANCE_DOCUMENT_VIEW_PERMISSIONS, type FinanceDocumentType } from "@/modules/finance/finance-constants";

export const runtime = "nodejs";

/**
 * Serves a stored finance file: a vendor's source invoice, or a generated PDF.
 *
 * This is `admin/financefile.php`. The stored path is relative and historically
 * inconsistent, so the same two roots are tried in the same order (the admin
 * directory, then the project root) and the resolved path must still sit under
 * the project root — that containment check is the whole security of this
 * endpoint and is kept exactly.
 */

interface FinanceFileRow extends RowDataPacket {
  id: number;
  file_path: string;
  original_name: string | null;
  mime_type: string | null;
  document_type: FinanceDocumentType;
}

function safeFileName(value: string): string {
  return value.replace(/[^A-Za-z0-9._-]/g, "_") || "document";
}

/** Resolves a stored path against the roots the current application tries. */
async function resolveStoredFile(storedPath: string): Promise<string | null> {
  const cleaned = storedPath.replaceAll("\\", "/").trim().replace(/^(\.\.\/)+/, "");
  if (cleaned === "") return null;

  const adminRoot = path.resolve(
    process.env.LEGACY_ADMIN_ROOT
    ?? path.join(path.resolve(process.env.LEGACY_APP_ROOT ?? path.resolve(process.cwd(), "..")), "admin"),
  );
  const projectRoot = path.resolve(adminRoot, "..");

  const candidates = /^[A-Za-z]:\//.test(cleaned)
    ? [cleaned]
    : [
      path.resolve(adminRoot, cleaned.replaceAll("/", path.sep)),
      path.resolve(projectRoot, cleaned.replaceAll("/", path.sep)),
    ];

  for (const candidate of candidates) {
    const resolved = path.resolve(candidate);
    // Must stay inside the project root, whatever the stored path claimed.
    if (!resolved.toLowerCase().startsWith(`${projectRoot.toLowerCase()}${path.sep}`)) continue;
    try {
      const info = await stat(resolved);
      if (info.isFile()) return resolved;
    } catch {
      // Try the next root.
    }
  }
  return null;
}

export async function GET(request: NextRequest, context: RouteContext<"/api/finance/files/[id]">) {
  const session = await requireApiSession();
  if (!session.ok) return session.response;

  const fileId = readId((await context.params).id);
  if (fileId <= 0) return new Response("File not found.", { status: 404 });

  try {
    const file = await queryOne<FinanceFileRow>(
      `SELECT fdf.*, fd.document_type
         FROM finance_document_files fdf
         JOIN finance_documents fd ON fd.id = fdf.document_id
         WHERE fdf.id = ? AND fd.deleted_at IS NULL
         LIMIT 1`,
      [fileId],
    );
    if (!file) return new Response("File not found.", { status: 404 });

    const allowed = FINANCE_DOCUMENT_VIEW_PERMISSIONS[file.document_type] ?? [];
    if (!(await canAny(session.user, allowed))) {
      return new Response("Access denied.", { status: 403 });
    }

    const resolved = await resolveStoredFile(file.file_path);
    if (!resolved) return new Response("The stored Finance file is unavailable.", { status: 404 });

    const bytes = await readFile(resolved);
    const mime = file.mime_type && file.mime_type !== "application/octet-stream"
      ? file.mime_type
      : "application/octet-stream";
    // A PDF opens in the tab, as the current link does; anything else downloads.
    const inline = mime === "application/pdf";
    return new Response(new Uint8Array(bytes), {
      headers: {
        "Content-Type": mime,
        "Content-Length": String(bytes.byteLength),
        "Content-Disposition": `${inline ? "inline" : "attachment"}; filename="${safeFileName(file.original_name ?? path.basename(resolved))}"`,
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "SAMEORIGIN",
        "Cache-Control": "private, no-store, max-age=0",
      },
    });
  } catch (error) {
    console.error("Unable to serve a Finance file", error);
    return new Response("The stored Finance file is unavailable.", { status: 404 });
  }
}
