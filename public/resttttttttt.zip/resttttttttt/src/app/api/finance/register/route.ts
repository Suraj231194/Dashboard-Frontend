import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireFinanceView } from "@/modules/finance/finance-guard";
import {
  clampFinancePerPage, financeSchemaReady, listFinanceDocuments, listFinancePayments,
} from "@/modules/finance/finance-documents";
import { isPaymentRegisterView } from "@/modules/finance/finance-views";

export const runtime = "nodejs";

/**
 * The finance registers, one endpoint for all seven screens.
 *
 * This is the `list` action of the current AJAX dispatcher
 * (`admin/finance/finance_actions.php:410-429`), including its parameter
 * clamps and its "migration not applied" answer.
 */
export async function GET(request: NextRequest) {
  const params = request.nextUrl.searchParams;
  const check = await requireFinanceView(request, params.get("view") ?? "");
  if (!check.ok) return check.response;

  if (!(await financeSchemaReady())) {
    return apiError("The Finance database migration has not been applied.", 503);
  }

  const pendingOnly = params.get("pending_only") === "1";
  const page = Math.max(1, Number.parseInt(params.get("page") ?? "1", 10) || 1);
  const perPage = clampFinancePerPage(
    Number.parseInt(params.get("per_page") ?? "10", 10),
    pendingOnly,
  );
  const search = (params.get("search") ?? "").trim();
  // The table sends sort_column/sort_direction; the current screen sent
  // sort/order. Both are accepted so either caller works.
  const sort = (params.get("sort_column") ?? params.get("sort") ?? "created_at").trim();
  const order = (params.get("sort_direction") ?? params.get("order") ?? "desc")
    .trim().toUpperCase() === "ASC" ? "ASC" : "DESC";

  try {
    const result = isPaymentRegisterView(check.view)
      ? await listFinancePayments(check.view, { page, perPage, search, sort, order })
      : await listFinanceDocuments(check.view, { page, perPage, search, sort, order }, pendingOnly);
    return apiSuccess(result);
  } catch (error) {
    console.error("Unable to load Finance records", error);
    return apiError("Unable to load Finance records.", 500);
  }
}
