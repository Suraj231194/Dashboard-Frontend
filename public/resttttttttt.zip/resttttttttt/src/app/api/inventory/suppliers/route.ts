import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createSupplier, listSuppliers, readSupplierForm, SUPPLIER_SORT_COLUMNS } from "@/modules/inventory/suppliers";


export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "suppliers");
  if (!guard.ok) return guard.response;
  try {
    // The current handler falls back to `name` ASC for any other column.
    const query = readListQuery(request.nextUrl.searchParams, SUPPLIER_SORT_COLUMNS, "name", "ASC");
    return apiSuccess(await listSuppliers(query));
  } catch (error) {
    console.error("Unable to list suppliers", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "store_supplier_add", "You do not have permission to add suppliers.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createSupplier({ ...readSupplierForm(data), createdBy: guard.user.user_id });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Supplier added successfully.");
  } catch (error) {
    console.error("Unable to add a supplier", error);
    return apiError("Something went wrong.", 500);
  }
}
