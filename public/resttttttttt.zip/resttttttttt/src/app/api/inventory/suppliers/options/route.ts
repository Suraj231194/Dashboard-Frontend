import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiSession } from "@/lib/http/guard";
import { listSupplierOptions } from "@/modules/inventory/suppliers";

export const runtime = "nodejs";

/** `loadSupplierListOptions`: the vendor selector on the low stocks form. */
export async function GET() {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ options: await listSupplierOptions() });
  } catch (error) {
    console.error("Unable to list suppliers", error);
    return apiError("Error loading data.", 500);
  }
}
