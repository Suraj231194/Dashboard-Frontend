import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { deleteSupplier, getSupplier, readSupplierForm, updateSupplier } from "@/modules/inventory/suppliers";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/inventory/suppliers/[id]">) {
  const guard = await requireApiPermission(request, "store_supplier_edit", "You do not have permission to edit suppliers.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const supplier = await getSupplier(id);
    if (!supplier) return apiError("No data found...!!", 404);
    return apiSuccess({ supplier });
  } catch (error) {
    console.error("Unable to read the supplier", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/inventory/suppliers/[id]">) {
  const guard = await requireApiPermission(request, "store_supplier_edit", "You do not have permission to edit suppliers.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateSupplier({ ...readSupplierForm(data), id, updatedBy: guard.user.user_id });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Supplier updated successfully.");
  } catch (error) {
    console.error("Unable to update the supplier", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext<"/api/inventory/suppliers/[id]">) {
  const guard = await requireApiPermission(request, "store_supplier_delete", "You do not have permission to delete suppliers.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteSupplier(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Supplier deleted successfully.");
  } catch (error) {
    console.error("Unable to delete the supplier", error);
    return apiError("Server error occurred.", 500);
  }
}
