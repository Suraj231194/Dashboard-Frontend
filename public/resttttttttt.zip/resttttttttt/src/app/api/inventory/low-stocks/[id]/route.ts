import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { deleteLowStock, getLowStock, updateLowStock } from "@/modules/inventory/low-stocks";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/inventory/low-stocks/[id]">) {
  const guard = await requireApiPermission(request, "low_stocks_menu_edit", "You do not have permission to edit purchase requests.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const request_ = await getLowStock(id);
    if (!request_) return apiError("No data found...!!", 404);
    return apiSuccess({ request: request_ });
  } catch (error) {
    console.error("Unable to read the low stock request", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/inventory/low-stocks/[id]">) {
  const guard = await requireApiPermission(request, "low_stocks_menu_edit", "You do not have permission to edit purchase requests.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const text = (key: string) => String(data.get(key) ?? "");
    const result = await updateLowStock({
      id,
      reportingPerson: text("reportingPersonEdit"),
      dateOfReport: text("dateOfReportEdit"),
      coaNumber: text("coaNumberEdit"),
      nonInventoryItemName: text("nonInventoryItemNameEdit"),
      materialCategory: Number.parseInt(text("materialCategoryEdit"), 10) || 0,
      productId: Number.parseInt(text("productsListEdit"), 10) || 0,
      quantity: Number.parseFloat(text("ProductItemquantityEdit")) || 0,
      quantityUnit: Number.parseInt(text("ProductItemquantityUnitEdit"), 10) || 0,
      vendorName: text("vendorNameEdit"),
      critical: Number.parseInt(text("isThisCriticalEdit"), 10) || 0,
      deliveryDate: text("dateOfDeliveryedit"),
      updatedBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message ?? "Low stock request updated successfully.");
  } catch (error) {
    console.error("Unable to update the low stock request", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext<"/api/inventory/low-stocks/[id]">) {
  const guard = await requireApiPermission(request, "low_stocks_menu_delete", "You do not have permission to delete purchase requests.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteLowStock(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message ?? "Low stock request deleted successfully.");
  } catch (error) {
    console.error("Unable to delete the low stock request", error);
    return apiError("Server error occurred.", 500);
  }
}
