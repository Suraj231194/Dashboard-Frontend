import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { viewLowStock } from "@/modules/inventory/low-stocks";

export const runtime = "nodejs";

/** `viewLowStocksRecord`: the read-only summary behind the eye button. */
export async function GET(request: NextRequest, context: RouteContext<"/api/inventory/low-stocks/[id]/view">) {
  const guard = await requireApiPermission(request, "low_stocks_menu_view", "You do not have permission to view purchase requests.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const record = await viewLowStock(id);
    if (!record) return apiError("No data found...!!", 404);
    return apiSuccess({ request: record });
  } catch (error) {
    console.error("Unable to read the low stock request", error);
    return apiError("Server error occurred.", 500);
  }
}
