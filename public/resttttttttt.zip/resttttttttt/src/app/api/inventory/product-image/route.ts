import { readFile } from "node:fs/promises";
import path from "node:path";
import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiSession } from "@/lib/http/guard";
import { resolveProductImage } from "@/modules/inventory/product-images";

export const runtime = "nodejs";

const CONTENT_TYPES: Record<string, string> = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
};

/**
 * Serves an image out of the shared uploads directory. The current application
 * serves these as static files; this application holds them behind the session
 * and refuses any path outside the product uploads directory.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  const filePath = resolveProductImage(request.nextUrl.searchParams.get("path"));
  const contentType = filePath ? CONTENT_TYPES[path.extname(filePath).toLowerCase()] : undefined;
  if (!filePath || !contentType) return apiError("No data found...!!", 404);
  try {
    const bytes = await readFile(filePath);
    return new Response(new Uint8Array(bytes), {
      headers: { "Content-Type": contentType, "Cache-Control": "private, max-age=3600" },
    });
  } catch {
    return apiError("No data found...!!", 404);
  }
}
