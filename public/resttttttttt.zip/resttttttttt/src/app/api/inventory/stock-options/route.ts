import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiSession } from "@/lib/http/guard";
import {
  listMaterialTypes,
  listProductsByMaterialType,
  listQuantityUnits,
  listUnitsByFullName,
} from "@/modules/inventory/stock-options";

export const runtime = "nodejs";

/**
 * The selector lists the stock and low-stock forms share:
 * `loadMaterialTypeOption`, `loadProductsByMaterialType` and `getQtyUnits`.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  const params = request.nextUrl.searchParams;
  try {
    switch (params.get("list")) {
      case "material-types": {
        // PHP's empty(): "" and "0" both mean "every category".
        const flag = params.get("onlyWithProducts") ?? "";
        return apiSuccess({ options: await listMaterialTypes(flag !== "" && flag !== "0") });
      }
      case "products":
        return apiSuccess({
          options: await listProductsByMaterialType(
            Number.parseInt(params.get("materialTypeId") ?? "0", 10) || 0,
          ),
        });
      case "units":
        return apiSuccess({ options: await listQuantityUnits() });
      case "unit-names":
        return apiSuccess({ options: await listUnitsByFullName() });
      default:
        return apiError("Unknown option list.", 422);
    }
  } catch (error) {
    console.error("Unable to load the inventory options", error);
    return apiError("Error loading data.", 500);
  }
}
