import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { importStockCsv } from "@/modules/inventory/stocks";

export const runtime = "nodejs";

const MAX_BYTES = 5 * 1024 * 1024;

/** `importStock`: the CSV upload behind the Import button on the stocks screen. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "stocks_add", "You do not have permission to import stock.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const file = data.get("importStockFile");
    if (!(file instanceof File)) return apiError("No file uploaded or upload error.", 422);
    if (!file.name.toLowerCase().endsWith(".csv")) return apiError("Only .csv files are supported.", 422);
    if (file.size > MAX_BYTES) return apiError("File is too large (max 5 MB).", 422);

    const result = await importStockCsv(await file.text(), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({ errors: result.errors }, result.message);
  } catch (error) {
    console.error("Unable to import stock", error);
    return apiError("Server error.", 500);
  }
}
