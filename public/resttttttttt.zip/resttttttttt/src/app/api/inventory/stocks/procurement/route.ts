import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { normalizeIntList } from "@/modules/inventory/stock-list-sql";
import { createProcurementRequests, listProcurementCandidates } from "@/modules/inventory/stocks";

export const runtime = "nodejs";

/** `loadProcurementCandidateProducts`: the rows the procurement dialog offers. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stocks");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const singleProductParam = params.get("singleProduct") ?? "";
    const result = await listProcurementCandidates({
      source: (params.get("procurementSource") ?? "").trim(),
      productId: Number.parseInt(params.get("productId") ?? "0", 10) || 0,
      singleProduct: singleProductParam !== "" && singleProductParam !== "0",
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({ items: result.items });
  } catch (error) {
    console.error("Unable to load the procurement products", error);
    return apiError("Unable to load procurement products.", 500);
  }
}

/** `createInventoryProcurementRequests`: hands the selection to the purchase queue. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "stocks_edit", "You do not have permission to raise procurement requests.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createProcurementRequests({
      productIds: normalizeIntList(data.getAll("productIds[]").map(String)),
      source: String(data.get("procurementSource") ?? "").trim(),
      coaNumber: String(data.get("coaNumber") ?? ""),
      reportingOfficer: String(data.get("reportingOfficer") ?? ""),
      createdBy: guard.user.user_id,
      fallbackReporter: guard.user.email,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to create the procurement requests", error);
    return apiError("Unable to create procurement requests.", 500);
  }
}
