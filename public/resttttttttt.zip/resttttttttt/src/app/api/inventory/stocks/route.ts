import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { normalizeIntList } from "@/modules/inventory/stock-list-sql";
import { addStockEntry, listStocks, STOCK_SORT_KEYS } from "@/modules/inventory/stocks";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stocks");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    // Any column outside the map sorts by prod.id, exactly as the current handler does.
    const query = readListQuery(params, STOCK_SORT_KEYS, "prod.id", "DESC");
    const statusesParam = params.get("statuses");
    return apiSuccess(
      await listStocks(query, {
        groups: normalizeIntList(params.get("groups") ?? []),
        categories: normalizeIntList(params.get("categories") ?? []),
        statuses: statusesParam === null ? [0, 1, 2] : normalizeIntList(statusesParam, true),
      }),
    );
  } catch (error) {
    console.error("Unable to list stocks", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "stocks_add", "You do not have permission to add stock.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const number = (key: string) => Number.parseInt(String(data.get(key) ?? "0"), 10) || 0;
    const result = await addStockEntry({
      categoryId: number("materilCategoryList"),
      productId: number("productsList"),
      quantity: Number.parseFloat(String(data.get("prodQuantity") ?? "0")) || 0,
      quantityUnit: number("prodQuantityUnit"),
      coaNo: String(data.get("coaNo") ?? ""),
      lotBatchNo: String(data.get("lotBatchNo") ?? ""),
      mfgDate: String(data.get("mfgDate") ?? ""),
      expiryDate: String(data.get("expiryDate") ?? ""),
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message ?? "Stock recorded successfully.");
  } catch (error) {
    console.error("Unable to record stock", error);
    return apiError("Something went wrong.", 500);
  }
}
