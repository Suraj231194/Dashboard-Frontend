import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { requireApiPageAccess } from "@/lib/http/guard";
import { normalizeIntList } from "@/modules/inventory/stock-list-sql";
import { buildStockExport, STOCK_EXPORT_COLUMNS } from "@/modules/inventory/stocks";

export const runtime = "nodejs";

/** `exportStocks`: the chosen columns as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stocks");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const columns = data.getAll("listOfColumns[]").map(String);
    const result = await buildStockExport({
      search: String(data.get("search") ?? "").trim(),
      groups: normalizeIntList(String(data.get("selectedCategs") ?? "[]")),
      categories: normalizeIntList(String(data.get("selectedSubcategs") ?? "[]")),
      sortColumn: String(data.get("sort_column") ?? ""),
      sortDirection: String(data.get("sort_order") ?? "").toUpperCase() === "DESC" ? "DESC" : "ASC",
      page: Number.parseInt(String(data.get("page") ?? "1"), 10) || 1,
      perPage: Number.parseInt(String(data.get("perPage") ?? "10"), 10) || 10,
      columns: columns.length > 0 ? columns : [...STOCK_EXPORT_COLUMNS],
    });
    if (!result.ok) return apiError(result.message, 404);
    return await tableExportResponse({
      format, title: "Stock Report", filePrefix: "stocks",
      headers: result.columns, rows: result.rows,
    });
  } catch (error) {
    console.error("Unable to build the stock export", error);
    return apiError("Server error occurred.", 500);
  }
}
