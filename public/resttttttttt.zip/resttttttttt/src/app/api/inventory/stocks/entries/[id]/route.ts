import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { deleteStockEntry } from "@/modules/inventory/stocks";

export const runtime = "nodejs";

/** `deleteStocksSingleRecord`: removes one live stock row. */
export async function DELETE(request: NextRequest, context: RouteContext<"/api/inventory/stocks/entries/[id]">) {
  const guard = await requireApiPermission(request, "stocks_edit", "You do not have permission to edit stock.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteStockEntry(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message ?? "Stock removed successfully.");
  } catch (error) {
    console.error("Unable to remove the stock entry", error);
    return apiError("Server error occurred.", 500);
  }
}
