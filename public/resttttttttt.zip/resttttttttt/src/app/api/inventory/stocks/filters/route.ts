import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listFilterOptions } from "@/modules/inventory/stocks";

export const runtime = "nodejs";

/** `loadInventoryFilterOptions`: the group and category tree for the filter menu. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stocks");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await listFilterOptions());
  } catch (error) {
    console.error("Unable to list the stock filters", error);
    return apiError("Error loading data.", 500);
  }
}
