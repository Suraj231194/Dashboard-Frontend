import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { getStockStats } from "@/modules/inventory/stocks";

export const runtime = "nodejs";

/** The three headline counts the stocks list returns alongside its rows. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stocks");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ stats: await getStockStats() });
  } catch (error) {
    console.error("Unable to read the stock summary", error);
    return apiError("Error loading data.", 500);
  }
}
