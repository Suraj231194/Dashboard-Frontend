import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { getStockDetail, listStockEntries, updateStockEntries, type StockEntryEdit } from "@/modules/inventory/stocks";

export const runtime = "nodejs";

/**
 * `fetchStocksViewRecord` and `fetchStocksEditRecord` in one place: the COA view
 * of a product, plus the editable live stock rows behind it.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stocks");
  if (!guard.ok) return guard.response;
  const productId = Number.parseInt(request.nextUrl.searchParams.get("product_id") ?? "0", 10) || 0;
  const categoryId = Number.parseInt(request.nextUrl.searchParams.get("categ_id") ?? "0", 10) || 0;
  if (productId <= 0 || categoryId <= 0) {
    return apiError("Something went wrong with this record..!!", 422);
  }
  try {
    const detail = await getStockDetail(productId, categoryId);
    if (!detail) return apiError("No product found...!!", 404);
    const entries = await listStockEntries(productId, categoryId);
    return apiSuccess({ detail, entries });
  } catch (error) {
    console.error("Unable to read the stock entries", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `updateStocksDirectRecord`: saves every edited live stock row. */
export async function PUT(request: NextRequest) {
  const guard = await requireApiPermission(request, "stocks_edit", "You do not have permission to edit stock.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const ids = data.getAll("stockEditId[]").map((value) => Number.parseInt(String(value), 10) || 0);
    const rows: StockEntryEdit[] = ids.map((id, index) => ({
      id,
      coaNo: String(data.getAll("coaNoEdit[]")[index] ?? ""),
      quantity: Number.parseFloat(String(data.getAll("prodQuantityEdit[]")[index] ?? "0")) || 0,
      quantityUnit: Number.parseInt(String(data.getAll("prodQuantityUnitEdit[]")[index] ?? "0"), 10) || 0,
      lotBatchNo: String(data.getAll("lotBatchNoEdit[]")[index] ?? ""),
      mfgDate: String(data.getAll("mfgDateEdit[]")[index] ?? ""),
      expiryDate: String(data.getAll("expiryDateEdit[]")[index] ?? ""),
    }));
    const result = await updateStockEntries(rows, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message ?? "Stock records updated successfully.");
  } catch (error) {
    console.error("Unable to update the stock entries", error);
    return apiError("Server error occurred.", 500);
  }
}
