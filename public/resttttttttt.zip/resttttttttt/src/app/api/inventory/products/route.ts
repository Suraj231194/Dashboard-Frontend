import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createProduct, listProducts, PRODUCT_SORT_COLUMNS } from "@/modules/inventory/products";
import { readProductForm } from "./form";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "products");
  if (!guard.ok) return guard.response;
  try {
    // The current screen opens on a sort key that is not in the handler's
    // allow-list, so the list first arrives ordered by product name.
    const query = readListQuery(request.nextUrl.searchParams, PRODUCT_SORT_COLUMNS, "product_name", "ASC");
    return apiSuccess(await listProducts(query));
  } catch (error) {
    console.error("Unable to list products", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "store_product_add", "You do not have permission to add products.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createProduct(readProductForm(data, ""), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to add a product", error);
    return apiError("Server error occurred.", 500);
  }
}
