import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { deleteProduct, readProduct, updateProduct } from "@/modules/inventory/products";
import { readProductForm } from "../form";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/inventory/products/[id]">) {
  const guard = await requireApiPageAccess(request, "products");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Invalid ID...!!", 422);
  try {
    const detail = await readProduct(id);
    if (!detail) return apiError("No data found...!!", 404);
    return apiSuccess(detail);
  } catch (error) {
    console.error("Unable to read the product", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/inventory/products/[id]">) {
  const guard = await requireApiPermission(
    request, "store_product_edit", "You do not have permission to edit products.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateProduct(
      {
        ...readProductForm(data, "Edit"),
        id,
        removeImage: Number.parseInt(String(data.get("removeProductImage") ?? "0"), 10) === 1,
      },
      guard.user.user_id,
    );
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update the product", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext<"/api/inventory/products/[id]">) {
  const guard = await requireApiPermission(
    request, "store_product_delete", "You do not have permission to delete products.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteProduct(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the product", error);
    return apiError("Server error occurred.", 500);
  }
}
