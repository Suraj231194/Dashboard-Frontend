import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listQtyUnitOptions } from "@/modules/inventory/products";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "products");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ units: await listQtyUnitOptions() });
  } catch (error) {
    console.error("Unable to list standard units", error);
    return apiError("Error loading data.", 500);
  }
}
