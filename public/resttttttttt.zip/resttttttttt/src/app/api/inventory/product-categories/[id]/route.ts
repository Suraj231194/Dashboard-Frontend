import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import {
  deleteProductCategory, readProductCategory, updateProductCategory,
} from "@/modules/inventory/product-categories";

export const runtime = "nodejs";

export async function GET(
  request: NextRequest, context: RouteContext<"/api/inventory/product-categories/[id]">,
) {
  const guard = await requireApiPageAccess(request, "product-categories");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const category = await readProductCategory(id);
    if (!category) return apiError("No data found...!!", 404);
    return apiSuccess({ category });
  } catch (error) {
    console.error("Unable to read the product category", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(
  request: NextRequest, context: RouteContext<"/api/inventory/product-categories/[id]">,
) {
  const guard = await requireApiPermission(
    request, "product_category_edit", "You do not have permission to edit product categories.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const number = (name: string) => Number.parseInt(String(data.get(name) ?? "0"), 10) || 0;
    const result = await updateProductCategory({
      id,
      name: String(data.get("editCategoryName") ?? ""),
      status: number("productCategoryStatusEdit"),
      webSync: number("editWebSync"),
      updatedBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update the product category", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(
  request: NextRequest, context: RouteContext<"/api/inventory/product-categories/[id]">,
) {
  const guard = await requireApiPermission(
    request, "product_category_delete", "You do not have permission to delete product categories.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteProductCategory(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the product category", error);
    return apiError("Server error occurred.", 500);
  }
}
