import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listProductCategoryOptions } from "@/modules/inventory/product-categories";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "products");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ options: await listProductCategoryOptions() });
  } catch (error) {
    console.error("Unable to list product categories", error);
    return apiError("Error loading data.", 500);
  }
}
