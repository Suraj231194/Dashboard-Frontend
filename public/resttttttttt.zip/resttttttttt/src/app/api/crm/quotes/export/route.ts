import { NextRequest } from "next/server";
import { requireApiAnyPermission } from "@/lib/http/guard";
import { apiError } from "@/lib/http/json";
import { exportPeriodSubtitle, readExportDateRange, readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { buildQuoteExport } from "@/modules/crm/quotes";

export const runtime = "nodejs";

/** The quotation list's current filters as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiAnyPermission(
    request, ["crm_quote_menu_list", "sales_billing_pi_generate_view"],
    "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const range = readExportDateRange(data);
    if (!range.ok) return apiError(range.message, 422);
    const value = (name: string) => String(data.get(name) ?? "").trim();
    const result = await buildQuoteExport(
      { status: value("status") || "all", search: value("search") },
      data.getAll("listOfColumns[]").map((entry) => String(entry)),
    );
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "CRM Quote Management", filePrefix: "crm_quotations",
      headers: result.columns, rows: result.rows,
      subtitle: exportPeriodSubtitle(range.fromDate, range.toDate, result.rows.length),
    });
  } catch (error) {
    console.error("Unable to build the CRM quotation export", error);
    return apiError("Server error occurred.", 500);
  }
}
