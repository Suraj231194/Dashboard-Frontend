import { NextRequest } from "next/server";
import { requireApiAnyPermission, requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { listQuotes, saveQuote, type QuoteFilters, type QuoteInput, type QuoteItemInput } from "@/modules/crm/quotes";

export const runtime = "nodejs";

const DENIED = "You do not have permission to perform this Sales & CRM action.";

/** `crm_load_quotes` — CRM-origin quotations only, ten a page, newest first. */
export async function GET(request: NextRequest) {
  const guard = await requireApiAnyPermission(
    request, ["crm_quote_menu_list", "sales_billing_pi_generate_view"], DENIED,
  );
  if (!guard.ok) return guard.response;
  try {
    const query = request.nextUrl.searchParams;
    return apiSuccess(await listQuotes(
      readQuoteFilters(query),
      Math.max(1, Number.parseInt(query.get("page") ?? "1", 10) || 1),
    ));
  } catch (error) {
    console.error("Unable to list the CRM quotations", error);
    return apiError("Failed to load quotes", 500);
  }
}

/** `crm_save_quote` without a `quote_id`. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "crm_quote_add", DENIED);
  if (!guard.ok) return guard.response;
  try {
    const result = await saveQuote(readQuoteForm(await request.formData(), 0), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status);
    return apiSuccess(result.quote, result.message);
  } catch (error) {
    console.error("Unable to create a CRM quotation", error);
    return apiError("Failed to save quotation", 500);
  }
}

export function readQuoteFilters(query: URLSearchParams): QuoteFilters {
  return {
    status: (query.get("status") ?? "all").trim(),
    search: (query.get("search") ?? "").trim(),
  };
}

export function readQuoteForm(data: FormData, quoteId: number): QuoteInput {
  const text = (name: string) => String(data.get(name) ?? "");
  const leadId = Number.parseInt(text("lead_id"), 10);
  let items: QuoteItemInput[] = [];
  try {
    const parsed: unknown = JSON.parse(text("items_json") || "[]");
    if (Array.isArray(parsed)) {
      items = parsed.map((entry) => {
        const row = entry as Record<string, unknown>;
        return {
          productId: Number.parseInt(String(row.product_id ?? ""), 10) || 0,
          quantity: Number.parseInt(String(row.quantity ?? ""), 10) || 0,
          // A blank rate or GST reads as -1 so it fails the same range check the
          // current handler applies to a missing posted value.
          unitPrice: row.unit_price === "" || row.unit_price === undefined ? -1 : Number(row.unit_price),
          gstRate: row.gst_rate === "" || row.gst_rate === undefined ? -1 : Number(row.gst_rate),
        };
      });
    }
  } catch {
    items = [];
  }
  return {
    quoteId,
    leadId: leadId > 0 ? leadId : null,
    targetCompanyName: text("target_company_name"),
    targetName: text("target_name"),
    targetEmail: text("target_email"),
    targetPhone: text("target_phone"),
    customerGstin: text("customer_gstin"),
    billingAddress: text("billing_address"),
    shippingAddress: text("shipping_address"),
    status: text("status"),
    notes: text("notes"),
    discountAmount: Number.parseFloat(text("discount_amount")) || 0,
    items,
  };
}
