import { NextRequest } from "next/server";
import { readId, requireApiAnyPermission, requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { deleteQuote, readQuoteDetail, saveQuote } from "@/modules/crm/quotes";
import { readQuoteForm } from "../route";

export const runtime = "nodejs";

type Context = { params: Promise<{ id: string }> };
const DENIED = "You do not have permission to perform this Sales & CRM action.";

/** `crm_get_quote_detail` — the quote plus its line items. */
export async function GET(request: NextRequest, context: Context) {
  const guard = await requireApiAnyPermission(
    request, ["crm_quote_menu_list", "sales_billing_pi_generate_view"], DENIED,
  );
  if (!guard.ok) return guard.response;
  try {
    const detail = await readQuoteDetail(readId((await context.params).id));
    if (!detail) return apiError("Quote not found", 404);
    return apiSuccess(detail);
  } catch (error) {
    console.error("Unable to read a CRM quotation", error);
    return apiError("Failed to load quotation", 500);
  }
}

/** `crm_save_quote` with a `quote_id`. */
export async function PUT(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(request, "crm_quote_edit", DENIED);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await saveQuote(readQuoteForm(await request.formData(), id), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status);
    return apiSuccess(result.quote, result.message);
  } catch (error) {
    console.error("Unable to update a CRM quotation", error);
    return apiError("Failed to save quotation", 500);
  }
}

/** `crm_delete_quote`. */
export async function DELETE(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(request, "crm_quote_delete", DENIED);
  if (!guard.ok) return guard.response;
  try {
    const result = await deleteQuote(readId((await context.params).id), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete a CRM quotation", error);
    return apiError("Failed to delete", 500);
  }
}
