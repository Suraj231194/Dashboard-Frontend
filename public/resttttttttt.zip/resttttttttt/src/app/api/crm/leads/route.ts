import { NextRequest } from "next/server";
import { requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { listLeadGrid, saveLead, type LeadGridFilters, type LeadInput } from "@/modules/crm/leads";

export const runtime = "nodejs";

/** `crm_load_leads_grid` — the tile grid, twelve cards a page, newest first. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "crm_lead_management_menu_list",
    "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    const query = request.nextUrl.searchParams;
    const page = Math.max(1, Number.parseInt(query.get("page") ?? "1", 10) || 1);
    return apiSuccess(await listLeadGrid(readFilters(query), page));
  } catch (error) {
    console.error("Unable to list CRM leads", error);
    return apiError("Failed to load leads", 500);
  }
}

/** `crm_save_lead` without a `lead_id`: a manual, already-accepted lead. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "crm_lead_add", "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    const result = await saveLead(readLeadForm(await request.formData(), 0), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({ lead_id: result.leadId }, result.message);
  } catch (error) {
    console.error("Unable to create a CRM lead", error);
    return apiError("Failed to save lead", 500);
  }
}

export function readFilters(query: URLSearchParams): LeadGridFilters {
  return {
    status: (query.get("status") ?? "all").trim(),
    search: (query.get("search") ?? "").trim(),
    source: (query.get("source") ?? "").trim(),
    customerType: (query.get("customer_type") ?? "").trim(),
    priority: (query.get("priority") ?? "").trim(),
  };
}

export function readLeadForm(data: FormData, leadId: number): LeadInput {
  const text = (name: string) => String(data.get(name) ?? "");
  return {
    leadId,
    companyName: text("company_name"),
    contactPerson: text("contact_person"),
    mobileNumber: text("mobile_number"),
    email: text("email"),
    // The dialog's first option is selected by default, as the current form is.
    customerType: text("customer_type").trim() || "Other",
    priority: text("priority").trim() || "Medium",
    city: text("city"),
    state: text("state"),
    territory: text("territory"),
    region: text("region"),
    assignedSalespersonId: Number.parseInt(text("assigned_salesperson_id"), 10) || 0,
    productIds: data.getAll("product_ids[]").map((value) => Number(value)).filter((value) => value > 0),
    notes: text("notes"),
  };
}
