import { NextRequest } from "next/server";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { deleteLead, readLeadDetail, readLeadForEdit, saveLead } from "@/modules/crm/leads";
import { readLeadForm } from "../route";

export const runtime = "nodejs";

type Context = { params: Promise<{ id: string }> };

/**
 * `crm_get_lead_detail` by default and `crm_get_lead_for_edit` with `?mode=edit`.
 * They differ deliberately: only the edit prefill requires an accepted lead.
 */
export async function GET(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, "crm_lead_management_menu_list",
    "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    if (request.nextUrl.searchParams.get("mode") === "edit") {
      const lead = await readLeadForEdit(id);
      if (!lead) return apiError("Lead not found", 404);
      return apiSuccess({ lead });
    }
    const lead = await readLeadDetail(id);
    if (!lead) return apiError("Lead not found", 404);
    return apiSuccess({ lead });
  } catch (error) {
    console.error("Unable to read a CRM lead", error);
    return apiError("Failed to load details", 500);
  }
}

/** `crm_save_lead` with a `lead_id`. */
export async function PUT(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, "crm_lead_edit", "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await saveLead(readLeadForm(await request.formData(), id), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({ lead_id: result.leadId }, result.message);
  } catch (error) {
    console.error("Unable to update a CRM lead", error);
    return apiError("Failed to save lead", 500);
  }
}

/** `crm_delete_lead` — a soft delete that leaves the activity log in place. */
export async function DELETE(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, "crm_lead_delete", "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    const result = await deleteLead(readId((await context.params).id), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete a CRM lead", error);
    return apiError("Failed to delete lead", 500);
  }
}
