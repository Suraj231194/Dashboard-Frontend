import { NextRequest } from "next/server";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { acceptLead, readAcceptModal } from "@/modules/crm/leads";

export const runtime = "nodejs";

type Context = { params: Promise<{ id: string }> };

/** `crm_get_lead_for_accept_modal` — the lead, its products and the recommendation. */
export async function GET(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, "crm_lead_management_menu_list",
    "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await readAcceptModal(readId((await context.params).id));
    if (!data) return apiError("Lead not found", 404);
    return apiSuccess(data);
  } catch (error) {
    console.error("Unable to open the CRM accept dialog", error);
    return apiError("Failed to load lead details", 500);
  }
}

/** `crm_confirm_accept_lead`. */
export async function POST(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(
    request, "crm_lead_accept", "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await acceptLead({
      leadId: readId((await context.params).id),
      salespersonId: Number.parseInt(String(data.get("salesperson_id") ?? ""), 10) || 0,
      priority: String(data.get("priority") ?? "Medium").trim(),
      notes: String(data.get("assignment_notes") ?? ""),
      userId: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to accept a CRM lead", error);
    return apiError("Failed to accept lead", 500);
  }
}
