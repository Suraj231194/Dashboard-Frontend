import { NextRequest } from "next/server";
import { requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { getLeadStats } from "@/modules/crm/leads";

export const runtime = "nodejs";

/** `crm_get_lead_stats` — pulls the incoming sources in first, then counts. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "crm_lead_management_menu_list",
    "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await getLeadStats(guard.user.user_id));
  } catch (error) {
    console.error("Unable to read the CRM lead statistics", error);
    return apiError("Unable to load lead statistics.", 500);
  }
}
