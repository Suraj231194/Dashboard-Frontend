import { NextRequest } from "next/server";
import { requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { listIncomingLeads } from "@/modules/crm/leads";

export const runtime = "nodejs";

/** `crm_load_incoming_leads` — every pending lead, newest capture first. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "crm_lead_management_menu_list",
    "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ rows: await listIncomingLeads(guard.user.user_id) });
  } catch (error) {
    console.error("Unable to list the incoming CRM leads", error);
    return apiError("Error loading leads", 500);
  }
}
