import { NextRequest } from "next/server";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { rejectLead } from "@/modules/crm/leads";

export const runtime = "nodejs";

/** `crm_reject_lead` — archives a pending lead without deleting it. */
export async function POST(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, "crm_lead_reject", "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    const result = await rejectLead(readId((await context.params).id), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to reject a CRM lead", error);
    return apiError("Failed to reject lead", 500);
  }
}
