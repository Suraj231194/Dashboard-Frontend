import { NextRequest } from "next/server";
import { requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readSalesPerformance } from "@/modules/crm/leads";

export const runtime = "nodejs";

/** `crm_get_sales_performance` — one grouped query over the salesperson master. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "crm_lead_management_menu_list",
    "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ rows: await readSalesPerformance() });
  } catch (error) {
    console.error("Unable to read the CRM sales performance", error);
    return apiError("Unable to load sales performance.", 500);
  }
}
