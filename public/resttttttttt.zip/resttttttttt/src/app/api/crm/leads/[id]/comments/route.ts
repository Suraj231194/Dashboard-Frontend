import { NextRequest } from "next/server";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { addLeadComment } from "@/modules/crm/leads";

export const runtime = "nodejs";

/** `crm_add_lead_comment` — a follow-up note on the activity timeline. */
export async function POST(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, "crm_lead_edit", "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await addLeadComment(
      readId((await context.params).id),
      String(data.get("comment") ?? ""),
      guard.user.user_id,
    );
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to log a CRM lead comment", error);
    return apiError("Failed to add comment", 500);
  }
}
