import { NextRequest } from "next/server";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { updateLeadStatus } from "@/modules/crm/leads";

export const runtime = "nodejs";

/**
 * `crm_update_lead_status`. Re-applying the status already on the lead affects
 * no row and is reported as an error, exactly as the current handler does.
 */
export async function POST(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, "crm_lead_edit", "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await updateLeadStatus(
      readId((await context.params).id),
      String(data.get("status") ?? "").trim(),
      guard.user.user_id,
    );
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to change a CRM lead status", error);
    return apiError("Failed to update status", 500);
  }
}
