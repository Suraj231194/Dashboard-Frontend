import { NextRequest } from "next/server";
import { requireApiAnyPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { listLeadsForPicker } from "@/modules/crm/leads";

export const runtime = "nodejs";

/** `crm_load_leads_for_quote` — accepted leads for the "From Existing Leads" dialog. */
export async function GET(request: NextRequest) {
  const guard = await requireApiAnyPermission(
    request,
    ["crm_quote_menu_list", "crm_lead_management_menu_list", "sales_billing_pi_generate_view"],
    "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    const query = request.nextUrl.searchParams;
    return apiSuccess(await listLeadsForPicker(
      (query.get("search") ?? "").trim(),
      Math.max(1, Number.parseInt(query.get("page") ?? "1", 10) || 1),
    ));
  } catch (error) {
    console.error("Unable to list the leads for a quotation", error);
    return apiError("Error loading leads", 500);
  }
}
