import { NextRequest } from "next/server";
import { readId, requireApiAnyPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readLeadPrefill } from "@/modules/crm/leads";

export const runtime = "nodejs";

/** `crm_get_lead_for_quote_prefill` — the lead and its interested products. */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiAnyPermission(
    request,
    ["crm_quote_menu_list", "crm_lead_management_menu_list", "sales_billing_pi_generate_view"],
    "You do not have permission to perform this Sales & CRM action.",
  );
  if (!guard.ok) return guard.response;
  try {
    const prefill = await readLeadPrefill(readId((await context.params).id));
    if (!prefill) return apiError("Lead not found", 404);
    return apiSuccess(prefill);
  } catch (error) {
    console.error("Unable to prefill a quotation from a lead", error);
    return apiError("Failed to prefill lead data", 500);
  }
}
