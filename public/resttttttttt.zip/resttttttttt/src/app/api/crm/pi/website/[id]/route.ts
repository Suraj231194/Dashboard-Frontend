import { NextRequest } from "next/server";
import { readId, requireApiAnyPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { PI_DENIED, PI_PAGE_SLUGS } from "@/modules/crm/pi-constants";
import { readWebsitePiDetail } from "@/modules/crm/pi";

export const runtime = "nodejs";

/** `getPiDetails` — the website snapshot the sync pull stored. */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiAnyPermission(request, PI_PAGE_SLUGS, PI_DENIED);
  if (!guard.ok) return guard.response;
  try {
    const detail = await readWebsitePiDetail(readId((await context.params).id));
    if (!detail) return apiError("PI request was not found.", 404);
    return apiSuccess({ detail });
  } catch (error) {
    console.error("Unable to read the website PI snapshot", error);
    return apiError("PI request was not found.", 500);
  }
}
