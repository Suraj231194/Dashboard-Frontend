import { NextRequest } from "next/server";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { PI_DENIED, PI_PERMISSIONS } from "@/modules/crm/pi-constants";
import { PiError, duplicateProformaInvoice } from "@/modules/crm/pi";

export const runtime = "nodejs";

/** `duplicateProformaInvoice` — a fresh PI number over the same details. */
export async function POST(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(request, PI_PERMISSIONS.duplicate, PI_DENIED);
  if (!guard.ok) return guard.response;
  try {
    const result = await duplicateProformaInvoice(readId((await context.params).id), guard.user.user_id);
    return apiSuccess({ new_invoice_id: result.new_invoice_id }, result.message);
  } catch (error) {
    if (error instanceof PiError) return apiError(error.message, error.status);
    console.error("Unable to duplicate a proforma invoice", error);
    return apiError("Duplicate failed: the proforma invoice could not be copied.", 500);
  }
}
