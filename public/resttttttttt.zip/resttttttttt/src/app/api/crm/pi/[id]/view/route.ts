import { NextRequest } from "next/server";
import { readId, requireApiAnyPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { PI_DENIED, PI_VIEW_SLUGS } from "@/modules/crm/pi-constants";
import { readPiView } from "@/modules/crm/pi";

export const runtime = "nodejs";

/** `viewProformaInvoicePdfRecord` — the invoice behind the details dialog. */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiAnyPermission(request, PI_VIEW_SLUGS, PI_DENIED);
  if (!guard.ok) return guard.response;
  try {
    const invoice = await readPiView(readId((await context.params).id));
    if (!invoice) return apiError("Proforma invoice not found.", 404);
    return apiSuccess({ invoice });
  } catch (error) {
    console.error("Unable to read the proforma invoice", error);
    return apiError("Error in fetching request.", 500);
  }
}
