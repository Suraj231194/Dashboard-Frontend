import { NextRequest } from "next/server";
import { requireApiAnyPermission } from "@/lib/http/guard";
import { apiError } from "@/lib/http/json";
import { exportPeriodSubtitle, readExportDateRange, readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { PI_DENIED, PI_PAGE_SLUGS } from "@/modules/crm/pi-constants";
import { buildPiExport } from "@/modules/crm/pi";

export const runtime = "nodejs";

/**
 * `exportPiRequests` (`exportajax.php:3160`). The dialog offers the current
 * search and the column list only, as the current one does; the file itself is
 * returned rather than written into `admin/exports/`.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiAnyPermission(request, PI_PAGE_SLUGS, PI_DENIED);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const range = readExportDateRange(data);
    if (!range.ok) return apiError(range.message, 422);
    const columns = data.getAll("listOfColumns[]").map((entry) => String(entry));
    if (columns.length === 0) return apiError("Select at least one column to export.", 422);

    const result = await buildPiExport(String(data.get("search") ?? "").trim(), columns);
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "PI Management Report", filePrefix: "pi_requests",
      headers: result.headers, rows: result.rows,
      subtitle: exportPeriodSubtitle(range.fromDate, range.toDate, result.rows.length),
    });
  } catch (error) {
    console.error("Unable to build the PI export", error);
    return apiError("Server error occurred.", 500);
  }
}
