import { NextRequest } from "next/server";
import { readId, requireApiAnyPermission, requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { PI_DENIED, PI_PAGE_SLUGS, PI_PERMISSIONS } from "@/modules/crm/pi-constants";
import { PiError, deleteProformaInvoice, readPiForEdit, updateProformaInvoice } from "@/modules/crm/pi";
import { readPiForm } from "../route";

export const runtime = "nodejs";

type Context = { params: Promise<{ id: string }> };

/** `fetchProformaInvoiceEditRecord` — the header and its live line items. */
export async function GET(request: NextRequest, context: Context) {
  const guard = await requireApiAnyPermission(request, PI_PAGE_SLUGS, PI_DENIED);
  if (!guard.ok) return guard.response;
  try {
    const record = await readPiForEdit(readId((await context.params).id));
    if (!record) return apiError("Proforma invoice not found.", 404);
    return apiSuccess({ record });
  } catch (error) {
    console.error("Unable to read a proforma invoice for editing", error);
    return apiError("Error in fetching request.", 500);
  }
}

/**
 * `updateProformaInvoice`. The current handler checks no permission at all;
 * the screen only offers the button behind `sales_billing_pi_generate_edit`,
 * so the endpoint asks for the same slug rather than leaving it open.
 */
export async function PUT(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(request, PI_PERMISSIONS.edit, PI_DENIED);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const input = { ...readPiForm(data), piId: readId((await context.params).id) };
    const result = await updateProformaInvoice(input, guard.user.user_id);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof PiError) return apiError(error.message, error.status);
    console.error("Unable to update a proforma invoice", error);
    return apiError("Error in updating request.", 500);
  }
}

/** `deleteProfInvoiceRecord`. */
export async function DELETE(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(request, PI_PERMISSIONS.delete, PI_DENIED);
  if (!guard.ok) return guard.response;
  try {
    const result = await deleteProformaInvoice(readId((await context.params).id), guard.user.user_id);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof PiError) return apiError(error.message, error.status);
    console.error("Unable to delete a proforma invoice", error);
    return apiError("Failed to prepare statement.", 500);
  }
}
