import { NextRequest } from "next/server";
import { readId, requireApiAnyPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { PI_CONVERT_SLUGS, PI_DENIED } from "@/modules/crm/pi-constants";
import { PiError, convertPiToOrder } from "@/modules/crm/pi";

export const runtime = "nodejs";

/** `crm_convert_pi_to_order` — confirms the PI and opens a Sales Order. */
export async function POST(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiAnyPermission(request, PI_CONVERT_SLUGS, PI_DENIED);
  if (!guard.ok) return guard.response;
  try {
    const result = await convertPiToOrder(
      readId((await context.params).id), guard.user.user_id, guard.user.name ?? "",
    );
    return apiSuccess(
      { order_id: result.order_id, order_number: result.order_number, routing: result.routing },
      result.message,
    );
  } catch (error) {
    if (error instanceof PiError) return apiError(error.message, error.status);
    console.error("Unable to convert a proforma invoice into an order", error);
    return apiError("The Sales Order conversion request failed. Please refresh and try again.", 500);
  }
}
