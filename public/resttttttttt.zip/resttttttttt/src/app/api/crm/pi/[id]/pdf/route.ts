import { NextRequest } from "next/server";
import { readId, requireApiAnyPermission } from "@/lib/http/guard";
import { apiError } from "@/lib/http/json";
import { simpleTablePdf } from "@/lib/pdf/simple-table";
import { PI_DENIED, PI_VIEW_SLUGS } from "@/modules/crm/pi-constants";
import { readPiView } from "@/modules/crm/pi";

export const runtime = "nodejs";

/**
 * The download behind `.pdfPurchaseOrderRawDownloadBtn`, which opens
 * `pages/pi_template.php?id=…&triggerDownload=1`. The printed invoice carries
 * the same line items and totals; the letterhead artwork is not reproduced.
 */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiAnyPermission(request, PI_VIEW_SLUGS, PI_DENIED);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Invalid or missing proforma invoice ID.", 400);
  try {
    const invoice = await readPiView(id);
    if (!invoice) return apiError("Proforma invoice not found.", 404);

    const rows = invoice.items.map((item) => [
      String(item.serial), item.catNo, item.name, item.packSize,
      item.qtyReq, item.prodRate, item.prodValue, item.gstVal, item.totalPrice,
    ]);
    rows.push(["", "", "FREIGHT", "", "", "", "", "", invoice.freight_amount]);
    rows.push(["", "", `FREIGHT TAX (${invoice.freight_percent}%)`, "", "", "", "", "", invoice.freight_percent_amount]);
    rows.push(["", "", "ROUND OFF", "", "", "", "", "", invoice.round_off]);
    rows.push(["", "", "TOTAL", "", invoice.total_qty, "", "", invoice.total_gst, invoice.grand_total]);

    const bytes = simpleTablePdf({
      title: "Proforma Invoice",
      subtitle: `${invoice.pi_auto_batch} · ${invoice.company_name}`,
      headers: ["S. No.", "Cat. No.", "Product", "Pack Size", "Qty.", "Rate", "Value", "GST", "Total Price (Inc. Vat)"],
      rows,
    });
    const name = (invoice.pi_auto_batch || `PI_${id}`).replace(/[^A-Za-z0-9_-]+/g, "_");
    return new Response(Uint8Array.from(bytes).buffer as ArrayBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${name}.pdf"`,
        "Cache-Control": "private, no-store",
      },
    });
  } catch (error) {
    console.error("Unable to render the proforma invoice PDF", error);
    return apiError("Error in fetching request.", 500);
  }
}
