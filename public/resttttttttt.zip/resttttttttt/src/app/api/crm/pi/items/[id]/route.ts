import { NextRequest } from "next/server";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { PI_DENIED, PI_PERMISSIONS } from "@/modules/crm/pi-constants";
import { PiError, deletePiItem } from "@/modules/crm/pi";

export const runtime = "nodejs";

/** `deletePISubItemRecord` — one saved line of an invoice being edited. */
export async function DELETE(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(request, PI_PERMISSIONS.edit, PI_DENIED);
  if (!guard.ok) return guard.response;
  try {
    const result = await deletePiItem(readId((await context.params).id), guard.user.user_id);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof PiError) return apiError(error.message, error.status);
    console.error("Unable to delete a proforma invoice item", error);
    return apiError("Failed to prepare statement.", 500);
  }
}
