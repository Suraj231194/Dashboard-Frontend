import { NextRequest } from "next/server";
import { requireApiAnyPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { PI_DENIED, PI_PAGE_SLUGS } from "@/modules/crm/pi-constants";
import { listPiCatalog } from "@/modules/crm/pi";

export const runtime = "nodejs";

/** `getPiProductCatalog` — the product list the line-item selects draw from. */
export async function GET(request: NextRequest) {
  const guard = await requireApiAnyPermission(request, PI_PAGE_SLUGS, PI_DENIED);
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ products: await listPiCatalog() });
  } catch (error) {
    console.error("Unable to load the PI product catalog", error);
    return apiError("Error loading data.", 500);
  }
}
