import { NextRequest } from "next/server";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { listSalespersons, saveSalesperson, type SalespersonInput, type Territory } from "@/modules/crm/salespersons";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "salesperson-master");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ rows: await listSalespersons(
      (request.nextUrl.searchParams.get("search") ?? "").trim(),
      (request.nextUrl.searchParams.get("status") ?? "all").trim(),
    ) });
  } catch (error) {
    console.error("Unable to list salespersons", error);
    return apiError("Error loading salespersons.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "crm_salesperson_add", "You do not have permission to add salespersons.");
  if (!guard.ok) return guard.response;
  try {
    const result = await saveSalesperson(0, readForm(await request.formData()), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to add a salesperson", error);
    return apiError("Unable to create the salesperson.", 500);
  }
}

export function readForm(data: FormData): SalespersonInput {
  let territories: Territory[] = [];
  try {
    const parsed: unknown = JSON.parse(String(data.get("territories_json") ?? "[]"));
    if (Array.isArray(parsed)) {
      territories = parsed.filter((item): item is Territory => (
        typeof item === "object" && item !== null && "name" in item && "type" in item
      ));
    }
  } catch {
    territories = [];
  }
  const nullableId = (name: string) => {
    const value = Number.parseInt(String(data.get(name) ?? ""), 10);
    return value > 0 ? value : null;
  };
  const ids = (name: string) => data.getAll(name).map((value) => Number(value)).filter((value) => value > 0);
  return {
    name: String(data.get("salesperson_name") ?? ""),
    code: String(data.get("salesperson_code") ?? ""),
    userId: nullableId("user_id"),
    employeeId: nullableId("employee_id"),
    email: String(data.get("email") ?? "").trim(),
    mobile: String(data.get("mobile") ?? "").trim(),
    salesTeam: String(data.get("sales_team") ?? "").trim(),
    assignmentPriority: Math.max(1, Number.parseInt(String(data.get("assignment_priority") ?? "100"), 10) || 100),
    status: Number.parseInt(String(data.get("status") ?? "1"), 10),
    territories,
    productExpertise: ids("product_expertise"),
    productResponsibility: ids("product_responsibility"),
  };
}
