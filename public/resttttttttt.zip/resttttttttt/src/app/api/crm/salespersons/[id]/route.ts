import { NextRequest } from "next/server";
import { readId, requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { deleteSalesperson, readSalesperson, saveSalesperson } from "@/modules/crm/salespersons";
import { readForm } from "../route";

export const runtime = "nodejs";

type Context = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, context: Context) {
  const guard = await requireApiPageAccess(request, "salesperson-master");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const salesperson = await readSalesperson(id);
    if (!salesperson) return apiError("Salesperson not found", 404);
    return apiSuccess({ salesperson });
  } catch (error) {
    console.error("Unable to read the salesperson", error);
    return apiError("Unable to load salesperson details.", 500);
  }
}

export async function PUT(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(request, "crm_salesperson_edit", "You do not have permission to edit salespersons.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await saveSalesperson(id, readForm(await request.formData()), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update a salesperson", error);
    return apiError("Unable to update the salesperson.", 500);
  }
}

export async function DELETE(request: NextRequest, context: Context) {
  const guard = await requireApiPermission(request, "crm_salesperson_delete", "You do not have permission to delete salespersons.");
  if (!guard.ok) return guard.response;
  try {
    const result = await deleteSalesperson(readId((await context.params).id), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete a salesperson", error);
    return apiError("Unable to delete the salesperson.", 500);
  }
}
