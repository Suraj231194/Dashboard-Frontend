import { NextRequest } from "next/server";
import type { RowDataPacket } from "mysql2";
import { queryOne } from "@/lib/db/query";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { deleteRole, updateRole } from "@/modules/access/roles";

export const runtime = "nodejs";

interface RoleDetailRow extends RowDataPacket {
  id: number;
  name: string;
  description: string | null;
  status: number;
}

export async function GET(request: NextRequest, context: RouteContext<"/api/access/roles/[id]">) {
  const guard = await requireApiPermission(request, "roles_edit", "You do not have permission to edit roles.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const role = await queryOne<RoleDetailRow>(
      "SELECT id, name, description, status FROM `roles` WHERE id = ? LIMIT 1",
      [id],
    );
    if (!role) return apiError("No data found...!!", 404);
    return apiSuccess({ role });
  } catch (error) {
    console.error("Unable to read the role", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/access/roles/[id]">) {
  const guard = await requireApiPermission(request, "roles_edit", "You do not have permission to edit roles.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateRole({
      id,
      name: String(data.get("editRolesName") ?? ""),
      description: String(data.get("editRoleDesc") ?? ""),
      status: Number.parseInt(String(data.get("roleStatusEdit") ?? "0"), 10) || 0,
      updatedBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Role updated successfully.");
  } catch (error) {
    console.error("Unable to update the role", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext<"/api/access/roles/[id]">) {
  const guard = await requireApiPermission(request, "roles_delete", "You do not have permission to delete roles.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteRole(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Role deleted successfully.");
  } catch (error) {
    console.error("Unable to delete the role", error);
    return apiError("Server error occurred.", 500);
  }
}
