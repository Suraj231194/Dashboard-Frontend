import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { deleteMenu, findMenu, readMenuInput, updateMenu } from "@/modules/access/menus-admin";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/access/menus/[id]">) {
  const guard = await requireApiPermission(request, "menus_edit", "You do not have permission to edit menus.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const menu = await findMenu(id);
    if (!menu) return apiError("No data found...!!", 404);
    return apiSuccess({ menu });
  } catch (error) {
    console.error("Unable to read the menu", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/access/menus/[id]">) {
  const guard = await requireApiPermission(request, "menus_edit", "You do not have permission to edit menus.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateMenu(id, readMenuInput(data, "edit"), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Menu updated successfully.");
  } catch (error) {
    console.error("Unable to update the menu", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext<"/api/access/menus/[id]">) {
  const guard = await requireApiPermission(request, "menus_delete", "You do not have permission to delete menus.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteMenu(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Menu deleted successfully.");
  } catch (error) {
    console.error("Unable to delete the menu", error);
    return apiError("Server error occurred.", 500);
  }
}
