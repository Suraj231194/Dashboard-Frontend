import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createMenu, listMenus, MENU_SORT_COLUMNS, readMenuInput } from "@/modules/access/menus-admin";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "menus");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, MENU_SORT_COLUMNS, "id", "DESC");
    return apiSuccess(await listMenus(query));
  } catch (error) {
    console.error("Unable to list menus", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "menus_add", "You do not have permission to add menus.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createMenu(readMenuInput(data, ""), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Menu added successfully");
  } catch (error) {
    console.error("Unable to add a menu", error);
    return apiError("Menu insert failed", 500);
  }
}
