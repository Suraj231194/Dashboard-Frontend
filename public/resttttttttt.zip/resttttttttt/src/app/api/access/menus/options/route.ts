import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listParentMenuOptions } from "@/modules/access/menus-admin";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "menus");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ options: await listParentMenuOptions() });
  } catch (error) {
    console.error("Unable to list parent menus", error);
    return apiError("Error loading data.", 500);
  }
}
