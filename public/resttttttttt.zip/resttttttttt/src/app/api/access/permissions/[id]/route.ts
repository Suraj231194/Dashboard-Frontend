import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { deletePermission, findPermission, updatePermission } from "@/modules/access/app-permissions";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/access/permissions/[id]">) {
  const guard = await requireApiPageAccess(request, "permissions");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const permission = await findPermission(id);
    if (!permission) return apiError("No data found...!!", 404);
    return apiSuccess({ permission });
  } catch (error) {
    console.error("Unable to read the permission", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/access/permissions/[id]">) {
  const guard = await requireApiPageAccess(request, "permissions");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updatePermission({
      id,
      name: String(data.get("editPermissionName") ?? ""),
      slug: String(data.get("editPermissionSlug") ?? ""),
      status: Number.parseInt(String(data.get("permissionStatusEdit") ?? "0"), 10) || 0,
      updatedBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Permission updated successfully.");
  } catch (error) {
    console.error("Unable to update the permission", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext<"/api/access/permissions/[id]">) {
  const guard = await requireApiPageAccess(request, "permissions");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deletePermission(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Permission deleted successfully.");
  } catch (error) {
    console.error("Unable to delete the permission", error);
    return apiError("Server error occurred.", 500);
  }
}
