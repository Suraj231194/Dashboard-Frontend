import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { listRolesForPermissions } from "@/modules/access/role-permissions";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request,
    "role_has_permission_menu_list",
    "You do not have permission to view role permissions.",
  );
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, ["name"], "name", "ASC");
    return apiSuccess(await listRolesForPermissions(query));
  } catch (error) {
    console.error("Unable to list roles for permissions", error);
    return apiError("Error loading data.", 500);
  }
}
