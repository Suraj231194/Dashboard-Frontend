import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { assignRolePermissions, getRolePermissions } from "@/modules/access/role-permissions";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/access/role-permissions/[roleId]">) {
  const guard = await requireApiPermission(
    request,
    "role_has_permission_edit",
    "You do not have permission to edit role permissions.",
  );
  if (!guard.ok) return guard.response;
  const roleId = readId((await context.params).roleId);
  try {
    const detail = await getRolePermissions(roleId);
    if (!detail) return apiError("Invalid Role ID.", 404);
    return apiSuccess(detail);
  } catch (error) {
    console.error("Unable to read role permissions", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/access/role-permissions/[roleId]">) {
  const guard = await requireApiPermission(
    request,
    "role_has_permission_edit",
    "You do not have permission to assign role permissions.",
  );
  if (!guard.ok) return guard.response;
  const roleId = readId((await context.params).roleId);
  try {
    const data = await request.formData();
    const permissionIds = data.getAll("permissions")
      .map((value) => Number.parseInt(String(value), 10))
      .filter((value) => Number.isInteger(value) && value > 0);
    const result = await assignRolePermissions(roleId, permissionIds);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Permissions updated successfully.");
  } catch (error) {
    console.error("Unable to assign role permissions", error);
    return apiError("Failed to assign permissions.", 500);
  }
}
