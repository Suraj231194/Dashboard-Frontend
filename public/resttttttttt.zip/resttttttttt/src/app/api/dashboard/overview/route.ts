import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiSession } from "@/lib/http/guard";
import { getDashboardOverview } from "@/modules/dashboard/dashboard";
import { dashboardVisibility } from "@/modules/dashboard/visibility";

export const runtime = "nodejs";

/**
 * The figures behind the dashboard cards and charts, for the refresh control.
 * Visibility is resolved on the server, so a role that cannot see a block is
 * never sent its numbers.
 */
export async function GET() {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await getDashboardOverview(await dashboardVisibility(guard.user)));
  } catch (error) {
    console.error("Unable to load the dashboard overview", error);
    return apiError("Error loading data.", 500);
  }
}
