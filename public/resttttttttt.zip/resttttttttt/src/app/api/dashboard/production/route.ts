import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { getDashboardProduction } from "@/modules/dashboard/dashboard";

export const runtime = "nodejs";

/**
 * The loadDashboardProduction action. It carries no permission check of its own
 * today, and the dashboard menu row records no slug, so a signed-in session is
 * all this asks for - the same rule the screen itself runs under.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "dashboard");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await getDashboardProduction());
  } catch (error) {
    console.error("Unable to load the production timeline", error);
    return apiError("Error loading data.", 500);
  }
}
