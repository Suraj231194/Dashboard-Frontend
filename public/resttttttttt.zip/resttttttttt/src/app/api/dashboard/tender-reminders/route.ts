import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { listTenderReminders } from "@/modules/dashboard/dashboard";
import { TENDER_DASHBOARD_PERMISSION } from "@/modules/dashboard/visibility";

export const runtime = "nodejs";

/**
 * The reminder rows. The current table has sorting switched off and is always
 * ordered by ageing, so that is the only column allowed here.
 */
const REMINDER_SORT_COLUMNS = ["aging_days"] as const;

export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request,
    TENDER_DASHBOARD_PERMISSION,
    "You do not have permission to view tender reminders.",
  );
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, REMINDER_SORT_COLUMNS, "aging_days", "DESC");
    return apiSuccess(await listTenderReminders(query));
  } catch (error) {
    console.error("Unable to list tender reminders", error);
    return apiError("Error loading data.", 500);
  }
}
