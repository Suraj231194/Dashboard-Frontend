import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { countCompanyStats } from "@/modules/company/setup";

export const runtime = "nodejs";

/**
 * The two counters the directory shows above the list. The current handler
 * returns them alongside the cards; the converted screen reads them on their
 * own, because the shared table owns the list request.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(request, "company_setup_view", "Permission denied.");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ stats: await countCompanyStats() });
  } catch (error) {
    console.error("Unable to count company profiles", error);
    return apiError("Error loading data.", 500);
  }
}
