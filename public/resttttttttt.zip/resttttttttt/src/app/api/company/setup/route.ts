import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import {
  COMPANY_SORT_COLUMNS, CompanySetupError, listCompanyProfiles,
  readCompanyProfileForm, saveCompanyProfile,
} from "@/modules/company/setup";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(request, "company_setup_view", "Permission denied.");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, COMPANY_SORT_COLUMNS, "p.id", "DESC");
    return apiSuccess(await listCompanyProfiles(query));
  } catch (error) {
    if (error instanceof CompanySetupError) return apiError(error.message, error.status);
    console.error("Unable to list company profiles", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "company_add", "Permission denied.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await saveCompanyProfile(readCompanyProfileForm(data, 0, guard.user.user_id));
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({ id: result.id }, "Company registration saved successfully.");
  } catch (error) {
    console.error("Unable to register a company", error);
    return apiError("Server error occurred.", 500);
  }
}
