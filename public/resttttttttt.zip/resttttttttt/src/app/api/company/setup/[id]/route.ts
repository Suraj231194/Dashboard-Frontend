import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import {
  CompanySetupError, readCompanyProfile, readCompanyProfileForm, saveCompanyProfile,
} from "@/modules/company/setup";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/company/setup/[id]">) {
  const guard = await requireApiPermission(request, "company_edit", "Permission denied.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    // The current action reads whatever id it is given; id 0 finds nothing.
    return apiSuccess({ data: await readCompanyProfile(id) });
  } catch (error) {
    if (error instanceof CompanySetupError) return apiError(error.message, error.status);
    console.error("Unable to read the company profile", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT(request: NextRequest, context: RouteContext<"/api/company/setup/[id]">) {
  const guard = await requireApiPermission(request, "company_edit", "Permission denied.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await saveCompanyProfile(readCompanyProfileForm(data, id, guard.user.user_id));
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({ id: result.id }, "Company registration saved successfully.");
  } catch (error) {
    console.error("Unable to update the company profile", error);
    return apiError("Server error occurred.", 500);
  }
}
