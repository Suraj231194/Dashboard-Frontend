import { NextRequest } from "next/server";
import { serializeCsv } from "@/lib/csv";
import { requireApiPageAccess } from "@/lib/http/guard";
import { apiError } from "@/lib/http/json";
import { simpleTablePdf } from "@/lib/pdf/simple-table";
import { ALL_ITEMS_PER_PAGE, readListQuery } from "@/lib/pagination";
import { listManualPayroll, MANUAL_EXPORT_COLUMNS, MANUAL_PAYROLL_SORT_COLUMNS } from "@/modules/payroll/manual";
import { readIds } from "../route";

export const runtime = "nodejs";

function escapeXml(value: unknown): string {
  return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "payroll-manual");
  if (!guard.ok) return guard.response;
  try {
    const params = new URLSearchParams(request.nextUrl.searchParams);
    params.set("page", "1"); params.set("per_page", String(ALL_ITEMS_PER_PAGE));
    const query = readListQuery(params, MANUAL_PAYROLL_SORT_COLUMNS, "employee_name", "ASC");
    const result = await listManualPayroll(guard.user, query, {
      month: params.get("month") ?? "", categories: readIds(params.get("categories")),
      statuses: readIds(params.get("statuses")), companies: readIds(params.get("companies")),
    });
    const requested = new Set((params.get("columns") ?? "").split(",").filter(Boolean));
    const selected = MANUAL_EXPORT_COLUMNS.filter(([label]) => requested.size === 0 || requested.has(label));
    if (selected.length === 0) return apiError("Select at least one export column.", 422);
    const headers = selected.map(([label]) => label);
    const rows = result.rows.map((row) => Object.fromEntries(selected.map(([label, key]) => [label, row[key]])));
    const format = params.get("format") ?? "csv";
    const base = `manual-payroll-${params.get("month") ?? "export"}`;
    if (format === "pdf") {
      const bytes = simpleTablePdf({ title: "Manual Payroll", subtitle: params.get("month") ?? "", headers, rows: rows.map((row) => headers.map((header) => String(row[header] ?? ""))) });
      return new Response(Uint8Array.from(bytes).buffer, { headers: { "Content-Type": "application/pdf", "Content-Disposition": `attachment; filename="${base}.pdf"`, "Cache-Control": "private, no-store" } });
    }
    if (format === "excel") {
      const table = `<?xml version="1.0"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet ss:Name="Payroll"><Table><Row>${headers.map((header) => `<Cell><Data ss:Type="String">${escapeXml(header)}</Data></Cell>`).join("")}</Row>${rows.map((row) => `<Row>${headers.map((header) => `<Cell><Data ss:Type="String">${escapeXml(row[header])}</Data></Cell>`).join("")}</Row>`).join("")}</Table></Worksheet></Workbook>`;
      return new Response(table, { headers: { "Content-Type": "application/vnd.ms-excel; charset=utf-8", "Content-Disposition": `attachment; filename="${base}.xls"`, "Cache-Control": "private, no-store" } });
    }
    return new Response(serializeCsv(headers, rows), { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="${base}.csv"`, "Cache-Control": "private, no-store" } });
  } catch (error) {
    console.error("Unable to export manual payroll", error);
    return apiError(error instanceof Error ? error.message : "Unable to export manual payroll.", 422);
  }
}
