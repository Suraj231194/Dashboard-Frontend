import { NextRequest } from "next/server";
import { requireApiPageAccess } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { saveEmployeeSalary } from "@/modules/payroll/manual";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "payroll-manual");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const number = (name: string) => Number(data.get(name) ?? 0);
    await saveEmployeeSalary(guard.user, {
      employeeId: number("employeeListId"), basicCapping: number("basicCapingSalary"), monthlySalary: number("monthlySalary"),
      hra: number("hra"), conveyance: number("convenceAllowance"), medical: number("medicalAllowance"),
      special: number("specialAllowance"), incentives: number("incentives"), deductions: number("deductions"),
      effectiveFrom: String(data.get("salaryEffectiveFromDate") ?? ""), effectiveTo: String(data.get("salaryEffectiveToDate") ?? ""),
    });
    return apiSuccess({}, "Salary updated successfully.");
  } catch (error) { return apiError(error instanceof Error ? error.message : "Unable to update salary.", 422); }
}
