import { NextRequest } from "next/server";
import { requireApiPageAccess } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { addBulkAttendance, markHalfDays, type AttendanceInput } from "@/modules/payroll/manual";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "payroll-manual");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const action = String(data.get("action") ?? "");
    const parsed = JSON.parse(String(data.get("items") ?? "[]")) as AttendanceInput[];
    const items = Array.isArray(parsed) ? parsed.slice(0, 500) : [];
    if (action === "bulk") {
      const result = await addBulkAttendance(guard.user, items);
      return apiSuccess(result, `Attendance marked: ${result.inserted}, skipped (already present): ${result.skipped}.`);
    }
    if (action === "halfday") {
      const result = await markHalfDays(guard.user, items);
      return apiSuccess(result, `Half-day updated: ${result.updated}${result.notFound ? `, not found: ${result.notFound}` : ""}.`);
    }
    return apiError("Select a valid attendance action.", 422);
  } catch (error) { return apiError(error instanceof Error ? error.message : "Unable to update attendance.", 422); }
}
