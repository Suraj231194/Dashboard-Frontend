import { NextRequest } from "next/server";
import { requireApiPageAccess } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readListQuery } from "@/lib/pagination";
import { listManualPayroll, MANUAL_PAYROLL_SORT_COLUMNS } from "@/modules/payroll/manual";

export const runtime = "nodejs";

export function readIds(value: string | null): number[] {
  return [...new Set((value ?? "").split(",").map((item) => Number.parseInt(item, 10)).filter((id) => id > 0))];
}

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "payroll-manual");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, MANUAL_PAYROLL_SORT_COLUMNS, "employee_name", "ASC");
    return apiSuccess(await listManualPayroll(guard.user, query, {
      month: params.get("month") ?? "",
      categories: readIds(params.get("categories")), statuses: readIds(params.get("statuses")),
      companies: readIds(params.get("companies")),
    }));
  } catch (error) {
    console.error("Unable to load manual payroll", error);
    return apiError(error instanceof Error ? error.message : "Unable to load manual payroll.", 422);
  }
}
