import { NextRequest } from "next/server";
import { requireApiPageAccess } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { manualPayrollOptions } from "@/modules/payroll/manual";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "payroll-manual");
  if (!guard.ok) return guard.response;
  try { return apiSuccess(await manualPayrollOptions(guard.user)); }
  catch (error) { console.error("Unable to load manual payroll options", error); return apiError("Unable to load form options.", 500); }
}
