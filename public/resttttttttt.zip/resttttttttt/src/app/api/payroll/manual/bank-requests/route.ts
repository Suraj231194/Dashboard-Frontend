import { NextRequest } from "next/server";
import { requireApiPageAccess } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { pendingBankRequests, reviewBankRequest } from "@/modules/payroll/manual";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "payroll-manual");
  if (!guard.ok) return guard.response;
  try { return apiSuccess({ requests: await pendingBankRequests(guard.user) }); }
  catch (error) { console.error("Unable to load bank requests", error); return apiError("Unable to load bank requests.", 500); }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "payroll-manual");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const decision = String(data.get("decision") ?? "") as "approve" | "reject";
    if (!(["approve", "reject"] as string[]).includes(decision)) return apiError("Select a valid review decision.", 422);
    await reviewBankRequest(guard.user, Number.parseInt(String(data.get("request_id") ?? "0"), 10) || 0, decision);
    return apiSuccess({}, `Bank details update request ${decision === "approve" ? "approved" : "rejected"} successfully.`);
  } catch (error) { return apiError(error instanceof Error ? error.message : "Unable to review bank request.", 422); }
}
