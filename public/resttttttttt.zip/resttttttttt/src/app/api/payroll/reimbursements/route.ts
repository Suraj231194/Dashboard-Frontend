import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { markReimbursementPaid } from "@/modules/finance/reimbursement-claims";
import {
  listPayrollReimbursements, REIMBURSEMENT_HISTORY_SORT_COLUMNS, reviewReimbursement,
} from "@/modules/payroll/reimbursements";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(request, "payroll_reimbursements_view", "You do not have permission to view reimbursements.");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, REIMBURSEMENT_HISTORY_SORT_COLUMNS, "id", "DESC");
    return apiSuccess(await listPayrollReimbursements(guard.user, query));
  } catch (error) {
    console.error("Unable to list payroll reimbursements", error);
    return apiError(error instanceof Error ? error.message : "Unable to load reimbursements.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "payroll_reimbursements_manage", "You do not have permission to manage reimbursements.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const action = String(data.get("action") ?? "review");
    const claimId = Number.parseInt(String(data.get("claim_id") ?? "0"), 10) || 0;
    if (action === "payment") {
      await markReimbursementPaid(guard.user, {
        claimId,
        paymentMode: String(data.get("payment_mode") ?? "").trim(),
        paymentReference: String(data.get("payment_reference") ?? "").trim(),
      });
      return apiSuccess({}, "Reimbursement payment recorded successfully.");
    }
    await reviewReimbursement(guard.user, {
      claimId,
      decision: String(data.get("decision") ?? "").trim(),
      note: String(data.get("action_note") ?? "").trim(),
    });
    return apiSuccess({}, `Reimbursement claim ${String(data.get("decision") ?? "")} successfully.`);
  } catch (error) {
    return apiError(error instanceof Error ? error.message : "Unable to update the reimbursement claim.", 422);
  }
}
