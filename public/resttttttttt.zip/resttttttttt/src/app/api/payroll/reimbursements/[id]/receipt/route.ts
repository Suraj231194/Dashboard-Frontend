import { readFile } from "node:fs/promises";
import path from "node:path";
import { NextRequest } from "next/server";
import { apiForbidden } from "@/lib/http/json";
import { requireApiSession, readId } from "@/lib/http/guard";
import { canAny } from "@/modules/access/permissions";
import { reimbursementReceipt } from "@/modules/finance/reimbursement-claims";

export const runtime = "nodejs";

export async function GET(
  request: NextRequest,
  context: RouteContext<"/api/payroll/reimbursements/[id]/receipt">,
) {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  if (!(await canAny(guard.user, ["payroll_reimbursements_view", "finance_reimbursement_claims_view"]))) {
    return apiForbidden();
  }
  const id = readId((await context.params).id);
  try {
    const file = id > 0 ? await reimbursementReceipt(guard.user, id) : null;
    if (!file) return new Response("File not found.", { status: 404 });
    const applicationRoot = path.resolve(process.env.LEGACY_APP_ROOT ?? path.resolve(process.cwd(), ".."));
    const adminRoot = path.resolve(process.env.LEGACY_ADMIN_ROOT ?? path.join(applicationRoot, "admin"));
    const payrollRoot = path.resolve(adminRoot, "uploads", "payroll");
    const absolutePath = path.resolve(adminRoot, file.relativePath.replaceAll("/", path.sep));
    if (!absolutePath.startsWith(`${payrollRoot}${path.sep}`)) return new Response("File not found.", { status: 404 });
    const bytes = await readFile(absolutePath);
    const name = file.originalName.replace(/[^A-Za-z0-9._-]/g, "_") || "receipt";
    const inline = request.nextUrl.searchParams.get("inline") === "1" && file.mimeType === "application/pdf";
    return new Response(bytes, { headers: {
      "Content-Type": file.mimeType, "Content-Length": String(bytes.byteLength),
      "Content-Disposition": `${inline ? "inline" : "attachment"}; filename="${name}"`,
      "X-Content-Type-Options": "nosniff", "X-Frame-Options": "SAMEORIGIN", "Cache-Control": "private, no-store, max-age=0",
    } });
  } catch (error) {
    console.error("Unable to serve payroll receipt", error);
    return new Response("The stored file is unavailable.", { status: 404 });
  }
}
