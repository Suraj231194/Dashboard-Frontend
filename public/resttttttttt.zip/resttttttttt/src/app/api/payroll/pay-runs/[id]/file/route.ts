import { NextRequest } from "next/server";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { apiError } from "@/lib/http/json";
import { payRunFile } from "@/modules/payroll/pay-runs";

export const runtime = "nodejs";

export async function GET(request: NextRequest, context: RouteContext<"/api/payroll/pay-runs/[id]/file">) {
  const guard = await requireApiPermission(request, "payroll_pay_runs_view", "You do not have permission to download pay runs.");
  if (!guard.ok) return guard.response;
  try {
    const file = await payRunFile(
      guard.user,
      readId((await context.params).id),
      request.nextUrl.searchParams.get("view") === "full",
    );
    if (!file) return apiError("The requested pay-run PDF was not found.", 404);
    const inline = request.nextUrl.searchParams.get("inline") === "1";
    return new Response(Uint8Array.from(file.bytes).buffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `${inline ? "inline" : "attachment"}; filename="${file.name.replaceAll('"', "")}"`,
        "Cache-Control": "private, no-store",
      },
    });
  } catch (error) {
    console.error("Unable to serve a pay-run PDF", error);
    return apiError("Unable to open the pay-run PDF.", 500);
  }
}
