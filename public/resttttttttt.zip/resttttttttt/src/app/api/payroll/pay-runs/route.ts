import { NextRequest } from "next/server";
import { requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readListQuery } from "@/lib/pagination";
import { generatePayRun, listPayRuns, PAY_RUN_SORT_COLUMNS } from "@/modules/payroll/pay-runs";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(request, "payroll_pay_runs_view", "You do not have permission to view pay runs.");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, PAY_RUN_SORT_COLUMNS, "id", "DESC");
    return apiSuccess(await listPayRuns(guard.user, query));
  } catch (error) {
    console.error("Unable to list pay runs", error);
    return apiError(error instanceof Error ? error.message : "Unable to load pay runs.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "payroll_pay_runs_manage", "You do not have permission to generate pay runs.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await generatePayRun(
      guard.user,
      String(data.get("payroll_month") ?? "").trim(),
      String(data.get("payment_date") ?? "").trim(),
    );
    return apiSuccess(result, `Pay run ${result.runNumber} generated successfully.`);
  } catch (error) {
    return apiError(error instanceof Error ? error.message : "Unable to generate the pay run.", 422);
  }
}
