import { NextRequest } from "next/server";
import { requireApiPermission } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { calculatePayRun, defaultPaymentDate } from "@/modules/payroll/calculation";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(request, "payroll_pay_runs_view", "You do not have permission to view pay runs.");
  if (!guard.ok) return guard.response;
  try {
    const month = request.nextUrl.searchParams.get("month")?.trim() ?? "";
    return apiSuccess({ paymentDate: await defaultPaymentDate(guard.user, month) });
  } catch (error) {
    return apiError(error instanceof Error ? error.message : "Unable to load the payment date.", 422);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "payroll_pay_runs_view", "You do not have permission to preview pay runs.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const month = String(data.get("payroll_month") ?? "").trim();
    const calculation = await calculatePayRun(guard.user, month);
    return apiSuccess({
      ...calculation,
      paymentDate: await defaultPaymentDate(guard.user, month),
    }, "Payroll preview prepared successfully.");
  } catch (error) {
    return apiError(error instanceof Error ? error.message : "Unable to prepare the payroll preview.", 422);
  }
}
