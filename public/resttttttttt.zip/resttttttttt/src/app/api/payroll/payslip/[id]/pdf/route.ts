import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { simpleTablePdf } from "@/lib/pdf/simple-table";
import { queryOne } from "@/lib/db/query";
import type { RowDataPacket } from "mysql2";

export const runtime = "nodejs";

/**
 * Pay Slip PDF generator (`admin/payroll/payroll_pdf.php`).
 */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(
    request, "payroll_pay_runs_view", "You do not have permission to download payslips."
  );
  if (!guard.ok) return guard.response;

  const { id } = await context.params;
  const slipId = readId(id);
  if (slipId === 0) return apiError("A valid payslip identifier is required.", 400);

  try {
    const slip = await queryOne<RowDataPacket & {
      id: number;
      emp_code: string;
      employee_name: string;
      department: string;
      designation: string;
      bank_account_number: string;
      bank_ifsc_code: string;
      pan_number: string;
      month: string;
      year: number;
      gross_salary: number;
      net_salary: number;
      basic_salary: number;
      hra: number;
      conveyance_allowance: number;
      medical_allowance: number;
      special_allowance: number;
      provident_fund: number;
      esi: number;
      professional_tax: number;
      tds: number;
      total_deductions: number;
      working_days: number;
      payable_days: number;
    }>(
      `SELECT ps.*, 
              CONCAT(COALESCE(e.first_name, ''), ' ', COALESCE(e.last_name, '')) AS employee_name,
              e.emp_code, e.pan_card AS pan_number, e.bank_account_number, e.bank_ifsc_code,
              d.department_name AS department, des.designation_name AS designation
       FROM hr_payroll_slips ps
       LEFT JOIN employees e ON e.id = ps.employee_id
       LEFT JOIN departments d ON d.id = e.department_id
       LEFT JOIN designations des ON des.id = e.designation_id
       WHERE ps.id = ?
       LIMIT 1`,
      [slipId]
    );

    if (!slip) {
      return apiError("Payslip record was not found.", 404);
    }

    const rows: string[][] = [
      ["Employee Code", slip.emp_code || "-"],
      ["Employee Name", slip.employee_name || "-"],
      ["Department", slip.department || "-"],
      ["Designation", slip.designation || "-"],
      ["Bank Account No.", slip.bank_account_number || "-"],
      ["IFSC Code", slip.bank_ifsc_code || "-"],
      ["PAN Number", slip.pan_number || "-"],
      ["Pay Period", `${slip.month} ${slip.year}`],
      ["Working Days", String(slip.working_days || 0)],
      ["Payable Days", String(slip.payable_days || 0)],
      ["--- Earnings ---", ""],
      ["Basic Salary", `INR ${Number(slip.basic_salary || 0).toLocaleString()}`],
      ["HRA", `INR ${Number(slip.hra || 0).toLocaleString()}`],
      ["Conveyance", `INR ${Number(slip.conveyance_allowance || 0).toLocaleString()}`],
      ["Medical Allowance", `INR ${Number(slip.medical_allowance || 0).toLocaleString()}`],
      ["Special Allowance", `INR ${Number(slip.special_allowance || 0).toLocaleString()}`],
      ["Gross Salary", `INR ${Number(slip.gross_salary || 0).toLocaleString()}`],
      ["--- Deductions ---", ""],
      ["Provident Fund (PF)", `INR ${Number(slip.provident_fund || 0).toLocaleString()}`],
      ["ESIC", `INR ${Number(slip.esi || 0).toLocaleString()}`],
      ["Professional Tax (PT)", `INR ${Number(slip.professional_tax || 0).toLocaleString()}`],
      ["TDS", `INR ${Number(slip.tds || 0).toLocaleString()}`],
      ["Total Deductions", `INR ${Number(slip.total_deductions || 0).toLocaleString()}`],
      ["--- Net Pay ---", ""],
      ["Net Salary Payable", `INR ${Number(slip.net_salary || 0).toLocaleString()}`],
    ];

    const bytes = simpleTablePdf({
      title: "Salary Slip / Pay Advice",
      subtitle: `${slip.employee_name} (${slip.emp_code}) · ${slip.month} ${slip.year}`,
      headers: ["Description", "Details / Amount"],
      rows,
    });

    const filename = `Payslip_${slip.emp_code}_${slip.month}_${slip.year}`.replace(/[^A-Za-z0-9_-]+/g, "_");

    return new Response(Uint8Array.from(bytes).buffer as ArrayBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${filename}.pdf"`,
      },
    });
  } catch (error) {
    console.error("Payslip PDF error:", error);
    return apiError("Failed to generate payslip PDF.", 500);
  }
}
