import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { listAdvancePeople } from "@/modules/payroll/advances";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(request, "payroll_advances_view", "You do not have permission to view advance salary records.");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ people: await listAdvancePeople(guard.user) });
  } catch (error) {
    console.error("Unable to load payroll advance options", error);
    return apiError(error instanceof Error ? error.message : "Unable to load Employee Master.", 500);
  }
}
