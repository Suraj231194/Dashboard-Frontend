import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { ADVANCE_SORT_COLUMNS, createPayrollAdvance, listPayrollAdvances } from "@/modules/payroll/advances";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(request, "payroll_advances_view", "You do not have permission to view advance salary records.");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, ADVANCE_SORT_COLUMNS, "issued_on", "DESC");
    return apiSuccess(await listPayrollAdvances(guard.user, query));
  } catch (error) {
    console.error("Unable to list payroll advances", error);
    return apiError(error instanceof Error ? error.message : "Unable to load advance salary records.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "payroll_advances_manage", "You do not have permission to record advance salary.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    await createPayrollAdvance(guard.user, {
      partyType: String(data.get("payroll_party_type") ?? "").trim(),
      employeeId: Number.parseInt(String(data.get("employee_id") ?? "0"), 10) || 0,
      issuedOn: String(data.get("issued_on") ?? "").trim(),
      amount: Number(data.get("amount") ?? 0),
      paymentMode: String(data.get("payment_mode") ?? "").trim(),
      reason: String(data.get("reason") ?? "").trim(),
    });
    return apiSuccess({}, "Advance salary recorded successfully.");
  } catch (error) {
    return apiError(error instanceof Error ? error.message : "Unable to record advance salary.", 422);
  }
}
