import { NextRequest } from "next/server";
import { requireApiPageAccess } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requestSalaryAccountUpdate, salaryAccountDetails } from "@/modules/payroll/salary-account";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "salary-account");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess(await salaryAccountDetails(guard.user));
  } catch (error) {
    console.error("Unable to load salary account details", error);
    return apiError("Unable to load salary account details.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "salary-account");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    await requestSalaryAccountUpdate(guard.user, {
      bankId: Number.parseInt(String(data.get("bank_id") ?? "0"), 10) || 0,
      accountNumber: String(data.get("bank_account_number") ?? ""),
      reconfirmAccountNumber: String(data.get("reconfirm_account_number") ?? ""),
      ifscCode: String(data.get("bank_ifsc_code") ?? ""),
      holderName: String(data.get("bank_account_holder_name") ?? ""),
    });
    return apiSuccess({}, "Your bank details update request has been submitted to HR for verification.");
  } catch (error) {
    return apiError(error instanceof Error ? error.message : "Unable to submit your request at this time. Please try again.", 422);
  }
}
