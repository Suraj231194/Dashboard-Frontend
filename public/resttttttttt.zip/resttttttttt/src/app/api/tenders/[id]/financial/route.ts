import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requireTenderPermission } from "@/modules/tenders/guard";
import { TENDER_PERMISSIONS } from "@/modules/tenders/tender-constants";
import { getFinancialEvaluationView, saveFinancialEvaluation } from "@/modules/tenders/tenders";
import { readEvaluationForm } from "../../forms";

export const runtime = "nodejs";

/** `fetchTenderFinacialEvalutionRecord` (the misspelling is the current flag's). */
export async function GET(request: NextRequest, context: RouteContext<"/api/tenders/[id]/financial">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.edit, "You do not have permission to edit tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const view = await getFinancialEvaluationView(id);
    if (!view) return apiError("No data found...!!", 404);
    return apiSuccess(view);
  } catch (error) {
    console.error("Unable to read the financial evaluation", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `submitTenderFinancialEvaluation`. The tender's own status is not advanced. */
export async function POST(request: NextRequest, context: RouteContext<"/api/tenders/[id]/financial">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.edit, "You do not have permission to edit tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await saveFinancialEvaluation({
      tenderId: id,
      lines: readEvaluationForm(data),
      userId: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to save the financial evaluation", error);
    return apiError("Something went wrong.", 500);
  }
}
