import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requireTenderPermission } from "@/modules/tenders/guard";
import { TENDER_PERMISSIONS } from "@/modules/tenders/tender-constants";
import { getAocView, saveAocContract } from "@/modules/tenders/tenders";
import { readAocItems, text } from "../../forms";

export const runtime = "nodejs";

/** `fetchTenderAOCRecord`. */
export async function GET(request: NextRequest, context: RouteContext<"/api/tenders/[id]/aoc">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.edit, "You do not have permission to edit tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const view = await getAocView(id);
    if (!view) return apiError("No data found...!!", 404);
    return apiSuccess(view);
  } catch (error) {
    console.error("Unable to read the AOC record", error);
    return apiError("Server error occurred.", 500);
  }
}

/**
 * `submitAOCRecord`. Unlike every other handler this one collects its errors
 * and returns them in one comma-joined message; `pgbRequired` keeps the current
 * form's spelling.
 */
export async function POST(request: NextRequest, context: RouteContext<"/api/tenders/[id]/aoc">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.edit, "You do not have permission to edit tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await saveAocContract({
      tenderId: id,
      contractName: text(data, "contractName"),
      contractDate: text(data, "contractDate"),
      contractValidity: text(data, "contractValidity"),
      pbgRequired: data.get("pgbRequired") === null ? 0 : 1,
      pbgAmount: text(data, "contractPbgAmount"),
      items: readAocItems(data),
      userId: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to save the AOC contract", error);
    return apiError("Something went wrong.", 500);
  }
}
