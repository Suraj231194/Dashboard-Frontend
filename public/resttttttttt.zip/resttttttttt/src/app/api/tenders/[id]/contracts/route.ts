import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requireTenderPermission } from "@/modules/tenders/guard";
import { TENDER_PERMISSIONS } from "@/modules/tenders/tender-constants";
import { getTenderContracts } from "@/modules/tenders/tenders";

export const runtime = "nodejs";

/** `loadTenderSection` with `action=load_contracts`. */
export async function GET(request: NextRequest, context: RouteContext<"/api/tenders/[id]/contracts">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.view, "You do not have permission to view tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Invalid Request", 422);
  try {
    return apiSuccess({ rows: await getTenderContracts(id) });
  } catch (error) {
    console.error("Unable to load the tender contracts", error);
    return apiError("Error loading data.", 500);
  }
}
