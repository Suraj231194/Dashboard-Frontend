import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requireTenderPermission } from "@/modules/tenders/guard";
import { TENDER_PERMISSIONS } from "@/modules/tenders/tender-constants";
import {
  getEditableTenderItems, getTender, listActiveInstitutionOptions, listQuantityUnits,
} from "@/modules/tenders/tenders";

export const runtime = "nodejs";

/**
 * `fetchTendersEditRecord`. The item rows come from `status != 3` alone, with
 * no `deleted_at` check, so the edit form can list a row the view accordion
 * hides.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/tenders/[id]/edit">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.edit, "You do not have permission to edit tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const tender = await getTender(id);
    if (!tender) return apiError("No data found...!!", 404);
    const [items, institutions, quantityUnits] = await Promise.all([
      getEditableTenderItems(id),
      listActiveInstitutionOptions(),
      listQuantityUnits(),
    ]);
    return apiSuccess({ tender, items, institutions, quantityUnits });
  } catch (error) {
    console.error("Unable to read the tender for editing", error);
    return apiError("Server error occurred.", 500);
  }
}
