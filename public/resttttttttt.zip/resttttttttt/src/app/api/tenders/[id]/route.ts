import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requireTenderPermission } from "@/modules/tenders/guard";
import { TENDER_PERMISSIONS } from "@/modules/tenders/tender-constants";
import {
  deleteTender, getTender, listActiveInstitutionOptions, updateTender,
} from "@/modules/tenders/tenders";
import { readUpdateTenderForm } from "../forms";

export const runtime = "nodejs";

/**
 * `loadTenderBasic`: the read-only header the view, payment and AOC dialogs
 * share. The current handler answers `success` even when the tender does not
 * exist, leaving an empty dialog on screen; this says so instead.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/tenders/[id]">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.view, "You do not have permission to view tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const tender = await getTender(id);
    if (!tender) return apiError("No data found...!!", 404);
    return apiSuccess({ tender, institutions: await listActiveInstitutionOptions() });
  } catch (error) {
    console.error("Unable to read the tender", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `updateTenderRecord`. */
export async function PUT(request: NextRequest, context: RouteContext<"/api/tenders/[id]">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.edit, "You do not have permission to edit tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateTender(readUpdateTenderForm(data, id, guard.user.user_id));
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update the tender", error);
    return apiError("Update failed", 500);
  }
}

/** `deleteTenderRecord`. */
export async function DELETE(request: NextRequest, context: RouteContext<"/api/tenders/[id]">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.remove, "You do not have permission to delete tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteTender(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the tender", error);
    return apiError("Server error occurred.", 500);
  }
}
