import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requireTenderPermission } from "@/modules/tenders/guard";
import { TENDER_PERMISSIONS } from "@/modules/tenders/tender-constants";
import { getTenderHistory } from "@/modules/tenders/tenders";

export const runtime = "nodejs";

/** `tendersHistoryViewRecord`: the timeline the history panel shows. */
export async function GET(request: NextRequest, context: RouteContext<"/api/tenders/[id]/history">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.view, "You do not have permission to view tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Invalid tender id", 422);
  try {
    return apiSuccess({ rows: await getTenderHistory(id) });
  } catch (error) {
    console.error("Unable to load the tender history", error);
    return apiError("Error loading data.", 500);
  }
}
