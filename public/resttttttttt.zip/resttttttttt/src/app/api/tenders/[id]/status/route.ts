import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requireTenderPermission } from "@/modules/tenders/guard";
import { TENDER_PERMISSIONS } from "@/modules/tenders/tender-constants";
import { changeTenderStatus } from "@/modules/tenders/tenders";
import { text, toInt } from "../../forms";

export const runtime = "nodejs";

/**
 * `changeTenderStatusRecord`. There is no workflow guard: any status may follow
 * any other, and the only rejection is picking the one already set.
 */
export async function POST(request: NextRequest, context: RouteContext<"/api/tenders/[id]/status">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.edit, "You do not have permission to edit tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await changeTenderStatus({
      id,
      newStatus: toInt(data.get("newStatus")),
      // `addtionalRemark` keeps the current form's spelling.
      remark: text(data, "addtionalRemark"),
      updatedBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to change the tender status", error);
    return apiError("Update failed", 500);
  }
}
