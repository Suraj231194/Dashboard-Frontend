import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requireTenderPermission } from "@/modules/tenders/guard";
import { TENDER_PERMISSIONS } from "@/modules/tenders/tender-constants";
import { getTenderPaymentView, saveTenderPayments } from "@/modules/tenders/tenders";
import { readPaymentForm } from "../../forms";

export const runtime = "nodejs";

/** `fetchTenderEmdPaymentRecord`: the header, the EMD figure and the cards. */
export async function GET(request: NextRequest, context: RouteContext<"/api/tenders/[id]/payments">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.view, "You do not have permission to view tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const view = await getTenderPaymentView(id);
    if (!view) return apiError("No data found...!!", 404);
    return apiSuccess(view);
  } catch (error) {
    console.error("Unable to read the tender payments", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `tenderPaymentsRecord`. */
export async function POST(request: NextRequest, context: RouteContext<"/api/tenders/[id]/payments">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.edit, "You do not have permission to edit tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await saveTenderPayments({
      tenderId: id,
      payments: readPaymentForm(data),
      userId: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to save the tender payments", error);
    return apiError("Server error occurred.", 500);
  }
}
