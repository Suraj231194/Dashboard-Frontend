import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requireTenderPermission } from "@/modules/tenders/guard";
import { TENDER_PERMISSIONS } from "@/modules/tenders/tender-constants";
import { getContractItems } from "@/modules/tenders/tenders";

export const runtime = "nodejs";

/** `loadTenderSection` with `action=load_contract_items`. */
export async function GET(request: NextRequest, context: RouteContext<"/api/tenders/contracts/[id]/items">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.view, "You do not have permission to view tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Contract ID missing", 422);
  try {
    return apiSuccess({ rows: await getContractItems(id) });
  } catch (error) {
    console.error("Unable to load the contract items", error);
    return apiError("Error loading data.", 500);
  }
}
