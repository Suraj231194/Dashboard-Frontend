import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { deleteBank } from "@/modules/settings/hr-settings";
import { TENDER_SETTINGS_PAGE } from "@/modules/tenders/tender-constants";

export const runtime = "nodejs";

/** `deleteBank`: a bank still attached to an active employee cannot be removed. */
export async function DELETE(request: NextRequest, context: RouteContext<"/api/tenders/banks/[id]">) {
  const guard = await requireApiPageAccess(request, TENDER_SETTINGS_PAGE);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteBank(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Bank deleted successfully.");
  } catch (error) {
    console.error("Unable to delete the bank", error);
    return apiError("Server error occurred.", 500);
  }
}
