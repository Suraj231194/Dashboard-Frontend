import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createBank, listBanks } from "@/modules/settings/hr-settings";
import { TENDER_SETTINGS_PAGE } from "@/modules/tenders/tender-constants";
import { toInt } from "../forms";

export const runtime = "nodejs";

/**
 * `loadBanks` / `addBank`. The Bank panel on the tender settings screen is the
 * HR bank table, shown through the same handlers, so the rules live in
 * `@/modules/settings/hr-settings` and only the page guard differs.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, TENDER_SETTINGS_PAGE);
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, ["name"], "name", "ASC");
    return apiSuccess(await listBanks(query));
  } catch (error) {
    console.error("Unable to list banks", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, TENDER_SETTINGS_PAGE);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createBank(
      String(data.get("bankName") ?? ""),
      data.get("bankStatus") === null ? 1 : toInt(data.get("bankStatus")),
      guard.user.user_id,
    );
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Bank added successfully.");
  } catch (error) {
    console.error("Unable to add a bank", error);
    return apiError("Failed to add bank.", 500);
  }
}
