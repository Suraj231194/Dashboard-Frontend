import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId } from "@/lib/http/guard";
import { requireTenderPermission } from "@/modules/tenders/guard";
import { TENDER_PERMISSIONS } from "@/modules/tenders/tender-constants";
import { deleteTenderItem } from "@/modules/tenders/tenders";

export const runtime = "nodejs";

/**
 * `deleteTenderSubItemRecord`. A row added while editing carries no id, so the
 * screen drops it from the form without calling this at all.
 */
export async function DELETE(request: NextRequest, context: RouteContext<"/api/tenders/items/[id]">) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.edit, "You do not have permission to edit tenders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteTenderItem(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the tender item", error);
    return apiError("Delete failed", 500);
  }
}
