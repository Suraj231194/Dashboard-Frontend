import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { requireTenderPermission } from "@/modules/tenders/guard";
import { TENDER_PERMISSIONS, TENDERS_PAGE } from "@/modules/tenders/tender-constants";
import { createTender, listTenders, TENDER_SORT_COLUMNS } from "@/modules/tenders/tenders";
import { readCreateTenderForm } from "./forms";

export const runtime = "nodejs";

/** `loadTenders`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, TENDERS_PAGE);
  if (!guard.ok) return guard.response;
  try {
    // Only `tnd.tender_no` is on the handler's allow-list; everything else
    // falls back to `tnd.id`, which is why the one sortable header on the
    // screen never changes the column.
    const query = readListQuery(request.nextUrl.searchParams, TENDER_SORT_COLUMNS, "tnd.id", "DESC");
    return apiSuccess(await listTenders(query));
  } catch (error) {
    console.error("Unable to list tenders", error);
    return apiError("Error loading data.", 500);
  }
}

/** `addTenderRecord`. */
export async function POST(request: NextRequest) {
  const guard = await requireTenderPermission(
    request, TENDER_PERMISSIONS.add, "You do not have permission to add tenders.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createTender(readCreateTenderForm(data, guard.user.user_id));
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to add the tender", error);
    return apiError("Transaction failed", 500);
  }
}
