import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { TENDER_SETTINGS_PAGE } from "@/modules/tenders/tender-constants";
import {
  deleteInstitution, getInstitution, updateInstitution,
} from "@/modules/tenders/tender-settings";
import { text, toInt } from "../../forms";

export const runtime = "nodejs";

/** `fetchTenderInstitutionRecord`. */
export async function GET(request: NextRequest, context: RouteContext<"/api/tenders/institutions/[id]">) {
  const guard = await requireApiPageAccess(request, TENDER_SETTINGS_PAGE);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const institution = await getInstitution(id);
    if (!institution) return apiError("No data found...!!", 404);
    return apiSuccess({ institution });
  } catch (error) {
    console.error("Unable to read the tender institution", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `updateTenderInstituution`. */
export async function PUT(request: NextRequest, context: RouteContext<"/api/tenders/institutions/[id]">) {
  const guard = await requireApiPageAccess(request, TENDER_SETTINGS_PAGE);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateInstitution({
      id,
      name: text(data, "designationNameEdit"),
      shortName: text(data, "designationShortNameEdit"),
      description: text(data, "designationDescriptionEdit"),
      status: toInt(data.get("designationStatusEdit")),
      updatedBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update the tender institution", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `deleteTenderInstitutions`. */
export async function DELETE(request: NextRequest, context: RouteContext<"/api/tenders/institutions/[id]">) {
  const guard = await requireApiPageAccess(request, TENDER_SETTINGS_PAGE);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteInstitution(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the tender institution", error);
    return apiError("Server error occurred.", 500);
  }
}
