import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { TENDER_SETTINGS_PAGE } from "@/modules/tenders/tender-constants";
import {
  createInstitution, INSTITUTION_SORT_COLUMNS, listInstitutions,
} from "@/modules/tenders/tender-settings";
import { text, toInt } from "../forms";

export const runtime = "nodejs";

/** `loadTenderInstitutions`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, TENDER_SETTINGS_PAGE);
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, INSTITUTION_SORT_COLUMNS, "name", "ASC");
    return apiSuccess(await listInstitutions(query));
  } catch (error) {
    console.error("Unable to list tender institutions", error);
    return apiError("Error loading data.", 500);
  }
}

/** `addDTenderInstitutions`. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, TENDER_SETTINGS_PAGE);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createInstitution({
      name: text(data, "designationName"),
      shortName: text(data, "designationShortName"),
      description: text(data, "designationDescription"),
      // `intval($_POST['designationStatus'] ?? 1)`: no radio means Active.
      status: data.get("designationStatus") === null ? 1 : toInt(data.get("designationStatus")),
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to add the tender institution", error);
    return apiError("Failed to add Institution.", 500);
  }
}
