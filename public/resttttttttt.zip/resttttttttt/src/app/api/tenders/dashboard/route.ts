import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { TENDER_DASHBOARD_PAGE } from "@/modules/tenders/tender-constants";
import { getTenderAnalytics } from "@/modules/tenders/tender-dashboard";

export const runtime = "nodejs";

/** `getTenderDashboardData`: the four stat tiles and the grand total. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, TENDER_DASHBOARD_PAGE);
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ analytics: await getTenderAnalytics() });
  } catch (error) {
    console.error("Unable to read the tender analytics", error);
    return apiError("Error loading data.", 500);
  }
}
