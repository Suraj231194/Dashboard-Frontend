import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readExportDateRange, readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { TENDER_DASHBOARD_PAGE } from "@/modules/tenders/tender-constants";
import { buildReminderExport } from "@/modules/tenders/tender-dashboard";
import { list, text } from "../../forms";

export const runtime = "nodejs";

/**
 * `exportTenderReminders` (`admin/exportajax.php:2686`).
 *
 * The current handler writes the file into `admin/exports/` and answers with
 * its URL, which leaves every export on disk; the bytes are streamed back here
 * instead. `pdf` is accepted, as it is upstream, even though the current
 * buttons only ever send `csv` or `excel`.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, TENDER_DASHBOARD_PAGE);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type.", 422);
    // The reminder rows carry no date of their own to filter on, so the range
    // is only validated; an inverted one is still refused rather than ignored.
    const range = readExportDateRange(data);
    if (!range.ok) return apiError(range.message, 422);

    const result = await buildReminderExport({
      search: text(data, "search"),
      selectedColumns: list(data, "listOfColumns[]"),
    });
    if (result.rows.length === 0) return apiError("No records found", 404);

    return await tableExportResponse({
      format,
      title: "Tender Reminders",
      filePrefix: "tender_reminders",
      headers: result.columns,
      rows: result.rows,
    });
  } catch (error) {
    console.error("Unable to build the tender reminder export", error);
    return apiError("Failed to export file.", 500);
  }
}
