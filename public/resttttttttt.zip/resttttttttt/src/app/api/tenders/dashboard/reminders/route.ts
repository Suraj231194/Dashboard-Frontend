import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { TENDER_DASHBOARD_PAGE } from "@/modules/tenders/tender-constants";
import { listTenderReminders, REMINDER_SORT_COLUMNS } from "@/modules/tenders/tender-dashboard";

export const runtime = "nodejs";

/**
 * `fetchTenderReminders`. The current table has ordering switched off and is
 * always sorted by ageing, so that is the only column on the allow-list.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, TENDER_DASHBOARD_PAGE);
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, REMINDER_SORT_COLUMNS, "aging_days", "DESC");
    return apiSuccess(await listTenderReminders(query));
  } catch (error) {
    console.error("Unable to list tender reminders", error);
    return apiError("Error loading data.", 500);
  }
}
