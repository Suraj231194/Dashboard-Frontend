import type {
  AocItemInput, CreateTenderInput, EvaluationLineInput, PaymentInput, TenderItemInput,
  UpdateTenderInput,
} from "@/modules/tenders/tenders";
import type { VendorInput } from "@/modules/tenders/tender-settings";

/** PHP's intval() over a form value. */
export function toInt(value: FormDataEntryValue | null | undefined): number {
  return Number.parseInt(String(value ?? ""), 10) || 0;
}

export function text(data: FormData, key: string): string {
  return String(data.get(key) ?? "");
}

export function list(data: FormData, key: string): string[] {
  return data.getAll(key).map((value) => String(value ?? ""));
}

/** A checkbox reads as its value when ticked and is absent otherwise. */
export function checked(data: FormData, key: string): number {
  return data.get(key) === null ? 0 : 1;
}

/**
 * The line-item rows the add and edit forms post, as parallel arrays under the
 * names the current form uses for each column.
 */
function readItems(data: FormData): TenderItemInput[] {
  const ids = list(data, "items[id][]");
  const names = list(data, "items[item_name][]");
  const codes = list(data, "items[item_code][]");
  const quantities = list(data, "items[quantity][]");
  const units = list(data, "items[quantity_unit][]");
  const emdAmounts = list(data, "items[sub_item_emd_amount][]");
  const specs = list(data, "items[specs][]");
  const quotePrices = list(data, "items[sub_item_qoute_price][]");
  return names.map((name, index) => ({
    id: toInt(ids[index]),
    itemName: name,
    itemCode: codes[index] ?? "",
    quantity: quantities[index] ?? "",
    quantityUnit: toInt(units[index]),
    subItemEmdAmount: emdAmounts[index] ?? "",
    specs: specs[index] ?? "",
    quotePrice: quotePrices[index] ?? "",
  }));
}

/** `addTenderRecord`. `submissionLasthDate` keeps the current form's spelling. */
export function readCreateTenderForm(data: FormData, createdBy: number): CreateTenderInput {
  return {
    tenderNumber: text(data, "tenderNumber"),
    tenderSelfId: text(data, "tenderSelfId"),
    institutionId: toInt(data.get("tenderInstitute")),
    authorityType: toInt(data.get("authorityType")),
    tenderType: toInt(data.get("tenderType")),
    tenderCategory: toInt(data.get("tenderCategory")),
    publishDate: text(data, "publishDate"),
    submissionLastDate: text(data, "submissionLasthDate"),
    submittedAt: text(data, "submissionAt"),
    emdType: toInt(data.get("emdType")),
    emdCalculationType: toInt(data.get("emdCalculationType")),
    fixedEmdAmount: text(data, "fixedEmdAmount"),
    eachItemsEmdAmount: text(data, "emdEachItemsAmount"),
    nItemsEmdAmount: text(data, "emdNItemsAmount"),
    items: readItems(data),
    createdBy,
  };
}

/**
 * `updateTenderRecord`. The institution, authority, type and category the form
 * still posts are not read here, because the handler discards them.
 */
export function readUpdateTenderForm(data: FormData, id: number, updatedBy: number): UpdateTenderInput {
  return {
    id,
    tenderNumber: text(data, "tenderNumberEdit"),
    tenderSelfId: text(data, "tenderSelfIdEdit"),
    submissionLastDate: text(data, "submissionLastDateEdit"),
    submittedAt: text(data, "submittedAtEdit"),
    items: readItems(data),
    updatedBy,
  };
}

/** `tenderPaymentsRecord`: one entry per payment card the modal renders. */
export function readPaymentForm(data: FormData): PaymentInput[] {
  const contractIds = list(data, "payment[contract_id][]");
  const types = list(data, "payment[payment_type][]");
  const applicable = list(data, "payment[applicable][]");
  const amounts = list(data, "payment[amount][]");
  const modes = list(data, "payment[payment_mode][]");
  const references = list(data, "payment[reference_no][]");
  const dates = list(data, "payment[payment_date][]");
  const statuses = list(data, "payment[payment_status][]");
  const remarks = list(data, "payment[remarks][]");
  return types.map((type, index) => ({
    contractId: toInt(contractIds[index]),
    paymentType: toInt(type),
    applicable: (applicable[index] ?? "0") === "1",
    amount: amounts[index] ?? "",
    paymentMode: modes[index] ?? "",
    referenceNo: references[index] ?? "",
    paymentDate: dates[index] ?? "",
    paymentStatus: statuses[index] ?? "",
    remarks: remarks[index] ?? "",
  }));
}

/**
 * `submitTenderFinancialEvaluation`. Each rank row carries its own rank, so the
 * ranks cannot slide onto the wrong rows the way the current checkbox array
 * lets them; a row the user removed is simply not posted.
 */
export function readEvaluationForm(data: FormData): EvaluationLineInput[] {
  const itemIds = list(data, "evaluationTenderItemId[]");
  const vendorIds = list(data, "evaluationVendorId[]");
  const ranks = list(data, "evaluationRank[]");
  const rates = list(data, "evaluationRate[]");
  const quantities = list(data, "evaluationTenderItemQty[]");
  const units = list(data, "evaluationTenderItemQtyUnit[]");
  const remarks = list(data, "evaluationRemark[]");
  return vendorIds.map((vendorId, index) => ({
    tenderItemId: toInt(itemIds[index]),
    vendorId: toInt(vendorId),
    rank: toInt(ranks[index]),
    rate: rates[index] ?? "",
    quantity: quantities[index] ?? "",
    quantityUnit: toInt(units[index]),
    remark: remarks[index] ?? "",
  }));
}

/** `submitAOCRecord`: the awarded-item rows, with the header read by the route. */
export function readAocItems(data: FormData): AocItemInput[] {
  const itemIds = list(data, "aocItem[tender_item_id][]");
  const applicable = list(data, "aocItem[applicable][]");
  const rates = list(data, "aocItem[aoc_rate][]");
  const quantities = list(data, "aocItem[aoc_quantity][]");
  const remarks = list(data, "aocItem[aoc_remarks][]");
  return itemIds.map((itemId, index) => ({
    tenderItemId: toInt(itemId),
    applicable: (applicable[index] ?? "0") === "1",
    rate: rates[index] ?? "",
    quantity: quantities[index] ?? "",
    remarks: remarks[index] ?? "",
  }));
}

/** `addTenderVendors` / `updateTenderVendor` share one field set. */
export function readVendorForm(data: FormData): VendorInput {
  return {
    vendorName: text(data, "vendorName"),
    gstNumber: text(data, "gstNumber"),
    panNo: text(data, "panNo"),
    contactPerson: text(data, "contactPerson"),
    mobile: text(data, "mobile"),
    email: text(data, "email"),
    address: text(data, "address"),
    city: text(data, "city"),
    state: text(data, "state"),
    pincode: text(data, "pincode"),
    isSupplier: checked(data, "is_supplier"),
    isContractor: checked(data, "is_contractor"),
    isConsultant: checked(data, "is_consultant"),
    // `(int) ($_POST['vendorStatus'] ?? 1)`: a missing radio defaults to Active.
    status: data.get("vendorStatus") === null ? 1 : toInt(data.get("vendorStatus")),
  };
}
