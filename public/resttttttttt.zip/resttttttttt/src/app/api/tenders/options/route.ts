import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { TENDERS_PAGE } from "@/modules/tenders/tender-constants";
import {
  listActiveInstitutionOptions, listActiveVendorOptions, listInstitutionOptions, listQuantityUnits,
} from "@/modules/tenders/tenders";

export const runtime = "nodejs";

/**
 * `getQtyUnits` and `getTenderInstitutionsList`, plus the two lists the modals
 * render server-side. The page's institution list and the modals' differ on
 * purpose: one filters `status != 3 AND deleted_at IS NULL`, the other
 * `status = 1`, so the two can legitimately disagree.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, TENDERS_PAGE);
  if (!guard.ok) return guard.response;
  try {
    const [quantityUnits, institutions, activeInstitutions, vendors] = await Promise.all([
      listQuantityUnits(),
      listInstitutionOptions(),
      listActiveInstitutionOptions(),
      listActiveVendorOptions(),
    ]);
    return apiSuccess({ quantityUnits, institutions, activeInstitutions, vendors });
  } catch (error) {
    console.error("Unable to load the tender options", error);
    return apiError("Error loading data.", 500);
  }
}
