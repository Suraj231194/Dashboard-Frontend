import type { ShortageItem } from "@/modules/procurement/material-requisitions";

/** The `items` payload the BOM review table posts as JSON. */
export function readShortageItems(raw: string): ShortageItem[] {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return [];
  }
  if (!Array.isArray(parsed)) return [];
  return parsed.map((entry) => {
    const item = entry as Record<string, unknown>;
    return {
      product_id: Number.parseInt(String(item.product_id ?? ""), 10) || 0,
      product_name: String(item.product_name ?? ""),
      category_id: Number.parseInt(String(item.category_id ?? ""), 10) || 0,
      unit_id: Number.parseInt(String(item.unit_id ?? ""), 10) || 0,
      shortfall_qty: Number.parseFloat(String(item.shortfall_qty ?? "")) || 0,
    };
  });
}
