import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { procureShortageItems } from "@/modules/procurement/material-requisitions";
import { readShortageItems } from "../items";

export const runtime = "nodejs";

/** `procureBomShortageItems`: queues the selected shortfalls to Purchase Management. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "production_material_requisition_add",
    "You do not have permission to raise procurement for a shortage.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await procureShortageItems(
      {
        batchNo: String(data.get("batch_no") ?? "").trim(),
        items: readShortageItems(String(data.get("items") ?? "[]")),
      },
      guard.user.user_id,
    );
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to queue the shortage items for procurement", error);
    return apiError("Server error while sending items to Purchase Management.", 500);
  }
}
