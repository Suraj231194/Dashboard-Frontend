import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { withTransaction } from "@/lib/db/query";
import { readFinishedProductBom } from "@/modules/procurement/material-options";

export const runtime = "nodejs";

/** `getFinishedProductBomForMatReq`: the BOM behind the chosen finished product. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "material-requisition");
  if (!guard.ok) return guard.response;
  const params = request.nextUrl.searchParams;
  const productId = Number.parseInt(params.get("productId") ?? "", 10) || 0;
  const batchSize = Number.parseFloat(params.get("batchSize") ?? "") || 0;
  if (productId <= 0) return apiError("Select a finished product.", 422);
  try {
    return apiSuccess(
      await withTransaction((connection) => readFinishedProductBom(connection, productId, batchSize)),
    );
  } catch (error) {
    console.error("Unable to read the finished product BOM", error);
    return apiError("Server error while loading BOM components.", 500);
  }
}
