import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readBomItems } from "@/modules/procurement/material-requisitions";

export const runtime = "nodejs";

/** `getBomItemListForMatReq`: the scaled BOM with its stock status. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "material-requisition");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const bomId = Number.parseInt(params.get("masterBomId") ?? "", 10) || 0;
    const batchSize = Number.parseFloat(params.get("batchSize") ?? "") || 0;
    return apiSuccess(await readBomItems(bomId, batchSize));
  } catch (error) {
    console.error("Unable to read the BOM item list", error);
    return apiError("Server error occurred.", 500);
  }
}
