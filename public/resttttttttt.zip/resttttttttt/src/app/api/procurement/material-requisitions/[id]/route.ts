import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import {
  deleteRequisition, readRequisitionView, updateRequisition,
} from "@/modules/procurement/material-requisitions";
import { readRequisitionEditForm } from "../form";

export const runtime = "nodejs";

/** `viewMatRequiRecord`. */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/procurement/material-requisitions/[id]">,
) {
  const guard = await requireApiPermission(
    request, "production_material_requisition_view",
    "You do not have permission to view material requisitions.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const detail = await readRequisitionView(id);
    if (!detail) return apiError("No data found...!!", 404);
    return apiSuccess(detail);
  } catch (error) {
    console.error("Unable to read the material requisition", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `updateMatRequiRecord`. */
export async function PUT(
  request: NextRequest, context: RouteContext<"/api/procurement/material-requisitions/[id]">,
) {
  const guard = await requireApiPermission(
    request, "production_material_requisition_edit",
    "You do not have permission to edit material requisitions.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateRequisition(readRequisitionEditForm(data, id), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update the material requisition", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `deleteMaterialRequisitionRecord`. */
export async function DELETE(
  request: NextRequest, context: RouteContext<"/api/procurement/material-requisitions/[id]">,
) {
  const guard = await requireApiPermission(
    request, "production_material_requisition_delete",
    "You do not have permission to delete material requisitions.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteRequisition(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the material requisition", error);
    return apiError("Server error occurred.", 500);
  }
}
