import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { readDepartmentName, readRequisitionDocument } from "@/modules/procurement/material-documents";

export const runtime = "nodejs";

/** `materialRequisionViewPdfRecord` as the requisition screen calls it. */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/procurement/material-requisitions/[id]/document">,
) {
  const guard = await requireApiPageAccess(request, "material-requisition");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Missing material request ID", 422);
  try {
    const document = await readRequisitionDocument(id);
    if (!document) return apiError("No material requisition found!", 404);
    const departmentName = await readDepartmentName(Number(document.header.department ?? 0));
    return apiSuccess({ ...document, departmentName });
  } catch (error) {
    console.error("Unable to read the material requisition document", error);
    return apiError("Server error occurred.", 500);
  }
}
