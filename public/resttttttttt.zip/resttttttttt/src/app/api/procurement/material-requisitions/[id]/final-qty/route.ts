import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { readFinalQtyForm, updateFinalQuantities } from "@/modules/procurement/material-requisitions";
import { readFinalQtyForm as readPostedFinalQty } from "../../form";

export const runtime = "nodejs";

const EDIT_SLUG = "production_material_requisition_edit";
const DENIED = "You do not have permission to edit material requisitions.";

/** `materialRequisitionFinalQtyUpdate`: the dialog behind the Edit Final Qty button. */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/procurement/material-requisitions/[id]/final-qty">,
) {
  const guard = await requireApiPermission(request, EDIT_SLUG, DENIED);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const detail = await readFinalQtyForm(id);
    if (!detail) return apiError("No data found...!!", 404);
    return apiSuccess(detail);
  } catch (error) {
    console.error("Unable to read the final quantity form", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `materialRequisitionEditQtyFinal`. */
export async function PUT(
  request: NextRequest, context: RouteContext<"/api/procurement/material-requisitions/[id]/final-qty">,
) {
  const guard = await requireApiPermission(request, EDIT_SLUG, DENIED);
  if (!guard.ok) return guard.response;
  // The id only names the record the dialog came from; the lines carry their own.
  readId((await context.params).id);
  try {
    const posted = readPostedFinalQty(await request.formData());
    if (!posted.balanced) return apiError("Missing or invalid input.", 422);
    const result = await updateFinalQuantities(posted.lines, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update the final quantities", error);
    return apiError("Server error occurred.", 500);
  }
}
