import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { readRequisitionEdit } from "@/modules/procurement/material-requisitions";

export const runtime = "nodejs";

/** `fetchMaterialRequisitionRecord`. */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/procurement/material-requisitions/[id]/edit">,
) {
  const guard = await requireApiPermission(
    request, "production_material_requisition_edit",
    "You do not have permission to edit material requisitions.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const form = await readRequisitionEdit(id);
    if (!form) return apiError("No data found...!!", 404);
    return apiSuccess(form);
  } catch (error) {
    console.error("Unable to read the material requisition edit form", error);
    return apiError("Server error occurred.", 500);
  }
}
