import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listDepartments, listUnits } from "@/modules/procurement/material-options";

export const runtime = "nodejs";

/** `getQtyUnits` and `getDepartmentList` for the add dialog. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "material-requisition");
  if (!guard.ok) return guard.response;
  try {
    const [units, departments] = await Promise.all([listUnits(), listDepartments()]);
    return apiSuccess({ units, departments });
  } catch (error) {
    console.error("Unable to load the material requisition options", error);
    return apiError("Server error occurred.", 500);
  }
}
