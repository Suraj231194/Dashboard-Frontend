import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { deleteRequisitionItem } from "@/modules/procurement/material-requisitions";

export const runtime = "nodejs";

/** `deleteMatRequiItemRecord`. */
export async function DELETE(
  request: NextRequest, context: RouteContext<"/api/procurement/material-requisitions/items/[id]">,
) {
  const guard = await requireApiPermission(
    request, "production_material_requisition_edit",
    "You do not have permission to edit material requisitions.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteRequisitionItem(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the material requisition item", error);
    return apiError("Server error occurred.", 500);
  }
}
