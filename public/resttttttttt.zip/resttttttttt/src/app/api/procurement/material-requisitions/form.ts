import type {
  CreateRequisitionInput, RequisitionInput, RequisitionItemInput,
} from "@/modules/procurement/material-requisitions";

function text(data: FormData, key: string): string {
  return String(data.get(key) ?? "").trim();
}

function int(data: FormData, key: string): number {
  return Number.parseInt(String(data.get(key) ?? ""), 10) || 0;
}

function float(data: FormData, key: string): number {
  return Number.parseFloat(String(data.get(key) ?? "")) || 0;
}

/** `addMaterialRequisitionForm`: the add dialog's fields. */
export function readRequisitionForm(data: FormData): CreateRequisitionInput {
  return {
    mrForRaw: int(data, "mrForRaw"),
    mrForPacking: int(data, "mrForPacking"),
    mrForConsumable: int(data, "mrForConsumable"),
    date: text(data, "mrDate"),
    // The handler overwrites this from the BOM's finished product anyway.
    productName: text(data, "mrProductName"),
    prodPlanId: int(data, "mrProdPlanId"),
    prodBomId: int(data, "mrProdBomId"),
    batchNumber: text(data, "mrBatchNumber"),
    batchSize: float(data, "mrBatchSize"),
    batchSizeUnit: int(data, "mrBatchSizeUnit"),
    slipNo: text(data, "mrSlipNo"),
    department: int(data, "mrDepartment"),
    requestedBy: text(data, "mrRequestedBy"),
  };
}

/** `updateMatRequiRecord`: the edit dialog posts the same fields with an Edit suffix. */
export function readRequisitionEditForm(data: FormData, id: number): RequisitionInput {
  const ids = data.getAll("matRequiItemIdEdit[]").map((value) => String(value));
  const descriptions = data.getAll("ProductItemDesciptionEdit[]").map((value) => String(value));
  const quantities = data.getAll("ProductItemquantityEdit[]").map((value) => String(value));
  const units = data.getAll("ProductItemquantityUnitEdit[]").map((value) => String(value));
  // The current loop walks the descriptions and indexes the other three by position.
  const items: RequisitionItemInput[] = descriptions.map((description, index) => ({
    id: Number.parseInt(ids[index] ?? "", 10) || 0,
    description: description.trim(),
    requiredQty: String(quantities[index] ?? "").trim(),
    requiredQtyUnit: String(units[index] ?? "").trim(),
  }));
  return {
    id,
    mrForRaw: int(data, "mrForRawEdit"),
    mrForPacking: int(data, "mrForPackingEdit"),
    mrForConsumable: int(data, "mrForConsumableEdit"),
    date: text(data, "mrDateEdit"),
    productName: text(data, "mrProductNameEdit"),
    batchNumber: text(data, "mrBatchNumberEdit"),
    batchSize: float(data, "mrBatchSizeEdit"),
    batchSizeUnit: int(data, "mrBatchSizeUnitEdit"),
    slipNo: text(data, "mrSlipNoEdit"),
    department: int(data, "mrDepartmentEdit"),
    requestedBy: text(data, "mrRequestedByEdit"),
    items,
  };
}

/** `materialRequisitionEditQtyFinal`: the returned, rejected and short totals. */
export function readFinalQtyForm(data: FormData) {
  const ids = data.getAll("matRequiItemIdEdit[]").map((value) => String(value));
  const rejected = data.getAll("productRejectedQty[]").map((value) => String(value));
  const returned = data.getAll("productReturnedQty[]").map((value) => String(value));
  const shortages = data.getAll("productShortQty[]").map((value) => String(value));
  return {
    // The current handler refuses the post when these two lists differ in length.
    balanced: ids.length > 0 && ids.length === rejected.length,
    lines: ids.map((id, index) => ({
      id: Number.parseInt(id, 10) || 0,
      rejectedQty: Number.parseFloat(rejected[index] ?? "") || 0,
      returnedQty: Number.parseFloat(returned[index] ?? "") || 0,
      shortQty: Number.parseFloat(shortages[index] ?? "") || 0,
    })),
  };
}
