import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createRequisition, listMaterialRequisitions } from "@/modules/procurement/material-requisitions";
import { readRequisitionForm } from "./form";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "material-requisition");
  if (!guard.ok) return guard.response;
  try {
    // The current list has no sortable heading: it always orders by id.
    const query = readListQuery(request.nextUrl.searchParams, [], "id", "DESC");
    return apiSuccess(await listMaterialRequisitions(query));
  } catch (error) {
    console.error("Unable to list material requisitions", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "production_material_requisition_add",
    "You do not have permission to add material requisitions.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createRequisition(readRequisitionForm(data), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to add a material requisition", error);
    return apiError("Server error occurred while saving the material requisition.", 500);
  }
}
