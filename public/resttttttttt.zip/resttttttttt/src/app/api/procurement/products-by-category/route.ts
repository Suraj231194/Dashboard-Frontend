import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listProductsWithQuantity } from "@/modules/procurement/material-options";

export const runtime = "nodejs";

/** `loadProductsCategoryTypeWithQuantity`: the product picker on an empty line. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "material-request");
  if (!guard.ok) return guard.response;
  try {
    const categoryId = Number.parseInt(request.nextUrl.searchParams.get("materialTypeId") ?? "", 10) || 0;
    return apiSuccess({ products: await listProductsWithQuantity(categoryId) });
  } catch (error) {
    console.error("Unable to load products for the category", error);
    return apiError("Server error occurred.", 500);
  }
}
