import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import {
  deleteTransferTicket, readTransferTicket, updateTransferTicket,
} from "@/modules/procurement/transfer-tickets";
import { readTransferTicketForm } from "../form";

export const runtime = "nodejs";

/** `transferTicketViewRecord` and `fetchTransferTicketRecord` read the same row. */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/procurement/transfer-tickets/[id]">,
) {
  const guard = await requireApiPermission(
    request, "transfer_ticket_view", "You do not have permission to view transfer tickets.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const detail = await readTransferTicket(id);
    if (!detail) return apiError("No data found...!!", 404);
    return apiSuccess(detail);
  } catch (error) {
    console.error("Unable to read the transfer ticket", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `updateTransferTicket`. */
export async function PUT(
  request: NextRequest, context: RouteContext<"/api/procurement/transfer-tickets/[id]">,
) {
  const guard = await requireApiPermission(
    request, "transfer_ticket_edit", "You do not have permission to edit transfer tickets.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await updateTransferTicket(
      { ...readTransferTicketForm(data, "Edit"), id }, guard.user.user_id,
    );
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to update the transfer ticket", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `deleteTransfetTicketRecord`. */
export async function DELETE(
  request: NextRequest, context: RouteContext<"/api/procurement/transfer-tickets/[id]">,
) {
  const guard = await requireApiPermission(
    request, "transfer_ticket_delete", "You do not have permission to delete transfer tickets.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const result = await deleteTransferTicket(id, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to delete the transfer ticket", error);
    return apiError("Server error occurred.", 500);
  }
}
