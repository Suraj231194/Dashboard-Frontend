import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { TRANSFER_TICKET_SORT_COLUMNS } from "@/modules/procurement/material-list-sql";
import { createTransferTicket, listTransferTickets } from "@/modules/procurement/transfer-tickets";
import { readTransferTicketForm } from "./form";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "transfer-ticket");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, TRANSFER_TICKET_SORT_COLUMNS, "id", "DESC");
    return apiSuccess(await listTransferTickets(query, {
      fromDate: (params.get("fromDate") ?? "").trim(),
      toDate: (params.get("toDate") ?? "").trim(),
    }));
  } catch (error) {
    console.error("Unable to list transfer tickets", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "transfer_ticket_add", "You do not have permission to add transfer tickets.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createTransferTicket(readTransferTicketForm(data, ""), guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({ id: result.id }, result.message);
  } catch (error) {
    console.error("Unable to add a transfer ticket", error);
    return apiError("Server error occurred.", 500);
  }
}
