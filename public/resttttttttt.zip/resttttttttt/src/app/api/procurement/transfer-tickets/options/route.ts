import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listUnits } from "@/modules/procurement/material-options";

export const runtime = "nodejs";

/** `getQtyUnits` for the pack, sample and quantity selectors. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "transfer-ticket");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ units: await listUnits() });
  } catch (error) {
    console.error("Unable to load the transfer ticket options", error);
    return apiError("Server error occurred.", 500);
  }
}
