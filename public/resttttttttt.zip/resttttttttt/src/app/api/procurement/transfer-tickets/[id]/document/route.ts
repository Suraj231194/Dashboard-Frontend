import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { readTransferTicketDocument } from "@/modules/procurement/transfer-tickets";

export const runtime = "nodejs";

/**
 * `transferTicketViewPdfRecord`, data path only. The printable four-copy
 * document is left to the document module; this changes nothing.
 */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/procurement/transfer-tickets/[id]/document">,
) {
  const guard = await requireApiPermission(
    request, "transfer_ticket_generate_pdf",
    "You do not have permission to download transfer tickets.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const document = await readTransferTicketDocument(id);
    if (!document) return apiError("No data found...!!", 404);
    return apiSuccess(document);
  } catch (error) {
    console.error("Unable to read the transfer ticket document", error);
    return apiError("Server error occurred.", 500);
  }
}
