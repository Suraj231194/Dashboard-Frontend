import type { TransferTicketInput } from "@/modules/procurement/transfer-tickets";

/**
 * The add and edit dialogs post the same ticket under two sets of names: the
 * edit dialog suffixes every field with "Edit".
 */
function text(data: FormData, base: string, suffix: string): string {
  return String(data.get(`${base}${suffix}`) ?? "").trim();
}

function int(data: FormData, base: string, suffix: string): number {
  return Number.parseInt(String(data.get(`${base}${suffix}`) ?? ""), 10) || 0;
}

/** `addTransferTicket` (suffix "") and `updateTransferTicket` (suffix "Edit"). */
export function readTransferTicketForm(data: FormData, suffix: string): TransferTicketInput {
  const rawPlanId = data.get("prod_plan_id");
  return {
    transferTicketNo: text(data, "transferTicketNo", suffix),
    finishedGoodCoaNo: text(data, "finishedGoodCoaNo", suffix),
    code: text(data, "code", suffix),
    transferTicketDate: text(data, "transferTicketDate", suffix),
    productDescription: text(data, "productDescription", suffix),
    packSize: text(data, "pack_size", suffix),
    packSizeUnit: int(data, "pack_size_unit", suffix),
    productCode: text(data, "productCode", suffix),
    batchNumber: text(data, "batchNumber", suffix),
    mfgDate: text(data, "transferTicketMfgDate", suffix),
    expDate: text(data, "transferTicketExpDate", suffix),
    sampleTakenByQa: text(data, "sampleTakenByQa", suffix),
    sampleTakenByQaUnit: int(data, "sampleTakenByQaUnit", suffix),
    quantityTransferred: text(data, "quantityTransferred", suffix),
    quantityUnit: int(data, "quantityUnit", suffix),
    remark: text(data, "ttRemark", suffix),
    productStatus: int(data, "productStatus", suffix),
    // Only the add dialog carries a plan link, and a blank one stays null.
    prodPlanId: suffix === "" && rawPlanId !== null && String(rawPlanId) !== ""
      ? Number.parseInt(String(rawPlanId), 10) || 0
      : null,
  };
}
