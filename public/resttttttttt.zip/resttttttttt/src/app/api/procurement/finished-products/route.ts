import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { searchFinishedProducts } from "@/modules/procurement/material-options";

export const runtime = "nodejs";

/** `getFinishedProductsWithBom`: the finished-product search on the add dialog. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "material-requisition");
  if (!guard.ok) return guard.response;
  try {
    const term = (request.nextUrl.searchParams.get("term") ?? "").trim();
    return apiSuccess({ results: await searchFinishedProducts(term) });
  } catch (error) {
    console.error("Unable to search finished products", error);
    return apiError("Server error occurred.", 500);
  }
}
