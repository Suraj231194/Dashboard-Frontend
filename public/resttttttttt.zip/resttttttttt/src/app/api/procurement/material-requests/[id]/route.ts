import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { readRequestView } from "@/modules/procurement/material-requests";

export const runtime = "nodejs";

/** `viewMaterialRequestRecord`, which the current list hides behind this slug. */
export async function GET(request: NextRequest, context: RouteContext<"/api/procurement/material-requests/[id]">) {
  const guard = await requireApiPermission(
    request, "store_material_request_view", "You do not have permission to view material requests.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const detail = await readRequestView(id);
    if (!detail) return apiError("No data found...!!", 404);
    return apiSuccess(detail);
  } catch (error) {
    console.error("Unable to read the material request", error);
    return apiError("Server error occurred.", 500);
  }
}
