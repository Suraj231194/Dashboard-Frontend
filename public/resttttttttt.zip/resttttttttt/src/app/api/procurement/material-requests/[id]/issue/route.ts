import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import {
  issueBomMaterials, issueMaterials, readIssuanceForm, readIssueLines,
} from "@/modules/procurement/material-requests";

export const runtime = "nodejs";

const EDIT_SLUG = "store_material_request_edit";
const DENIED = "You do not have permission to edit material requests.";

/** `fetchMaterialRequestRecord` / `fetchMaterialRequestBomRecord`. */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/procurement/material-requests/[id]/issue">,
) {
  const guard = await requireApiPermission(request, EDIT_SLUG, DENIED);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const form = await readIssuanceForm(id);
    if (!form) return apiError("No data found...!!", 404);
    return apiSuccess(form);
  } catch (error) {
    console.error("Unable to read the material issuance form", error);
    return apiError("Server error occurred.", 500);
  }
}

/**
 * `updateMaterialReqestRecord` and `updateMaterialReqestBOMRecord`. The dialog
 * says which it is, exactly as the current list picks between the two buttons.
 */
export async function PUT(
  request: NextRequest, context: RouteContext<"/api/procurement/material-requests/[id]/issue">,
) {
  const guard = await requireApiPermission(request, EDIT_SLUG, DENIED);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const data = await request.formData();
    const items = readIssueLines(data);
    const prodPlanId = Number.parseInt(String(data.get("matRequiProdPlanIdEdit") ?? ""), 10) || 0;
    const fromBom = String(data.get("mode") ?? "") === "bom";
    const departmentId = Number.parseInt(
      String(data.get(fromBom ? "matRequiDepartment" : "mrDepartmentEdit") ?? ""), 10,
    ) || 0;
    const input = { mrId: id, departmentId, prodPlanId, items };
    const result = fromBom
      ? await issueBomMaterials(input, guard.user.user_id)
      : await issueMaterials(input, guard.user.user_id);
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to issue materials", error);
    return apiError("Server error occurred.", 500);
  }
}
