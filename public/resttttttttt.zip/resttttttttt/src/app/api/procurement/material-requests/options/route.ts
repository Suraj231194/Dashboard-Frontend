import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listActiveProductCategories, listUnits } from "@/modules/procurement/material-options";

export const runtime = "nodejs";

/** `getQtyUnits` plus the category selector the issuance dialog builds. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "material-request");
  if (!guard.ok) return guard.response;
  try {
    const [units, categories] = await Promise.all([listUnits(), listActiveProductCategories()]);
    return apiSuccess({ units, categories });
  } catch (error) {
    console.error("Unable to load the material request options", error);
    return apiError("Server error occurred.", 500);
  }
}
