import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { generateBomFromPlan } from "@/modules/procurement/material-requisitions";

export const runtime = "nodejs";

/** Reads the `{ productId: qty }` map the BOM review table posts. */
function readCustomQuantities(raw: string): Record<number, number> {
  if (raw === "") return {};
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return {};
  }
  if (typeof parsed !== "object" || parsed === null) return {};
  const quantities: Record<number, number> = {};
  for (const [key, value] of Object.entries(parsed as Record<string, unknown>)) {
    quantities[Number.parseInt(key, 10) || 0] = Number.parseFloat(String(value)) || 0;
  }
  return quantities;
}

/** `generateBomFromPlan`. */
export async function POST(
  request: NextRequest, context: RouteContext<"/api/procurement/production-plans/[id]/generate-bom">,
) {
  const guard = await requireApiPermission(
    request, "production_material_requisition_add",
    "You do not have permission to add material requisitions.",
  );
  if (!guard.ok) return guard.response;
  const planId = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await generateBomFromPlan(
      {
        planId,
        bomId: Number.parseInt(String(data.get("bom_id") ?? ""), 10) || 0,
        customQuantities: readCustomQuantities(String(data.get("custom_quantities") ?? "")),
      },
      guard.user.user_id,
    );
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to generate the BOM for the plan", error);
    return apiError("Server error while generating BOM.", 500);
  }
}
