import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { listNewProductionPlans } from "@/modules/procurement/material-requisitions";

export const runtime = "nodejs";

/** `loadNewProductionPlans` with the material requisition context. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "material-requisition");
  if (!guard.ok) return guard.response;
  try {
    const page = Math.max(1, Number.parseInt(request.nextUrl.searchParams.get("page") ?? "1", 10) || 1);
    return apiSuccess(await listNewProductionPlans(page));
  } catch (error) {
    console.error("Unable to list the new production plans", error);
    return apiError("Error loading data.", 500);
  }
}
