import { redirect } from "next/navigation";
import Image from "next/image";
import { ArrowRight, LockKeyhole, Mail } from "lucide-react";
import { getSession } from "@/modules/auth/session";

export default async function LoginPage({ searchParams }: {
  searchParams: Promise<{ error?: string }>;
}) {
  if (await getSession()) redirect("/dashboard");
  const { error } = await searchParams;
  return (
    <main className="flex min-h-dvh items-center justify-center p-4" style={{ background: "radial-gradient(ellipse at 9% 5%, #d1fae9 0, transparent 42%), radial-gradient(ellipse at 88% 94%, #d1fae9 0, transparent 43%), #f8fbff" }}>
      <form action="/api/auth/login" method="post" className="w-full max-w-[394px] rounded-[28px] border border-white bg-white/90 px-9 py-9 shadow-[0_18px_55px_rgba(25,50,40,0.05)]">
        <div className="mx-auto mb-7 flex h-16 w-36 items-center justify-center rounded-2xl border border-slate-200 bg-white shadow-sm">
          <Image src="/images/logo3.jpeg" alt="Biogenix" width={110} height={48} className="h-11 w-auto object-contain" priority />
        </div>
        <h1 className="text-center text-[21px] font-bold text-slate-800">Welcome back 🚀</h1>
        <p className="mt-1 text-center text-sm text-slate-500">Please sign in to your account</p>
        {error && <p role="alert" className="mt-6 rounded-lg bg-red-50 p-3 text-sm text-red-700">
          {error === "unavailable" ? "Sign in is temporarily unavailable." : "Invalid email or password."}
        </p>}
        <label className="mt-7 block text-sm font-semibold text-slate-600" htmlFor="email">Email Address</label>
        <div className="relative mt-1.5">
          <Mail className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
        <input id="email" name="email" type="email" required autoComplete="username"
          placeholder="name@biogenix.in" className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-10 pr-4 text-sm shadow-sm focus:border-primary-600 focus:outline-none" />
        </div>
        <label className="mt-5 block text-sm font-semibold text-slate-600" htmlFor="password">Password</label>
        <div className="relative mt-1.5">
          <LockKeyhole className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
        <input id="password" name="password" type="password" required autoComplete="current-password"
          placeholder="••••••••••••" className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-10 pr-4 text-sm shadow-sm focus:border-primary-600 focus:outline-none" />
        </div>
        <button type="submit" className="mt-7 flex w-full items-center justify-center gap-2 rounded-xl bg-[#1a4d2e] px-4 py-3 text-sm font-semibold text-white shadow-sm hover:bg-[#133d23]">Sign In <ArrowRight className="h-4 w-4" aria-hidden="true" /></button>
      </form>
    </main>
  );
}
