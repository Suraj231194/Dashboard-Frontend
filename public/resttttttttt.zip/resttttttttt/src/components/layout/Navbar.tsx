import Link from "next/link";
import type { SessionUser } from "@/modules/auth/session";
import { getNavbarProfile } from "@/modules/users/profile";
import { UserMenu, type AccountSummary } from "./UserMenu";
import { SidebarToggle } from "./SidebarToggle";

function initialsFrom(first: string, last: string, fallback: string): string {
  const letters = `${first.charAt(0)}${last.charAt(0)}`.trim()
    || fallback.charAt(0);
  return letters.toUpperCase() || "U";
}

export async function Navbar({ user }: { user: SessionUser }) {
  const profile = await getNavbarProfile(user.user_id);
  const fullName = [profile?.first_name, profile?.middle_name, profile?.last_name]
    .map((part) => (part ?? "").trim()).filter(Boolean).join(" ");
  const account: AccountSummary = {
    displayName: fullName || user.name,
    roleName: (user.role_name ?? "ADMIN").toUpperCase(),
    email: profile?.email ?? user.email,
    employeeCode: (profile?.emp_code ?? "").trim() || `USR-${String(user.user_id).padStart(4, "0")}`,
    companyName: profile?.company_name ?? user.company_name ?? "",
    branchName: profile?.branch_name ?? user.branch_name ?? "",
    initials: initialsFrom(profile?.first_name ?? "", profile?.last_name ?? "", fullName || user.name),
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-slate-200 bg-white px-3 sm:px-4 lg:px-6">
      <SidebarToggle />
      <Link href="/dashboard" aria-label="Dashboard"
        className="flex h-14 w-32 shrink-0 items-center rounded-lg px-1">
        <span aria-label="Biogenix ERP" className="block h-12 w-28 bg-[var(--appearance-accent)] [mask:url('/images/biogenix-navbar-profile-logo.png')_center/contain_no-repeat]" />
      </Link>
      <div className="ms-auto flex min-w-0 items-center gap-2 sm:gap-3">
        <span className="hidden max-w-60 truncate text-sm font-semibold text-slate-700 md:inline">
          {user.name} ({account.roleName})
        </span>
        <UserMenu account={account} />
      </div>
    </header>
  );
}
