"use client";

import { Menu } from "lucide-react";
import { useNavigation } from "./NavigationProvider";

/** Opens the navigation drawer on screens too narrow for the sidebar. */
export function SidebarToggle() {
  const { openDrawer } = useNavigation();
  return (
    <button type="button" onClick={openDrawer} aria-label="Open navigation"
      className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-slate-200 text-slate-700 transition-colors hover:bg-slate-50 lg:hidden">
      <Menu className="h-5 w-5" aria-hidden="true" />
    </button>
  );
}
