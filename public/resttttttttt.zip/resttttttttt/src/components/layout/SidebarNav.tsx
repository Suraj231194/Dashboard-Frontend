"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import type { MenuNode } from "@/modules/navigation/menus";
import { ChevronLeft, ChevronRight, LogOut, MenuIcon, X } from "@/components/ui/icons";
import { useNavigation } from "./NavigationProvider";

function containsPath(node: MenuNode, pathname: string): boolean {
  if (node.href && node.href === pathname) return true;
  return node.children.some((child) => containsPath(child, pathname));
}

function MenuEntry({ node, depth, pathname, compact, onNavigate }: {
  node: MenuNode;
  depth: number;
  pathname: string;
  compact: boolean;
  onNavigate?: () => void;
}) {
  const hasChildren = node.children.length > 0;
  const isActive = node.href === pathname;
  const [open, setOpen] = useState(() => hasChildren && containsPath(node, pathname));
  const indent = compact ? undefined : { paddingInlineStart: `${0.75 + (depth - 1) * 0.75}rem` };

  const label = (
    <>
      <MenuIcon iconClasses={node.iconClasses} depth={depth} className="h-4 w-4 shrink-0" />
      {!compact && <span className="flex-1 truncate">{node.name}</span>}
      {!compact && node.badge !== null && (
        <span title="Pending incoming leads"
          className="rounded-full bg-rose-600 px-2 py-0.5 text-[11px] font-bold text-white">
          {node.badge > 99 ? "99+" : node.badge}
        </span>
      )}
    </>
  );

  const baseClasses = compact
    ? "flex w-full items-center justify-center rounded-xl p-2.5 text-left transition-colors"
    : "flex w-full items-center gap-3 rounded-xl py-2.5 pe-3 text-left text-[13px] font-semibold transition-colors";

  if (hasChildren) {
    return (
      <li>
        <button type="button" onClick={() => setOpen((value) => !value)} aria-expanded={open}
          style={indent} title={compact ? node.name : undefined}
          className={`${baseClasses} text-slate-600 hover:bg-[var(--color-primary-50)] hover:text-[var(--color-primary-800)]`}>
          {label}
          {!compact && (
            <ChevronRight className={`h-4 w-4 shrink-0 transition-transform ${open ? "rotate-90" : ""}`}
              aria-hidden="true" />
          )}
        </button>
        {open && !compact && (
          <ul className="mt-0.5 space-y-0.5">
            {node.children.map((child) => (
              <MenuEntry key={child.id} node={child} depth={depth + 1} pathname={pathname}
                compact={false} onNavigate={onNavigate} />
            ))}
          </ul>
        )}
      </li>
    );
  }

  if (!node.href) {
    return (
      <li>
        <span style={indent} title={`${node.name} — not available yet`}
          className={`${baseClasses} cursor-not-allowed text-slate-400`}>
          {label}
        </span>
      </li>
    );
  }

  return (
    <li>
      <Link href={node.href} style={isActive ? { ...indent, backgroundColor: "var(--appearance-accent)" } : indent} aria-current={isActive ? "page" : undefined}
        onClick={onNavigate} title={compact ? node.name : undefined}
        className={`${baseClasses} ${isActive ? "text-white shadow-sm" : "text-slate-600 hover:bg-[var(--color-primary-50)] hover:text-[var(--color-primary-800)]"}`}>
        {label}
      </Link>
    </li>
  );
}

function MenuList({ menus, pathname, compact, onNavigate }: {
  menus: MenuNode[];
  pathname: string;
  compact: boolean;
  onNavigate?: () => void;
}) {
  return (
    <ul className="space-y-0.5">
      {menus.length > 0
        ? menus.map((node) => (
          <MenuEntry key={node.id} node={node} depth={1} pathname={pathname}
            compact={compact} onNavigate={onNavigate} />
        ))
        : <li className="px-3 py-2 text-[13px] font-semibold text-slate-400">No Menu Found</li>}
      <li className="pt-2">
        <form action="/api/auth/logout" method="post">
          <button type="submit" title="Logout"
            className={compact
              ? "flex w-full items-center justify-center rounded-xl p-2.5 text-slate-600 hover:bg-[var(--color-primary-50)] hover:text-[var(--color-primary-800)]"
              : "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[13px] font-semibold text-slate-600 hover:bg-[var(--color-primary-50)] hover:text-[var(--color-primary-800)]"}>
            <LogOut className="h-4 w-4 shrink-0" aria-hidden="true" />
            {!compact && <span>Logout</span>}
          </button>
        </form>
      </li>
    </ul>
  );
}

export function SidebarNav({ menus }: { menus: MenuNode[] }) {
  const pathname = usePathname();
  const { drawerOpen, closeDrawer, collapsed, toggleCollapsed } = useNavigation();

  useEffect(() => {
    if (!drawerOpen) return;
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") closeDrawer();
    }
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [drawerOpen, closeDrawer]);

  return (
    <>
      {/* Large screens: a sidebar that can be narrowed to icons. */}
      <aside className={`${collapsed ? "lg:w-16" : "lg:w-72"} sticky top-16 hidden h-[calc(100dvh-4rem)] shrink-0 flex-col border-r border-slate-200 bg-white p-3 transition-[width] lg:flex`}>
        <button type="button" onClick={toggleCollapsed} aria-expanded={!collapsed}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            className="absolute -right-4 top-22 z-10 inline-flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-[var(--appearance-accent)] shadow-sm hover:bg-[var(--color-primary-50)]">
            {collapsed
              ? <ChevronRight className="h-4 w-4" aria-hidden="true" />
              : <ChevronLeft className="h-4 w-4" aria-hidden="true" />}
        </button>
        <nav aria-label="Main" className="sidebar-scroll flex-1 overflow-y-auto rounded-2xl border border-slate-200 px-2 py-3 shadow-sm">
          <MenuList menus={menus} pathname={pathname} compact={collapsed} />
        </nav>
      </aside>

      {/* Small screens: the same navigation as a drawer over the page. */}
      {drawerOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div aria-hidden="true" onClick={closeDrawer}
            className="absolute inset-0 h-full w-full bg-slate-900/50" />
          <aside aria-label="Navigation"
            className="absolute inset-y-0 start-0 flex w-72 max-w-[85vw] flex-col bg-white p-3 shadow-xl">
            <div className="flex items-center justify-between gap-2 px-3 py-4">
              <span className="truncate text-sm font-extrabold tracking-wide text-slate-800">AutoIVD</span>
              <button type="button" onClick={closeDrawer} aria-label="Close navigation"
                className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-600 hover:bg-slate-100">
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
            <nav aria-label="Main" className="sidebar-scroll flex-1 overflow-y-auto rounded-2xl border border-slate-200 px-2 py-3">
              <MenuList menus={menus} pathname={pathname} compact={false} onNavigate={closeDrawer} />
            </nav>
          </aside>
        </div>
      )}
    </>
  );
}
