"use client";

import Link from "next/link";
import { LogOut, Palette, ShieldCheck, User } from "@/components/ui/icons";
import { useEffect, useRef, useState } from "react";

export type AccountSummary = {
  displayName: string;
  roleName: string;
  email: string;
  employeeCode: string;
  companyName: string;
  branchName: string;
  initials: string;
};

export function UserMenu({ account }: { account: AccountSummary }) {
  const [open, setOpen] = useState(false);
  const container = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    function onPointerDown(event: MouseEvent) {
      if (!container.current?.contains(event.target as Node)) setOpen(false);
    }
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  return (
    <div className="relative" ref={container}>
      <button type="button" onClick={() => setOpen((value) => !value)} aria-expanded={open}
        aria-haspopup="menu" aria-label="Open account menu" title="My Profile"
        className="inline-flex h-9 w-9 items-center justify-center rounded-full border-2 border-slate-200 bg-primary-100 text-xs font-bold text-primary-900">
        {account.initials}
      </button>
      {open && (
        <div role="menu"
          className="absolute end-0 z-30 mt-2 w-[min(20rem,calc(100vw-1.5rem))] rounded-2xl border border-slate-200 bg-white p-2 shadow-xl">
          <div className="rounded-xl bg-primary-900 p-4 text-white">
            <p className="text-sm font-bold">{account.displayName}</p>
            <p className="mt-0.5 truncate text-xs text-slate-200">{account.email}</p>
            <p className="mt-2 text-[11px] font-semibold uppercase tracking-wide text-slate-300">
              {account.roleName} · {account.employeeCode}
            </p>
          </div>
          {(account.companyName || account.branchName) && (
            <p className="px-3 py-2 text-xs font-medium text-slate-500">
              {[account.companyName, account.branchName].filter(Boolean).join(" · ")}
            </p>
          )}
          <div className="mt-1 border-t border-slate-100 pt-1">
            <Link href="/profile" role="menuitem" onClick={() => setOpen(false)}
              className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
              <User className="h-4 w-4" aria-hidden="true" /> My Profile
            </Link>
            <Link href="/account-settings" role="menuitem" onClick={() => setOpen(false)}
              className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
              <ShieldCheck className="h-4 w-4" aria-hidden="true" /> Account Settings
            </Link>
            <Link href="/appearance" role="menuitem" onClick={() => setOpen(false)}
              className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
              <Palette className="h-4 w-4" aria-hidden="true" /> Appearance Settings
            </Link>
            <form action="/api/auth/logout" method="post">
              <button type="submit" role="menuitem"
                className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm font-medium text-rose-700 hover:bg-rose-50">
                <LogOut className="h-4 w-4" aria-hidden="true" /> Sign out
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
