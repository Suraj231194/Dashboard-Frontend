import Link from "next/link";
import { Lock } from "@/components/ui/icons";
import { ui } from "@/components/ui/styles";

/** The 403 screen shown when a signed-in user opens a screen they cannot access. */
export function Forbidden() {
  return (
    <div className="mx-auto flex w-full max-w-xl flex-col items-center py-16 text-center">
      <span className="mb-5 inline-flex h-16 w-16 items-center justify-center rounded-full bg-rose-50 text-rose-600">
        <Lock className="h-8 w-8" aria-hidden="true" />
      </span>
      <h1 className="text-2xl font-extrabold text-slate-900">403 - Forbidden</h1>
      <p className="mt-2 text-sm font-medium text-slate-600">
        You do not have permission to view this screen. Contact an administrator if you need access.
      </p>
      <Link href="/dashboard" className={`${ui.primaryButton} mt-6`}>Back to dashboard</Link>
    </div>
  );
}
