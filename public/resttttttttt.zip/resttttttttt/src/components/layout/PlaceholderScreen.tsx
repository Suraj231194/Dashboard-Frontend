import { PageHeader } from "@/components/layout/PageHeader";
import { ui } from "@/components/ui/styles";
import { Wrench } from "@/components/ui/icons";

/**
 * A screen that exists in the current application but has never been built:
 * its page file renders a heading and one line of placeholder text and calls
 * nothing. These are converted so the route resolves and the menu entry is not
 * dead, and they say plainly that there is nothing here yet rather than
 * repeating the "This is the X screen" filler.
 *
 * Replace one of these with a real screen as soon as the behaviour is defined.
 */
export function PlaceholderScreen({ title, slug }: { title: string; slug: string }) {
  return (
    <>
      <PageHeader title={title} />
      <div className={`${ui.card} p-8 text-center`}>
        <span className="mx-auto mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-slate-100 text-slate-400">
          <Wrench className="h-7 w-7" aria-hidden="true" />
        </span>
        <h2 className="m-0 text-lg font-bold text-slate-800">Nothing here yet</h2>
        <p className="mx-auto mt-2 max-w-prose text-sm font-medium text-slate-500">
          This screen is a placeholder in the current application too — its page
          renders a heading and no behaviour. It is kept so the route and the
          menu entry resolve.
        </p>
        <p className="mt-3 text-xs font-medium text-slate-400">Screen: {slug}</p>
      </div>
    </>
  );
}
