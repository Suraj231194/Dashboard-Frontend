"use client";

import {
  createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode,
} from "react";

type NavigationState = {
  /** Whether the navigation drawer is open on small screens. */
  drawerOpen: boolean;
  openDrawer: () => void;
  closeDrawer: () => void;
  /** Whether the sidebar is narrowed on large screens. */
  collapsed: boolean;
  toggleCollapsed: () => void;
};

const NavigationContext = createContext<NavigationState | null>(null);

export function NavigationProvider({ children }: { children: ReactNode }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);

  // The drawer is a small-screen affordance; widening the window dismisses it.
  useEffect(() => {
    const wide = window.matchMedia("(min-width: 1024px)");
    const sync = (event: MediaQueryListEvent) => {
      if (event.matches) setDrawerOpen(false);
    };
    wide.addEventListener("change", sync);
    return () => wide.removeEventListener("change", sync);
  }, []);

  const openDrawer = useCallback(() => setDrawerOpen(true), []);
  const closeDrawer = useCallback(() => setDrawerOpen(false), []);
  const toggleCollapsed = useCallback(() => setCollapsed((value) => !value), []);

  const value = useMemo(
    () => ({ drawerOpen, openDrawer, closeDrawer, collapsed, toggleCollapsed }),
    [drawerOpen, openDrawer, closeDrawer, collapsed, toggleCollapsed],
  );

  return <NavigationContext.Provider value={value}>{children}</NavigationContext.Provider>;
}

export function useNavigation(): NavigationState {
  const context = useContext(NavigationContext);
  if (!context) throw new Error("useNavigation must be used inside a NavigationProvider");
  return context;
}
