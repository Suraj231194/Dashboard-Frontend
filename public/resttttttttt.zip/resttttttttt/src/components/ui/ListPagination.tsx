"use client";

import { useId } from "react";
import { ALL_ITEMS_PER_PAGE, PER_PAGE_OPTIONS } from "@/lib/pagination";
import { Pagination } from "./Pagination";
import { ui } from "./styles";

export function PageSizeSelect({
  value,
  onChange,
  options = PER_PAGE_OPTIONS,
  includeAll = true,
  id,
  className,
}: {
  value: number;
  onChange: (value: number) => void;
  options?: readonly number[];
  includeAll?: boolean;
  id?: string;
  className?: string;
}) {
  const generatedId = useId();
  const selectId = id ?? `page-size-${generatedId.replaceAll(":", "")}`;

  return (
    <>
      <label className="sr-only" htmlFor={selectId}>Items per page</label>
      <select id={selectId} value={value} onChange={(event) => onChange(Number(event.target.value))}
        className={className ?? `${ui.input} h-10 w-full shrink-0 sm:w-auto`}>
        {includeAll ? <option value={ALL_ITEMS_PER_PAGE}>All items</option> : null}
        {options.map((option) => <option key={option} value={option}>{option} items</option>)}
      </select>
    </>
  );
}

export function PaginationFooter({
  totalRows,
  currentPage,
  perPage,
  visibleRows,
  totalPages,
  onChange,
  className,
}: {
  totalRows: number;
  currentPage: number;
  perPage: number;
  visibleRows: number;
  totalPages: number;
  onChange: (page: number) => void;
  className?: string;
}) {
  const first = totalRows > 0 ? (currentPage - 1) * perPage + 1 : 0;
  const through = totalRows > 0 ? Math.min(first + Math.max(visibleRows - 1, 0), totalRows) : 0;

  return (
    <div className={className ?? "flex flex-col items-center justify-between gap-3 border-t border-slate-200 bg-white p-3 md:flex-row lg:px-6"}>
      <p className="text-sm font-medium text-slate-500">
        {totalRows > 0 ? `Showing ${first} to ${through} of ${totalRows} entries` : "Showing 0 entries"}
      </p>
      <Pagination totalPages={totalPages} currentPage={currentPage} onChange={onChange} />
    </div>
  );
}
