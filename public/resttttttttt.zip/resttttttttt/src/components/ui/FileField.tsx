"use client";

import { useId, useState } from "react";
import { Paperclip, X } from "@/components/ui/icons";
import { ui } from "./styles";

/** Bytes as the size a person reads, for the chosen-file line. */
function readableSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * The attachment picker every upload dialog shares: a labelled file input, the
 * names of what is attached, and a way to clear the selection.
 *
 * `onChange` is optional. A form that is submitted with `new FormData(form)`
 * needs only the `name`; a form that builds its body by hand reads the files
 * from `onChange` instead.
 */
export function FileField({
  name,
  label,
  accept,
  multiple = false,
  hint,
  maxBytes,
  onChange,
  required = false,
}: {
  name: string;
  label: string;
  accept?: string;
  multiple?: boolean;
  hint?: string;
  /** Rejects an oversized file in the browser, before the request is made. */
  maxBytes?: number;
  onChange?: (files: File[]) => void;
  required?: boolean;
}) {
  const inputId = useId();
  const [files, setFiles] = useState<File[]>([]);
  const [error, setError] = useState("");

  function handleChange(event: React.ChangeEvent<HTMLInputElement>) {
    const chosen = Array.from(event.target.files ?? []);
    const tooBig = maxBytes !== undefined && chosen.some((file) => file.size > maxBytes);
    if (tooBig) {
      setError(`Each file must be ${readableSize(maxBytes)} or smaller.`);
      event.target.value = "";
      setFiles([]);
      onChange?.([]);
      return;
    }
    setError("");
    setFiles(chosen);
    onChange?.(chosen);
  }

  function clear() {
    const input = document.getElementById(inputId) as HTMLInputElement | null;
    if (input) input.value = "";
    setError("");
    setFiles([]);
    onChange?.([]);
  }

  return (
    <div>
      <label className={ui.label} htmlFor={inputId}>{label}</label>
      <input id={inputId} name={name} type="file" accept={accept} multiple={multiple}
        required={required} onChange={handleChange}
        className={`${ui.input} cursor-pointer file:mr-3 file:cursor-pointer file:rounded-lg file:border-0 file:bg-emerald-50 file:px-3 file:py-1 file:text-sm file:font-bold file:text-emerald-700`} />
      {hint && !error && <p className="mt-1 text-xs font-medium text-slate-500">{hint}</p>}
      {error && <p role="alert" className="mt-1 text-xs font-bold text-rose-600">{error}</p>}
      {files.length > 0 && (
        <ul className="mt-2 space-y-1">
          {files.map((file) => (
            <li key={`${file.name}-${file.size}`}
              className="flex items-center gap-2 rounded-lg bg-slate-50 px-2 py-1 text-xs font-medium text-slate-700">
              <Paperclip className="h-3.5 w-3.5 shrink-0 text-slate-400" aria-hidden="true" />
              <span className="min-w-0 flex-1 truncate">{file.name}</span>
              <span className="shrink-0 text-slate-500">{readableSize(file.size)}</span>
            </li>
          ))}
          <li>
            <button type="button" onClick={clear}
              className="inline-flex items-center gap-1 text-xs font-bold text-rose-600 hover:text-rose-700">
              <X className="h-3.5 w-3.5" aria-hidden="true" /> Remove
            </button>
          </li>
        </ul>
      )}
    </div>
  );
}
