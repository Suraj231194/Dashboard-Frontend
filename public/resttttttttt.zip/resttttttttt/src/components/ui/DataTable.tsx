"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { DEFAULT_PER_PAGE } from "@/lib/pagination";
import { PageSizeSelect, PaginationFooter } from "./ListPagination";
import { ui } from "./styles";
import { ArrowUpDown, RefreshCw, Search } from "./icons";

export type Column<T> = {
  /** Sort key sent to the server; omit for a column that cannot be sorted. */
  sortKey?: string;
  header: string;
  headerClassName?: string;
  cellClassName?: string;
  render: (row: T, rowNumber: number) => ReactNode;
};

type LoadedPage<T> = {
  key: string;
  rows: T[];
  totalRows: number;
  totalPages: number;
  error: string;
  /** The serial number the first row carries, kept with the rows it belongs to. */
  firstRowNumber: number;
};

/** The parameters behind the page currently on screen. */
export type TableQuery = {
  page: number;
  perPage: number;
  search: string;
  sortColumn: string;
  sortDirection: "ASC" | "DESC";
};

export type ListResponse<T> = {
  status?: string;
  message?: string;
  rows?: T[];
  totalRows?: number;
  page?: number;
  perPage?: number;
  totalPages?: number;
  [key: string]: unknown;
};

export function DataTable<T>({
  endpoint, columns, defaultSortColumn, defaultSortDirection = "DESC",
  searchPlaceholder = "Search Data...", toolbarActions, reloadToken = 0, rowKey,
  pinLastColumn = true, extraParams, queryRef, onLoaded, includeAllPageSizes = true,
  defaultPerPage = DEFAULT_PER_PAGE,
}: {
  endpoint: string;
  columns: Column<T>[];
  defaultSortColumn: string;
  defaultSortDirection?: "ASC" | "DESC";
  searchPlaceholder?: string;
  toolbarActions?: ReactNode;
  reloadToken?: number;
  rowKey: (row: T, index: number) => string | number;
  /** Pins the final column, so row actions stay reachable on a narrow screen. */
  pinLastColumn?: boolean;
  /** Filters a screen sends alongside the paging parameters. */
  extraParams?: Record<string, string>;
  /** Receives the parameters of the page on screen, for exports and the like. */
  queryRef?: { current: TableQuery | null };
  /** Receives successful list metadata such as screen counters. */
  onLoaded?: (payload: ListResponse<T>) => void;
  /**
   * Offers "All items" in the page-size menu. Set false where the endpoint
   * caps the page size, so the menu cannot promise a size it will not honour.
   */
  includeAllPageSizes?: boolean;
  /** The page size the screen opens on, where it is not the usual ten. */
  defaultPerPage?: number;
}) {
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState<number>(defaultPerPage);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [sortColumn, setSortColumn] = useState(defaultSortColumn);
  const [sortDirection, setSortDirection] = useState<"ASC" | "DESC">(defaultSortDirection);
  const [loaded, setLoaded] = useState<LoadedPage<T> | null>(null);
  /** Bumped by the retry button; it only exists to change the query key. */
  const [retryToken, setRetryToken] = useState(0);
  const requestId = useRef(0);

  const params = new URLSearchParams({
    page: String(page),
    per_page: String(perPage),
    search: debouncedSearch,
    sort_column: sortColumn,
    sort_direction: sortDirection,
    ...extraParams,
  });
  /** Identifies the page currently on screen, so a stale one reads as loading. */
  // An endpoint may already carry its own query (the finance registers pass
  // `?view=`), so the list parameters join it rather than start a second one.
  const separator = endpoint.includes("?") ? "&" : "?";
  const queryKey = `${endpoint}${separator}${params.toString()}#${reloadToken}.${retryToken}`;
  const loading = loaded?.key !== queryKey;

  // A refetch keeps the rows it already has on screen. Searching, sorting and
  // paging all replace the same list, so blanking it to a spinner between each
  // keystroke loses the reader's place for no gain. The stale rows are dimmed
  // and a progress line runs above them until the new page arrives.
  const settled = loaded !== null;
  const rows = settled ? loaded.rows : [];
  const totalRows = settled ? loaded.totalRows : 0;
  const totalPages = settled ? loaded.totalPages : 0;
  const error = loading ? "" : (loaded?.error ?? "");
  /** Nothing has ever loaded, so there is genuinely nothing to show yet. */
  const firstLoad = loading && !settled;
  /** A reload over rows already on screen. */
  const refreshing = loading && settled;
  /** The last error, still worth showing while a retry is in flight. */
  const staleError = refreshing ? loaded.error : "";

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search.trim());
      setPage(1);
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);

  // A changed filter shows a different set of rows, so go back to the first
  // page while rendering, rather than after a wasted fetch of the old page.
  const extraKey = JSON.stringify(extraParams ?? {});
  const [appliedExtraKey, setAppliedExtraKey] = useState(extraKey);
  if (extraKey !== appliedExtraKey) {
    setAppliedExtraKey(extraKey);
    setPage(1);
  }

  useEffect(() => {
    if (queryRef) {
      queryRef.current = { page, perPage, search: debouncedSearch, sortColumn, sortDirection };
    }
    const id = requestId.current + 1;
    requestId.current = id;
    const controller = new AbortController();
    fetch(queryKey, { signal: controller.signal })
      .then(async (response) => {
        const payload: ListResponse<T> = await response.json();
        if (!response.ok) throw new Error(payload.message || "Error loading data.");
        return payload;
      })
      .then((payload) => {
        if (requestId.current !== id) return;
        const serverPage = Math.max(1, Number(payload.page ?? page));
        if (serverPage !== page) {
          setPage(serverPage);
          return;
        }
        onLoaded?.(payload);
        setLoaded({
          key: queryKey,
          rows: payload.rows ?? [],
          totalRows: Number(payload.totalRows ?? 0),
          totalPages: Number(payload.totalPages ?? 0),
          error: "",
          firstRowNumber: (serverPage - 1) * perPage,
        });
      })
      .catch((cause: unknown) => {
        if (controller.signal.aborted || requestId.current !== id) return;
        setLoaded({
          key: queryKey,
          rows: [],
          totalRows: 0,
          totalPages: 0,
          error: cause instanceof Error ? cause.message : "Error loading data.",
          firstRowNumber: 0,
        });
      });
    return () => controller.abort();
    // queryKey carries the request values; callbacks intentionally do not refetch the table.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [queryKey]);

  /**
   * Re-runs the current request. The query key carries the request values, so
   * a nudge that changes nothing else is what forces the effect to run again.
   */
  function retry() {
    setLoaded(null);
    setRetryToken((current) => current + 1);
  }

  function changePerPage(value: number) {
    setPerPage(value);
    setPage(1);
  }

  function toggleSort(key: string) {
    if (sortColumn === key) {
      setSortDirection((direction) => (direction === "ASC" ? "DESC" : "ASC"));
    } else {
      setSortColumn(key);
      setSortDirection("ASC");
    }
    setPage(1);
  }

  /** Classes that pin the final column against the end of the scroll region. */
  function pinned(index: number, background: string): string {
    if (!pinLastColumn || index !== columns.length - 1) return "";
    return `sticky end-0 z-10 ${background} shadow-[inset_1px_0_0_rgb(226_232_240)]`;
  }

  // Taken from the rows on screen, not the requested page. During a page turn
  // the stale rows stay visible, and numbering them from the new page would
  // label them with positions they do not hold.
  const firstRowNumber = settled ? loaded.firstRowNumber : 0;
  return (
    <div className={ui.card}>
      <div className="border-b border-slate-200 bg-slate-50/70 p-3 lg:px-6 lg:py-3">
        <div className={ui.toolbar}>
          <PageSizeSelect value={perPage} onChange={changePerPage} includeAll={includeAllPageSizes}
            className="h-10 w-full shrink-0 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm sm:w-auto" />
          <div className="relative h-10 w-full flex-grow sm:min-w-40 sm:max-w-56">
            <Search className="pointer-events-none absolute inset-y-0 start-3 my-auto h-4 w-4 text-slate-400" aria-hidden="true" />
            <input type="search" value={search} onChange={(event) => setSearch(event.target.value)}
              aria-label={searchPlaceholder} placeholder={searchPlaceholder}
              className={`${ui.input} h-10 ps-9`} />
          </div>
          {toolbarActions}
        </div>
      </div>

      {/* A thin indeterminate line, so a refresh is visible without the rows
          moving or disappearing. It occupies no height when idle. */}
      <div aria-hidden="true" className="relative h-0.5 overflow-hidden bg-transparent">
        {loading && <div className="absolute inset-y-0 w-1/3 animate-[datatable-sweep_1.1s_ease-in-out_infinite] rounded-full bg-emerald-500/70" />}
      </div>

      <div className="w-full overflow-x-auto" tabIndex={0} role="region" aria-label="Table contents"
        aria-busy={loading || undefined}>
        <table className="w-full min-w-full border-collapse text-left">
          {/* Keep the header in the table flow. A sticky top offset inside this
              horizontal scroll region displaces it over the first data row. */}
          <thead className="border-b border-slate-100 bg-white whitespace-nowrap">
            <tr>
              <th className={`${ui.headerCell} w-16`}>#</th>
              {columns.map((column, index) => (
                <th key={column.header}
                  className={`${ui.headerCell} ${column.headerClassName ?? ""} ${pinned(index, "bg-white")} ${column.sortKey ? "cursor-pointer transition-colors hover:bg-slate-50/50" : ""}`}
                  onClick={column.sortKey ? () => toggleSort(column.sortKey as string) : undefined}
                  aria-sort={column.sortKey && sortColumn === column.sortKey
                    ? (sortDirection === "ASC" ? "ascending" : "descending") : undefined}>
                  <span className="inline-flex items-center gap-1">
                    {column.header}
                    {column.sortKey ? <ArrowUpDown className="h-3.5 w-3.5 text-slate-400" aria-hidden="true" /> : null}
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className={`divide-y divide-slate-100 bg-white ${refreshing ? "opacity-60 transition-opacity" : ""}`}>
            {firstLoad && (
              <tr><td colSpan={columns.length + 1} className="px-6 py-10 text-center text-sm font-semibold text-slate-500">Loading</td></tr>
            )}
            {(error || staleError) && (
              <tr>
                <td colSpan={columns.length + 1} className="px-6 py-10 text-center">
                  <p className="m-0 text-sm font-semibold text-rose-600">{error || staleError}</p>
                  <button type="button" onClick={retry} disabled={loading}
                    className={`${ui.secondaryButton} mt-3`}>
                    <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} aria-hidden="true" />
                    {loading ? "Retrying" : "Try again"}
                  </button>
                </td>
              </tr>
            )}
            {!firstLoad && !error && !staleError && rows.length === 0 && (
              <tr><td colSpan={columns.length + 1} className="px-6 py-3 text-center text-[13px] font-medium text-slate-500">No Records Available</td></tr>
            )}
            {!error && !staleError && rows.map((row, index) => (
              <tr key={rowKey(row, index)} className="group transition-colors hover:bg-slate-50/50">
                <td className={`${ui.cell} font-semibold whitespace-nowrap text-slate-900`}>{firstRowNumber + index + 1}</td>
                {columns.map((column, columnIndex) => (
                  <td key={column.header}
                    className={`${ui.cell} ${column.cellClassName ?? ""} ${pinned(columnIndex, "bg-white group-hover:bg-slate-50")}`}>
                    {column.render(row, firstRowNumber + index + 1)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <PaginationFooter totalRows={totalRows} currentPage={page} perPage={perPage}
        visibleRows={rows.length} totalPages={totalPages} onChange={setPage} />
    </div>
  );
}
