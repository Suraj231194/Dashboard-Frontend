"use client";

import { useId, type ButtonHTMLAttributes, type ReactNode } from "react";

/**
 * A button that says why it cannot be used.
 *
 * A control disabled for a moment while a request is in flight explains itself:
 * you just clicked it. One that stays dead because of a permission, an empty
 * selection or the state of the record does not, and a plain `disabled`
 * attribute makes it worse: the browser skips it when tabbing, so a keyboard
 * or screen-reader user cannot even reach it to find out why.
 *
 * So a stated reason is carried with `aria-disabled` instead of `disabled`.
 * The control stays reachable and announces its reason, and the click is
 * swallowed here rather than by the browser.
 *
 * Use `busy` for the in-flight case and `disabledReason` for the lasting one.
 */
export function ActionButton({
  disabledReason,
  busy = false,
  busyLabel,
  disabled,
  className = "",
  children,
  onClick,
  ...rest
}: Omit<ButtonHTMLAttributes<HTMLButtonElement>, "disabled"> & {
  /** Why this cannot be used. Shown on hover and to assistive technology. */
  disabledReason?: string;
  /** A request is in flight. The control is genuinely disabled meanwhile. */
  busy?: boolean;
  /** What to show while busy, such as "Saving…". */
  busyLabel?: ReactNode;
  disabled?: boolean;
  children: ReactNode;
}) {
  const hintId = useId();
  const blocked = Boolean(disabled) || disabledReason !== undefined;
  const stated = disabledReason !== undefined && !busy;

  return (
    <>
      <button
        {...rest}
        // Only the in-flight case uses the real attribute. A lasting reason
        // stays focusable so it can be read.
        disabled={busy || (blocked && !stated)}
        aria-disabled={stated || undefined}
        aria-describedby={stated ? hintId : undefined}
        title={stated ? disabledReason : rest.title}
        className={`${className} ${stated ? "cursor-not-allowed opacity-60" : ""}`}
        onClick={(event) => {
          if (stated) {
            event.preventDefault();
            return;
          }
          onClick?.(event);
        }}>
        {busy && busyLabel !== undefined ? busyLabel : children}
      </button>
      {stated && <span id={hintId} className="sr-only">{disabledReason}</span>}
    </>
  );
}
