import { createElement } from "react";
import {
  Activity, ArrowDown, ArrowLeftRight, ArrowUp, Award, BadgeCheck, Banknote, Beaker, BookUser,
  Bot, Boxes, Briefcase, Building2, Calendar, CalendarCheck, CalendarClock, CalendarDays,
  ChartPie, CircleCheck, CircleHelp, CirclePlus, ClipboardCheck, ClipboardList, Clock,
  CreditCard, Database, DoorOpen, Dot, Eye, FileBadge, FileCheck, FileCode, FileHeart,
  FileInput, FilePlus, FileSpreadsheet, FileText, FileType, Fingerprint, FlaskConical, Gauge,
  HandCoins, Handshake, Hourglass, IdCard, IndianRupee, Layers, LineChart, List, ListTree,
  Lock, Microscope, Package, PackageOpen, PackagePlus, Pill, Receipt, ReceiptText, RefreshCw,
  Scale, Settings, ShieldCheck, ShieldUser, Sparkles, SquarePlus, Stamp, Tags, TestTube, Truck,
  Upload, UserCog, UserPen, UserPlus, Users, Wallet, Warehouse, Wheat,
  type LucideIcon,
} from "lucide-react";

/**
 * The icon names stored against each menu row, mapped onto this application's
 * icon set. Keys are the significant part of the stored class, so both the
 * Tabler and Font Awesome spellings in the menu table resolve to one icon.
 */
const MENU_ICONS: Record<string, LucideIcon> = {
  // Stored against menu rows.
  "fa-calendar": Calendar,
  "fa-superpowers": Sparkles,
  "fa-building-wheat": Wheat,
  "fa-arrow-down": ArrowDown,
  "fa-arrow-up": ArrowUp,
  "fa-boxes": Boxes,
  "fa-briefcase": Briefcase,
  "fa-chart-line": LineChart,
  "fa-check-circle": CircleCheck,
  "fa-database": Database,
  "fa-file-alt": FileText,
  "fa-file-invoice": FileSpreadsheet,
  "fa-key": Lock,
  "fa-list": List,
  "fa-plus-circle": CirclePlus,
  "fa-robot": Bot,
  "fa-sync": RefreshCw,
  "fa-tachometer-alt": Gauge,
  "fa-user-edit": UserPen,
  "fa-user-plus": UserPlus,
  "fa-user-tag": IdCard,
  "fa-user-tie": Briefcase,
  "fa-users": Users,
  "fa-vial": TestTube,
  "fa-warehouse": Warehouse,
  "ti-briefcase": Briefcase,
  "ti-calendar-check": CalendarCheck,
  "ti-calendar-event": Calendar,
  "ti-calendar-stats": CalendarClock,
  "ti-cash": Banknote,
  "ti-cash-banknote": Banknote,
  "ti-clock-cog": Clock,
  "ti-credit-card-pay": CreditCard,
  "ti-credit-card-refund": CreditCard,
  "ti-currency-rupee": IndianRupee,
  "ti-door-exit": DoorOpen,
  "ti-file-check": FileCheck,
  "ti-file-description": FileText,
  "ti-file-dollar": FileSpreadsheet,
  "ti-file-invoice": FileSpreadsheet,
  "ti-file-text": FileText,
  "ti-file-upload": Upload,
  "ti-file-waveform": Activity,
  "ti-fingerprint": Fingerprint,
  "ti-help-circle": CircleHelp,
  "ti-hourglass": Hourglass,
  "ti-id-badge-2": IdCard,
  "ti-package-import": PackagePlus,
  "ti-receipt": Receipt,
  "ti-receipt-refund": ReceiptText,
  "ti-receipt-rupee": ReceiptText,
  "ti-refresh": RefreshCw,
  "ti-truck-delivery": Truck,
  "ti-user-plus": UserPlus,
  "ti-users": Users,
  "ti-point": Dot,

  // Used by the fallbacks for menu rows that carry no icon of their own.
  "fa-address-book": BookUser,
  "fa-box-open": PackageOpen,
  "fa-boxes-packing": Package,
  "fa-boxes-stacked": Boxes,
  "fa-building": Building2,
  "fa-building-shield": ShieldCheck,
  "fa-calendar-check": CalendarCheck,
  "fa-calendar-days": CalendarDays,
  "fa-cart-arrow-down": ArrowDown,
  "fa-cart-shopping": Package,
  "fa-certificate": Award,
  "fa-chart-pie": ChartPie,
  "fa-clipboard-check": ClipboardCheck,
  "fa-clipboard-list": ClipboardList,
  "fa-dolly": Truck,
  "fa-eye": Eye,
  "fa-file-circle-check": FileCheck,
  "fa-file-circle-plus": FilePlus,
  "fa-file-code": FileCode,
  "fa-file-import": FileInput,
  "fa-file-invoice-dollar": FileSpreadsheet,
  "fa-file-medical": FileHeart,
  "fa-file-pdf": FileType,
  "fa-file-prescription": Pill,
  "fa-file-signature": Stamp,
  "fa-file-waveform": Activity,
  "fa-flask": FlaskConical,
  "fa-gear": Settings,
  "fa-hand-holding-dollar": HandCoins,
  "fa-handshake": Handshake,
  "fa-layer-group": Layers,
  "fa-list-ul": ListTree,
  "fa-microscope": Microscope,
  "fa-money-check-dollar": Wallet,
  "fa-plus-square": SquarePlus,
  "fa-receipt": Receipt,
  "fa-right-left": ArrowLeftRight,
  "fa-tags": Tags,
  "fa-truck": Truck,
  "fa-truck-loading": PackagePlus,
  "fa-user-gear": UserCog,
  "fa-user-shield": ShieldUser,
  "fa-vial-circle-check": Beaker,
  "fa-scale-balanced": Scale,
  "fa-badge-check": BadgeCheck,
  "fa-file-badge": FileBadge,
};

function lookupMenuIcon(iconClasses: string, depth: number): LucideIcon | null {
  for (const name of iconClasses.split(/\s+/).filter(Boolean)) {
    const icon = MENU_ICONS[name];
    if (icon) return icon;
  }
  // Nested entries without an icon of their own keep a neutral marker.
  return depth > 1 ? Dot : null;
}

/** Renders the icon a menu row asks for, or nothing when it has none. */
export function MenuIcon({ iconClasses, depth, className }: {
  iconClasses: string;
  depth: number;
  className?: string;
}) {
  const icon = lookupMenuIcon(iconClasses, depth);
  if (!icon) return null;
  return createElement(icon, { className, "aria-hidden": true });
}

/** The icons the converted screens use directly. */
export {
  AlertTriangle, ArrowLeft, ArrowRight, ArrowUpDown, Briefcase, Building, Building2,
  Calendar, Camera, Check, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight,
  CircleCheck, CreditCard, Dot, Eye, EyeOff, Factory, FileText, FlaskConical, FolderX,
  House, IdCard, Info, KeyRound, Lock, LogOut, Mail, MapPin, Minus, Palette,
  Pencil, Phone, Plus, RotateCcw, Save, Search, ShieldCheck, Store, Trash2, Upload,
  Boxes, ChevronDown, Download, Filter, Package, PackagePlus, ShoppingCart, TriangleAlert, Truck,
  User, UserPlus, Warehouse, Wrench, X,
  ArrowLeftRight, Bell, ChartColumn, CheckCheck, CircleX, ClipboardList, Clock,
  FilePlus, Pause, Play, RefreshCw, Square, Table, Users,
  CircleAlert, ClipboardCheck, EllipsisVertical, FileSpreadsheet, Settings,
  Ban, FileDown, Tags,
  Banknote, ReceiptText, CalendarClock, Paperclip,
  Award, BadgeCheck, Coins, History, IndianRupee, Landmark, Receipt, Shield, Layers,
  Bot, Send, Database, Copy, UserCheck,
  CalendarCheck, Cpu, DoorOpen, FileBadge, Fingerprint, HandCoins, Headset, TrendingUp,
  UserCog, UserPen, Wallet,
  ArrowDown, ArrowUp, CalendarDays, Star, TestTube, Image as ImageIcon,
  LockOpen,
} from "lucide-react";
export type { LucideIcon } from "lucide-react";
