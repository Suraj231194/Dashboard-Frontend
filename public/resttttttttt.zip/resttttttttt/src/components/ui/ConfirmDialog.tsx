"use client";

import { useEffect, useRef } from "react";
import { ui } from "./styles";
import { AlertTriangle } from "./icons";

/** Stands in for the delete confirmation prompt the current screens show. */
export function ConfirmDialog({ open, title, message, confirmLabel = "Yes, delete it!", onConfirm, onCancel, busy = false }: {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
  busy?: boolean;
}) {
  const cancel = useRef<HTMLButtonElement | null>(null);
  const panel = useRef<HTMLDivElement | null>(null);
  /** Whatever had focus before the prompt opened, so it can be handed back. */
  const opener = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return;
    opener.current = document.activeElement as HTMLElement | null;

    // Focus starts on Cancel, never on the destructive button: a stray Enter
    // or Space should not delete anything.
    cancel.current?.focus();

    const { body } = document;
    const previousOverflow = body.style.overflow;
    body.style.overflow = "hidden";

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape" && !busy) {
        onCancel();
        return;
      }
      if (event.key !== "Tab") return;
      // Only two buttons, so the trap is just: keep focus on one of them.
      const buttons = [...(panel.current?.querySelectorAll<HTMLButtonElement>("button:not([disabled])") ?? [])];
      if (buttons.length === 0) {
        event.preventDefault();
        return;
      }
      const active = document.activeElement;
      const index = buttons.findIndex((button) => button === active);
      event.preventDefault();
      const next = event.shiftKey
        ? (index <= 0 ? buttons.length - 1 : index - 1)
        : (index === -1 || index === buttons.length - 1 ? 0 : index + 1);
      buttons[next].focus();
    }

    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      body.style.overflow = previousOverflow;
      opener.current?.focus?.();
    };
  }, [open, busy, onCancel]);

  if (!open) return null;
  return (
    // A destructive prompt is not dismissed by a stray click on the backdrop;
    // Cancel and Escape are the ways out.
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/50 p-4">
      <div ref={panel} role="alertdialog" aria-modal="true" aria-label={title}
        className="w-full max-w-md rounded-2xl bg-white p-5 text-center shadow-xl sm:p-6">
        <span className="mx-auto mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-amber-50 text-amber-600">
          <AlertTriangle className="h-7 w-7" aria-hidden="true" />
        </span>
        <h2 className="text-xl font-bold text-slate-900">{title}</h2>
        <p className="mt-2 text-sm font-medium text-slate-600">{message}</p>
        <div className="mt-6 flex flex-col-reverse items-stretch justify-center gap-3 sm:flex-row sm:items-center">
          <button ref={cancel} type="button" className={ui.secondaryButton} onClick={onCancel} disabled={busy}>Cancel</button>
          <button type="button" className={ui.primaryButton} onClick={onConfirm} disabled={busy}>
            {busy ? "Working…" : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
