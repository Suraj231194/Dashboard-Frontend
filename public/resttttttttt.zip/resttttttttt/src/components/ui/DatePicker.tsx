"use client";

import {
  useCallback,
  useEffect,
  useId,
  useRef,
  useState,
} from "react";
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
} from "@/components/ui/icons";
import { Field } from "./Form";

export interface DatePickerProps {
  name?: string;
  id?: string;
  value?: string;
  defaultValue?: string;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  min?: string;
  max?: string;
  className?: string;
  error?: string;
  ariaLabel?: string;
  "aria-label"?: string;
  onChange?: (isoDate: string) => void;
}

const MONTH_NAMES = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

const WEEKDAYS = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];

/** Converts `YYYY-MM-DD` or ISO string to `DD-MM-YYYY` */
export function formatToDisplayDate(dateStr: string | null | undefined): string {
  if (!dateStr) return "";
  const clean = dateStr.slice(0, 10);
  const parts = clean.split("-");
  if (parts.length === 3 && parts[0].length === 4) {
    const [year, month, day] = parts;
    return `${day.padStart(2, "0")}-${month.padStart(2, "0")}-${year}`;
  }
  return dateStr;
}

/** Converts `DD-MM-YYYY` or `YYYY-MM-DD` to `YYYY-MM-DD` */
export function formatToISODate(dateStr: string | null | undefined): string {
  if (!dateStr) return "";
  const clean = dateStr.slice(0, 10);
  if (clean.includes("-")) {
    const parts = clean.split("-");
    if (parts.length === 3) {
      if (parts[0].length === 4) {
        // already YYYY-MM-DD
        return clean;
      }
      if (parts[2].length === 4) {
        // DD-MM-YYYY -> YYYY-MM-DD
        const [day, month, year] = parts;
        return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
      }
    }
  }
  return dateStr;
}

export function DatePicker({
  name,
  id,
  value: controlledValue,
  defaultValue = "",
  placeholder = "dd-mm-yyyy",
  required = false,
  disabled = false,
  min,
  max,
  className = "",
  error,
  ariaLabel,
  "aria-label": ariaLabelAttr,
  onChange,
}: DatePickerProps) {
  const generatedId = useId();
  const datePickerId = id ?? generatedId;
  const isControlled = controlledValue !== undefined;

  const [internalISO, setInternalISO] = useState<string>(
    formatToISODate(defaultValue)
  );
  const isoValue = isControlled
    ? formatToISODate(controlledValue)
    : internalISO;

  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Parse initial view year/month from current value or today
  const initialDate = isoValue ? new Date(isoValue) : new Date();
  const validInitial = !isNaN(initialDate.getTime()) ? initialDate : new Date();

  const [viewYear, setViewYear] = useState<number>(validInitial.getFullYear());
  const [viewMonth, setViewMonth] = useState<number>(validInitial.getMonth());

  function syncView() {
    if (isoValue) {
      const d = new Date(isoValue);
      if (!isNaN(d.getTime())) {
        setViewYear(d.getFullYear());
        setViewMonth(d.getMonth());
      }
    }
  }


  // Handle outside click to close popover
  useEffect(() => {
    if (!isOpen) return;

    function handleMouseDown(event: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    }

    document.addEventListener("mousedown", handleMouseDown);
    return () => document.removeEventListener("mousedown", handleMouseDown);
  }, [isOpen]);

  const handleSelectDate = useCallback(
    (year: number, month: number, day: number) => {
      const padM = String(month + 1).padStart(2, "0");
      const padD = String(day).padStart(2, "0");
      const newISO = `${year}-${padM}-${padD}`;

      if (!isControlled) {
        setInternalISO(newISO);
      }
      onChange?.(newISO);
      setIsOpen(false);
    },
    [isControlled, onChange]
  );

  const handleClear = useCallback(() => {
    if (!isControlled) {
      setInternalISO("");
    }
    onChange?.("");
    setIsOpen(false);
  }, [isControlled, onChange]);

  const handleToday = useCallback(() => {
    const today = new Date();
    handleSelectDate(
      today.getFullYear(),
      today.getMonth(),
      today.getDate()
    );
  }, [handleSelectDate]);

  const handlePrevMonth = () => {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear((y) => y - 1);
    } else {
      setViewMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear((y) => y + 1);
    } else {
      setViewMonth((m) => m + 1);
    }
  };

  // Build calendar matrix
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  const firstDayIndex = new Date(viewYear, viewMonth, 1).getDay();
  const prevMonthDays = new Date(viewYear, viewMonth, 0).getDate();

  const calendarCells: {
    day: number;
    month: number;
    year: number;
    isCurrentMonth: boolean;
  }[] = [];

  // Previous month trailing days
  for (let i = firstDayIndex - 1; i >= 0; i--) {
    const m = viewMonth === 0 ? 11 : viewMonth - 1;
    const y = viewMonth === 0 ? viewYear - 1 : viewYear;
    calendarCells.push({
      day: prevMonthDays - i,
      month: m,
      year: y,
      isCurrentMonth: false,
    });
  }

  // Current month days
  for (let i = 1; i <= daysInMonth; i++) {
    calendarCells.push({
      day: i,
      month: viewMonth,
      year: viewYear,
      isCurrentMonth: true,
    });
  }

  // Next month leading days (fill up to 42 cells)
  const remaining = 42 - calendarCells.length;
  for (let i = 1; i <= remaining; i++) {
    const m = viewMonth === 11 ? 0 : viewMonth + 1;
    const y = viewMonth === 11 ? viewYear + 1 : viewYear;
    calendarCells.push({
      day: i,
      month: m,
      year: y,
      isCurrentMonth: false,
    });
  }

  const todayStr = new Date().toISOString().slice(0, 10);
  const displayValue = formatToDisplayDate(isoValue);

  return (
    <div ref={containerRef} className={`relative w-full ${className}`}>
      {/* Hidden input for standard form submission with ISO date */}
      {name && (
        <input
          type="hidden"
          name={name}
          value={isoValue}
          required={required && !isoValue}
        />
      )}

      {/* Visible Input Control */}
      <div className="relative flex items-center">
        <input
          id={datePickerId}
          type="text"
          readOnly
          disabled={disabled}
          value={displayValue}
          placeholder={placeholder}
          aria-label={ariaLabel ?? ariaLabelAttr}
          aria-invalid={error ? true : undefined}
          onClick={() => {
            if (!disabled) {
              syncView();
              setIsOpen((prev) => !prev);
            }
          }}
          className={`h-10 w-full cursor-pointer rounded-xl border bg-white px-3.5 pe-10 text-sm font-semibold transition-all outline-none ${
            error
              ? "border-rose-400 ring-2 ring-rose-500/20"
              : isOpen
              ? "border-primary-600 ring-2 ring-primary-500/20"
              : "border-slate-200 hover:border-slate-300"
          } ${
            disabled
              ? "cursor-not-allowed bg-slate-50 text-slate-400"
              : displayValue
              ? "text-slate-800"
              : "text-slate-400"
          }`}
        />

        <div className="pointer-events-none absolute end-3 flex items-center gap-1.5">
          <CalendarIcon
            className={`h-4 w-4 ${
              isOpen ? "text-primary-600" : "text-slate-400"
            }`}
            aria-hidden="true"
          />
        </div>
      </div>

      {/* Calendar Popover */}
      {isOpen && (
        <div className="absolute start-0 top-full z-50 mt-1.5 w-72 overflow-hidden rounded-2xl border border-slate-200 bg-white p-3 shadow-2xl ring-1 ring-slate-900/5 animate-in fade-in-50 zoom-in-95 duration-100">
          {/* Header Month / Year Navigation */}
          <div className="mb-2 flex items-center justify-between">
            <button
              type="button"
              onClick={handlePrevMonth}
              aria-label="Previous month"
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900"
            >
              <ChevronLeft className="h-4 w-4" aria-hidden="true" />
            </button>

            <div className="flex items-center gap-1">
              <span className="text-sm font-bold text-slate-800">
                {MONTH_NAMES[viewMonth]}
              </span>
              <span className="text-sm font-extrabold text-slate-900">
                {viewYear}
              </span>
            </div>

            <button
              type="button"
              onClick={handleNextMonth}
              aria-label="Next month"
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900"
            >
              <ChevronRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>

          {/* Weekday Row */}
          <div className="mb-1 grid grid-cols-7 text-center">
            {WEEKDAYS.map((day) => (
              <span
                key={day}
                className="py-1 text-[11px] font-bold tracking-wider text-slate-400"
              >
                {day}
              </span>
            ))}
          </div>

          {/* Day Grid */}
          <div className="grid grid-cols-7 gap-1 text-center">
            {calendarCells.map((cell, index) => {
              const cellISO = `${cell.year}-${String(cell.month + 1).padStart(
                2,
                "0"
              )}-${String(cell.day).padStart(2, "0")}`;
              const isSelected = cellISO === isoValue;
              const isToday = cellISO === todayStr;
              const isOutOfRange =
                (min && cellISO < min) || (max && cellISO > max);

              return (
                <button
                  key={index}
                  type="button"
                  disabled={Boolean(isOutOfRange)}
                  onClick={() =>
                    handleSelectDate(cell.year, cell.month, cell.day)
                  }
                  style={{
                    backgroundColor: isSelected
                      ? "var(--appearance-accent, #1a4d2e)"
                      : undefined,
                  }}
                  className={`flex h-8 w-8 items-center justify-center rounded-lg text-xs font-semibold transition-all ${
                    isOutOfRange
                      ? "cursor-not-allowed opacity-30 text-slate-300"
                      : isSelected
                      ? "font-extrabold text-white shadow-sm"
                      : isToday
                      ? "border border-primary-500 bg-primary-50/60 font-bold text-primary-800"
                      : cell.isCurrentMonth
                      ? "text-slate-800 hover:bg-slate-100"
                      : "text-slate-300 hover:bg-slate-50"
                  }`}
                >
                  {cell.day}
                </button>
              );
            })}
          </div>

          {/* Footer Actions */}
          <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2 text-xs font-semibold">
            <button
              type="button"
              onClick={handleToday}
              style={{ color: "var(--appearance-accent, #1a4d2e)" }}
              className="hover:underline"
            >
              Today
            </button>
            {isoValue && (
              <button
                type="button"
                onClick={handleClear}
                className="text-rose-600 hover:underline"
              >
                Clear
              </button>
            )}
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="text-slate-500 hover:text-slate-800"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export function DateField({
  label,
  required,
  hint,
  error,
  className,
  id,
  ...datePickerProps
}: DatePickerProps & {
  label: string;
  hint?: string;
}) {
  const generatedId = useId();
  const controlId = id ?? generatedId;

  return (
    <Field
      label={label}
      htmlFor={controlId}
      required={required}
      hint={hint}
      error={error}
      className={className}
    >
      <DatePicker
        id={controlId}
        required={required}
        error={error}
        {...datePickerProps}
      />
    </Field>
  );
}
