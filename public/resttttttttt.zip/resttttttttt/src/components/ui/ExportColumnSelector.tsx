"use client";

import { ui } from "./styles";

/** Shared column picker used by every tabular export dialog. */
export function ExportColumnSelector({
  columns,
  selected,
  onChange,
  name = "listOfColumns[]",
  legend = "Select columns",
}: {
  columns: readonly string[];
  selected: readonly string[];
  onChange: (columns: string[]) => void;
  name?: string;
  legend?: string;
}) {
  const allSelected = columns.length > 0 && columns.every((column) => selected.includes(column));

  function toggle(column: string, checked: boolean) {
    onChange(checked
      ? columns.filter((entry) => entry === column || selected.includes(entry))
      : selected.filter((entry) => entry !== column));
  }

  return (
    <fieldset>
      <div className="mb-2 flex items-center justify-between gap-3">
        <legend className={`${ui.label} mb-0`}>{legend}</legend>
        <button type="button" className="text-sm font-bold transition-colors hover:opacity-80"
          style={{ color: "var(--appearance-accent, #1a4d2e)" }}
          onClick={() => onChange(allSelected ? [] : [...columns])}>
          {allSelected ? "Deselect all" : "Select all"}
        </button>
      </div>
      <div className="grid grid-cols-1 gap-1 sm:grid-cols-2">
        {columns.map((column) => (
          <label key={column}
            className="flex min-h-10 cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-white">
            <input type="checkbox" name={name} value={column}
              style={{ accentColor: "var(--appearance-accent, #1a4d2e)" }}
              className="h-4 w-4 rounded"
              checked={selected.includes(column)} onChange={(event) => toggle(column, event.target.checked)} />
            <span>{column}</span>
          </label>
        ))}
      </div>
    </fieldset>

  );
}
