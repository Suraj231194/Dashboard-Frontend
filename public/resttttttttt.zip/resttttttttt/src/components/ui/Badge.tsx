import { STATUS_BADGES } from "./styles";

/** Renders the Active/Inactive pill used across the list screens. */
export function StatusBadge({ status }: { status: number }) {
  if (status !== 0 && status !== 1) return null;
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-bold ${status === 1 ? STATUS_BADGES.active : STATUS_BADGES.inactive}`}>
      {status === 1 ? "Active" : "Inactive"}
    </span>
  );
}

/** Renders the Yes/No pill used for the sidebar visibility column. */
export function YesNoBadge({ value }: { value: number }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-bold ${value === 1 ? STATUS_BADGES.active : STATUS_BADGES.warning}`}>
      {value === 1 ? "Yes" : "No"}
    </span>
  );
}
