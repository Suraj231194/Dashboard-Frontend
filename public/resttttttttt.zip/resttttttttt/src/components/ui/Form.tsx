"use client";

import { useId, type ReactNode, type SelectHTMLAttributes, type InputHTMLAttributes, type TextareaHTMLAttributes } from "react";
import { ui } from "./styles";

/** The `{ key, value }` pair every options endpoint already returns. */
export type Option = { key: string | number; value: string };

/**
 * A labelled control. Every screen was writing the same
 * `<div><label className={ui.label}>…</label>…</div>` by hand, which is why
 * required markers and hint text drifted between them.
 */
export function Field({ label, htmlFor, required = false, hint, error, className = "", action, children }: {
  label: string;
  htmlFor?: string;
  required?: boolean;
  hint?: string;
  error?: string;
  className?: string;
  /** A small control on the label's line, such as an upload for the field. */
  action?: ReactNode;
  children: ReactNode;
}) {
  const labelElement = (
    <label className={action ? ui.label.replace(/mb-1/, "mb-0") : ui.label} htmlFor={htmlFor}>
      {label}
      {required && <span className="ms-0.5 text-rose-600" aria-hidden="true">*</span>}
    </label>
  );
  return (
    <div className={className}>
      {action
        ? <div className="mb-1.5 flex items-center justify-between gap-2">{labelElement}{action}</div>
        : labelElement}
      {children}
      {error
        ? <p className="mt-1 text-xs font-semibold text-rose-600">{error}</p>
        : hint ? <p className="mt-1 text-xs font-medium text-slate-500">{hint}</p> : null}
    </div>
  );
}

import { SearchableSelect, type SearchableOption } from "./SearchableSelect";
import { DatePicker } from "./DatePicker";

/**
 * A select whose options come from an options endpoint. The empty first entry
 * matches the `----Select Option----` placeholder the current screens show.
 */
export function Select({
  options, placeholder = "----Select Option----", includePlaceholder = true, className = "",
  value, defaultValue, name, id, required, disabled, onChange, children, ...rest
}: Omit<SelectHTMLAttributes<HTMLSelectElement>, "children"> & {
  options?: readonly (Option | SearchableOption)[];
  placeholder?: string;
  includePlaceholder?: boolean;
  children?: ReactNode;
}) {
  if (options && options.length > 0 && !children) {
    return (
      <SearchableSelect
        id={id}
        name={name}
        value={value !== undefined ? String(value) : undefined}
        defaultValue={defaultValue !== undefined ? String(defaultValue) : undefined}
        placeholder={placeholder}
        required={required}
        disabled={disabled}
        options={options}
        className={className}
        onChange={(val) => {
          if (onChange) {
            const syntheticEvent = {
              target: { value: val, name: name || "" },
              currentTarget: { value: val, name: name || "" },
            } as React.ChangeEvent<HTMLSelectElement>;
            onChange(syntheticEvent);
          }
        }}
        {...(rest as Record<string, unknown>)}
      />
    );
  }

  return (
    <select id={id} name={name} value={value} defaultValue={defaultValue}
      required={required} disabled={disabled} onChange={onChange}
      className={`${ui.input} ${className}`} {...rest}>
      {includePlaceholder && <option value="">{placeholder}</option>}
      {options?.map((option) => {
        const key = "key" in option ? option.key : "id" in option ? (option as { id: unknown }).id : (option as { value: unknown }).value;
        const val = "value" in option ? option.value : (option as { label: string }).label;
        return <option key={String(key)} value={String(key)}>{val}</option>;
      })}
      {children}
    </select>
  );
}

/** A labelled select, the shape most dialogs need. */
export function SelectField({
  label, required, hint, error, className, options, placeholder, includePlaceholder, id, ...rest
}: Omit<SelectHTMLAttributes<HTMLSelectElement>, "children"> & {
  label: string;
  required?: boolean;
  hint?: string;
  error?: string;
  className?: string;
  options?: readonly (Option | SearchableOption)[];
  placeholder?: string;
  includePlaceholder?: boolean;
}) {
  const generated = useId();
  const controlId = id ?? generated;
  return (
    <Field label={label} htmlFor={controlId} required={required} hint={hint} error={error} className={className}>
      <Select id={controlId} required={required} options={options} placeholder={placeholder}
        includePlaceholder={includePlaceholder} aria-invalid={error ? true : undefined} {...rest} />
    </Field>
  );
}

/** A labelled text, number, date or time input. Automatically renders DatePicker for date types. */
export function InputField({
  label, required, hint, error, className, action, id, type, value, defaultValue, onChange, name, disabled, readOnly, placeholder, ...rest
}: InputHTMLAttributes<HTMLInputElement> & {
  label: string;
  required?: boolean;
  hint?: string;
  error?: string;
  className?: string;
  action?: ReactNode;
}) {
  const generated = useId();
  const controlId = id ?? generated;

  if (type === "date") {
    return (
      <Field label={label} htmlFor={controlId} required={required} hint={hint} error={error} className={className}>
        <DatePicker
          id={controlId}
          name={name}
          value={value !== undefined ? String(value) : undefined}
          defaultValue={defaultValue !== undefined ? String(defaultValue) : undefined}
          required={required}
          disabled={disabled || readOnly}
          placeholder={placeholder || "dd-mm-yyyy"}
          error={error}
          ariaLabel={label}
          onChange={(isoDate) => {
            if (onChange) {
              const syntheticEvent = {
                target: { value: isoDate, name: name || "" },
                currentTarget: { value: isoDate, name: name || "" },
              } as React.ChangeEvent<HTMLInputElement>;
              onChange(syntheticEvent);
            }
          }}
          {...(rest as Record<string, unknown>)}
        />
      </Field>
    );
  }

  return (
    <Field label={label} htmlFor={controlId} required={required} hint={hint} error={error} className={className} action={action}>
      <input id={controlId} type={type} required={required} value={value} defaultValue={defaultValue}
        name={name} disabled={disabled} readOnly={readOnly} placeholder={placeholder} onChange={onChange}
        className={ui.input} aria-invalid={error ? true : undefined} {...rest} />
    </Field>
  );
}

/** A labelled multi-line input. */
export function TextAreaField({
  label, required, hint, error, className, id, rows = 3, ...rest
}: TextareaHTMLAttributes<HTMLTextAreaElement> & {
  label: string;
  required?: boolean;
  hint?: string;
  error?: string;
  className?: string;
}) {
  const generated = useId();
  const controlId = id ?? generated;
  return (
    <Field label={label} htmlFor={controlId} required={required} hint={hint} error={error} className={className}>
      <textarea id={controlId} required={required} rows={rows} className={ui.input}
        aria-invalid={error ? true : undefined} {...rest} />
    </Field>
  );
}

/**
 * The body and footer of a dialog form. Keeping them here means every dialog
 * scrolls its body and stacks its footer the same way on a narrow screen.
 */
export function ModalForm({ onSubmit, children, footer }: {
  onSubmit: (event: React.FormEvent<HTMLFormElement>) => void;
  children: ReactNode;
  footer: ReactNode;
}) {
  return (
    <form onSubmit={onSubmit} noValidate>
      <div className="max-h-[70vh] overflow-y-auto p-4 sm:p-5">{children}</div>
      <div className="flex flex-col-reverse items-stretch gap-2 border-t border-slate-200 bg-slate-50/80 px-4 py-3 sm:flex-row sm:items-center sm:justify-end sm:gap-3 sm:px-5">
        {footer}
      </div>
    </form>
  );
}

/** The two-column grid dialog fields sit in, stacking below `sm`. */
export function FieldGrid({ columns = 2, children }: { columns?: 1 | 2 | 3; children: ReactNode }) {
  const layout = columns === 1 ? "" : columns === 3
    ? "sm:grid-cols-2 lg:grid-cols-3"
    : "sm:grid-cols-2";
  return <div className={`grid grid-cols-1 gap-4 ${layout}`}>{children}</div>;
}

export { SearchableSelect, SearchableSelectField } from "./SearchableSelect";
export type { SearchableOption, SearchableSelectProps } from "./SearchableSelect";
export { DatePicker, DateField, formatToDisplayDate, formatToISODate } from "./DatePicker";
export type { DatePickerProps } from "./DatePicker";

