"use client";

import { useId, useState, type ReactNode } from "react";
import { Download } from "@/components/ui/icons";
import { ExportColumnSelector } from "@/components/ui/ExportColumnSelector";
import { Modal } from "@/components/ui/Modal";
import { DatePicker } from "@/components/ui/DatePicker";
import { SearchableSelect } from "@/components/ui/SearchableSelect";
import { ui } from "./styles";

/** The three formats the current export handlers accept, with their labels. */
export const EXPORT_FORMAT_OPTIONS = [
  { value: "csv", label: "CSV (Comma Separated Values)" },
  { value: "excel", label: "Excel Workbook (.xlsx)" },
  { value: "pdf", label: "PDF Document" },
] as const;

/**
 * The export dialog every list shares: a format picker, an optional date
 * range and the column selector, over whatever extra filters a screen adds.
 *
 * Every list in the current application opens the same dialog, so keeping one
 * component here is what stops the screens drifting apart again. The form is
 * submitted by the caller, which posts it to its own export endpoint.
 */
export function ExportDialog({
  open,
  onClose,
  onSubmit,
  columns,
  selected,
  onColumnsChange,
  busy = false,
  title = "Export Document",
  subtitle = "Configure your export settings before downloading.",
  dateRange = false,
  dateRangeLabels = { from: "From date", to: "To date" },
  children,
}: {
  open: boolean;
  onClose: () => void;
  onSubmit: (event: React.FormEvent<HTMLFormElement>) => void;
  columns: readonly string[];
  selected: readonly string[];
  onColumnsChange: (columns: string[]) => void;
  busy?: boolean;
  title?: string;
  subtitle?: string;
  /** Adds the `exportFromDate` / `exportToDate` pair the period exports use. */
  dateRange?: boolean;
  dateRangeLabels?: { from: string; to: string };
  /** Extra filters this list's export offers, rendered above the columns. */
  children?: ReactNode;
}) {
  const prefix = useId();
  const id = (suffix: string) => `${prefix}-${suffix}`;
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  // A range that runs backwards would silently return nothing, so the dialog
  // says so rather than letting the export come back empty.
  const rangeInverted = dateRange && from !== "" && to !== "" && from > to;

  return (
    <Modal open={open} title={title} subtitle={subtitle} icon={Download} onClose={onClose}>
      <form onSubmit={onSubmit}>
        <div className="space-y-4 bg-slate-50/70 p-3 sm:p-4">
          <div>
            <label className={ui.label} htmlFor={id("format")}>File format</label>
            <SearchableSelect
              id={id("format")}
              name="exportType"
              defaultValue="csv"
              includePlaceholder={false}
              allowClear={false}
              options={EXPORT_FORMAT_OPTIONS.map((option) => ({
                key: option.value,
                value: option.label,
              }))}
            />
          </div>

          {dateRange && (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className={ui.label} htmlFor={id("from")}>{dateRangeLabels.from}</label>
                <DatePicker
                  id={id("from")}
                  name="exportFromDate"
                  value={from}
                  max={to || undefined}
                  onChange={(iso) => setFrom(iso)}
                />
              </div>
              <div>
                <label className={ui.label} htmlFor={id("to")}>{dateRangeLabels.to}</label>
                <DatePicker
                  id={id("to")}
                  name="exportToDate"
                  value={to}
                  min={from || undefined}
                  onChange={(iso) => setTo(iso)}
                />
              </div>
              <p className="col-span-full m-0 text-xs font-medium text-slate-500">
                Leave both blank to export every record the current filters match.
              </p>

              {rangeInverted && (
                <p role="alert" className="col-span-full m-0 text-xs font-bold text-rose-600">
                  The start date must not be later than the end date.
                </p>
              )}
            </div>
          )}

          {children}

          <ExportColumnSelector columns={columns} selected={selected} onChange={onColumnsChange} />
          {selected.length === 0 && (
            <p role="alert" className="m-0 text-xs font-bold text-rose-600">
              Select at least one column to export.
            </p>
          )}
        </div>
        <div className="flex flex-col-reverse items-stretch justify-end gap-3 border-t border-slate-200 bg-white p-3 sm:flex-row sm:items-center sm:px-4">
          <button type="button" className={ui.secondaryButton} onClick={onClose}>Cancel</button>
          <button type="submit" className={ui.primaryButton} disabled={busy || selected.length === 0 || rangeInverted}>
            <Download className="h-4 w-4" aria-hidden="true" /> {busy ? "Exporting…" : "Export"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
