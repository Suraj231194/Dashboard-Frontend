/**
 * The signature widget the controlled documents (COA, BMR/BPR) render into
 * their editable markup: a typed name, or an uploaded image of a signature,
 * held in one hidden field that the document's collector reads.
 *
 * Both document families share the behaviour and differ only in their class
 * prefix (`coa-v1-sig-*`, `bmr-v2-sig-*`), which is what the current page
 * scripts do with two copies of the same handlers.
 */

/** 250 KB, the limit both current page scripts enforce. */
export const SIGNATURE_MAX_BYTES = 250 * 1024;

/**
 * Puts a signature image into a widget, or clears it (`dataUri` empty): the
 * hidden value, the preview, and which half of the widget shows.
 */
export function applySignature(widget: Element, prefix: string, dataUri: string): void {
  const cls = (name: string) => `${prefix}-sig-${name}`;
  const hidden = widget.querySelector<HTMLInputElement>(`.${cls("value")}`);
  if (hidden) hidden.value = dataUri;
  const preview = widget.querySelector<HTMLElement>(`.${cls("preview")}`);
  let image = widget.querySelector<HTMLImageElement>(`.${cls("preview-img")}`);
  if (dataUri !== "") {
    if (!image && preview) {
      image = document.createElement("img");
      image.className = cls("preview-img");
      image.alt = "Signature";
      preview.prepend(image);
    }
    if (image) image.src = dataUri;
  } else {
    image?.removeAttribute("src");
  }
  if (preview) preview.style.display = dataUri !== "" ? "" : "none";
  const group = widget.querySelector<HTMLElement>(`.${cls("input-group")}`);
  if (group) group.style.display = dataUri !== "" ? "none" : "";
  const text = widget.querySelector<HTMLInputElement>(`.${cls("text")}`);
  if (text) text.value = "";
}

/**
 * Reads a picked file as a signature: an image of at most 250 KB, as a
 * `data:` URI. Reports and resolves empty on anything else.
 */
export function readSignatureFile(file: File, onError: (message: string) => void): Promise<string> {
  if (file.size > SIGNATURE_MAX_BYTES) {
    onError("Signed image size must not exceed 250 KB.");
    return Promise.resolve("");
  }
  if (!/^image\//i.test(file.type)) {
    onError("Please upload a valid image file (PNG, JPG, JPEG, WEBP).");
    return Promise.resolve("");
  }
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => resolve("");
    reader.readAsDataURL(file);
  });
}

/**
 * Wires the widgets under `root` by delegation. Returns the cleanup.
 * `prefix` is the part before `-sig-`, e.g. `coa-v1` or `bmr-v2`.
 */
export function attachSignatureWidgets(
  root: HTMLElement,
  prefix: string,
  onError: (message: string) => void,
): () => void {
  const cls = (name: string) => `${prefix}-sig-${name}`;
  const within = (widget: Element | null, name: string) => widget?.querySelector<HTMLElement>(`.${cls(name)}`) ?? null;

  const onInput = (event: Event) => {
    const target = event.target;
    if (!(target instanceof HTMLInputElement) || !target.classList.contains(cls("text"))) return;
    const hidden = within(target.closest(`.${cls("widget")}`), "value");
    if (hidden instanceof HTMLInputElement) hidden.value = target.value;
  };

  const onChange = (event: Event) => {
    const target = event.target;
    if (!(target instanceof HTMLInputElement) || !target.classList.contains(cls("file-input"))) return;
    const file = target.files?.[0];
    target.value = "";
    if (!file) return;
    const widget = target.closest(`.${cls("widget")}`);
    void readSignatureFile(file, onError).then((dataUri) => {
      if (widget && dataUri !== "") applySignature(widget, prefix, dataUri);
    });
  };

  const onClick = (event: Event) => {
    const button = (event.target as HTMLElement).closest(`.${cls("clear-btn")}`);
    if (!button) return;
    const widget = button.closest(`.${cls("widget")}`);
    if (!widget) return;
    applySignature(widget, prefix, "");
    within(widget, "text")?.focus();
  };

  root.addEventListener("input", onInput);
  root.addEventListener("change", onInput);
  root.addEventListener("change", onChange);
  root.addEventListener("click", onClick);
  return () => {
    root.removeEventListener("input", onInput);
    root.removeEventListener("change", onInput);
    root.removeEventListener("change", onChange);
    root.removeEventListener("click", onClick);
  };
}
