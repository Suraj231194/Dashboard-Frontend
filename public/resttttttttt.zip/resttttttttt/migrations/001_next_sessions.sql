-- Apply to a disposable copy first. Do not run against production during setup.
CREATE TABLE IF NOT EXISTS next_sessions (
  token_hash CHAR(64) NOT NULL PRIMARY KEY,
  user_id INT NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_next_sessions_user_id (user_id),
  KEY idx_next_sessions_expires_at (expires_at),
  CONSTRAINT fk_next_sessions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
