-- The COA template mapping records which profile family a product uses.
--
-- Both applications read and write `coa_template_product_mappings.family_key`,
-- but no migration creates it. Where it is missing, the current application's
-- lookup fails its prepare and every batch falls back to choosing a template by
-- hand, and a chosen template is never remembered. This application copes with
-- either shape; applying this lets both behave as their code intends.
--
-- Idempotent: safe on a database that already has the column.

ALTER TABLE `coa_template_product_mappings`
  ADD COLUMN IF NOT EXISTS `family_key` VARCHAR(100) NULL DEFAULT NULL AFTER `coa_type`;
