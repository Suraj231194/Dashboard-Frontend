# Warehouse and inventory remediation

A field-level audit of the converted warehouse and inventory screens against
the current PHP application found defects that corrupt stock, not just cosmetic
differences. This records what was fixed, what is still open, and why the
remaining work is a rewrite rather than a patch.

## The root cause

`live_stock` was refactored to **one balance row per product**:

| Column | Meaning |
|---|---|
| `quantity_available` | the physical balance |
| `reserved_qty` | the part committed to orders |
| `unreserved_qty` | generated, `quantity_available - reserved_qty` — what may actually be issued |

`UNIQUE KEY uq_live_stock_product (product_id)` enforces one row per product,
and `quantity_initial`, `qauntity_initial_unit`, `unit_factor`,
`quantity_in_base` and `reserved_quantity` were dropped
(`migrations/2026_09_23_001_*` and `2026_09_23_003_*`).

Every quantity change in the PHP application goes through the `inventory*`
helpers in `admin/functions.php:2449-2811`, which guard the balance and write an
`inventory_movements` ledger row.

The conversion targeted the **pre-refactor per-batch schema** and wrote plain
`UPDATE live_stock SET quantity_available = …` statements, so it bypassed both
the guards and the ledger.

## Fixed

The ledger helpers are ported in `src/modules/inventory/inventory-ledger.ts`
(`ensureBalance`, `getBalance`, `addStock`, `consumeUnreservedStock`,
`consumeReservedStock`, `restoreStock`, `logMovement`). Use them for every
quantity change; do not write to `live_stock` directly.

| # | Defect | Effect before the fix | Where |
|---|---|---|---|
| 1 | Product edit posted no reorder level | **Every product edit reset `reorder_level` to 0**, disabling the low-stock and out-of-stock machine for that product. The field was missing from both the add and the edit dialog while the endpoint still read it. | `ProductsScreen.tsx` |
| 2 | Availability summed `quantity_available` | Reserved stock counted as available across the stock list, the three tiles, the low-stock ageing clock, procurement candidates and the export. The current application sums `unreserved_qty`. | `stock-list-sql.ts`, `stocks.ts` |
| 3 | Goods-issuance availability check summed `quantity_available` | Stock already committed to an order could be issued again. | `goods-issuance.ts` |
| 4 | Dispatch deducted with a plain `UPDATE` | `reserved_qty` was never decremented, so **a product stayed reserved forever after every dispatch** and could never be dispatched again. No ledger row. | `stock-outwards.ts` |
| 5 | Partial dispatch closed every reservation | A partial dispatch flipped all matching reservations to a closed status without reducing the quantity, **destroying the remaining reservation**. | `stock-outwards.ts` |
| 6 | Only the `_base` fulfilment columns moved | `fulfilled_quantity`, `reserved_quantity` and `shortfall_quantity` never changed, so the order screens showed stale fulfilment. | `stock-outwards.ts` |
| 7 | Manual outward deducted with a plain `UPDATE` | No unreserved guard and no ledger row. | `stock-outwards.ts` |
| 8 | Delete-outward restored by balance-row id, with no `deleted_at` filter | **Deleting twice restored the stock twice**, and the restore left no ledger row. | `stock-outwards.ts` |
| 9 | Delete-outward had no id guard | A missing id silently no-opped instead of reporting invalid input. | `stock-outwards.ts` |
| 10 | Goods receipt stored a literal `0` quantity | **Every hand-entered receipt recorded no quantity.** The PHP code had already fixed this and says so in a comment; the conversion reproduced the old bug and described it as a preserved quirk. | `stock-inwards.ts` |
| 11 | Intact goods credited stock immediately | **Receipts were released to available without QC.** The current application calls `inventoryEnsureBalance` only, leaving goods quarantined until final QC approval. | `stock-inwards.ts` |

### The allocation rewrite

`live_stock` is now read and written as one balance row per product everywhere:

- **Dispatch against an order** walks `order_stock_reservations` (the stock row
  supplies only the batch identity) and deducts through `consumeReservedStock`.
- **Manual outward, BOM issuance, material-request issuance and order routing**
  deduct through `consumeUnreservedStock`, guarded on the unreserved balance.
- **Goods receipt and PO verify** open the balance with `ensureBalance` and
  leave the goods quarantined for QC.
- **Production receipt** credits the full actual quantity through `addStock`
  with `reference_key = production_receipt:{id}`, so a retry cannot double it.
- **Product create/edit and the stock entry and CSV import** set or credit the
  balance through `setUnreservedStock` / `addStock`.
- Reservation capacity is read from the generated `unreserved_qty` rather than
  a dropped base column.

No unit factors are applied to a balance any more; the quantity stored is the
quantity issued, which is what the current application does.

## Also fixed

### The QC-release lock

Deleting a goods receipt, and changing its received quantity, are both refused
once final QC has released the goods, with the messages the current handlers
use. The release is identified by the `qc_release:{id}` row in
`inventory_movements`, which is the same test the current code makes. Neither
path touches `live_stock` any more: they used to look the balance up by a
`stock_inward_id` column that no longer exists.

### The post-commit hooks

- **Auto-routing.** `autoRoutePendingOrdersAfterStockChange` in
  `order-routing.ts` re-checks the oldest 25 orders in the eight waiting
  statuses, which is what `tasks/route_pending.php` does when the current code
  spawns it. Both goods-receipt paths now await it and report the outcome; the
  messages used to promise a background task the port never started.
- **Reserved-quantity sync.** Dispatch collects the balances it drew on and
  runs `syncLiveStockReservedQuantity` over them inside the transaction.
- **Fulfilment recalculation.** After the commit, every order the dispatch left
  partially delivered is recalculated, and a failure there is logged rather
  than failing the committed dispatch.

### The finance sync

`finance-sync.ts` ports the Goods-Receipt importer and `finance-dispatch-sync.ts`
the Goods-Dispatch importer, both from
`admin/finance/finance_common.php`. A receipt now raises its Incoming Bill and a
dispatch raises its Sales Invoice and Delivery Challan, and the reply says how
many of each were raised.

Both entry points borrow their own connection, so the sync never shares the
transaction that stored the receipt or the dispatch, and a billing failure is
reported in the message rather than thrown: the warehouse record is already
committed and must not be rolled back by an accounting problem.

Points worth keeping in mind when reading them:

- The bill is keyed on the receipt **submission token**, not the invoice
  number, so entering an invoice during Quality cannot mint a second bill.
- The recency guard throughout is a five-minute wall clock on the database
  server. There is no watermark table, which is also true of the current code.
- One dispatch yields two documents. A Delivery Challan is the same snapshot
  with no tax, no accounting effect and its own source-key namespace, and it
  gets header enrichment from a Proforma Invoice but not line enrichment.
- The dispatch importer computes no money. The line and header totals belong to
  the generation step, as they do now.
- The proforma tables are optional and are probed through `information_schema`
  before either enrichment runs.

### Invoice attachments

`lib/uploads/invoice-uploads.ts` ports `mvStoreInvoiceUploads`: the same 10 MB
cap, the same four accepted types, the same `uploads/invoices/` directory and
the same JSON-array column, which is the shape the finance sync reads back. The
type is decided from the file's leading bytes rather than its name or the
browser's declared type, as the current code decides it with `finfo`.

Both receipt dialogs now carry the attachment control, through the shared
`components/ui/FileField.tsx`: several images on the add dialog
(`invoiceImages[]`) and one file on the PO verify dialog (`verifyInvoiceFile`).
An oversized file is refused in the browser before the request is made, and
refused again on the server.

### The website order-status push

Ported, in `modules/sync/`, and called after a dispatch commits, once per order
whose status moved. It cannot fail the dispatch. See `docs/WEBSITE-SYNC.md`.

### Exports

One server renderer, `lib/export/table-export.ts`, writes the CSV, the .xlsx
(exceljs) and the PDF for every list, and one client dialog,
`components/ui/ExportDialog.tsx`, offers the format picker, the optional date
range and the column selector. Seven export endpoints and their screens now
share them: stock inwards, stock outwards, goods issuance, stocks, order
management, purchase management and manual payroll. Goods issuance has its date
range back. The endpoints stream the file rather than writing it into an
`exports/` directory as the current application does.

## Still open

The per-batch model is gone. Every read and write across the warehouse,
inventory, procurement and sales modules now targets the per-product balance,
and no code references a dropped column. What remains is behaviour the audits
found missing, not schema breakage:

- `bmrBprEnsureRequestForMaterialRequisition` is not called when a requisition
  completes, so the controlled BMR/BPR request is never raised.
- Production receipt omits its history rows, order re-check and notification,
  and does not run the two batch-size cross-checks.
- Stocks: the inline add/edit **product** form the toolbar and row pencil open
  has no Next counterpart; Product Stage, Unreserved Stock and the image
  drop-zone exist nowhere.
- Bulk select-all on the inbound dispatch list, the dispatcher pre-select, and
  the "Create / Clone BOM" recovery path are missing.

## Rule for new code

Never write `UPDATE live_stock SET quantity_available = …`. Every credit,
issue, dispatch and reversal goes through `inventory-ledger.ts` so the balance
is guarded and the movement is recorded.
