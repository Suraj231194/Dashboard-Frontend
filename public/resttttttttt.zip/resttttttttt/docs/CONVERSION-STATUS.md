# Conversion status

What has been converted from the current PHP application, what has not, and
what the remaining work is. Counts are measured from the source, not estimated:
the legacy screens are the `.php` files under `admin/pages/`, and the converted
screens are the entries in `src/modules/navigation/routes.ts`, each of which has
a matching `src/app/(erp)/<slug>/page.tsx`.

Last measured: 89 converted, 117 legacy page files.

## How to read the numbers

Not every `admin/pages/*.php` file is a screen:

| Kind | Count | Examples |
|---|---|---|
| Dated backups | 10 | `bmr copy 2`, `dashboard24072025bpk`, `suppliers12082025bkp` |
| Print/PDF templates and partials | 14 | `pi_template`, `purchase_order_template`, `clone-bom-modal` |
| Placeholder stubs with no behaviour | 5 | `bpr`, `rapid-show`, `user-list`, `create_user` |
| Wrappers that set a variable and require another page | 8 | the seven `finance-*` pages, `pi-requests` |
| Real screens | ~84 | |

A wrapper is not extra work: the seven finance wrappers are one implementation
(`finance-page.php`) behind seven routes, and are converted the same way here.

## Converted (89)

Access and administration
: `roles`, `permissions`, `role-has-permissions`, `menus`, `users`,
  `company-setup`, `settings`, `appearance`, `profile`, `account-settings`

Inventory and store
: `products`, `product-categories`, `suppliers`, `stocks`, `low-stocks`,
  `labels`, `store-setting`

Procurement and purchasing
: `material-request`, `material-requisition`, `transfer-ticket`,
  `purchase-management`, `final-purchase-orders`

Warehouse
: `stock-inwards`, `stock-outwards`, `goods-received-production`,
  `goods-issuance`

Sales and CRM
: `order-received`, `order-detail`, `salesperson-master`, `pricelist-catalog`

Payroll
: `payroll-advances`, `payroll-reimbursements`, `payroll-pay-runs`,
  `salary-account`, `payroll-manual`

Finance
: `finance-reimbursement-claims`, and the seven registers below

Website sync
: `meeting-requests`, `quotation-requests`, `quiz-activity-feed`,
  `customer-management`

Production and quality
: `production-plan`, `production-bmr-bpr`, `raw-material-packing-material`,
  `bmr-bpr-form-request`, `bmr-bpr-issuance`, `bmr`, `bpr`,
  `daily-production-report-bseh`, `rapid`, `rapid-create`, `rapid-show`,
  `coa-generation`, `coa-templates`, `ip-coa-generation`, `fg-coa-generation`,
  `sa-generation`, `goods-received-production`

HR, attendance and payroll
: `employee-master`, `employees`, `employee-profile`, `attendance-management`,
  `worker-attendance`, `attendance-summary`, `leave-management`,
  `annual-calendar`, `offboarding`, `advance-salary`, `shift-management`,
  `payroll-advances`, `payroll-reimbursements`, `payroll-pay-runs`,
  `payroll-manual`, `salary-account`, `user-list`, `create_user`

Customer relationships and tenders
: `lead-management`, `crm-quote-management`, `pi-requests`,
  `salesperson-master`, `tenders`, `tender-settings`, `tender-dashboard`

Other
: `dashboard`, `sync`, `ai-assistance`, `custom-import`, `store-scm-dashborad`

### Website sync screens

Four of the entries the sidebar lists under Sync. All four read snapshots the
website pull writes into this database.

| Screen | Writes it allows |
|---|---|
| `meeting-requests` | None. Read-only, with a detail dialog. |
| `quotation-requests` | None. Read-only, with a line-item detail dialog. |
| `quiz-activity-feed` | The lead status, guarded by the same slug that guards the screen, as today. |
| `customer-management` | Add and edit a customer, with the full validation list. |

Three deliberate differences from the current screens, each marked in the code
where it occurs:

1. **Paging moved to the server.** All four current grids fetch every row and
   page in the browser. Their endpoints already accept search and filter
   parameters, but the pages never send them, so the predicates were dead code.
   They are used now: the same rows, one page at a time.
2. **Search matches what the box says it matches.** The meeting and customer
   search boxes filter on more fields in the browser than their server
   predicates covered. The endpoints now cover the same fields as the box.
3. **Soft-deleted quotations are excluded.** The current quotation grid has no
   `deleted_at` condition while its own export does, so a deleted quotation
   appears on screen but not in the file. The list now filters it, as the
   export does.

Two defects found in the current code and not reproduced:

- The meeting export reads `website_meeting_requests`, a table that exists in
  no migration and appears once in the whole codebase. The query fails, the
  error is swallowed, and the user gets a valid file containing only a header
  row and a success message. Worth fixing in the PHP application too.
- `getMeetingDetails` and `getCustomerDetails` return no message when the row is
  missing, and the screens have no failure branch, so clicking through to a
  deleted record does nothing at all. Both now report the miss.

The **Sync Website / Import** buttons now work. The pull subsystem is ported in
`modules/sync/`, along with the outbound pushes and the `sync` dashboard that
controls them. See `docs/WEBSITE-SYNC.md` for how it is shaped and what will
surprise you in it.

### Finance registers

All seven screens that `finance-page.php` serves are converted, from one screen
component driven by the same view configuration the PHP file carries:

| Screen | View |
|---|---|
| `finance-bill-generation` | `bill_generation` |
| `finance-invoice-generation` | `invoice_generation` |
| `finance-challan-generation` | `challan_generation` |
| `finance-payment-made` | `payment_made` |
| `finance-payment-received` | `payment_received` |
| `finance-trade-payables` | `trade_payables` |
| `finance-trade-receivables` | `trade_receivables` |

Converted behaviour: the seven registers with their own columns, search, sort
and paging; the incoming queue with its pending count; classifying a vendor
bill Paid / Unpaid / Not Sure, which records a full payment when it is Paid;
Create / Don't on an invoice or challan, re-checked under a row lock; recording
a payment or receipt against a document, capped at the outstanding amount; the
document detail dialog with its lines and tax summary; and serving a stored
source invoice or generated PDF.

Not yet converted in Finance, and why it matters:

| Missing | Effect |
|---|---|
| Document generation (`generate_document`) | An invoice or challan cannot be created from a draft, so `DRAFT` rows cannot reach `GENERATED`. This is the GST calculation, the numbering sequence and the PDF. |
| Source sync (`sync_sources`) | The incoming queue is populated by syncing Goods Received and Goods Dispatched into `finance_documents`. Without it the queue only shows rows the PHP application already created. |
| Payment reversal (`reverse_payment`) | A posted payment cannot be reversed. |
| Product commercials, bank accounts | The two dialogs behind the invoice editor. |
| `preview_document_html` | The template preview. |

## Every screen is converted

All 89 slugs in `CONVERTED_PAGES` have a page, and every page directory is
registered; the two lists reconcile exactly. The clusters that were open are:

| Cluster | Screens |
|---|---|
| HR and attendance | `employee-master`, `employees`, `employee-profile`, `attendance-management`, `worker-attendance`, `attendance-summary`, `leave-management`, `annual-calendar`, `offboarding`, `advance-salary` |
| Production and quality | `production-plan`, `production-bmr-bpr`, `raw-material-packing-material`, `bmr-bpr-form-request`, `bmr-bpr-issuance`, `bmr`, `daily-production-report-bseh`, `rapid`, `rapid-create` |
| Certificates of analysis | `coa-generation`, `coa-templates`, `ip-coa-generation`, `fg-coa-generation`, `sa-generation` |
| Tenders | `tenders`, `tender-settings`, `tender-dashboard` |
| Customer relationships | `lead-management`, `crm-quote-management`, `pi-requests` |
| Purchasing | `purchase-order`, `purchase-order-raw` |
| Other | `sync`, `ai-assistance` |

`pages/calender.php` is deliberately **not** ported. It is an unreferenced
demo: no menu migration row, no sidebar icon entry, its permission slugs appear
only as string literals in the dispatcher, and the table it reads has no schema
definition anywhere.

## What was changed rather than reproduced

Each of these is a defect in the current application that the port corrects.
They are commented where they occur.

| Change | Why |
|---|---|
| An advance-salary insert now sets `status = 1` | The legacy insert omits it, so every advance is invisible to payroll, which filters on that value. |
| A certificate template's items are deleted by their foreign key | The legacy delete matches the item id against the *template* id, removing an unrelated row. |
| Reading and deleting an assistant conversation are scoped to the owner | The legacy handlers take the id alone, so any signed-in person can read or delete another's chat by guessing a number. |
| A template preview no longer injects stored header and footer markup | That path echoes unsanitised stored HTML. |
| Bank and designation are selected on the employee section editor | They were omitted, so their dropdowns never pre-filled. |
| Several endpoints gained the permission their button already carries | Their handlers had no check at all. |

## What is deliberately left out

**Printable documents.** The sampling advice, the certificate of analysis, the
certificate record, the proforma invoice letterhead and the batch record pages
were a separate document-layout stack. Their buttons remain and say the
printable document is not available yet. Every list export works in all three
formats.

**Offboarding email.** The app has no mail transport. Documents still move to
`generated` and are rendered on demand for download instead of being posted.

**The sync crons.** Three loops over functions `modules/sync/` already exposes.
They belong behind a scheduled route guarded by a shared secret rather than in
the request path. The dashboard's manual buttons cover the same ground.

**Dead reference behaviour**, verified unreachable before being skipped: a
dialog no control opens, buttons rendered with `d-none`, handlers that do not
exist, and a fire-and-forget request whose response is ignored.

## One thing to decide before cutover

Document snapshot checksums are computed in JavaScript over the same fields,
but are not byte-identical to the PHP encoding. Snapshots written and verified
inside this application are self-consistent. A snapshot already written by the
PHP application will fail its integrity check. Either port the PHP encoding
exactly, or rehash the existing rows during the migration.

## Shared components

The pieces every screen draws from. Use these rather than writing a local copy;
that is what the duplication below came from.

| Concern | Module |
|---|---|
| Money, dates, quantities, rounding, masking | `src/lib/format.ts` |
| Labelled inputs, selects, textareas, dialog form shell, field grid | `src/components/ui/Form.tsx` |
| Loading, empty and error states | `src/components/ui/States.tsx` |
| Table with search, sort and paging | `src/components/ui/DataTable.tsx` |
| Dialog shell | `src/components/ui/Modal.tsx` |
| Delete confirmation | `src/components/ui/ConfirmDialog.tsx` |
| Notifications | `src/components/ui/Toast.tsx` |
| Control classes | `src/components/ui/styles.ts` |
| Icons | `src/components/ui/icons.tsx` |
| Calling an endpoint | `src/lib/client/api.ts` |
| Response envelope, guards, paging | `src/lib/http/`, `src/lib/pagination.ts` |

### Consolidated

`money()` had four identical copies and `formatDateDMY()` four; both now live in
`src/lib/format.ts`, along with `formatDateDMYTime`, `dateDMonY`,
`dateSlashDMY`, `currentMonthValue`, `maskTail`, `toNumber` and `round2`. The
modules that exported the old names re-export them, so their callers are
unchanged.

`PayrollPayRunsScreen` keeps its own `dateLabel`: it renders "05 Jan 2026",
which is a different format from the `d/m/Y` the other two used, so folding it
in would have changed what the screen shows.

### Still worth consolidating

The `<select>` elements that predate `Form.tsx` and could adopt `SelectField`.
They are visually identical today, so this is tidying rather than a fix; do it
per screen, not in one sweep, so each can be looked at. A grouped select cannot
use `SelectField`, which takes a flat option list, but should still sit inside
the shared `Field` wrapper so the label and hint styling come from one place.

## Checks

```bash
npx tsc --noEmit -p tsconfig.json   # clean
npx eslint .                        # clean
npx next build                      # succeeds
node tests/check-responsive.mjs     # needs the app running
```

The production build was failing before this work: `PayrollManualScreen` (a
client component) imported `MANUAL_EXPORT_COLUMNS` from `manual.ts`, which is
`server-only`, pulling the query helpers and the MySQL driver into the browser
bundle and failing on `net` and `tls`. The column lists moved to
`manual-constants.ts`; `manual.ts` re-exports them. A scan of every client
component found no other import of this kind.
