# The website sync

The ERP and the public website exchange records over HTTP. This records how
the ported subsystem is shaped and the decisions worth knowing before changing
it. The reference is `admin/sync/` in the current application.

## The pieces

| File | What it is |
|---|---|
| `lib/sync/sync-manager.ts` | the HTTP client, the configuration read and the retry schedule |
| `modules/sync/sync-settings.ts` | the module switches and the `sync_logs` ledger |
| `modules/sync/website-push.ts` | ERP to website: order status and product stock |
| `modules/sync/website-pull.ts` | website to ERP: customers, meetings, quiz leads, proformas and quotations |
| `modules/sync/sync-dashboard.ts` | what the screen reads, including the website's own queue |
| `modules/sync/SyncDashboardScreen.tsx` | the screen |

## It fails closed

A module with no `sync_settings` row reads as **disabled**. A half-applied
migration therefore exchanges nothing rather than pushing data at an endpoint
that may not be ready.

A module cannot be enabled at all until `WEBSITE_SYNC_BASE_URL` and
`WEBSITE_SYNC_TOKEN` are set. Both are read from the server environment and
must never be `NEXT_PUBLIC_`. The example placeholders that ship in the
environment file are treated as absent, so a module cannot be switched on
against a token that was never replaced.

## Every exchange is logged before it is made

A push writes its `sync_logs` row first and marks it afterwards. A failure is
therefore a queued retry rather than a lost message, and the dashboard can
offer it back to a person.

The pull inverts this: it acknowledges only the records that stored cleanly,
and writes its log row after the acknowledgement. A record that fails to save
is never acknowledged, so the website keeps offering it.

## What retries and what does not

Only **outbound** rows retry, up to five attempts, with one, two, four, eight
then sixteen minutes between them. Nothing distinguishes a rejection from a
transport failure: both are retried until the attempts run out, and the row
then stays failed. There is no dead-letter status.

An inbound acknowledgement batch is never retried automatically, because a
batch cannot be replayed on its own. Recovery is another pull.

A manual retry from the dashboard ignores the backoff.

## Two gates, deliberately different

- An **order** syncs when its category **or** its product carries the website
  flag.
- **Stock** syncs only when the category **and** the product carry it.

That asymmetry is in the current application and is kept: an order is a single
event worth reporting even when only part of it is listed on the website, while
publishing a stock figure for an unlisted product would be wrong.

## Points that will surprise you

- A stock push allocates its version number **before** the call and never rolls
  it back, so a failed push still burns a number. A retry reuses the stored
  payload and does not allocate another.
- The stock quantity comes from the **first** balance row, not a sum. One
  balance row per product is the current schema, so the two agree, but the
  query is not defensive about it.
- The ERP sends its **raw** status integer as `erp_status`. There is no
  ERP-to-website status map on this side; the label appears only inside the
  human-readable remark. Do not add one, or the two systems will disagree.
- A document snapshot is refused when the website offers a `sync_version` older
  than the one already stored. A delayed record cannot overwrite a newer one.
- The quiz answers are replaced only when the incoming record carries the
  `answers` key at all, so a partial record cannot silently wipe them.

## Where it is called from

`syncOrderStatusSafely` runs after a goods dispatch commits, once per order
whose status moved. It never throws: a dispatch that is already committed must
not fail because the website is unreachable.

The dashboard's buttons drive the rest — enabling a module, pulling one by
hand, pushing pending stock, and retrying a single failure.

## Not ported

The three cron workers (`cron_sync_pull.php`, `cron_sync_retry.php`,
`cron_sync_inventory.php`). Each is a loop over the same functions this module
already exposes, so they belong behind a scheduled route guarded by a shared
secret rather than inside the request path. The manual buttons on the dashboard
cover the same ground meanwhile.
