# How a screen is converted

Every converted screen follows the same shape. Read the access module, the role
screen and the role endpoints before writing anything: they are the reference
implementation and cover a list, a create, an edit, a delete and a permission
gate.

## Source of truth

The current PHP application decides behaviour. For each screen, read its page
file under `admin/pages/` and every action it posts to `admin/ajax.php` (search
for the action name). Keep the same SQL, the same validation order, the same
messages, the same permission slugs and the same side effects. Where the current
code has a quirk, keep the quirk and note it in a comment.

## Files each module adds

```text
src/modules/<area>/<thing>.ts          service: SQL and rules, "server-only"
src/modules/<area>/<Thing>Screen.tsx   the screen, a client component
src/app/api/<area>/<thing>/route.ts    list and create
src/app/api/<area>/<thing>/[id]/route.ts  read, update, delete
src/app/(erp)/<page-slug>/page.tsx     server page: access check, then screen
```

The page slug must match the `page=` value in the menu route, so the sidebar
links to it.

## Rules

**Database.** Use the helpers in `src/lib/db/query.ts`. Never build SQL by
concatenating user input; the only interpolation allowed is a sort column that
has been checked against an allow-list, exactly as the list endpoints do.

**Access.** A page calls `getPageAccess("<page-slug>")` and renders `Forbidden`
when it is not allowed. An endpoint calls `requireApiPermission` with the slug
the current action checks, or `requireApiPageAccess` when the current action has
no check of its own. Controls that the current screen hides behind a permission
are resolved on the server with `canAll` and passed to the screen as booleans.

**Responses.** Endpoints answer with the `{ status, message, ... }` envelope
from `src/lib/http/json.ts`. Lists return `{ rows, totalRows, page, perPage,
totalPages }` and read their parameters with `readListQuery`.

**Screens.** Wrap the screen in `ToastProvider`. Use `DataTable` for lists,
`Modal` for dialogs, `ConfirmDialog` for deletes, `PageHeader` for the heading,
and the classes in `src/components/ui/styles.ts` for controls. Call endpoints
through `sendForm` from `src/lib/client/api.ts`.

**Icons.** Import icons from `src/components/ui/icons.tsx`, which re-exports the
icon set. Never add an icon font or a `<i class="ti ...">` element. If a new
icon is needed, add it to that file's exports so every screen draws from one
place.

**Responsive.** Every screen must work from 320px upwards. Stack toolbars and
modal footers on small screens, keep tap targets at least 40px tall, let wide
tables scroll inside their own region rather than the page, and never let the
page scroll sideways. `tests/check-responsive.mjs` enforces this; add the new
screen to its list.

**Style.** British-adjacent plain names, short comments that explain why rather
than what, no `any`, no unchecked non-null assertions. Keep SQL and rules in the
service, never in a component.

## Before calling a module done

- `npx tsc --noEmit -p tsconfig.json` and `npx eslint` both clean.
- The screen's list matches the current query: add a case to
  `tests/legacy-lists.php` and `tests/compare-list-results.mjs`.
- The main flows exercised against the local copy, with any rows the check
  creates removed afterwards.

Do not treat a passing build as evidence that the behaviour matches.
