# Photograph credits

- `alpine-cover-hd.jpg`: **Smiling Woman in Pink Jacket Skiing**, Rockwell branding agency, [Pexels photo 20598491](https://www.pexels.com/photo/smiling-woman-in-pink-jacket-skiing-20598491/). Downloaded as a 1440 × 2790 portrait crop for case artwork.
- `alpine-ski-hd.jpg`: the same photograph in a wider 1600-pixel version, retained as a source alternative.
- `alpine-hd.jpg`: **Woman in Pink Jacket Hiking in Mountains**, Vish Pix, [Pexels photo 20544050](https://www.pexels.com/photo/woman-in-pink-jacket-hiking-in-mountains-20544050/). Retained as a second HD source option.

Photographs are provided under the [Pexels license](https://www.pexels.com/license/). No affiliation or endorsement is implied.

`alpine-memory.jpg` is the previous user-supplied reference crop. It remains for provenance and is no longer used by the application.

The press photographs come from the seven reference photos in `scripts/ref` (supplied 18 November 2026), which replaced every earlier press photo:

- `hd/press-hero` (hero) is `5c4b2345-…jpeg`; `hd/press-cover` (finale) is `ffb57c64-…jpeg`. Both are upscaled to 2560 px, cleaned and sharpened, with a 1080 px `-sm` version.
- `journey/press-loaded` (step 3) is cut out of `18b6ba89-…jpeg`.
- `journey/press-load`, `press-seal`, `press-heat` and `press-reveal` (step 5, the press at work) are cut out of `5c4b2345-…`, `6a1bf088-…`, `e63561cc-…` and `519832d5-…jpeg`, and placed on one 1620 × 1536 canvas aligned on the base of the press so they change in place. The lid of each open frame meets the base at 49.7 % (`seal`) and 48 % (`reveal`) of the canvas height, which `Journey.tsx` uses to fold the lid.
- Cutouts are masked on the press's turquoise, with the enclosed interior filled and edge colours taken from inside the press; they are 2× upscaled WebP with alpha. `8a850c54-…jpeg` is not used.
- In `press-reveal`, the printed case from the photo is replaced with the step 1 artwork (`alpine-cover-hd.jpg`), warped onto the case and lit to match, so the press reveals the design the journey started with. The photo's own camera opening (the mould showing through it) is kept. The frame as photographed is in the backup as `journey/press-reveal-red-case.webp`.
- `journey/drop-blank` and `journey/drop-film` are `7-blank` (upscaled 2×) and `4-film`, turned to lie the way the case lies in the tray; step 5 drops them onto the mould in 3D. The rising case at the end of step 5 is `8-final`, and the swinging membrane is drawn in CSS to match `press-seal`.

`press-heat` shows the vendor's Podind.in label on the clear cover, as supplied.

The old press photos (`hd/press-*`, `workshop/press-*`, `journey/3-press-photo`, `journey/5-press`, `heat-press.jpg`) were removed; a copy is in `scripts/Case-main-backup-2026-11-18`. The other photos in `hd/` (`mould`, `blank-shell`, `case-samples`, `printer-real`) came with the Case Studio redesign brief; `case-samples` is cropped to the finished cases and excludes the third-party logo in the original. `workshop/` holds the previous design's derivatives and is no longer used.
