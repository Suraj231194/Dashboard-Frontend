"use client";

import { memo, useEffect, useRef, useState, type CSSProperties, type RefObject } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUpRight } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import type Lenis from "lenis";
import { steps } from "./process";

const count = steps.length;
export const number = (i: number) => String(i + 1).padStart(2, "0");
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const smooth = (v: number) => {
  const t = clamp(v, 0, 1);
  return t * t * (3 - 2 * t);
};

/*
 * Product photographs with their backgrounds removed (WebP with alpha). Steps 3 and 5 are the
 * workshop's own turquoise press, cut out of the photographs in scripts/ref and upscaled 2×
 * (see public/assets/CREDITS.md); steps 1, 4 and 8 are HD renders of the case artwork; the rest
 * come from the reference infographic.
 */
const images: { src: string; w: number; h: number }[] = [
  ["1-app", 626, 1280],
  ["2-paper", 257, 449],
  ["press-loaded", 1954, 1800],
  ["4-film", 904, 1280],
  ["press-load", 1620, 1536],
  ["6-mould", 200, 502],
  ["7-blank", 243, 541],
  ["8-final", 651, 1280],
].map(([name, w, h]) => ({ src: `/assets/journey/${name}.webp`, w: w as number, h: h as number }));

/*
 * Step 5 plays the press's operation as the page scrolls, so it gets a longer stretch of scroll.
 * Its four frames share one canvas, aligned on the base of the press, so they change in place.
 */
const OP_STEP = 4;
const spans = steps.map((_, i) => (i === OP_STEP ? 3.5 : 1));
const starts = spans.map((_, i) => spans.slice(0, i).reduce((a, b) => a + b, 0));
const total = starts[count - 1] + spans[count - 1];
const OP = { w: 1620, h: 1536 };
const opSrc = (name: string) => `/assets/journey/press-${name}.webp`;
/** Where the lid meets the base in each open frame, as a share of the frame's height. */
const HINGE = { seal: 0.497, reveal: 0.48 };
const phases = [
  { name: "Load", note: "A blank case, then your printed film, go onto the mould" },
  { name: "Seal", note: "The membrane swings down and the lid closes" },
  { name: "Heat", note: "Heat and vacuum press the design into the case" },
  { name: "Reveal", note: "The lid lifts and your finished case rises out" },
];
/** Where each phase starts in the operation's own progress, 0 → 1. */
const phaseStart = [0, 0.22, 0.48, 0.7, 1];

/** Step names as the reference words them. */
const labels = [
  "Design App",
  "Sublimation paper (white paper)",
  "L8058 printer",
  "Sublimation film (with design)",
  "Sublimation heat press",
  "Universal mould",
  "Blank phone case",
  "Customized phone case",
];
const short = ["App", "Paper", "Printer", "Film", "Press", "Mould", "Blank", "Final"];

/*
 * Film position x runs 0 → 8; screen i owns x ∈ [i, i + 1).
 * A screen plays in over [i − 0.05, i + 0.25] and out over [i + 0.75, i + 1],
 * so only one step is on screen at a time, with a short overlap between them.
 */
const playIn = (x: number, i: number) => (i === 0 ? 1 : smooth((x - i + 0.05) / 0.3));
const playOut = (x: number, i: number) => (i === count - 1 ? 0 : smooth((x - i - 0.75) / 0.25));
const seg = (v: number, a: number, b: number) => clamp((v - a) / (b - a), 0, 1);

/** Scroll progress (0 → 1) to film position x; screen i takes spans[i] of the scroll. */
function toX(p: number) {
  const t = clamp(p, 0, 1) * total;
  let i = count - 1;
  while (i > 0 && t < starts[i]) i--;
  return i + clamp((t - starts[i]) / spans[i], 0, 1);
}

/** Film position x back to scroll progress, 0 → 1. */
function toProgress(x: number) {
  const i = clamp(Math.floor(x), 0, count - 1);
  return (starts[i] + (x - i) * spans[i]) / total;
}

type OpParts = {
  load: HTMLElement;
  dropShadow: HTMLElement;
  blank: HTMLElement;
  film: HTMLElement;
  membrane: HTMLElement;
  sealBase: HTMLElement;
  sealLid: HTMLElement;
  heat: HTMLElement;
  glow: HTMLElement;
  haze: HTMLElement;
  revealBase: HTMLElement;
  after: HTMLElement;
  revealLid: HTMLElement;
  riseShadow: HTMLElement;
  rise: HTMLElement;
  sheen: HTMLElement;
  items: HTMLElement[];
  bars: HTMLElement[];
  phase: number;
};

type Parts = {
  scene: HTMLElement;
  shot: HTMLElement | null;
  copy: HTMLElement | null;
  big: HTMLElement | null;
  box: HTMLElement | null;
  sheen: HTMLElement | null;
  sheet: HTMLElement | null;
  shadow: HTMLElement | null;
  op: OpParts | null;
  shown: boolean;
};

function findOperation(scene: HTMLElement): OpParts | null {
  const get = (name: string) => scene.querySelector<HTMLElement>(`[data-op="${name}"]`)!;
  if (!scene.querySelector('[data-op="load"]')) return null;
  return {
    load: get("load"),
    dropShadow: get("drop-shadow"),
    blank: get("blank"),
    film: get("film"),
    membrane: get("membrane"),
    sealBase: get("seal-base"),
    sealLid: get("seal-lid"),
    heat: get("heat"),
    glow: get("glow"),
    haze: get("haze"),
    revealBase: get("reveal-base"),
    after: get("after"),
    revealLid: get("reveal-lid"),
    riseShadow: get("rise-shadow"),
    rise: get("rise"),
    sheen: get("sheen"),
    items: Array.from(scene.querySelectorAll<HTMLElement>(".op-phases li")),
    bars: Array.from(scene.querySelectorAll<HTMLElement>(".op-phases li > i > i")),
    phase: -1,
  };
}

const easeOut = (t: number) => 1 - Math.pow(1 - clamp(t, 0, 1), 3);

/** A piece falls into the chamber in 3D: from above and toward the viewer, tilted, settling flat. */
function dropIn(el: HTMLElement, d: number, visible: number, from: number, flutter: number) {
  const e = easeOut(d);
  const a = 1 - e;
  el.style.opacity = (seg(d, 0, 0.15) * visible).toFixed(3);
  el.style.transform =
    `translate3d(0, ${(-from * a).toFixed(1)}%, ${(170 * a).toFixed(1)}px) ` +
    `rotateX(${(-32 * a + Math.sin(e * Math.PI) * 9 * flutter).toFixed(2)}deg) ` +
    `rotateY(${(24 * a * flutter).toFixed(2)}deg) rotateZ(${(-10 * a).toFixed(2)}deg)`;
}

/*
 * Step 5: the press at work, driven by u (0 → 1) while the step holds.
 *   Load    0.00–0.22  a blank case drops onto the mould, then the printed film settles over it.
 *   Seal    0.22–0.48  the membrane swings down from upright onto the tray, the photographed
 *                      membrane takes over, and the lid folds down toward the viewer.
 *   Heat    0.48–0.70  the closed press clamps down a touch and glows; haze rises off it.
 *   Reveal  0.70–1.00  the lid swings up, then the finished case rises out of the tray, stands
 *                      up and turns to the viewer, leaving the mould behind.
 * Each incoming photo fades in above the outgoing one, which stays solid until the end, so the
 * press never turns see-through mid-change.
 */
function paintOperation(o: OpParts, u: number, full: boolean) {
  let drop1 = seg(u, 0.03, 0.11);
  let drop2 = seg(u, 0.1, 0.19);
  let swing = smooth(seg(u, 0.22, 0.33));
  let toSeal = smooth(seg(u, 0.32, 0.36));
  let fold = smooth(seg(u, 0.38, 0.5));
  let closed = smooth(seg(u, 0.45, 0.51));
  let opened = smooth(seg(u, 0.7, 0.75));
  let lift = smooth(seg(u, 0.71, 0.84));
  let rise = seg(u, 0.84, 0.97);
  if (!full) {
    // Reduced motion: each phase shows its end state, with no travel between them.
    drop1 = drop2 = 1;
    swing = toSeal = u >= phaseStart[1] ? 1 : 0;
    fold = closed = u >= phaseStart[2] ? 1 : 0;
    opened = lift = rise = u >= phaseStart[3] ? 1 : 0;
  }
  const heat = full ? seg(u, 0.5, 0.56) * (1 - seg(u, 0.68, 0.73)) : closed * (1 - opened);
  // The drop-in pieces and the membrane hand over to the photographed membrane once it is in.
  const before = 1 - toSeal;

  o.load.style.opacity = (1 - seg(toSeal, 0.6, 1)).toFixed(3);
  dropIn(o.blank, drop1, before, 260, 0.35);
  dropIn(o.film, drop2, before, 190, 1);
  const landed = Math.max(easeOut(drop1), easeOut(drop2));
  o.dropShadow.style.opacity = (landed * 0.75 * before).toFixed(3);
  o.dropShadow.style.transform = `scale(${(0.55 + 0.45 * landed).toFixed(3)})`;

  o.membrane.style.opacity = (seg(swing, 0, 0.08) * before).toFixed(3);
  o.membrane.style.transform = `rotateX(${(115 * (1 - swing)).toFixed(2)}deg)`;

  o.sealBase.style.opacity = (toSeal * (1 - seg(closed, 0.6, 1))).toFixed(3);
  o.sealLid.style.opacity = (toSeal * (1 - seg(fold, 0.7, 1))).toFixed(3);
  o.sealLid.style.transform = `rotateX(${(-86 * fold).toFixed(2)}deg)`;

  o.heat.style.opacity = (closed * (1 - seg(opened, 0.6, 1))).toFixed(3);
  o.heat.style.transform = `scale(1, ${(1 - 0.014 * heat).toFixed(4)})`;
  o.glow.style.opacity = heat.toFixed(3);
  o.haze.style.opacity = (full ? heat : 0).toFixed(3);

  o.revealBase.style.opacity = opened.toFixed(3);
  o.after.style.opacity = smooth(seg(rise, 0, 0.3)).toFixed(3);
  o.revealLid.style.opacity = (opened * seg(lift, 0, 0.3)).toFixed(3);
  o.revealLid.style.transform = `rotateX(${(-86 * (1 - lift)).toFixed(2)}deg)`;

  // The finished case lifts off the mould, stands up and turns toward the viewer.
  const r = smooth(rise);
  const appear = seg(rise, 0, 0.12);
  const turn = full ? smooth(seg(u, 0.9, 1)) : 1;
  o.rise.style.opacity = appear.toFixed(3);
  o.rise.style.transform =
    `translate3d(0, ${(-102 * r).toFixed(1)}%, ${(150 * r).toFixed(1)}px) ` +
    `rotateY(${(-32 * r + 34 * turn).toFixed(2)}deg) rotateX(${(22 - 16 * r).toFixed(2)}deg) ` +
    `rotateZ(${(-90 + 82 * r).toFixed(2)}deg) scale(${(1 + 0.45 * r).toFixed(3)})`;
  o.riseShadow.style.opacity = (appear * (1 - r) * 0.8 + r * 0.25).toFixed(3);
  o.riseShadow.style.transform = `scale(${(1 - 0.35 * r).toFixed(3)})`;

  // The light sweep is masked to the fully open silhouette, so it shows only while the lid is all the way up.
  o.sheen.style.opacity = (full ? 1 - seg(fold, 0, 0.12) + seg(lift, 0.9, 1) : 0).toFixed(3);

  let phase = 0;
  while (phase < phases.length - 1 && u >= phaseStart[phase + 1]) phase++;
  o.bars.forEach((bar, k) => {
    bar.style.transform = `scaleX(${seg(u, phaseStart[k], phaseStart[k + 1]).toFixed(3)})`;
  });
  if (phase !== o.phase) {
    o.phase = phase;
    o.items.forEach((item, k) => {
      if (k === phase) item.setAttribute("data-on", "");
      else item.removeAttribute("data-on");
      if (k < phase) item.setAttribute("data-done", "");
      else item.removeAttribute("data-done");
    });
  }
}

/** The press photographs, the 3D pieces that move through it, the heat effects and the light sweep. */
function Operation({ alt }: { alt: string }) {
  const frame = { width: OP.w, height: OP.h, decoding: "async", fetchPriority: "low", draggable: false } as const;
  const piece = { decoding: "async", fetchPriority: "low", draggable: false, alt: "" } as const;
  const hinge = (h: number) => ({ "--hinge": h } as CSSProperties);
  return (
    <span className="j-fit">
      <span className="j-fitbox op-box" style={{ "--w": OP.w, "--h": OP.h } as CSSProperties}>
        <span className="j-contact" aria-hidden="true" />
        <img data-op="load" src={opSrc("load")} alt={alt} {...frame} />
        <span data-op="drop-shadow" className="op-drop-shadow" aria-hidden="true" />
        <img data-op="blank" className="op-piece op-blank" src="/assets/journey/drop-blank.webp" width={1082} height={486} {...piece} />
        <img data-op="film" className="op-piece op-film" src="/assets/journey/drop-film.webp" width={1280} height={904} {...piece} />
        <span data-op="membrane" className="op-membrane" aria-hidden="true"><i /></span>
        <img data-op="seal-base" className="op-base" src={opSrc("seal")} alt="" style={hinge(HINGE.seal)} {...frame} />
        <img data-op="seal-lid" className="op-lid" src={opSrc("seal")} alt="" style={hinge(HINGE.seal)} {...frame} />
        <img data-op="heat" src={opSrc("heat")} alt="" {...frame} />
        <span data-op="glow" className="op-glow" aria-hidden="true" style={{ "--mask": `url(${opSrc("heat")})` } as CSSProperties}><i /></span>
        <span data-op="haze" className="op-haze" aria-hidden="true"><i /><i /><i /><i /><i /></span>
        <img data-op="reveal-base" className="op-base" src={opSrc("reveal")} alt="" style={hinge(HINGE.reveal)} {...frame} />
        <img data-op="after" className="op-base" src={opSrc("load")} alt="" style={hinge(HINGE.reveal)} {...frame} />
        <img data-op="reveal-lid" className="op-lid" src={opSrc("reveal")} alt="" style={hinge(HINGE.reveal)} {...frame} />
        <span data-op="rise-shadow" className="op-rise-shadow" aria-hidden="true" />
        <img data-op="rise" className="op-piece op-rise" src="/assets/journey/8-final.webp" width={651} height={1280} {...piece} />
        <span data-op="sheen" className="j-sheen" aria-hidden="true" style={{ "--mask": `url(${opSrc("load")})` } as CSSProperties}><i /></span>
      </span>
    </span>
  );
}

/** Step 3: the white sheet from step 2 is placed into the open press. t runs 0 → 1 while the step holds. */
const SHEET_STEP = 2;
function placeSheet(sheet: HTMLElement, shadow: HTMLElement | null, t: number) {
  const e = t * t * (3 - 2 * t);
  // Offsets are in container-width units (cqw) of the press image, so they scale with it.
  const dx = (1 - e) * 30;
  const dy = (1 - e) * -64 + Math.sin(e * Math.PI) * -6;
  const rz = -8 + e * -82;
  const rx = e * 35;
  const scale = 1.3 - 0.3 * e;
  sheet.style.opacity = Math.min(1, t * 5).toFixed(3);
  sheet.style.transform =
    `translate(-50%, -50%) translate3d(${dx.toFixed(2)}cqw, ${dy.toFixed(2)}cqw, 0) ` +
    `rotateX(${rx.toFixed(1)}deg) rotateZ(${rz.toFixed(1)}deg) scale(${scale.toFixed(3)})`;
  if (shadow) {
    shadow.style.opacity = (e * 0.9).toFixed(3);
    shadow.style.transform = `translate(-50%, -50%) scale(${(0.5 + 0.5 * e).toFixed(3)})`;
  }
}

function Journey({
  lenis,
  onDesign,
  onActiveChange,
}: {
  lenis: RefObject<Lenis | null>;
  onDesign: () => void;
  onActiveChange?: (inView: boolean) => void;
}) {
  const section = useRef<HTMLElement>(null);
  const pin = useRef<HTMLDivElement>(null);
  const scenes = useRef<(HTMLElement | null)[]>([]);
  const rail = useRef<HTMLElement>(null);
  const progress = useRef({ value: 0 });
  const activeRef = useRef(0);
  const inView = useRef(false);
  const notify = useRef(onActiveChange);
  const [active, setActive] = useState(0);

  useEffect(() => {
    notify.current = onActiveChange;
  }, [onActiveChange]);

  // Decode every step image before the section arrives, so no step stalls on first paint.
  useEffect(() => {
    const node = section.current;
    if (!node) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) return;
      observer.disconnect();
      node.querySelectorAll<HTMLImageElement>(".j-shot img").forEach((img) => {
        img.decode?.().catch(() => {});
      });
    }, { rootMargin: "1600px 0px" });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const journey = section.current;
    const frame = pin.current;
    if (!journey || !frame) return;
    gsap.registerPlugin(ScrollTrigger);
    const media = gsap.matchMedia();

    // Look the moving parts up once, not on every frame.
    const parts: Parts[] = scenes.current.map((scene, i) => ({
      scene: scene!,
      shot: scene!.querySelector<HTMLElement>(".j-shot"),
      copy: scene!.querySelector<HTMLElement>(".j-copy"),
      big: scene!.querySelector<HTMLElement>(".j-big"),
      box: scene!.querySelector<HTMLElement>(".j-fitbox"),
      sheen: scene!.querySelector<HTMLElement>(".j-sheen > i"),
      sheet: scene!.querySelector<HTMLElement>(".j-sheet"),
      shadow: scene!.querySelector<HTMLElement>(".j-sheet-shadow"),
      op: findOperation(scene!),
      shown: i === 0,
    }));

    media.add({ full: "(prefers-reduced-motion: no-preference)", still: "(prefers-reduced-motion: reduce)" }, ({ conditions }) => {
      const full = !!conditions?.full;
      let lastX = -1;
      const paint = (value: number) => {
        const x = toX(value);
        if (Math.abs(x - lastX) < 0.0005) return;
        lastX = x;
        parts.forEach((p, i) => {
          let enter = playIn(x, i);
          let leave = playOut(x, i);
          if (!full) {
            enter = i === 0 || x >= i ? 1 : 0;
            leave = i < count - 1 && x >= i + 1 ? 1 : 0;
          }
          const shown = enter * (1 - leave);
          const visible = shown > 0.001;
          // Screens far from the scroll position are skipped once they are hidden.
          if (!visible && !p.shown) return;
          p.shown = visible;
          p.scene.style.opacity = shown.toFixed(3);
          p.scene.style.visibility = visible ? "visible" : "hidden";
          if (p.sheet) placeSheet(p.sheet, p.shadow, full ? clamp((x - i - 0.18) / 0.47, 0, 1) : 1);
          // The operation runs from just before the screen settles until just before it leaves.
          const u = clamp((x - i - 0.18) / 0.64, 0, 1);
          if (p.op) paintOperation(p.op, u, full);
          if (!full || !visible) return;
          const hold = clamp((x - i - 0.25) / 0.5, 0, 1);
          const away = 1 - enter + leave;
          // The press turns a little on its own axis as the step holds, like a product on a turntable.
          if (p.box) {
            const turn = p.op ? u : hold;
            p.box.style.transform = `rotateX(${(9 - 5 * turn).toFixed(2)}deg) rotateY(${(-13 + 24 * turn).toFixed(2)}deg)`;
          }
          // A band of studio light sweeps across the press with the scroll.
          if (p.sheen) p.sheen.style.transform = `translate3d(${(-130 + 260 * (p.op ? u : hold)).toFixed(1)}%, 0, 0) skewX(-18deg)`;
          if (p.shot) {
            p.shot.style.transform =
              `translate3d(${(1 - enter) * 48 - leave * 48}%, ${(1 - enter) * 5 - leave * 5}%, 0) ` +
              `rotateY(${(1 - enter) * -30 + leave * 30}deg) rotateZ(${(1 - enter) * 5 - leave * 5}deg) ` +
              `scale(${0.86 + 0.14 * (1 - away) + 0.035 * hold})`;
          }
          if (p.copy) p.copy.style.transform = `translate3d(0, ${(1 - enter) * 60 - leave * 60}px, 0)`;
          if (p.big) p.big.style.transform = `translate3d(${(1 - enter) * -26 + leave * 26 - hold * 4}%, 0, 0)`;
        });
        // Set on the fill itself: a custom property on the pin would restyle all eight screens.
        if (rail.current) rail.current.style.transform = `scaleX(${clamp((x - 0.5) / (count - 1), 0, 1).toFixed(4)})`;
        const next = clamp(Math.floor(x), 0, count - 1);
        if (next !== activeRef.current) {
          activeRef.current = next;
          setActive(next);
        }
      };
      paint(progress.current.value);
      const tween = gsap.to(progress.current, {
        value: 1,
        ease: "none",
        scrollTrigger: {
          trigger: journey,
          start: "top top",
          end: () => "+=" + (journey.offsetHeight - frame.offsetHeight),
          scrub: full ? 0.4 : true,
          invalidateOnRefresh: true,
          onToggle: (self) => {
            inView.current = self.isActive;
            notify.current?.(self.isActive);
          },
        },
        onUpdate: () => paint(progress.current.value),
      });
      return () => {
        tween.scrollTrigger?.kill();
        tween.kill();
      };
    });
    return () => media.revert();
  }, []);

  function goToStep(index: number) {
    const journey = section.current;
    const frame = pin.current;
    if (!journey || !frame) return;
    const top = journey.getBoundingClientRect().top + window.scrollY;
    const i = clamp(index, 0, count - 1);
    // Land mid-screen; on the press, land where its operation begins.
    const y = top + (journey.offsetHeight - frame.offsetHeight) * toProgress(i + (i === OP_STEP ? 0.26 : 0.5));
    if (lenis.current) lenis.current.scrollTo(y, { duration: 1.4 });
    else window.scrollTo({ top: y, behavior: "instant" });
  }

  function continueOn() {
    const next = document.getElementById("designs");
    if (!next) return;
    if (lenis.current) lenis.current.scrollTo(next, { duration: 1.2 });
    else next.scrollIntoView();
  }

  // Left and right arrow keys step through the film while it is on screen.
  const step = useRef({ goToStep, continueOn });
  useEffect(() => {
    step.current = { goToStep, continueOn };
  });
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (!inView.current || event.altKey || event.ctrlKey || event.metaKey) return;
      const target = event.target as HTMLElement | null;
      if (target?.closest("input, textarea, select, dialog[open]")) return;
      if (event.key === "ArrowRight") {
        event.preventDefault();
        if (activeRef.current < count - 1) step.current.goToStep(activeRef.current + 1);
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        if (activeRef.current > 0) step.current.goToStep(activeRef.current - 1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const last = active === count - 1;

  return (
    <section className="journey" id="process" ref={section} aria-labelledby="journey-title" style={{ "--j-len": total } as CSSProperties}>
      <div className="journey-pin" ref={pin} data-stage={active}>
        <header className="j-top">
          <div>
            <p className="eyebrow"><i /> How it&rsquo;s made</p>
            <h2 id="journey-title">Customize your exclusive phone case</h2>
          </div>
          <p className="j-count" aria-hidden="true">
            <span className="j-count-now" key={active}>{number(active)}</span>
            <span className="j-count-all">/ {number(count - 1)}</span>
          </p>
        </header>

        <div className="j-stage">
          {steps.map((s, i) => (
            <article
              key={s.title}
              className="j-scene"
              ref={(el) => { scenes.current[i] = el; }}
              aria-hidden={i !== active}
              data-on={i === active || undefined}
              style={{ opacity: i === 0 ? 1 : 0, visibility: i === 0 ? "visible" : "hidden" } as CSSProperties}
            >
              <span className="j-big" aria-hidden="true">{number(i)}</span>
              <div className="j-copy">
                <p className="j-chapter"><span>Step {number(i)}</span> {labels[i]}</p>
                <h3>{s.headline.replace("\n", " ")}</h3>
                <p className="j-desc">{s.description}</p>
                {i === OP_STEP && (
                  <ol className="op-phases" aria-label="How the press works">
                    {phases.map((ph) => (
                      <li key={ph.name}>
                        <b>{ph.name}</b>
                        <span>{ph.note}</span>
                        <i aria-hidden="true"><i /></i>
                      </li>
                    ))}
                  </ol>
                )}
                {i === count - 1 && (
                  <button className="btn btn-teal j-cta" onClick={onDesign} tabIndex={i === active ? 0 : -1}>
                    Design your case <ArrowUpRight size={16} />
                  </button>
                )}
              </div>
              <figure className="j-shot">
                <span className="j-halo" aria-hidden="true"><i className="j-shine" /></span>
                {i === OP_STEP ? (
                  <Operation alt={labels[i]} />
                ) : i === SHEET_STEP ? (
                  <span className="j-fit">
                    <span className="j-fitbox" style={{ "--w": images[i].w, "--h": images[i].h } as CSSProperties}>
                      <span className="j-contact" aria-hidden="true" />
                      <img src={images[i].src} width={images[i].w} height={images[i].h} alt={labels[i]} decoding="async" fetchPriority="low" draggable={false} />
                      <span className="j-sheen" aria-hidden="true" style={{ "--mask": `url(${images[i].src})` } as CSSProperties}><i /></span>
                      <span className="j-sheet-shadow" aria-hidden="true" />
                      <img className="j-sheet" src={images[1].src} width={images[1].w} height={images[1].h} alt="" decoding="async" draggable={false} />
                    </span>
                  </span>
                ) : (
                  <img
                    src={images[i].src}
                    width={images[i].w}
                    height={images[i].h}
                    alt={labels[i]}
                    decoding="async"
                    fetchPriority={i === 0 ? "high" : "low"}
                    draggable={false}
                  />
                )}
                <span className="j-floor" aria-hidden="true" />
              </figure>
            </article>
          ))}
          <p className="sr-only" aria-live="polite">Step {active + 1} of {count}: {labels[active]}</p>
        </div>

        <div className="j-track">
          <button className="round" aria-label="Previous step" disabled={active === 0} onClick={() => goToStep(active - 1)}><ArrowLeft size={17} /></button>
          <nav className="j-rail" aria-label="Manufacturing steps">
            <span className="j-rail-line" aria-hidden="true"><i ref={rail} /></span>
            {steps.map((s, i) => (
              <button
                key={s.title}
                className="j-node"
                data-state={i === active ? "active" : i < active ? "done" : "next"}
                aria-label={`Step ${i + 1}: ${labels[i]}`}
                aria-current={i === active ? "step" : undefined}
                onClick={() => goToStep(i)}
              >
                <b>{i + 1}</b>
                <small>{short[i]}</small>
              </button>
            ))}
          </nav>
          <button className="round" aria-label={last ? "Continue to the designs" : "Next step"} onClick={() => (last ? continueOn() : goToStep(active + 1))}>
            {last ? <ArrowDown size={17} /> : <ArrowRight size={17} />}
          </button>
        </div>
      </div>
    </section>
  );
}

/** Memoised: header and navigation state changes in the page must not re-render the film. */
export default memo(Journey);
