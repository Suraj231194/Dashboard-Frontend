# Parity gaps against the current application

Measured on 2026-09-28 by reading both code bases in full, domain by domain, and
checking the findings against the restored staging database.

**Read this before `CONVERSION-STATUS.md`.** That document says all 89 screens are
converted and that only printable documents and parts of Finance were left out.
At screen level that is true. At behaviour level it is not: whole actions are
missing, several flows are severed, and a few defects corrupt data. The claims
listed under "Corrections to the status document" below are wrong as written.

Severity:

- **HIGH** — an action or flow is missing, or a side effect is wrong. Includes
  everything that writes bad data.
- **MEDIUM** — a field, validation, message, predicate or edge case differs.
- **LOW** — cosmetic or minor.

---

## Corrections to the status document

| Claim | Reality |
|---|---|
| "Every list export works in all three formats" | Six lists have no export at all: transfer tickets, material requests, customer management, meeting requests, quiz activity feed, quotation requests. |
| "The Sync Website / Import buttons now work" | None of the four website-sync screens has a Sync Website button or an export. |
| "Printable documents were deliberately left out" | The structured batch-record and certificate renderers are already ported to HTML and work. Only the sampling advice and the raw/packing certificate are placeholders; several other buttons fetch data and show a success message without producing anything. |
| "No code references a dropped column" | `unit_factor` is still read from the stock balance in four places, and every material-request issuance and BOM stock check fails on it. |
| `role-has-permissions` and `settings` converted | Each is only partly converted; see the relevant sections. |
| Automatic sync retries with backoff | Nothing runs retries. Only a delay helper exists. |
| Advance-salary status fix rationale | The stated reason is wrong: the column already defaults to 1. The explicit write is harmless. |

## Fixed in this pass

| Gap | What was wrong | Change |
|---|---|---|
| Reservations never reached the balance | The balance rebuild tested for `reserved_quantity`, dropped by `2026_09_23_003`, so it returned early every time and `reserved_qty` was never written. Reservation rows also left `quantity` at zero, and the rebuild sums that column. Measured: 3,181 balances, **none** with a reserved quantity, against an open reservation. Committed stock therefore stayed inside the generated `unreserved_qty` and could be issued or sold again. | `reserveStock`, `releaseReserved` and `syncReservedFromReservations` added to the inventory ledger, ported from the current helpers. The order flow now reconciles `reserved_qty` from open reservations and writes both quantity columns. Verified against staging inside a rolled-back transaction: reserving removes stock from the free balance and releasing returns it. |
| Releasing wrote an unknown status | `status = 3`, which nothing else recognises, so a released reservation was neither open nor accounted for. | `status = 0` with `closed_reason = 'released'`, as the current helper writes. |
| Brand scale was an invalid cycle | Each `--color-primary-N` in `@theme` referenced its own name, which CSS treats as a cycle. Inside the shell the saved appearance masked it; on the sign-in page, which has no such override, the brand colour resolved to nothing. 800 also duplicated 700. | Plain values, matching the current Tailwind theme, plus 950. The appearance style still overrides them at runtime. Verified in the built stylesheet. |
| Sign-in button hard-coded the brand hex | Did not follow the accent. | Uses the scale token. |
| Material issuance and the bill-of-materials stock check could not run | Three queries summed `unit_factor` on the stock balance, dropped by `2026_09_23_003`, so each threw "Unknown column". One of them would also have scaled the issued quantity by a factor the balance no longer carries. | All three read `unreserved_qty` from the single balance row, one for one, as the current handlers do. Allocation now also selects only rows with something free, so a shortage is reported rather than failing part-way through the ledger. |
| Every product save reset that product's free stock to zero | The service derived the balance from the pack rows, which the dialog always posts as zero, and the editor never loaded the real figure, so opening a product and pressing Save wiped its stock. | The balance comes from the stock field, as the current handlers read it, with the "Unreserved Stock cannot be negative." check restored. The editor prefills from the live balance. |
| Product delete had no guards | A product with stock committed to an order could be deleted, orphaning the reservation, and deleting twice silently succeeded. The balance row was left behind. | Reserved stock blocks the delete, the update is restricted to a live row, and the balance is soft-deleted in the same transaction, with the current messages. |
| A new bill of materials could never be approved | It is written as a draft so its author cannot approve their own work, but nothing moved it on: the queue offered only `PENDING_APPROVAL`, the submit endpoint was gated on a permission slug that does not exist, and its SQL named two columns that do not exist. Nothing could then use the bill in planning, requisitions or issuance. | The separation of duties is kept. The submit endpoint uses the real slug and drops the two phantom columns; the reviewer's queue and its count include drafts, through one shared predicate. |
| New manual orders disappeared | They were inserted as Pending Review and set back to it after routing, and the list excludes that status. | Inserted as Pending, which is what the current handler writes, and the post-routing overwrite is gone so the status the stock position implies survives. |
| The wrong controlled document could be snapshotted | The request screen pre-selected the best name-token match from every active template, so submitting the default took a snapshot of a template the product is not mapped to and recorded it as a manual override. | The product's mapped templates are returned with the options, and only a mapped template is pre-selected. Where there is no mapping, nothing is pre-selected and the operator chooses. Name matches are still offered, never chosen. |
| Two copies of the auto-queued transfer ticket | The packaging-completion copy omitted the ticket number, certificate number, code, date, product description and product code, and took the batch and plan from the request rather than the certificate, so blank ticket numbers flowed downstream. | The faithful version is exported and reused; the divergent copy is gone. |
| **The production cycle was severed at Step 11** | Nothing confirmed a transfer ticket and nothing ever wrote a `goods_received_from_production` row, so a batch that had passed every quality gate could not be transferred and the store could never receive it. | Ported the incoming queue and the confirmation with its origin split: a live-inventory batch is credited straight to stock, marked received and its plan completed; an order batch opens the balance without crediting it, stages a pending store receipt and is marked transferred. The full release gate (`loadReleaseSource`) is ported alongside, so approval of the request, both certificates, every batch record, the sampling advice and the batch identity are all re-checked. Re-confirming with the same values succeeds; changing a confirmed ticket is refused. Verified against staging in a rolled-back transaction: the queue offers the batch, every gate resolves, the origin is detected and the receipt is staged. |

### Third pass — parallel workstreams

All verified with a clean type check, lint and build.

| Area | What landed |
|---|---|
| HR, attendance, payroll | The attendance engine queried two columns that do not exist, so every recalculation threw *after* its writes had committed. The biometric endpoint wrote five non-existent columns and swallowed the error while answering success, so nothing was ever stored; it now writes correctly, keeps its batch bookkeeping, and recalculates attendance after ingest. Manual payroll was rebuilt on the current formula and checked against real employees. Reimbursement payment writes its history row and notifies. Plus the pinned-revision and ledger-hash guards, legacy holidays scoring as holidays, the work email on onboarding, the roster tenant check, two offboarding scope defects, and the leave balance check moved inside its transaction. |
| Exports | The six missing list exports and the two per-order downloads, columns taken verbatim. The current application's meeting export reads a table that exists in no migration and silently returns an empty file; that bug is deliberately not reproduced. |
| Finance | The bank account selects that were silently storing nothing on every payment and classification; the vendor bill review rebuilt with its credit-term calculation and conditional payment block; payment reversal; bank accounts; product commercials; the document detail's vendor-bill banner, files list and payment history; and the three real decision history events with the dispatch refresh that precedes them. |
| Notifications | The bell did not exist, so the calendar, finance and tender reminders it generates were never created at all. Bell, actions and the three generators are ported, exposed both on the bell's own poll and behind a secret-guarded scheduled route. Three account-menu entries restored. |
| Website sync | Sync and Import buttons on the four sync screens, force sync, the bio queue table with retry, and the legacy catalog tools. Correctness: the stale-version guard so older website data cannot overwrite newer records, acknowledgement validation, the order push version, retry gating and the per-module permission. A retry worker behind a secret. |
| Printable documents | Sampling advice (three copies), the raw/packing certificate (ten rows a page, section rows excluded from the count), the transfer ticket (four copies) and the material requisition (two copies, paged at 22). All rendered as HTML from the real data, matching the existing batch-record and certificate renderers. Two dead routes that read columns which do not exist were deleted. |
| Production cycle | The confirmation screen for step 11: the queue of released batches and the confirm dialog, wired to the endpoint. With the two Produce entry points and the transfer confirmation, a batch can now travel the whole cycle in the interface. |
| Orders | External order approval, which did not exist. Two guards added so an unapproved external order cannot be routed or dispatched even if the screen is bypassed. |

### Still open

- The finance invoice and delivery-challan editor, with its numbering, tax calculation and document generation. The largest single remaining piece.
- A scheduler must call the retry route with `SYNC_CRON_SECRET` set. Order status pushes now queue rather than sending inline, matching the current application, so without one they will sit pending.
- `migrations/003_sync_production_hardening.sql` is ported but **not applied**. Until it is, three sync pulls run without stale-version protection and order pushes send version 1. The code detects the missing columns and degrades rather than failing.
- Roughly eighty smaller mismatches remain in labels, placeholders, default selections and sort orders, listed per screen in the working notes.
- A branch with no offboarding settings row now shows empty settings rather than inheriting the company-wide ones. The current application auto-creates a row on first view, which is a write, so it was left alone — confirm which behaviour you want.

### Second pass

| Gap | What was wrong | Change |
|---|---|---|
| Changing a user's password never worked | The dialog posted `password` / `confirmPassword`; the endpoint reads `userNewPassword`, so the password arrived empty and every attempt failed with "Password is required." | The current field names, plus the confirm-match check the current dialog performs before posting. |
| Saving custom user permissions never worked | The control was named `perm_<id>` and no role was posted; the endpoint reads `permission[<id>]` and `role_id`, so every save was rejected as "Invalid user or role". It also defaulted each row to the role's grant, which would have written an explicit override for every permission. | Allow/Deny radio pairs named as the endpoint expects, nothing preselected, a hidden role, and the "Role" chip. An untouched permission now writes nothing and the role keeps deciding. |
| Order row actions ignored status | Edit, Hold/Cancel and Delete showed on every row, so a dispatched or completed order could be held or deleted, and "Confirm order" — the only way into reviewing an order that arrived from outside — was unreachable. | Status gates restored: hold and cancel hidden on the five locked statuses, delete limited to Pending and Pending Review, and Edit becomes Confirm order while the order awaits review. |
| Creating a user had no Confirm Password | A mistyped password was accepted, leaving an account nobody could sign in to. Company and Branch were also optional where the current form requires them. | The field, the match check, and the two required flags. |
| A typed product code was discarded | The form offered an editable CAT No and the service always generated one, so the field did nothing. There was also no duplicate or length check. | A typed code is kept and checked for duplicates and length; one is generated only when the field is blank, as the current handler does. |
| **"Produce" was missing from both stock screens** | The production cycle had only one entry point — an order. A product that had simply run out could be purchased but never made, which is also why no batch ever reached the live-inventory branch of the Transfer Ticket. | Both entry points ported (`modules/inventory/produce-requests.ts`): quantities are recalculated on the server, a product with an open request is skipped rather than duplicated, and each plan is raised with no order so it is recognised downstream as a live-inventory batch. |
| Assigning permissions to a role was missing | Only the edit dialog existed, which replaces a role's whole set. There was no way to grant a permission without disturbing what the role already held. | The additive assign flow: service, endpoint and dialog. |
| The legacy holiday list was editable | Annual Calendar is the master source after cutover and the current application answers every write with 409. A holiday edited here would have been silently superseded. | Reads gated on the calendar permission; create, update and delete answer 409 with the current message; the screen shows the superseded banner and a link instead of add and row actions. |
| Acknowledging a receipt buried the queue | The banner filtered the main list, mixing what is awaiting acknowledgement among records already received. | The dedicated paged Incoming Transfer Tickets dialog, each row handing straight to the acknowledge dialog. |

New modules: `modules/production/release-source.ts` (the shared release gate),
`modules/production/transfer-workflow.ts` (queue and confirmation),
`modules/production/notifications.ts` (the notification helper and page-to-roles lookup),
`app/api/production/transfer-queue/route.ts`.

Build, type check and lint were clean before and after every change.

**Still to do on this flow:** the confirmation has no screen yet — the endpoint exists and is
tested, but the Transfer Ticket screen needs the incoming widget and confirm dialog wired to it.
Step 12 acknowledgement still does not recalculate the linked order, and Step 13 dispatch still
consumes stock where the current action only marks the order ready.

---

## Fixed in the final pass (2026-09-28)

Five workstreams ran in parallel, each locked to a disjoint set of files. What follows
is what closed, and — more usefully — what deliberately did **not** close and why.

### Order intake

All three inbound channels are now real. Previously an order could only be typed in
by hand: the website interface did not exist, and the messaging and email pipelines
were sixty-line stubs.

| Was | Now |
|---|---|
| No token-protected interface at all. | Seven endpoints behind a bearer token compared in constant time. It refuses when the token is unset **or** still one of the three placeholder values the source ships, so it can never run open. |
| Messaging webhook did not verify signatures, hardcoded a fallback verify token, handled only the first message in a payload, and never deduplicated. | HMAC over the raw body, no fallback token, every message walked with its own error boundary, deduplication on the provider's message id. |
| Both stubs logged to tables that **do not exist in the database** (`whatsapp_messages_log`, `email_order_logs`). Confirmed absent on staging. | The real tables (`whatsapp_order_log`, `email_order_log`). This is why lead intake had never seen a single inbound message — it anti-joins the table the stub was not writing to. |
| No parser, order creation, interactive flow or replies. | All ported, wording verbatim. External orders land at status 12 with their source type, and are held for review before stock is committed. |

**Not closed — needs a decision.** Nothing in this project's dependencies can open a
mailbox or hand a message to a mail server. The email pipeline is complete up to a
single marked injection point (`src/modules/intake/email/transport.ts`); until a
transport is registered the route reports itself unconfigured rather than pretending
to poll, and an unsendable reply is recorded rather than silently dropped. Adding one
means installing a package — a call for the repository's owner, not for this pass.

**A correction to this register's own brief.** The work was specified as "customer
match or creation" from inbound email. The source only ever *matches* an existing
customer and leaves the link empty when it finds none; it never inserts one. The
matching was ported and no creation path was invented.

**Two source defects preserved on purpose, both commented in place:** the product
catalogue attachment joins on a column `products` does not have, so it always sends
headings and zero rows; and the draft email has its two dispatch labels swapped and
quotes a deadline that contradicts its own expiry. Faithful beats quietly divergent —
but both are one-line fixes whenever someone decides the port should lead here.

### Finance — the draft-to-generated link

The register could produce a DRAFT and never move it on, because no editor and no
`generate_document` existed. Both now do, along with an HTML preview reachable from
the register, the detail dialog and the editor footer.

The tax arithmetic was verified differentially against the source PHP rather than by
inspection: 400 randomised cases plus 6 hand-picked rounding boundaries, compared per
line and per document — **17,028 comparisons, zero mismatches**. This is money, so
nothing here rests on reading the code and agreeing with it.

**One source bug corrected, not reproduced.** `preview_document_html` reads the totals
from the wrong level of the calculator's result, so previewing unsaved editor lines
prints every total as `0.00` while the lines themselves are right. The port reads the
correct level. The stored-document path is identical either way.

**Not reproduced, deliberately:** the source stamps a generated invoice onto two
SHA-pinned PDF files. Consequence to be aware of — the register's existing "Open PDF"
link will not appear for documents generated through the port; the preview and the
document route are the print path instead. Logo, digital signature and payment QR are
likewise omitted, which is the branch the source itself takes when its image library
is unavailable.

### Batch records and certificates

The renderers were already faithful; these were fidelity defects that changed what
prints on a controlled document.

- The QA in-charge cell rendered one combined field where the source renders a
  Signature and a Date as a pair, with a fallback to the legacy combined key.
- Date fields printed their stored `Y-m-d` value instead of `d/m/Y`.
- Signature-key detection was missing the source's role-suffix pattern, so a dozen
  named roles rendered as plain text boxes rather than signature widgets.
- Certificates never printed the signer's **name** under the signature, and the two
  `_name` keys were dropped by the payload sanitiser. `tested_by` consequently stayed
  blank, and a downstream auto-queued transfer ticket recorded the sampler as the
  literal string "QC Analyst".
- The controlled-form loader lacked the source's snapshot, profile and legacy-layout
  fallbacks, so it could show a compatibility form where the source renders correctly.

**A correction to this register's own brief.** The work was specified as "the source
joins templates on `status = 1`". It does not — that condition sits on the *mapping*
queries and never on the loader. Adding it would have been worse than the divergence
it was meant to fix: a retired template would stop printing its own header on an
already-issued record. The real divergence was a `deleted_at` filter the port had
added, and that is what was removed.

**The shared signature widget was wired to only one of the two families.** The source
scripts are not copies of each other: a batch record treats the typed name and the
uploaded image as alternatives and wipes the name on upload, whereas a certificate
prints the name *underneath* the signature and keeps both. The shared module
implemented the batch-record behaviour for both, so uploading a signature on a
certificate silently discarded the signer's name. Now split by family, with the typed
name mirroring back to the workspace box as the source does.

**The parity claim in the renderer's own header comment was false.** It asserted a
check that "proves template by template" and no such check existed anywhere in the
repository. One now does: `tests/compare-document-render.mjs` renders every real
template in staging through both the ported renderer and the source PHP renderer and
diffs the output — **756 of 756 documents identical**, editable and printed, blank and
filled. What it does not cover is stated in its own header: editor behaviour, PDF
layout, persistence, and the derived columns above.

### Printable documents

All eight remaining documents now render as real HTML through `documentPage()`,
following the renderer pattern already in the repository. None is an image or a
screenshot. Proforma invoice, purchase order and its raw variant, daily production
report (single and bulk), quotation snapshot, payroll sheet and bank disbursement,
offboarding letters, annual calendar report, stock report.

Two shared pieces were extracted: the number-to-words converter (ported digit for
digit, including its quirks) and the company branding/artwork resolver.

**A money bug in the source was fixed, not copied.** The proforma template adds
freight to the running total *inside* the per-page loop, so a multi-page invoice
over-counts it once per page. The port adds it once, with a comment saying why the
divergence is deliberate.

**Two orphans in the source, both now reachable and gated.** The proforma template
has no permission check at all — anyone holding an id could read customer prices;
it is now behind the screen's own view permission. The stock report has no session,
no permission check and no caller anywhere in the source — it has never been
reachable from a screen. It is now behind the stocks page access and linked from the
inventory toolbar. Its page-break rule was also un-inverted; the source has it
backwards.

**Known limitation:** the annual calendar's page-number footer uses a PDF-engine
feature with no HTML equivalent. The port emits the standard CSS page-counter rule
plus a static end-of-document line; Chrome ignores the former, so in a Chrome print
only the static line appears.

**Left alone deliberately:** the payroll archive written at generation time still
uses the old plain-text writer, because changing it would change what is written to
disk and to the database. The new renderer serves preview and download.

### Field-level parity

Roughly eighty differences in labels, placeholders, defaults, preselection, input
types and default sort order, across settings, suppliers, labels, store/BOM, users,
menus, roles, permissions, products, stocks, low stocks, employee master, employees,
attendance, shifts, annual calendar, leave, payroll, tenders, salesperson master and
customer management. A shared `recentFirstOrder()` helper was ported so lists default
to most-recently-touched first, as the source does.

**Eight categories of change alter what gets SAVED.** These are the port becoming
faithful, not the port breaking, but they will be noticed in daily use:

1. Status / Is Approved / BOM type / Show Menu radios no longer arrive pre-selected.
   An operator who never touched the control used to save Active / Yes / BOM type 4
   silently; now the field is required and they must choose.
2. An unselected parent menu stores `0`, not `NULL`.
3. An empty product-category name is refused; it used to create a nameless row.
4. An unrecognised salesperson territory type is dropped rather than filed as City.
5. Untouched shift numeric fields submit empty rather than `0`.
6. The shift attendance policy submits what the operator types rather than defaulting
   to 240 / 480 / today.
7. Leave `adjustment_days` is always written as 0, as the source writes it, rather
   than from an operator-editable field.
8. Attendance `ingest_enabled` follows the selected device, so saving without changing
   anything no longer force-enables ingestion.
9. Customer state / province is constrained to the 36-item list (a value the row
   already held still round-trips), country code to the five offered, and a valid
   GSTIN now auto-fills PAN.

**Two deliberate deviations, kept on purpose.** The source answers an empty role name
with a bare `'error'` and an empty permission with a generic "Missing or invalid
input.". The port says what is actually wrong. Nothing branches on either string, so
fidelity buys nothing and costs the operator a usable message.

---

## Verification of this pass

`npx tsc --noEmit`, `npx eslint .` and `npx next build` are all clean.

A read-only browser crawl of the built application covered **all 92 routes: every one
returned 200, with no page errors and no failing API calls**, opening **545 dialogs**
and exercising 114 row actions. Nothing was submitted and no delete was confirmed.

The 24 controls that opened no dialog were each checked and are all legitimate:
password visibility toggles, filter tiles, a banner dismiss, a chat reset, and the
full-page editors (products, batch-record requests, quote and proforma creation)
which render a panel rather than a dialog. Diffed against the previous crawl, the
only difference is which product rows land on the first page now that lists default
to most-recently-touched first — the same control, the same behaviour, no regression.

**Note on how this was measured.** The first two crawl attempts reported almost
everything empty. That was not the code: building the application replaced the chunks
the already-running development server had handed to the browser, so pages loaded and
then failed to hydrate. The figures above come from crawling a freshly built server
on a separate port. If a crawl here ever comes back uniformly empty, restart the
development server before believing it.

---

## A. Production batch records (steps 2 to 9)

HIGH

- Completing a plan checks only that a finished-goods certificate row exists. The
  current code re-validates the whole release: request approved, finished-goods and
  in-process certificates approved, every batch record complete with matching
  counts, sampling advice approved, and the requisition, plan and batch identities
  matching.
- Material requisition creation is switched back on. The current application
  returns 409 and allows requisitions only through the plan hand-off. The port has
  no acceptance gate, no duplicate check, and forces the plan's status.
- The form-request screen pre-selects a template by matching name tokens instead of
  the exact pack-size-aware product mapping, then snapshots it as a manual
  override. By default this takes a **snapshot of the wrong controlled document**.
- Completing the last packaging record queues a transfer ticket with no ticket
  number, certificate number, code, date, product description or product code, and
  takes the batch and plan from the request rather than the certificate. A faithful
  version of this helper already exists elsewhere in the codebase and should be
  reused.

MEDIUM — order recalculation moved outside the completion transaction and its
errors are swallowed; the plan queue and the requisition queue both drop
live-inventory and low-stock origins, so those plans skip acceptance; accepting a
plan rejects those origins outright; the list visibility filter shows unaccepted
queue plans with edit and delete; approval creates no work items for requests that
predate the documents table; the form payload limit is 1 MB against 5 MB, so
signature images fail; the goods-issuance permission slug differs; a new unit-factor
check can block an issuance the current code completes; the production list sorts by
serial rather than recent activity; the form-request export is missing; the rapid
"generate PDF" returns a column table rather than the report document.

LOW — controlled-form loading skips the snapshot profile fallback, the legacy layout
normalisation and the structured-snapshot condition; sorts, unit labels, a search
pre-fill, row-click view, BOM check breadth, an integer truncation quirk, and a
named lock for certificate numbering.

No endpoint: create production plans from live inventory; create them from low
stock; the daily production report documents, single and bulk.

The status document in the current application is itself stale on two points: the
"Produce" button does now exist on both stock screens, and work items are created
queued rather than as drafts.

## B. Certificates and the transfer tail (steps 8, 10 to 13)

HIGH

- The incoming transfer-ticket queue does not exist.
- Confirming a transfer ticket does not exist, and with it the entire origin split:
  a live-inventory batch should credit stock directly and close, while an order
  batch should stage a pending receipt for the store. **Nothing in the port ever
  creates a step-12 receipt**, so the production cycle is severed.
- Acknowledging a receipt never recalculates the linked order.
- "Send to dispatch" dispatches immediately, consuming stock and closing
  reservations. The current action only moves the order to ready-for-dispatch and
  explicitly does not create an outward or consume stock.
- Observation rows that carry a section heading lose their parameter row entirely,
  so that parameter is never saved.
- Orders are not auto-routed after quality release.
- The transfer ticket, raw/packing certificate and sampling advice documents are
  missing; one dead route reads columns that do not exist.

MEDIUM — release-source checks are much weaker on receipt; audit trail and
notifications missing; cancel zeroes only one of two columns and sets no close
reason; no confirmation before dispatch or cancel; department not auto-selected or
required on the in-process certificate; the manual template switch is missing and
mapping takes precedence the wrong way round; signer names are dropped from payload,
renderer and derived fields; manufacturing and expiry dates are not carried from the
in-process certificate; several create and update validations are stricter than the
current ones; finance sync missing after certificate and sampling-advice approval;
the template recommendation predicate is simpler and can pre-select a different
template.

## C. Sales, orders, CRM, tenders, sync, integrations

HIGH

- Manual orders are inserted as pending review and set back to it after routing,
  and the list filters that status out, so **a new manual order disappears**.
- External-order approval is missing entirely, as are the guards that stop an
  unapproved external order being edited or dispatched.
- The stock analysis formula was rewritten to use base columns, unit factors and a
  reorder holdback. This changes the sufficiency verdict, dispatchability and
  production batch sizes.
- Website status push happens only after goods dispatch, not at the six other
  points the current code pushes from.
- Row actions ignore status, so terminal orders still offer hold, cancel and
  delete, and "confirm order" can never be reached.
- The notification bell does not exist, and with it the calendar, finance and
  tender reminders generated while polling.
- The token-protected intake interface is missing; the messaging webhook and the
  email-to-order pipeline are stubs, one querying a table that does not exist and
  neither authenticated.
- No sync button and no export on any of the four website-sync screens; the bio
  queue and retry are missing; the legacy category sync is missing.
- Per-order document downloads are missing.

MEDIUM — three terminal statuses release reservations instead of being left alone;
the dispatch hand-off lacks its lock, terminal re-check, item filter and specific
error; export scope differs; changing the customer in the edit dialog leaves stale
related records so saving fails; force sync missing; three pull types skip the
stale-version guard, so older website data can overwrite newer records;
acknowledgement is not validated; the order push omits its version and is sent
inline rather than queued; nothing runs retries; order detail lacks terminal and
per-line state; a proforma can link an arbitrary blank-named customer; a pull
requires too broad a permission; delete has no confirmation; a deep link and its
target are both missing; default sorts differ.

## D. Inventory, store, BOM, procurement, purchasing, warehouse

HIGH

- **Every product save resets free stock to zero.** The form always posts zero, the
  service ignores the real field, and the edit dialog never loads the current
  figures.
- Product delete drops both guards and the balance soft-delete.
- Both material-request issuance paths and the BOM stock check query the dropped
  `unit_factor` column, so **every issue fails**.
- New BOMs are inserted as drafts, nothing submits them, and the approval screen
  only accepts pending ones, so **a new BOM can never be approved or used**. The
  submit endpoint is gated on a slug that does not exist and writes two columns that
  do not exist.
- The stock editor and its delete bypass the ledger and its guards, so reserved
  stock can be edited away or deleted.
- Adding stock and importing stock do not re-route waiting orders.
- Both "send to production" entry points are missing, as is the create/clone BOM
  dialog and the material-request export.

MEDIUM — reference BOMs work differently; the ledger's absolute-set writes a
different movement row and revives soft-deleted balances; several validation
messages are missing or weaker; the vendor on a purchase request is stored as an
identifier but displayed and searched as a name; the stock list omits the reserved
and unreserved columns; a manual outward pre-check misapplies the unit factor;
category push to the website is missing.

LOW — ledger source labels, default list ordering across six lists.

## E. HR, attendance, payroll

HIGH

- The attendance recalculation engine queries two columns that do not exist on the
  calendar table, so **every recalculation throws** once those tables are present,
  after its writes have already committed. It would also read draft revisions
  rather than the finalised one.
- The biometric endpoint writes five columns that do not exist and swallows the
  error, so **nothing is stored** while it still answers success. It also never
  recalculates attendance afterwards.
- Manual payroll was rebuilt on the pay-run engine, so its rows and every amount
  differ from the current formula.
- Marking a reimbursement paid writes no history row and sends no notification.

MEDIUM — the batch lifecycle around biometric ingest is absent; employee matching
ignores the device's company and branch; bulk attendance allows one date per row
instead of several; two pickers are tenant-scoped where the current ones are not;
the leave team email is never sent; the leave balance check can race; the finalised
day reader drops the pinned-revision and ledger-hash rules while claiming to keep
them; calendar exports lose their metadata block, monthly summary and formula
escaping; legacy holidays are not scored as holidays; a scoped user can see all
companies when their own is deactivated; roster delete skips the tenant check; the
offboarding manager panel loads and edits the wrong settings row for a branch, and a
branch-scoped user can save company-wide settings; onboarding does not store the work
email for non-portal employees; imports accept only one spreadsheet format.

LOW — several messages, orderings, date handling and a fabricated payslip route that
reads tables which do not exist.

## F. Core administration and shell

HIGH

- Deleting a role from the users screen skips every safety check.
- Editing a role never unassigns the users removed from it.
- The assign-permission flow is missing.
- The legacy holiday list is editable, where the current application returns 409
  and marks it read-only and superseded.
- Six list exports and the per-order downloads are missing.
- The notification bell and the three reminder generators are missing.

MEDIUM — login collapses three distinct messages into one; session lifetime differs
in kind; the appearance page has no access check; the role wizard's edit rules,
permission checks and overview flags all differ; account-menu entries are missing;
two extra sidebar fallback entries appear without permission slugs; deep links are
ignored; the dashboard shows different content from the current one; imports accept
only one format.

LOW — 403 status and wording, no in-shell 404, a missing route alias, page titles,
avatar photo, voice input.

## G. Printable documents

Already ported and working: the structured batch record and the in-process and
finished-goods certificates, served through the shared document page.

**All 21 batch-record templates and all 10 certificate templates in the database
declare a structured HTML renderer, and not one has a page image or source PDF.**
The image-based path is for a legacy schema the current application has retired,
and no live template uses it. It is dead code here, not the active path.

P0 — bring the two ported renderers back into line: the signature-and-date pair and
its styles, day/month/year printing for date fields, the role-suffix signature
regex, and print styles; print the signer name under certificate signatures and
accept the name fields through the payload; correct the controlled-form loader; add
a real parity test that renders both implementations from the same fixtures.

P1 — replace the two placeholders and the three buttons that show a success message
without producing a document; add the proforma, purchase-order and daily-report
letterheads.

P2 — finance documents, quotation snapshot, payroll sheets, offboarding letters,
calendar report.

P3 — decide whether "download" must produce a file. The current application streams
a PDF; the port opens the browser print dialog.

## H. Theme and colour

- The brand scale cycle and the sign-in button are fixed above.
- Theme mode is saved but never applied: no theme attribute is rendered on the
  server and no dark tokens exist.
- Changing the font does not update body text until a full reload.
- One appearance rule is dead because of an unescaped selector.
- The sidebar background variable is set but never used; the sidebar is white,
  where the current one is themed, and its inactive icons use an accent mix.
- 132 occurrences across 54 files hard-code the brand green where the current
  screens follow the accent; 49 arbitrary hex classes and around 130 raw hex
  literals remain. Documents should keep their fixed colours.
- Four separate badge-tone maps disagree with each other.
- The shared page header, input, button and modal styles differ from the current
  ones in specific, listed ways.
- The chart palette is new work, not a port, and is not accent-aware.
- The accessible contrast of one preset accent against white text is about 2.5:1.

## I. Finance

Not audited in this pass. The status document already admits document generation,
source sync, payment reversal, the two editor dialogs and the template preview are
missing. Treat that list as a starting point, not a complete one, given how the
other domains compared.

---

## Where the source copy is incomplete

The built asset directory is absent, so the compiled theme, the template styles,
several scripts and the legacy batch-record page images could not be read. Findings
that depend on them are marked unverifiable in the working notes.

## Security, outside parity

Plain-text credentials are committed in the current application: a notes file with
live database and code-repository credentials, an API key in one script, and remote
database credentials in another. All should be rotated and removed from the tree.
