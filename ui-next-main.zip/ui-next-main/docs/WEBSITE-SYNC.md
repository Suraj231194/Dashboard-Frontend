# The website sync

The ERP and the public website exchange records over HTTP. This records how
the ported subsystem is shaped and the decisions worth knowing before changing
it. The reference is `admin/sync/` in the current application.

## The pieces

| File | What it is |
|---|---|
| `lib/sync/sync-manager.ts` | the HTTP client, the configuration read and the retry schedule |
| `lib/sync/cron-secret.ts` | the shared secret the scheduled route is guarded with |
| `lib/sync/website-db.ts` | a direct connection to the website's database, for the catalog tools only |
| `modules/sync/sync-settings.ts` | the module switches and the `sync_logs` ledger |
| `modules/sync/sync-retry-worker.ts` | the retry cycle behind `POST /api/cron/sync-retry` |
| `modules/sync/force-sync.ts` | "run every enabled pull, then the pending inventory job" |
| `modules/sync/catalog-sync.ts` | the legacy category and sub-category tools |
| `modules/sync/website-push.ts` | ERP to website: order status and product stock |
| `modules/sync/website-pull.ts` | website to ERP: customers, meetings, quiz leads, proformas and quotations |
| `modules/sync/sync-dashboard.ts` | what the screen reads, including the website's own queue |
| `modules/sync/SyncDashboardScreen.tsx` | the screen |

## It fails closed

A module with no `sync_settings` row reads as **disabled**. A half-applied
migration therefore exchanges nothing rather than pushing data at an endpoint
that may not be ready.

A module cannot be enabled at all until `WEBSITE_SYNC_BASE_URL` and
`WEBSITE_SYNC_TOKEN` are set. Both are read from the server environment and
must never be `NEXT_PUBLIC_`. The example placeholders that ship in the
environment file are treated as absent, so a module cannot be switched on
against a token that was never replaced.

## Every exchange is logged before it is made

A push writes its `sync_logs` row first and marks it afterwards. A failure is
therefore a queued retry rather than a lost message, and the dashboard can
offer it back to a person.

An **order** push goes further and does not call the website at all: it writes
the row and returns. An ERP action must never wait on, or fail because of, the
website, so delivery is left entirely to the retry cycle. The row is therefore
`pending` until something sends it, which is why the cycle picks up `pending`
rows as well as `failed` ones. A **stock** push still calls inline, because it
is already running in a background context of its own.

The pull inverts this: it acknowledges only the records that stored cleanly,
and writes its log row after the acknowledgement. A record that fails to save
is never acknowledged, so the website keeps offering it.

An HTTP success is not an acknowledgement. The acknowledgement body has to say
`status: success`, or the log row is marked failed and the run reports that the
records were saved but not acknowledged. What the run reports as synced is the
website's own `acknowledged_count`, not how many rows the ERP wrote.

## What retries and what does not

Only **outbound** rows retry, up to five attempts, with one, two, four, eight
then sixteen minutes between them. Nothing distinguishes a rejection from a
transport failure: both are retried until the attempts run out, and the row
then stays failed. There is no dead-letter status.

Only **orders** and **inventory** can be replayed at all, because their stored
payload is the whole message. Every other module reaches the ERP through pull,
upsert and acknowledge, whose batch cannot be replayed on its own, so neither
the cycle nor the dashboard offers a retry for one. Recovery is another pull.

The cycle runs at `POST /api/cron/sync-retry`, guarded by `SYNC_CRON_SECRET`
from the server environment — never `NEXT_PUBLIC_` — offered as
`Authorization: Bearer <secret>` or `X-Cron-Secret`. With nothing configured
the route is closed, not open. Point a scheduler at it every five minutes,
which is the interval the current `cron_sync_retry.php` is documented with. One
cycle runs at a time in a process; a second call while one is in flight returns
without doing anything, since it would only find rows the first has claimed.

A manual retry from the dashboard ignores the backoff.

## Two gates, deliberately different

- An **order** syncs when its category **or** its product carries the website
  flag.
- **Stock** syncs only when the category **and** the product carry it.

That asymmetry is in the current application and is kept: an order is a single
event worth reporting even when only part of it is listed on the website, while
publishing a stock figure for an unlisted product would be wrong.

## Points that will surprise you

- A stock push allocates its version number **before** the call and never rolls
  it back, so a failed push still burns a number. A retry reuses the stored
  payload and does not allocate another.
- The stock quantity comes from the **first** balance row, not a sum. One
  balance row per product is the current schema, so the two agree, but the
  query is not defensive about it.
- The ERP sends its **raw** status integer as `erp_status`. There is no
  ERP-to-website status map on this side; the label appears only inside the
  human-readable remark. Do not add one, or the two systems will disagree.
- A snapshot is refused when the website offers a `sync_version` older than the
  one already stored. A delayed record cannot overwrite a newer one. This holds
  for customers, meetings and quiz leads as well as the two document types, but
  the first three keep their version in a column that arrives with a migration
  which is still pending on some installs. That column is probed rather than
  assumed: where it is missing the pull carries on without the protection it
  cannot have, instead of failing every record.
- An order push sends `erp_status_version` so the website can refuse a status
  update older than the one it holds. An unversioned row sends 1.
- The quiz answers are replaced only when the incoming record carries the
  `answers` key at all, so a partial record cannot silently wipe them.

## Where it is called from

`syncOrderStatusSafely` runs after a goods dispatch commits, once per order
whose status moved. It never throws: a dispatch that is already committed must
not fail because the website is unreachable.

The dashboard's buttons drive the rest — enabling a module, pulling one by
hand, pushing pending stock, and retrying a single failure.

## The legacy catalog tools

`Sync Categories` and `Sync Sub Categories` predate the sync API and write
straight into both databases, matching rows by **slug** rather than by
identifier. They need `WEBSITE_DB_HOST`, `WEBSITE_DB_DATABASE`,
`WEBSITE_DB_USERNAME` and `WEBSITE_DB_PASSWORD` (plus an optional
`WEBSITE_DB_PORT`) in the server environment, and refuse before touching either
database when those are absent.

In the current application this second connection is named `$webConn` and is
never opened anywhere, so both buttons fail on their first query. Refusing
therefore leaves behind exactly what the current code leaves behind, which is
nothing.

## Not ported

Two of the three cron workers (`cron_sync_pull.php` and
`cron_sync_inventory.php`). Each is a loop over the same functions this module
already exposes, and the dashboard's "Run enabled pulls" covers both by hand.
`cron_sync_retry.php` **is** ported, at `POST /api/cron/sync-retry`.
