import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";

const projectRoot = path.resolve(import.meta.dirname, "..");
const sourcePath = path.join(projectRoot, "public", "images", "logo3.jpeg");
const outputPath = path.join(projectRoot, "src", "app", "favicon.ico");
const source = sharp(await readFile(sourcePath));
const metadata = await source.metadata();
const cropWidth = Math.min(metadata.width ?? 64, 64);
const cropHeight = metadata.height ?? 89;
const mark = source
  .clone()
  .extract({ left: 0, top: 0, width: cropWidth, height: cropHeight })
  .trim({ background: "#ffffff", threshold: 10 });
const sizes = [16, 32, 48, 256];
const images = await Promise.all(sizes.map((size) => mark
  .clone()
  .resize({
    width: Math.max(1, Math.round(size * 0.82)),
    height: Math.max(1, Math.round(size * 0.82)),
    fit: "contain",
    background: "#ffffff",
  })
  .extend({
    top: Math.floor(size * 0.09),
    bottom: size - Math.max(1, Math.round(size * 0.82)) - Math.floor(size * 0.09),
    left: Math.floor(size * 0.09),
    right: size - Math.max(1, Math.round(size * 0.82)) - Math.floor(size * 0.09),
    background: { r: 255, g: 255, b: 255, alpha: 1 },
  })
  .flatten({ background: "#ffffff" })
  .ensureAlpha(1)
  .png()
  .toBuffer()));

const headerSize = 6 + images.length * 16;
const header = Buffer.alloc(headerSize);
header.writeUInt16LE(0, 0);
header.writeUInt16LE(1, 2);
header.writeUInt16LE(images.length, 4);
let offset = headerSize;
images.forEach((image, index) => {
  const entry = 6 + index * 16;
  const size = sizes[index];
  header.writeUInt8(size === 256 ? 0 : size, entry);
  header.writeUInt8(size === 256 ? 0 : size, entry + 1);
  header.writeUInt8(0, entry + 2);
  header.writeUInt8(0, entry + 3);
  header.writeUInt16LE(1, entry + 4);
  header.writeUInt16LE(32, entry + 6);
  header.writeUInt32LE(image.length, entry + 8);
  header.writeUInt32LE(offset, entry + 12);
  offset += image.length;
});

await writeFile(outputPath, Buffer.concat([header, ...images]));
console.log(`Generated favicon with ${sizes.length} sizes.`);
