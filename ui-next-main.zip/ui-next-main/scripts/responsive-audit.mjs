import { readdir, writeFile } from "node:fs/promises";
import { chromium } from "playwright";

const baseUrl = process.env.AUDIT_BASE_URL ?? "http://127.0.0.1:3000";
const routeRoot = new URL("../src/app/(erp)/", import.meta.url);
const routeEntries = await readdir(routeRoot, { withFileTypes: true });
const routes = routeEntries.filter((entry) => entry.isDirectory()).map((entry) => `/${entry.name}`).sort();
const viewports = [
  { name: "phone", width: 360, height: 800 },
  { name: "tablet", width: 768, height: 1024 },
  { name: "laptop", width: 1024, height: 768 },
  { name: "desktop", width: 1440, height: 900 },
];

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: viewports.at(-1) });
const findings = [];

for (let routeIndex = 0; routeIndex < routes.length; routeIndex += 1) {
  const route = routes[routeIndex];
  const runtimeErrors = [];
  const onPageError = (error) => runtimeErrors.push(error.message);
  page.on("pageerror", onPageError);
  try {
    await page.setViewportSize(viewports.at(-1));
    const response = await page.goto(`${baseUrl}${route}`, { waitUntil: "domcontentloaded", timeout: 60_000 });
    await page.waitForTimeout(250);
    for (const viewport of viewports) {
      await page.setViewportSize(viewport);
      await page.waitForTimeout(250);
      const metrics = await page.evaluate(() => {
        const root = document.documentElement;
        const body = document.body;
        const viewportWidth = root.clientWidth;
        const offenders = [...document.querySelectorAll("body *")].flatMap((element) => {
          if (!(element instanceof HTMLElement)) return [];
          const style = getComputedStyle(element);
          const rect = element.getBoundingClientRect();
          if (style.display === "none" || style.visibility === "hidden" || rect.width === 0 || rect.height === 0) return [];
          if (rect.right <= viewportWidth + 2 && rect.left >= -2) return [];
          let ancestor = element.parentElement;
          while (ancestor && ancestor !== body) {
            const overflow = getComputedStyle(ancestor).overflowX;
            if (["auto", "scroll", "hidden", "clip"].includes(overflow)) return [];
            ancestor = ancestor.parentElement;
          }
          return [{ tag: element.tagName.toLowerCase(), classes: element.className.toString().slice(0, 120), left: Math.round(rect.left), right: Math.round(rect.right) }];
        }).slice(0, 5);
        return {
          rootWidth: root.scrollWidth,
          bodyWidth: body.scrollWidth,
          viewportWidth,
          title: document.title,
          text: body.innerText.slice(0, 500),
          offenders,
        };
      });
      const redirectedToLogin = new URL(page.url()).pathname === "/login";
      const applicationError = /Application error|Internal Server Error/i.test(metrics.text);
      const rootOverflow = metrics.rootWidth > metrics.viewportWidth + 2 || metrics.bodyWidth > metrics.viewportWidth + 2;
      if (!response || response.status() >= 400 || redirectedToLogin || applicationError || rootOverflow || metrics.offenders.length || runtimeErrors.length) {
        findings.push({
          route,
          viewport: viewport.name,
          size: `${viewport.width}x${viewport.height}`,
          status: response?.status() ?? 0,
          redirectedToLogin,
          applicationError,
          rootOverflow,
          widths: `${metrics.rootWidth}/${metrics.bodyWidth}/${metrics.viewportWidth}`,
          offenders: metrics.offenders,
          runtimeErrors,
        });
      }
    }
  } catch (error) {
    findings.push({ route, viewport: "navigation", navigationError: error instanceof Error ? error.message : String(error) });
  } finally {
    page.off("pageerror", onPageError);
  }
  if ((routeIndex + 1) % 10 === 0 || routeIndex === routes.length - 1) {
    console.log(`AUDIT_PROGRESS ${routeIndex + 1}/${routes.length} findings=${findings.length}`);
  }
}

await writeFile(new URL("../.next/responsive-audit.json", import.meta.url), JSON.stringify({ routes: routes.length, viewports, findings }, null, 2));
await browser.close();
console.log(`AUDIT_DONE routes=${routes.length} checks=${routes.length * viewports.length} findings=${findings.length}`);
