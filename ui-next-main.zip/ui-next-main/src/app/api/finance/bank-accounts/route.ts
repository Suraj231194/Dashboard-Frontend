import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiAnyPermission } from "@/lib/http/guard";
import { saveFinanceBankAccount } from "@/modules/finance/finance-company";

export const runtime = "nodejs";

/**
 * The Finance bank-account dialog (`save_bank_account`,
 * `finance_actions.php:1391-1476`). Either document-editor manage permission
 * is enough, which is the pair the current action checks.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiAnyPermission(
    request,
    ["finance_invoice_generation_manage", "finance_delivery_challan_generation_manage"],
    "You do not have permission to manage Finance bank accounts.",
  );
  if (!guard.ok) return guard.response;

  const data = await request.formData();
  const text = (key: string) => String(data.get(key) ?? "").trim();
  const optional = (value: string) => (value === "" ? null : value);
  const qrFile = data.get("qr_file");

  try {
    const result = await saveFinanceBankAccount({
      bankName: text("bank_name"),
      branchName: optional(text("branch_name")),
      accountName: optional(text("account_name")),
      accountNumber: optional(text("account_number")),
      ifscCode: optional(text("ifsc_code").toUpperCase()),
      swiftCode: optional(text("swift_code").toUpperCase()),
      upiId: optional(text("upi_id")),
      isDefault: String(data.get("is_default") ?? "") === "1",
      qrFile: qrFile instanceof File ? qrFile : null,
      userId: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status);
    return apiSuccess({ bankId: result.bankId }, "Finance bank account saved.");
  } catch (error) {
    console.error("Unable to save the Finance bank account", error);
    return apiError("Unable to save bank account.", 500);
  }
}
