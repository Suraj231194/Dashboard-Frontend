import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { listProductCommercials, saveProductCommercial } from "@/modules/finance/finance-commercials";

export const runtime = "nodejs";

const DENIED = "You do not have permission to use this screen.";

/** `list_product_commercials` (`finance_actions.php:1254-1318`). */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(request, "finance_invoice_generation_manage", DENIED);
  if (!guard.ok) return guard.response;

  const params = request.nextUrl.searchParams;
  try {
    return apiSuccess(await listProductCommercials({
      page: Number.parseInt(params.get("page") ?? "1", 10) || 1,
      perPage: Number.parseInt(params.get("per_page") ?? "50", 10) || 50,
      search: (params.get("search") ?? "").trim(),
    }));
  } catch (error) {
    console.error("Unable to load product commercial data", error);
    return apiError("Unable to load product commercial data.", 500);
  }
}

/** `save_product_commercial` (`finance_actions.php:1320-1389`). */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "finance_invoice_generation_manage", DENIED);
  if (!guard.ok) return guard.response;

  const data = await request.formData();
  const number = (key: string) => Number.parseFloat(String(data.get(key) ?? "0")) || 0;
  try {
    const result = await saveProductCommercial({
      productId: Number.parseInt(String(data.get("product_id") ?? "0"), 10) || 0,
      hsnCode: String(data.get("hsn_code") ?? ""),
      mrp: number("mrp"),
      sellingRate: number("selling_rate"),
      gstRate: number("gst_rate"),
      effectiveFrom: String(data.get("effective_from") ?? ""),
      userId: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status);
    return apiSuccess({}, "Product commercial data saved.");
  } catch (error) {
    console.error("Unable to save product commercial data", error);
    return apiError("Unable to save product commercial data.", 500);
  }
}
