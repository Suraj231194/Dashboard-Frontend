import { NextRequest } from "next/server";
import { apiError, apiForbidden, apiSuccess } from "@/lib/http/json";
import { readId, requireApiSession } from "@/lib/http/guard";
import { isSameOrigin } from "@/lib/http/same-origin";
import { roleHasPermission } from "@/modules/access/permissions";
import { FINANCE_DOCUMENT_MANAGE_PERMISSION, type FinanceItemInput } from "@/modules/finance/finance-constants";
import { findFinanceDocumentForWrite } from "@/modules/finance/finance-documents";
import { generateFinanceDocument } from "@/modules/finance/finance-generate";

export const runtime = "nodejs";

const field = (data: FormData, name: string): string => String(data.get(name) ?? "").trim();

/** The lines the editor posts, as one JSON string (`editorItemsPayload()`). */
function readItems(raw: string): FinanceItemInput[] {
  if (raw === "") return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item): item is FinanceItemInput => typeof item === "object" && item !== null);
  } catch {
    return [];
  }
}

/**
 * `generate_document`: the DRAFT invoice or delivery challan becomes a
 * GENERATED one, numbered, with its lines and totals rewritten.
 */
export async function POST(request: NextRequest, context: RouteContext<"/api/finance/documents/[id]/generate">) {
  const session = await requireApiSession();
  if (!session.ok) return session.response;
  if (!isSameOrigin(request)) {
    return apiError("Your session token is invalid. Please refresh the page and try again.", 419);
  }

  const documentId = readId((await context.params).id);
  const document = await findFinanceDocumentForWrite(documentId);
  if (!document) return apiError("Finance document not found.", 404);

  const slug = FINANCE_DOCUMENT_MANAGE_PERMISSION[document.document_type];
  if (!(await roleHasPermission(session.user.user_id, session.user.role_id, slug))) {
    return apiForbidden("You do not have permission to perform this action.");
  }

  const data = await request.formData();
  const posted: Record<string, unknown> = {};
  for (const [key, value] of data.entries()) {
    if (typeof value === "string") posted[key] = value;
  }

  const creditDaysRaw = Number.parseInt(field(data, "credit_days"), 10);

  const result = await generateFinanceDocument({
    documentId,
    documentType: document.document_type,
    erpCompanyId: Number.parseInt(field(data, "erp_company_id"), 10) || 0,
    documentDate: field(data, "document_date"),
    dueDate: field(data, "due_date"),
    taxMode: field(data, "tax_mode") || "INTRA",
    creditDays: Number.isFinite(creditDaysRaw) ? creditDaysRaw : 30,
    counterpartyName: field(data, "counterparty_name"),
    counterpartyAddress: field(data, "counterparty_address"),
    counterpartyShippingAddress: field(data, "counterparty_shipping_address"),
    counterpartyEmail: field(data, "counterparty_email"),
    counterpartyGstin: field(data, "counterparty_gstin"),
    counterpartyState: field(data, "counterparty_state"),
    counterpartyStateCode: field(data, "counterparty_state_code"),
    counterpartyContact: field(data, "counterparty_contact"),
    irn: field(data, "irn"),
    acknowledgementNumber: field(data, "acknowledgement_number"),
    casesText: field(data, "cases_text"),
    lrNumber: field(data, "lr_number"),
    lrDate: field(data, "lr_date"),
    transportMode: field(data, "transport_mode"),
    trackingId: field(data, "tracking_id"),
    bankAccountId: Number.parseInt(field(data, "bank_account_id"), 10) || 0,
    bankSnapshot: {
      bank_name: field(data, "bank_name"),
      branch_name: field(data, "branch_name"),
      account_name: field(data, "account_name"),
      account_number: field(data, "account_number"),
      ifsc_code: field(data, "ifsc_code"),
      swift_code: field(data, "swift_code"),
      upi_id: field(data, "upi_id"),
    },
    termsSnapshot: String(data.get("terms_snapshot") ?? ""),
    notes: field(data, "notes"),
    saveCreditDefault: field(data, "save_credit_default") === "1",
    saveCommercialDefaults: field(data, "save_commercial_defaults") === "1",
    items: readItems(field(data, "items")),
    posted,
    userId: session.user.user_id,
  });

  if (!result.ok) return apiError(result.message, result.status);
  return apiSuccess(
    { document_id: result.documentId, document_number: result.documentNumber },
    result.message,
  );
}
