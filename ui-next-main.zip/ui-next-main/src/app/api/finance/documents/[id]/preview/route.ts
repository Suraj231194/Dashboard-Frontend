import { NextRequest } from "next/server";
import { apiError, apiForbidden, apiSuccess } from "@/lib/http/json";
import { readId, requireApiSession } from "@/lib/http/guard";
import { canAny } from "@/modules/access/permissions";
import {
  FINANCE_DOCUMENT_VIEW_PERMISSIONS, type FinanceDocumentType, type FinanceItemInput,
} from "@/modules/finance/finance-constants";
import { findFinanceDocumentForWrite } from "@/modules/finance/finance-documents";
import { buildPreviewDocument, type PreviewOverrides } from "@/modules/finance/finance-generate";
import { financeDocumentStandaloneHtml } from "@/modules/finance/finance-document-render";

export const runtime = "nodejs";

const field = (data: FormData, name: string): string => String(data.get(name) ?? "").trim();
const orUndefined = (value: string): string | undefined => (value === "" ? undefined : value);

function readItems(raw: string): FinanceItemInput[] | undefined {
  if (raw === "") return undefined;
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return undefined;
    return parsed.filter((item): item is FinanceItemInput => typeof item === "object" && item !== null);
  } catch {
    return undefined;
  }
}

/**
 * `preview_document_html`: the printed format, rendered from the stored
 * document with the editor's unsaved values laid over it.
 *
 * It is a POST because the draft travels in the body; nothing is written.
 * A GET of `/document` renders the same builder as a printable page.
 */
export async function POST(request: NextRequest, context: RouteContext<"/api/finance/documents/[id]/preview">) {
  const session = await requireApiSession();
  if (!session.ok) return session.response;

  const documentId = readId((await context.params).id);
  const document = await findFinanceDocumentForWrite(documentId);
  if (!document) return apiError("Finance document not found.", 404);

  const allowed = FINANCE_DOCUMENT_VIEW_PERMISSIONS[document.document_type as FinanceDocumentType] ?? [];
  if (!(await canAny(session.user, allowed))) {
    return apiForbidden("You do not have permission to preview this Finance document format.");
  }

  const data = await request.formData();
  const overrides: PreviewOverrides = {
    taxMode: orUndefined(field(data, "tax_mode")),
    items: readItems(field(data, "items")),
    transportMode: orUndefined(field(data, "transport_mode")),
    documentDate: orUndefined(field(data, "document_date")),
    dueDate: orUndefined(field(data, "due_date")),
    counterpartyName: orUndefined(field(data, "counterparty_name")),
    counterpartyAddress: orUndefined(field(data, "counterparty_address")),
    counterpartyShippingAddress: orUndefined(field(data, "counterparty_shipping_address")),
    counterpartyGstin: orUndefined(field(data, "counterparty_gstin")),
    counterpartyState: orUndefined(field(data, "counterparty_state")),
    counterpartyStateCode: orUndefined(field(data, "counterparty_state_code")),
    counterpartyContact: orUndefined(field(data, "counterparty_contact")),
    counterpartyEmail: orUndefined(field(data, "counterparty_email")),
    termsSnapshot: orUndefined(field(data, "terms_snapshot")),
    bankAccountId: Number.parseInt(field(data, "bank_account_id"), 10) || undefined,
    bankSnapshot: {
      bank_name: field(data, "bank_name"),
      branch_name: field(data, "branch_name"),
      account_name: field(data, "account_name"),
      account_number: field(data, "account_number"),
      ifsc_code: field(data, "ifsc_code"),
      swift_code: field(data, "swift_code"),
      upi_id: field(data, "upi_id"),
    },
  };

  try {
    const rendered = await buildPreviewDocument(documentId, overrides);
    if (!rendered) return apiError("Finance document not found.", 404);
    return apiSuccess({ html: financeDocumentStandaloneHtml(rendered) });
  } catch (error) {
    console.error(`Unable to build the Finance document preview ${documentId}`, error);
    return apiError("Unable to build preview.", 500);
  }
}
