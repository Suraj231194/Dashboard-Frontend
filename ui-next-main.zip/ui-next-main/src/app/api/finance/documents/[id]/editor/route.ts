import { NextRequest } from "next/server";
import { apiError, apiForbidden, apiSuccess } from "@/lib/http/json";
import { readId, requireApiSession } from "@/lib/http/guard";
import { roleHasPermission } from "@/modules/access/permissions";
import { FINANCE_DOCUMENT_MANAGE_PERMISSION } from "@/modules/finance/finance-constants";
import { getFinanceDocumentForEditor } from "@/modules/finance/finance-editor";

export const runtime = "nodejs";

/**
 * The record the invoice / delivery-challan editor opens with
 * (`get_document`, as `financeOpenEditor()` calls it).
 *
 * The editor is a write surface, so this is guarded by the manage permission
 * of the document's own type — `financeRequireDocumentManage()` reads the row
 * first and derives the slug from it, which is the order kept here.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/finance/documents/[id]/editor">) {
  const session = await requireApiSession();
  if (!session.ok) return session.response;

  const document = await getFinanceDocumentForEditor(readId((await context.params).id));
  if (!document) return apiError("Finance document not found.", 404);

  const slug = FINANCE_DOCUMENT_MANAGE_PERMISSION[document.document_type];
  if (!(await roleHasPermission(session.user.user_id, session.user.role_id, slug))) {
    return apiForbidden("You do not have permission to perform this action.");
  }
  return apiSuccess({ document });
}
