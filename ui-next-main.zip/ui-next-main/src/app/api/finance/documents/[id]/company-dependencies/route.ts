import { NextRequest } from "next/server";
import { apiError, apiForbidden, apiSuccess } from "@/lib/http/json";
import { readId, requireApiSession } from "@/lib/http/guard";
import { roleHasPermission } from "@/modules/access/permissions";
import { FINANCE_DOCUMENT_MANAGE_PERMISSION } from "@/modules/finance/finance-constants";
import { findFinanceDocumentForWrite } from "@/modules/finance/finance-documents";
import { FinanceCompanyError, readCompanyDependencies } from "@/modules/finance/finance-company";

export const runtime = "nodejs";

/**
 * `get_company_dependencies` (`finance_actions.php:520-538`): the bank accounts
 * and the terms block that belong to the company the editor has just switched
 * to. A read, so it answers a GET.
 */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/finance/documents/[id]/company-dependencies">,
) {
  const session = await requireApiSession();
  if (!session.ok) return session.response;

  const document = await findFinanceDocumentForWrite(readId((await context.params).id));
  if (!document) return apiError("Finance document not found.", 404);

  const slug = FINANCE_DOCUMENT_MANAGE_PERMISSION[document.document_type];
  if (!(await roleHasPermission(session.user.user_id, session.user.role_id, slug))) {
    return apiForbidden("You do not have permission to perform this action.");
  }

  const companyId = Number.parseInt(request.nextUrl.searchParams.get("erp_company_id") ?? "0", 10);
  if (!Number.isFinite(companyId) || companyId <= 0) {
    return apiError("Select a valid company.", 422);
  }

  try {
    const dependencies = await readCompanyDependencies(companyId, document.document_type);
    return apiSuccess(dependencies);
  } catch (error) {
    if (error instanceof FinanceCompanyError) return apiError(error.message, 422);
    console.error("Unable to load the Finance company dependencies", error);
    return apiError("Unable to load company Finance settings.", 500);
  }
}
