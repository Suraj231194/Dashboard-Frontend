import { NextRequest } from "next/server";
import { documentError, documentId, documentPage, requireDocumentPermission } from "@/lib/documents/document-page";
import { FINANCE_DOCUMENT_VIEW_PERMISSIONS, type FinanceDocumentType } from "@/modules/finance/finance-constants";
import { findFinanceDocumentForWrite } from "@/modules/finance/finance-documents";
import { buildPreviewDocument } from "@/modules/finance/finance-generate";
import {
  financeBuildDocumentBody, financeDocumentFileName, FINANCE_DOCUMENT_STYLES,
} from "@/modules/finance/finance-document-render";

export const runtime = "nodejs";

/**
 * The printable invoice or delivery challan, served the way every other
 * controlled document in this application is: an A4 page the browser prints.
 *
 * The current application stores a PDF built by overlaying this document onto
 * a pinned template; that overlay is not reproduced, so this is the HTML path
 * its own preview uses. `?download=1` opens the print dialog.
 */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/finance/documents/[id]/document">,
) {
  const id = documentId((await context.params).id);
  if (id === 0) return documentError("A valid document ID is required.", 422);

  // The permissions depend on the document's type, so the row is read first,
  // exactly as `preview_document_html` reads it before it checks.
  const document = await findFinanceDocumentForWrite(id);
  if (!document) return documentError("Finance document not found.", 404);

  const guard = await requireDocumentPermission(
    FINANCE_DOCUMENT_VIEW_PERMISSIONS[document.document_type as FinanceDocumentType] ?? [],
  );
  if (!guard.ok) return guard.response;

  try {
    const rendered = await buildPreviewDocument(id);
    if (!rendered) return documentError("Finance document not found.", 404);
    return documentPage({
      title: financeDocumentFileName(rendered),
      bodyHtml: financeBuildDocumentBody(rendered),
      pageStyles: FINANCE_DOCUMENT_STYLES,
      orientation: "landscape",
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    console.error(`Unable to render the Finance document ${id}`, error);
    return documentError("The Finance document could not be rendered.", 500);
  }
}
