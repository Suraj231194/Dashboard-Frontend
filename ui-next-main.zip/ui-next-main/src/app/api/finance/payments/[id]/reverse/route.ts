import { NextRequest } from "next/server";
import { apiError, apiForbidden, apiSuccess } from "@/lib/http/json";
import { readId, requireApiSession } from "@/lib/http/guard";
import { isSameOrigin } from "@/lib/http/same-origin";
import { roleHasPermission } from "@/modules/access/permissions";
import {
  findFinancePaymentForWrite, paymentDirectionManagePermission, reverseFinancePayment,
} from "@/modules/finance/finance-payments";

export const runtime = "nodejs";

/**
 * Reverses one posted payment (`reverse_payment`,
 * `finance_actions.php:1195-1252`). The permission is the register the payment
 * belongs to, which the current action reads from the locked row before it
 * checks anything.
 */
export async function POST(request: NextRequest, context: RouteContext<"/api/finance/payments/[id]/reverse">) {
  const session = await requireApiSession();
  if (!session.ok) return session.response;
  if (!isSameOrigin(request)) {
    return apiError("Your session token is invalid. Please refresh the page and try again.", 419);
  }

  const paymentId = readId((await context.params).id);
  const payment = await findFinancePaymentForWrite(paymentId);
  if (!payment) return apiError("This payment is not available for reversal.", 422);

  const slug = paymentDirectionManagePermission(payment.direction);
  if (!(await roleHasPermission(session.user.user_id, session.user.role_id, slug))) {
    return apiForbidden("You do not have permission to perform this action.");
  }

  const data = await request.formData();
  const result = await reverseFinancePayment({
    paymentId,
    reason: String(data.get("reason") ?? ""),
    userId: session.user.user_id,
  });
  if (!result.ok) return apiError(result.message, result.status);
  return apiSuccess({}, "Payment reversed successfully.");
}
