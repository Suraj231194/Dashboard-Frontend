import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import {
  createProductCategory, listProductCategories, PRODUCT_CATEGORY_SORT_COLUMNS,
} from "@/modules/inventory/product-categories";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "product-categories");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(
      request.nextUrl.searchParams, PRODUCT_CATEGORY_SORT_COLUMNS, "recent", "DESC",
    );
    return apiSuccess(await listProductCategories(query));
  } catch (error) {
    console.error("Unable to list product categories", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "product_category_add", "You do not have permission to add product categories.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createProductCategory({
      name: String(data.get("categoryName") ?? ""),
      webSync: Number.parseInt(String(data.get("isWebSync") ?? "0"), 10) || 0,
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to add a product category", error);
    return apiError("Something went wrong.", 500);
  }
}
