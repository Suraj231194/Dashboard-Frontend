import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { createLowStockProductionPlans } from "@/modules/inventory/produce-requests";

export const runtime = "nodejs";

type PostedItem = {
  product_id?: unknown;
  category_id?: unknown;
  quantity?: unknown;
  unit_id?: unknown;
};

/**
 * `createLowStockProductionPlans`: the Produce button on the low-stock purchase
 * request form, beside Procure.
 *
 * The form posts its rows as a JSON `items` array, as the current screen does.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request,
    "operations_admin_production_plan_add",
    "You do not have permission to create Production Plans.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    let parsed: unknown = [];
    try {
      parsed = JSON.parse(String(data.get("items") ?? "[]"));
    } catch {
      return apiError("Provide a reporter, valid report date, and at least one production item.", 422);
    }
    const rows: PostedItem[] = Array.isArray(parsed) ? (parsed as PostedItem[]) : [];

    const result = await createLowStockProductionPlans({
      reportingPerson: String(data.get("reportingPerson") ?? ""),
      dateOfReport: String(data.get("dateOfReport") ?? "").trim(),
      items: rows.map((row) => ({
        productId: Number(row.product_id ?? 0) || 0,
        categoryId: Number(row.category_id ?? 0) || 0,
        quantity: Number(row.quantity ?? 0) || 0,
        unitId: Number(row.unit_id ?? 0) || 0,
      })),
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 422);
    return apiSuccess({ created: result.created, existing: result.existing }, result.message);
  } catch (error) {
    console.error("Unable to send the purchase request to Production", error);
    return apiError("Unable to send the selection to Production.", 500);
  }
}
