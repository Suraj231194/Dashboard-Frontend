import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createLowStocks, listLowStocks, LOW_STOCK_SORT_KEYS, type LowStockLine } from "@/modules/inventory/low-stocks";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "low-stocks");
  if (!guard.ok) return guard.response;
  try {
    // Any other column falls back to lowstk.id DESC, as the current handler does.
    const query = readListQuery(request.nextUrl.searchParams, LOW_STOCK_SORT_KEYS, "recent", "DESC");
    return apiSuccess(await listLowStocks(query));
  } catch (error) {
    console.error("Unable to list low stocks", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "low_stocks_menu_add", "You do not have permission to raise purchase requests.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const column = (key: string) => data.getAll(key).map(String);
    const itemType = column("itemType[]");
    const nonInventoryItemName = column("nonInventoryItemName[]");
    const materialCategory = column("materialCategory[]");
    const productsList = column("productsList[]");
    const packSizeId = column("packSizeId[]");
    const quantity = column("ProductItemquantity[]");
    const quantityUnit = column("ProductItemquantityUnit[]");
    const vendorName = column("vendorName[]");
    const critical = column("isThisCritical[]");
    const deliveryDate = column("dateOfDelivery[]");
    const procurementSource = column("procurementSource[]");
    const branchId = column("branchId[]");
    const warehouseId = column("warehouseId[]");
    const currentStock = column("currentStock[]");
    const reorderLevel = column("reorderLevel[]");
    const currencyType = column("currencyType[]");
    const priceValue = column("priceInValue[]");

    const rowCount = Math.max(
      materialCategory.length, productsList.length, nonInventoryItemName.length, quantity.length,
    );
    const lines: LowStockLine[] = [];
    for (let index = 0; index < rowCount; index += 1) {
      lines.push({
        itemType: itemType[index] ?? "inventory",
        nonInventoryItemName: nonInventoryItemName[index] ?? "",
        materialCategory: Number.parseInt(materialCategory[index] ?? "0", 10) || 0,
        productId: Number.parseInt(productsList[index] ?? "0", 10) || 0,
        packSizeId: Number.parseInt(packSizeId[index] ?? "0", 10) || 0,
        quantity: Number.parseFloat(quantity[index] ?? "0") || 0,
        quantityUnit: Number.parseInt(quantityUnit[index] ?? "0", 10) || 0,
        vendorName: vendorName[index] ?? "",
        critical: Number.parseInt(critical[index] ?? "0", 10) || 0,
        deliveryDate: deliveryDate[index] ?? "",
        procurementSource: procurementSource[index] ?? "",
        branchId: Number.parseInt(branchId[index] ?? "0", 10) || 0,
        warehouseId: Number.parseInt(warehouseId[index] ?? "0", 10) || 0,
        currentStock: currentStock[index] ?? "",
        reorderLevel: reorderLevel[index] ?? "",
        currencyType: Number.parseInt(currencyType[index] ?? "0", 10) || 0,
        priceValue: priceValue[index] ?? "",
      });
    }

    const result = await createLowStocks({
      reportingPerson: String(data.get("reportingPerson") ?? ""),
      dateOfReport: String(data.get("dateOfReport") ?? ""),
      lines,
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message ?? "Low Stock records added successfully.");
  } catch (error) {
    console.error("Unable to add low stock requests", error);
    return apiError("Something went wrong.", 500);
  }
}
