import { NextRequest } from "next/server";
import { documentError, documentPage } from "@/lib/documents/document-page";
import { requireApiPageAccess } from "@/lib/http/guard";
import {
  readStockReport, renderStockReport, STOCK_REPORT_STYLES,
} from "@/modules/inventory/stock-report-render";

export const runtime = "nodejs";

/**
 * The Stock Report (`admin/pages/print_stockList.php`).
 *
 * The reference template has no authentication of its own and no caller; this
 * endpoint puts it behind the stocks screen's page access, which is the
 * permission that decides who may see stock levels at all.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "stocks");
  if (!guard.ok) return guard.response;
  try {
    const lines = await readStockReport();
    return documentPage({
      title: "stock_report",
      bodyHtml: renderStockReport(lines),
      pageStyles: STOCK_REPORT_STYLES,
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    console.error("Unable to render the stock report", error);
    return documentError("The Stock Report could not be rendered.", 500);
  }
}
