import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { normalizeIntList } from "@/modules/inventory/stock-list-sql";
import { createInventoryProductionPlans } from "@/modules/inventory/produce-requests";

export const runtime = "nodejs";

/**
 * `createInventoryProductionPlans`: the Produce button on Live Inventory.
 *
 * Raises a Production Plan for each selected product, with the quantities
 * recalculated on the server. Sits beside the procurement route, which raises a
 * purchase request for the same selection instead.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request,
    "operations_admin_production_plan_add",
    "You do not have permission to create Production Plans.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createInventoryProductionPlans({
      productIds: normalizeIntList(data.getAll("productIds[]").map(String)),
      source: String(data.get("procurementSource") ?? "").trim(),
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 422);
    return apiSuccess({ created: result.created, existing: result.existing }, result.message);
  } catch (error) {
    console.error("Unable to send the selection to Production", error);
    return apiError("Unable to send the selection to Production.", 500);
  }
}
