import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { previewProductCatNumber } from "@/modules/inventory/products";

export const runtime = "nodejs";

/** `generateProductCatPreview`: the next CAT number for a category and stage. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "products");
  if (!guard.ok) return guard.response;
  const categoryId = Number.parseInt(request.nextUrl.searchParams.get("categoryId") ?? "", 10);
  if (!Number.isFinite(categoryId) || categoryId <= 0) return apiError("Select a product category.", 422);
  try {
    const preview = await previewProductCatNumber(categoryId, request.nextUrl.searchParams.get("stage") ?? "FG");
    return apiSuccess({ cat_code: preview.catCode, prefix: preview.prefix });
  } catch (error) {
    console.error("Unable to preview the CAT number", error);
    return apiError("Server error occurred.", 500);
  }
}
