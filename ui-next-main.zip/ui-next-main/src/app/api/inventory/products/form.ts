import type { ProductFormInput } from "@/modules/inventory/products";

/**
 * The add and edit dialogs post the same product under two sets of field
 * names, and the current handler reads the suffixed name first and falls back
 * to the plain one. This keeps that mapping in one place.
 */
function text(data: FormData, base: string, suffix: string): string {
  const suffixed = data.get(`${base}${suffix}`);
  if (suffixed !== null) return String(suffixed);
  return String(data.get(base) ?? "");
}

function list(data: FormData, base: string, suffix: string): string[] {
  const suffixed = data.getAll(`${base}${suffix}[]`);
  const values = suffixed.length > 0 ? suffixed : data.getAll(`${base}[]`);
  return values.map((value) => String(value));
}

function file(data: FormData, base: string, suffix: string): File | null {
  for (const key of [`${base}${suffix}`, base]) {
    const value = data.get(key);
    // An untouched file input still posts an empty entry, which is no upload.
    if (value instanceof File && value.name !== "") return value;
  }
  return null;
}

/** Reads a product out of a posted form. `suffix` is "" to add, "Edit" to update. */
export function readProductForm(data: FormData, suffix: string): ProductFormInput {
  return {
    productName: text(data, "productName", suffix),
    hsnCode: text(data, "hsnCode", suffix),
    description: text(data, "productDescription", suffix),
    categoryId: text(data, "productCategory", suffix),
    gstRate: text(data, "gstRate", suffix),
    // The current handler reads this one under the same name on both dialogs.
    reorderLevel: String(data.get("reorderLevel") ?? ""),
    // `unreservedStockEdit` on the edit dialog and `unreservedStock` on add,
    // with the same fall back to the plain name the edit handler has.
    unreservedStock: text(data, "unreservedStock", suffix),
    // The add handler keeps a typed CAT No and generates one only when it is
    // blank. The update reads `productCodeEdit`, falling back to `productCode`
    // (the stock screen's form posts the plain name), and a blank one keeps
    // the stored code.
    productCode: text(data, "productCode", suffix),
    productStage: String(data.get("productStage") ?? "FG"),
    packSizes: list(data, "packSize", suffix),
    packUnits: list(data, "packSizeUnit", suffix),
    packQtys: list(data, "packSizeQty", suffix),
    image: file(data, "productImage", suffix),
  };
}
