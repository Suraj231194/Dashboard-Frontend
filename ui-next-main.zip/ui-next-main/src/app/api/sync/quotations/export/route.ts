import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { requireApiAnyPermission } from "@/lib/http/guard";
import { SYNC_PERMISSIONS } from "@/modules/sync/sync-constants";
import { buildQuotationExport } from "@/modules/sync/sync-lists";

export const runtime = "nodejs";

/** The quotation screens accept either the sync slug or the CRM one. */
const QUOTATION_SLUGS = [SYNC_PERMISSIONS.quotations, SYNC_PERMISSIONS.quotationsCrm];

/** `exportQuotationRequests`: the chosen columns as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiAnyPermission(
    request, QUOTATION_SLUGS, "You do not have permission to view quotation requests.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const columns = data.getAll("listOfColumns[]").map((entry) => String(entry));
    if (columns.length === 0) return apiError("Please select at least one column to export.", 422);
    const result = await buildQuotationExport(String(data.get("search") ?? "").trim(), columns);
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "Quotation Requests Report", filePrefix: "quotation_requests",
      headers: result.columns, rows: result.rows,
    });
  } catch (error) {
    console.error("Unable to build the quotation request export", error);
    return apiError("Server error occurred.", 500);
  }
}
