import { NextRequest } from "next/server";
import { documentError, documentId, documentPage, requireDocumentPermission } from "@/lib/documents/document-page";
import { SYNC_PERMISSIONS } from "@/modules/sync/sync-constants";
import {
  logQuotationDownload, QUOTATION_SNAPSHOT_STYLES, QuotationAuditError,
  readQuotationSnapshot, renderQuotationSnapshot,
} from "@/modules/sync/quotation-snapshot-render";

export const runtime = "nodejs";

/**
 * The website quotation snapshot (`admin/quotation-snapshot-pdf.php`), opened
 * from the quotation detail modal behind `sync_quotations_view`. Landscape,
 * and each download writes its own audit row before the page is served.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/sync/quotations/[id]/document">) {
  const guard = await requireDocumentPermission([SYNC_PERMISSIONS.quotations]);
  if (!guard.ok) return guard.response;

  const id = documentId((await context.params).id);
  if (id === 0) return documentError("A valid quotation is required.", 422);

  try {
    const snapshot = await readQuotationSnapshot(id);
    if (!snapshot) return documentError("Quotation snapshot not found.", 404);
    await logQuotationDownload(snapshot, Number(guard.user.user_id));
    return documentPage({
      title: snapshot.fileName.replace(/\.pdf$/i, ""),
      bodyHtml: renderQuotationSnapshot(snapshot),
      pageStyles: QUOTATION_SNAPSHOT_STYLES,
      orientation: "landscape",
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    if (error instanceof QuotationAuditError) return documentError(error.message, 500);
    console.error(`Unable to render the quotation snapshot ${id}`, error);
    return documentError("The quotation snapshot could not be rendered.", 500);
  }
}
