import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { runEnabledSyncs } from "@/modules/sync/force-sync";

export const runtime = "nodejs";

/**
 * `#forceSyncAll`: every enabled pull module and the pending inventory job, one
 * after another. The current screen gates the button on the manage permission,
 * so the endpoint asks for the same.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "sync_settings_manage",
    "You do not have permission to run manual synchronization.");
  if (!guard.ok) return guard.response;
  try {
    const result = await runEnabledSyncs();
    const payload = {
      succeeded: result.succeeded, failed: result.failed, jobs: result.jobs,
    };
    // A run with failures still reports what went through, so the toast can
    // carry the same "X succeeded, Y failed" line the current screen shows.
    if (!result.success) return apiError(result.message, result.jobs.length === 0 ? 409 : 422);
    return apiSuccess(payload, result.message);
  } catch (error) {
    console.error("Unable to run the enabled syncs", error);
    return apiError("Unable to run the enabled syncs.", 500);
  }
}
