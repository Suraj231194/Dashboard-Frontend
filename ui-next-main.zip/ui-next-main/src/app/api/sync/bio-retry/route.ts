import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { retryBioQueueJob } from "@/modules/sync/sync-dashboard";

export const runtime = "nodejs";

/** `retryBioQueueJob`: asks the website to re-run one of its own queued jobs. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "sync_failures_retry", "You do not have permission to retry Bio sync failures.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const uuid = String(data.get("uuid") ?? "").trim();
    const result = await retryBioQueueJob(uuid);
    if (!result.success) return apiError(result.message, result.status);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to retry the Bio queue job", error);
    return apiError("Bio could not retry the sync job.", 500);
  }
}
