import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { requireApiPermission } from "@/lib/http/guard";
import { buildCustomerExport } from "@/modules/sync/customers";

export const runtime = "nodejs";

/** `exportCustomerManagement`: the chosen columns as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "sync_users_view", "You do not have permission to manage customers.",
  );
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const columns = data.getAll("listOfColumns[]").map((entry) => String(entry));
    if (columns.length === 0) return apiError("Please select at least one column to export.", 422);
    const result = await buildCustomerExport(String(data.get("search") ?? "").trim(), columns);
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "Customer Management Report", filePrefix: "customer_management",
      headers: result.columns, rows: result.rows,
    });
  } catch (error) {
    console.error("Unable to build the customer export", error);
    return apiError("Server error occurred.", 500);
  }
}
