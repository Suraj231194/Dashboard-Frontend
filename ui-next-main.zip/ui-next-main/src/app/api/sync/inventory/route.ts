import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { runPendingInventoryPushes } from "@/modules/sync/website-push";

export const runtime = "nodejs";

/**
 * `triggerInventorySync`: up to twenty products whose stock is still pending.
 * The run itself lives in the service, so the force-sync route reports the
 * same numbers from the same code.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "sync_settings_manage", "You do not have permission to run a manual sync.");
  if (!guard.ok) return guard.response;
  try {
    const result = await runPendingInventoryPushes();
    if (result.disabled) return apiError(result.message, 409);
    if (!result.success) return apiError(result.message, 422);
    return apiSuccess({ processed: result.processed, failed: result.failed }, result.message);
  } catch (error) {
    console.error("Unable to run the inventory sync", error);
    return apiError("Unable to run the inventory sync.", 500);
  }
}
