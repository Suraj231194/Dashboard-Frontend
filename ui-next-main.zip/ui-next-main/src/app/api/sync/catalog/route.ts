import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { syncCategories, syncSubCategories } from "@/modules/sync/catalog-sync";

export const runtime = "nodejs";

/**
 * `syncCategories` and `syncSubCategories`, the legacy catalog tools. The
 * current handler carries no permission check of its own beyond being signed
 * in, so the screen's own access stands in for one.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "sync");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const scope = String(data.get("scope") ?? "").trim();
    if (scope !== "categories" && scope !== "subcategories") {
      return apiError("Choose either the category or the sub-category tool.", 422);
    }
    const result = scope === "categories" ? await syncCategories() : await syncSubCategories();
    const payload = {
      website_to_erp: result.website_to_erp,
      erp_to_website: result.erp_to_website,
    };
    if (!result.status) return apiError(result.message ?? "Catalog sync failed.", 409);
    return apiSuccess(payload, "Catalog sync finished.");
  } catch (error) {
    console.error("Unable to run the catalog sync", error);
    return apiError("Catalog sync failed. Check server logs.", 500);
  }
}
