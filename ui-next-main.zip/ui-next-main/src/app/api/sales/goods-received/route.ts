import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import {
  cancelReservedOrderRecord, dispatchOrderToStockOutward, getGoodsReceivedReservedList,
} from "@/modules/sales/order-routing";

export const runtime = "nodejs";

/** loadGoodsReceivedReservedData. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ data: await getGoodsReceivedReservedList() });
  } catch (error) {
    console.error("Unable to load the goods received records", error);
    return apiError(error instanceof Error ? error.message : "Error loading data.", 500);
  }
}

/** dispatchReservedOrderRecord and cancelReservedOrderRecord. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "order-received");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const action = String(data.get("action") ?? "");
    const orderId = Number.parseInt(String(data.get("order_id") ?? "0"), 10) || 0;
    const orderItemId = Number.parseInt(String(data.get("order_item_id") ?? "0"), 10) || 0;

    if (action === "dispatch") {
      // dispatchReservedOrderRecord now only queues the order; physical
      // dispatch (and stock consumption) stays in Goods Dispatch.
      const result = await dispatchOrderToStockOutward(
        orderId, "Sent from Goods Received & Reserved.", guard.user.user_id);
      if (result.status !== "success") return apiError(result.message, 400);
      return apiSuccess(result, result.message);
    }
    if (action === "cancel") {
      const result = await cancelReservedOrderRecord(orderId, orderItemId, guard.user.user_id);
      return apiSuccess(result, result.message);
    }
    return apiError("Unknown action.", 422);
  } catch (error) {
    console.error("Unable to process the reserved order record", error);
    return apiError(error instanceof Error ? error.message : "Server error occurred.", 400);
  }
}
