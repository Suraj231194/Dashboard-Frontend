import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { readId, requireApiAnyPermission } from "@/lib/http/guard";
import { tableExportResponse } from "@/lib/export/table-export";
import { buildOrderDocumentExport, ORDER_DOWNLOAD_SLUGS } from "@/modules/sales/orders";

export const runtime = "nodejs";

/** `exportajax.php?downloadOrderExcel=<id>`: one sales order as an .xlsx. */
export async function POST(
  request: NextRequest, context: RouteContext<"/api/sales/orders/[id]/excel">,
) {
  const guard = await requireApiAnyPermission(
    request, ORDER_DOWNLOAD_SLUGS, "You do not have permission to download Sales Orders.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Sales Order not found.", 422);
  try {
    const document = await buildOrderDocumentExport(id, "excel");
    if (!document) return apiError("Sales Order not found.", 404);
    return await tableExportResponse({ format: "excel", ...document });
  } catch (error) {
    console.error("Unable to build the sales order spreadsheet", error);
    return apiError("Server error occurred.", 500);
  }
}
