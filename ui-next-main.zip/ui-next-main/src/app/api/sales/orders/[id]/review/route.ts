import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { isSameOrigin } from "@/lib/http/same-origin";
import { reviewExternalOrder } from "@/modules/sales/order-review";

export const runtime = "nodejs";

/**
 * `reviewIncomingExternalOrder`: approve or reject an order that arrived from
 * the website, by email or over messaging.
 *
 * Until this existed, such an order could be edited and dispatched with nobody
 * having looked at it.
 */
export async function POST(
  request: NextRequest,
  context: { params: Promise<{ id: string }> },
) {
  const guard = await requireApiPermission(
    request, "store_order_received_edit", "You do not have permission to review orders.");
  if (!guard.ok) return guard.response;
  if (!isSameOrigin(request)) {
    return apiError("Your session token is invalid. Please refresh the page and try again.", 419);
  }
  const orderId = readId((await context.params).id);
  try {
    const data = await request.formData();
    const result = await reviewExternalOrder({
      orderId,
      decision: String(data.get("decision") ?? ""),
      reason: String(data.get("reason") ?? ""),
      reviewedBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 422);
    return apiSuccess({}, result.message);
  } catch (error) {
    console.error("Unable to review the order", error);
    return apiError("Unable to review this order.", 500);
  }
}
