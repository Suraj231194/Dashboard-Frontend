import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import {
  createProductionPlansForOrder, processOrderItemForDispatch, sendOrderToProcurement, sendOrdersToDispatch,
} from "@/modules/sales/order-routing";

export const runtime = "nodejs";

/**
 * The four fulfilment routes the Order Detail screen offers: send the whole
 * order to Dispatch, prepare one reserved line, or route the shortfall to
 * Procurement or Production. Dispatch, line preparation and procurement have
 * no permission check of their own today; routing to Production does, because
 * `bmrBprProductionWritePermissions()` gates `sendOrderToProduction` on the
 * order-edit slug before any handler runs.
 */
export async function POST(request: NextRequest, context: RouteContext<"/api/sales/orders/[id]/fulfillment">) {
  const guard = await requireApiPageAccess(request, "order-detail");
  if (!guard.ok) return guard.response;
  const orderId = readId((await context.params).id);
  const data = await request.formData();
  const action = String(data.get("action") ?? "");
  const notes = String(data.get("fulfillment_notes") ?? "").trim();
  const orderItemId = Number.parseInt(String(data.get("order_item_id") ?? "0"), 10) || 0;

  try {
    if (action === "dispatch") {
      const result = await sendOrdersToDispatch([orderId], notes, guard.user.user_id);
      if (result.status !== "success") return apiError(result.message, 400);
      return apiSuccess(result, result.message);
    }
    if (action === "item-dispatch") {
      const result = await processOrderItemForDispatch(orderId, orderItemId, guard.user.user_id);
      return apiSuccess(result, result.message);
    }
    if (action === "procurement") {
      const result = await sendOrderToProcurement(orderId, orderItemId, notes, guard.user.user_id);
      return apiSuccess(result, result.message);
    }
    if (action === "production") {
      const permitted = await requireApiPermission(
        request, "store_order_received_edit", "You do not have permission to perform this action.",
      );
      if (!permitted.ok) return permitted.response;
      const result = await createProductionPlansForOrder(orderId, guard.user.user_id, notes, orderItemId);
      return apiSuccess(result, result.message);
    }
    return apiError("Unknown fulfillment action.", 422);
  } catch (error) {
    console.error(`Fulfillment routing failed for order ${orderId}`, error);
    return apiError(error instanceof Error ? error.message : "Unable to process this item.", 400);
  }
}
