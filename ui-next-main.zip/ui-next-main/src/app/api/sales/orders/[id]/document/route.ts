import { NextRequest } from "next/server";
import { documentError, documentId, documentPage, requireDocumentPermission } from "@/lib/documents/document-page";
import { ORDER_DOWNLOAD_SLUGS } from "@/modules/sales/orders";
import { buildSalesOrderDocument, salesOrderFileName } from "@/modules/finance/sales-order-document";
import { financeBuildDocumentBody, FINANCE_DOCUMENT_STYLES } from "@/modules/finance/finance-document-render";

export const runtime = "nodejs";

/**
 * The printable Sales Order (`exportajax.php?downloadOrderPdf=<id>`).
 *
 * It is the Finance document template with `document_type = 'SALES_ORDER'`,
 * which is why it renders through the same builder as the invoice and the
 * delivery challan. The current export streams it through Dompdf; here it is
 * the A4 page the browser prints, as every other document in this application
 * is served. `?download=1` opens the print dialog.
 *
 * Either download slug admits, exactly as `requireSalesOrderDownloadAccess()`
 * does and as the existing `/pdf` route already reads it.
 */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/sales/orders/[id]/document">,
) {
  const guard = await requireDocumentPermission(ORDER_DOWNLOAD_SLUGS);
  if (!guard.ok) return guard.response;

  const id = documentId((await context.params).id);
  if (id === 0) return documentError("A valid Sales Order ID is required.", 422);

  try {
    const order = await buildSalesOrderDocument(id);
    if (!order) return documentError("Sales Order not found.", 404);
    return documentPage({
      title: salesOrderFileName(order.document_number),
      bodyHtml: financeBuildDocumentBody(order),
      pageStyles: FINANCE_DOCUMENT_STYLES,
      orientation: "landscape",
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    console.error(`Unable to render the Sales Order document ${id}`, error);
    return documentError("The Sales Order could not be rendered.", 500);
  }
}
