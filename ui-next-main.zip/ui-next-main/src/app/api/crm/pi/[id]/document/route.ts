import { NextRequest } from "next/server";
import { documentError, documentId, documentPage, requireDocumentPermission } from "@/lib/documents/document-page";
import { PI_VIEW_SLUGS } from "@/modules/crm/pi-constants";
import { readPiView } from "@/modules/crm/pi";
import {
  PROFORMA_INVOICE_STYLES, proformaInvoiceFileName, renderProformaInvoiceDocument,
} from "@/modules/crm/pi-render";

export const runtime = "nodejs";

/**
 * The Proforma Invoice document (`admin/pages/pi_template.php`), opened from
 * the PI Requests screen. `?download=1` opens the print dialog, where the
 * current template streams a PDF (`triggerDownload=1`).
 *
 * The current template checks nothing at all: `pi_template.php` requires the
 * database and the helpers and goes straight to the invoice, so any signed-out
 * visitor with an id can read a customer's prices. This endpoint gates it on
 * the same view permission the PI screen itself uses.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/crm/pi/[id]/document">) {
  const guard = await requireDocumentPermission(PI_VIEW_SLUGS);
  if (!guard.ok) return guard.response;

  const id = documentId((await context.params).id);
  if (id === 0) return documentError("A valid proforma invoice ID is required.", 422);

  try {
    const invoice = await readPiView(id);
    if (!invoice) return documentError("Proforma invoice not found.", 404);
    return documentPage({
      title: proformaInvoiceFileName(invoice),
      bodyHtml: renderProformaInvoiceDocument(invoice),
      pageStyles: PROFORMA_INVOICE_STYLES,
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    console.error(`Unable to render the proforma invoice ${id}`, error);
    return documentError("The Proforma Invoice document could not be rendered.", 500);
  }
}
