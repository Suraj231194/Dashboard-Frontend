import { NextRequest } from "next/server";
import { requireApiAnyPermission, requireApiPageAccess } from "@/lib/http/guard";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readListQuery } from "@/lib/pagination";
import { can } from "@/modules/access/permissions";
import { PI_DENIED, PI_PAGE_SLUGS, PI_PERMISSIONS, PI_SORT_COLUMNS } from "@/modules/crm/pi-constants";
import { PiError, createProformaInvoice, listPiRequests, type PiFormInput, type PiItemInput } from "@/modules/crm/pi";

export const runtime = "nodejs";

/** `loadProformaInvoiceTable` — the ERP/website union, ten a page, newest first. */
export async function GET(request: NextRequest) {
  const guard = await requireApiAnyPermission(request, PI_PAGE_SLUGS, PI_DENIED);
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, PI_SORT_COLUMNS, "recent", "DESC");
    return apiSuccess(await listPiRequests(query));
  } catch (error) {
    console.error("Unable to list the proforma invoices", error);
    return apiError("Error loading data.", 500);
  }
}

/**
 * `addProformaInvoiceMobile`. An unlinked PI carries no permission check of its
 * own in the current handler, so the screen's own access guards it; a linked
 * one additionally needs `sales_billing_pi_generate_add`, which the service
 * enforces with the flag resolved here.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "pi-requests");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const canCreateLinked = await can(guard.user, PI_PERMISSIONS.add);
    const result = await createProformaInvoice(readPiForm(data), guard.user.user_id, canCreateLinked);
    return apiSuccess({ id: result.id, pi_auto_batch: result.pi_auto_batch }, result.message);
  } catch (error) {
    if (error instanceof PiError) return apiError(error.message, error.status);
    console.error("Unable to create a proforma invoice", error);
    return apiError("Error in adding request.", 500);
  }
}

/** The posted form, in the shape the service takes. */
export function readPiForm(data: FormData): PiFormInput {
  const value = (name: string) => String(data.get(name) ?? "").trim();
  const list = (name: string) => data.getAll(name).map((entry) => String(entry ?? "").trim());
  const id = (name: string) => {
    const parsed = Number.parseInt(value(name), 10);
    return Number.isInteger(parsed) && parsed > 0 ? parsed : null;
  };

  const itemIds = list("prodItemId[]");
  const catNos = list("catNo[]");
  const names = list("productName[]");
  const packs = list("packSize[]");
  const quantities = list("quantity[]");
  const rates = list("rate[]");
  const values = list("value[]");
  const gstPercents = list("gstPercent[]");
  const gsts = list("gst[]");
  const totals = list("totalPrice[]");

  const items: PiItemInput[] = names.map((productName, index) => ({
    itemId: itemIds[index] ?? "",
    catNo: catNos[index] ?? "",
    productName,
    packSize: packs[index] ?? "",
    quantity: quantities[index] ?? "",
    rate: rates[index] ?? "",
    value: values[index] ?? "",
    gstPercent: gstPercents[index] ?? "",
    gst: gsts[index] ?? "",
    totalPrice: totals[index] ?? "",
  }));

  return {
    piId: id("piId") ?? undefined,
    leadId: id("lead_id"),
    quoteRequestId: id("quote_request_id"),
    companyName: value("companyName"),
    companyAddress: value("companyAddress"),
    gstNo: value("gstNo"),
    isShippingSame: value("isShippingSame") === "1",
    shipCompanyName: value("companyShippinigName"),
    shipCompanyAddress: value("companyShippingAddress"),
    shipGstNo: value("gstShippingNo"),
    attendPerson: value("attendPerson"),
    attendPersonContact: value("attendPersonContact"),
    enquiryMedium: value("enquiryMedium"),
    enquiryDate: value("enquiryDate"),
    totalQty: value("totalQty"),
    totalGstAmount: value("totalGstAmount"),
    totalPriceAmount: value("totalPriceAmount"),
    supplyPeriod: value("supplyPeriod"),
    freightAmount: value("freightAmount"),
    freightAmountTaxPercent: value("freightAmountTaxPercent"),
    freightAmountTax: value("freightAmountTax"),
    totalFreight: value("totalFreight"),
    freightNotice: value("freightNotice"),
    items,
  };
}
