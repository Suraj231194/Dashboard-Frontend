import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { listHolidays } from "@/modules/settings/hr-settings";

export const runtime = "nodejs";

/**
 * The legacy holiday list is **read-only**.
 *
 * Annual Calendar & Working Days is the master source after cutover, and the
 * current application answers every write here with 409 and this message. The
 * port allowed create, update and delete, so a holiday edited here would have
 * been silently superseded by the calendar — or worse, disagreed with it.
 *
 * Reading is still allowed, behind `hrms_calendar_view` as the current handler
 * requires, rather than plain access to the settings page.
 */
const LEGACY_HOLIDAY_LOCK =
  "Holidays are now maintained in Annual Calendar & Working Days. This legacy list is read-only.";


export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "hrms_calendar_view", "Permission denied.");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, ["name"], "name", "ASC");
    return apiSuccess(await listHolidays(query));
  } catch (error) {
    console.error("Unable to list holidays", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST() {
  return apiError(LEGACY_HOLIDAY_LOCK, 409);
}
