import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { findHoliday } from "@/modules/settings/hr-settings";

export const runtime = "nodejs";

/**
 * The legacy holiday list is **read-only**.
 *
 * Annual Calendar & Working Days is the master source after cutover, and the
 * current application answers every write here with 409 and this message. The
 * port allowed create, update and delete, so a holiday edited here would have
 * been silently superseded by the calendar — or worse, disagreed with it.
 *
 * Reading is still allowed, behind `hrms_calendar_view` as the current handler
 * requires, rather than plain access to the settings page.
 */
const LEGACY_HOLIDAY_LOCK =
  "Holidays are now maintained in Annual Calendar & Working Days. This legacy list is read-only.";


export async function GET(request: NextRequest, context: RouteContext<"/api/settings/holidays/[id]">) {
  const guard = await requireApiPermission(
    request, "hrms_calendar_view", "Permission denied.");
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  try {
    const record = await findHoliday(id);
    if (!record) return apiError("No data found...!!", 404);
    return apiSuccess({ record });
  } catch (error) {
    console.error("Unable to read the record", error);
    return apiError("Server error occurred.", 500);
  }
}

export async function PUT() {
  return apiError(LEGACY_HOLIDAY_LOCK, 409);
}

export async function DELETE() {
  return apiError(LEGACY_HOLIDAY_LOCK, 409);
}
