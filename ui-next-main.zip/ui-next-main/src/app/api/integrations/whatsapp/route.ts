import { NextResponse } from "next/server";
import { hasValidWebhookSignature, secureEquals, verifyToken } from "@/modules/intake/whatsapp/config";
import { whatsappLog } from "@/modules/intake/whatsapp/log";
import { processWebhookPayload } from "@/modules/intake/whatsapp/webhook";

export const runtime = "nodejs";
/** A webhook delivery must never be answered from a cache. */
export const dynamic = "force-dynamic";

/**
 * The Meta Cloud API webhook (`admin/api/controllers/WhatsAppApiController.php`).
 *
 * This route is deliberately outside the bearer-token interface: Meta
 * authenticates itself with `hub.verify_token` on the subscription handshake
 * and with `X-Hub-Signature-256` on every delivery, which is why the current
 * dispatcher exempts `whatsapp/webhook` from `verifyApiToken()`.
 */

/** The subscription handshake. */
export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  // Meta sends dotted names; the current controller also accepts underscores.
  const mode = params.get("hub_mode") ?? params.get("hub.mode") ?? "";
  const token = params.get("hub_verify_token") ?? params.get("hub.verify_token") ?? "";
  const challenge = params.get("hub_challenge") ?? params.get("hub.challenge") ?? "";
  const configured = verifyToken();

  whatsappLog("VERIFY_CHECK", `Meta requested webhook verification (hub_mode=${mode})`);

  // No configured token means no verification: there is no default to fall
  // back to, because a shipped default would let anybody subscribe.
  if (configured !== "" && mode === "subscribe" && secureEquals(configured, token)) {
    whatsappLog("VERIFY_SUCCESS", "Webhook token matched successfully");
    return new Response(challenge, { status: 200 });
  }

  whatsappLog("VERIFY_FAILED", "Token mismatch on webhook verification");
  return new Response("Forbidden: Invalid verification token", { status: 403 });
}

/** A message delivery. */
export async function POST(request: Request) {
  // The signature covers the exact bytes sent, so the body is read as text and
  // parsed afterwards rather than through request.json().
  const rawInput = await request.text();
  const signature = request.headers.get("x-hub-signature-256") ?? "";

  if (!hasValidWebhookSignature(rawInput, signature)) {
    whatsappLog("SIGNATURE_INVALID", "Rejected webhook with an invalid Meta signature.");
    return NextResponse.json(
      { status: false, message: "Invalid webhook signature" },
      { status: 403 },
    );
  }

  let payload: unknown = null;
  try {
    payload = JSON.parse(rawInput);
  } catch {
    payload = null;
  }

  const entry = payload !== null && typeof payload === "object"
    ? (payload as Record<string, unknown>).entry
    : undefined;

  if (entry === undefined) {
    whatsappLog("PAYLOAD_INVALID", "Payload is empty or missing entry field");
    // Meta retries anything that is not a prompt 200, so a payload this route
    // cannot use is still acknowledged.
    return NextResponse.json({ status: true, message: "Event received" });
  }

  whatsappLog("PAYLOAD_RECEIVED", "Received POST payload from Meta");

  try {
    await processWebhookPayload(payload, rawInput);
  } catch (error) {
    // Still acknowledge: a failure here is recorded, not retried at us forever.
    console.error("WhatsApp webhook processing failed", error);
  }

  return NextResponse.json({ status: true, message: "Processed" });
}
