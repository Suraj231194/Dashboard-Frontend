import { NextRequest } from "next/server";
import { documentError, documentId, documentPage, requireDocumentPermission } from "@/lib/documents/document-page";
import {
  payRunDocumentFileName, payRunDocumentStyles, readPayRunDocument, renderPayRunDocument,
  type PayRunDocumentKind,
} from "@/modules/payroll/pay-run-render";

export const runtime = "nodejs";

/**
 * The payroll documents (`admin/payroll/payroll_pdf.php`): `?view=full` gives
 * the A3 Payroll Sheet, anything else the A4 Bank Disbursement.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/payroll/pay-runs/[id]/document">) {
  const guard = await requireDocumentPermission(["payroll_pay_runs_view"]);
  if (!guard.ok) return guard.response;

  const id = documentId((await context.params).id);
  if (id === 0) return documentError("A valid pay run is required.", 422);
  const kind: PayRunDocumentKind = request.nextUrl.searchParams.get("view") === "full" ? "sheet" : "bank";

  try {
    const document = await readPayRunDocument(guard.user, id);
    if (!document) return documentError("The requested pay run was not found.", 404);
    return documentPage({
      title: payRunDocumentFileName(document, kind),
      bodyHtml: renderPayRunDocument(document, kind),
      pageStyles: payRunDocumentStyles(kind),
      orientation: "landscape",
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    console.error(`Unable to render the pay run ${id}`, error);
    return documentError("The payroll document could not be rendered.", 500);
  }
}
