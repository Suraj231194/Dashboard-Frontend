import type { NextRequest } from "next/server";
import { apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { getAnalyticsData } from "@/modules/analytics/analytics";
import { analyticsVisibility } from "@/modules/analytics/visibility";

/**
 * The refresh behind the dashboard's Refresh button. It is a read, so it is
 * guarded by the same slug as the screen and resolves the per-section gates
 * again rather than trusting anything the browser sends.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "analytics");
  if (!guard.ok) return guard.response;
  const visibility = await analyticsVisibility(guard.user);
  const data = await getAnalyticsData(visibility);
  return apiSuccess({ data });
}
