import { listProducts } from "@/modules/intake/products";
import { runIntakeRoute } from "@/modules/intake/route-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** `product/getList` (`ProductController::getProducts`), on GET and on POST. */
export async function GET(request: Request) {
  return runIntakeRoute(request, (params) => listProducts(params));
}

export async function POST(request: Request) {
  return runIntakeRoute(request, (params) => listProducts(params));
}
