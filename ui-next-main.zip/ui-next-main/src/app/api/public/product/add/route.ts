import { addProduct } from "@/modules/intake/products";
import { runIntakeRoute } from "@/modules/intake/route-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** `product/add` (`ProductController::addProduct`). */
export async function POST(request: Request) {
  return runIntakeRoute(request, (params) => addProduct(params));
}
