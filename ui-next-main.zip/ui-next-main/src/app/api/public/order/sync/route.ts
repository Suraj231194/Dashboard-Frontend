import { createExternalOrder } from "@/modules/intake/external-orders";
import { runIntakeRoute } from "@/modules/intake/route-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * `order/sync` (`OrderApiController::syncOrder`): the source type comes from
 * the payload, no external reference is demanded, and nothing is written to
 * `sync_logs` because only the website channel is logged there.
 */
export async function POST(request: Request) {
  return runIntakeRoute(request, (params) => createExternalOrder(params, null, false));
}
