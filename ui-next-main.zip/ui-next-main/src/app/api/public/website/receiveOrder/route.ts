import { createExternalOrder } from "@/modules/intake/external-orders";
import { runIntakeRoute } from "@/modules/intake/route-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** `website/receiveOrder`: the same handler as `website/order`, under its second name. */
export async function POST(request: Request) {
  return runIntakeRoute(request, (params) => createExternalOrder(params, 2, true));
}
