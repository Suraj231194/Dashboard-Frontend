import { createExternalOrder } from "@/modules/intake/external-orders";
import { runIntakeRoute } from "@/modules/intake/route-guard";

export const runtime = "nodejs";
/** An intake call must never be answered from a cache. */
export const dynamic = "force-dynamic";

/**
 * `website/order` (`OrderApiController::receiveWebsiteOrder`): source type 2,
 * an external reference is required, and the call is recorded in `sync_logs`.
 */
export async function POST(request: Request) {
  return runIntakeRoute(request, (params) => createExternalOrder(params, 2, true));
}
