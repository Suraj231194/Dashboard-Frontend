import { intakeResponse, readRequestData } from "@/modules/intake/api-response";
import { verifyApiToken } from "@/modules/intake/api-token";
import { LeadIntakeError, captureWebsiteLead } from "@/modules/intake/website-leads";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * `crm/captureLead` (`CrmLeadApiController::captureWebsiteLead`). This one
 * carries its own status codes - 201 on a new lead, 200 on a repeat, 422 on a
 * rejected payload, 405 on anything but POST - so it does not go through the
 * shared runner.
 */
export async function POST(request: Request) {
  const token = verifyApiToken(request.headers);
  if (!token.ok) return intakeResponse(false, token.message, [], token.status);

  const payload = await readRequestData(request);
  if (payload === null) {
    return intakeResponse(false, "The request body must be a JSON object or form payload.", [], 422);
  }

  try {
    const result = await captureWebsiteLead(payload);
    return intakeResponse(
      true,
      result.created ? "Lead captured successfully." : "Lead already captured.",
      result,
      result.created ? 201 : 200,
    );
  } catch (error) {
    if (error instanceof LeadIntakeError) {
      return intakeResponse(false, error.message, [], 422);
    }
    console.error("CRM lead intake failed", error);
    return intakeResponse(false, "Unable to capture the lead.", [], 500);
  }
}

/** The current controller answers 405 for any other method. */
export async function GET() {
  return intakeResponse(false, "Method not allowed.", [], 405);
}
