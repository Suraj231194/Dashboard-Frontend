import { updateStock } from "@/modules/intake/inventory";
import { runIntakeRoute } from "@/modules/intake/route-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** `inventory/updateStock` (`InventoryApiController::updateStock`). */
export async function POST(request: Request) {
  return runIntakeRoute(request, () => updateStock());
}
