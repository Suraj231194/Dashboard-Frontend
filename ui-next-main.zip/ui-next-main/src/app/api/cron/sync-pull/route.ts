import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { authoriseCronRequest } from "@/lib/sync/cron-secret";
import { PULLABLE_ENTITIES } from "@/modules/sync/sync-settings";
import { pullAndSyncEntity } from "@/modules/sync/website-pull";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** One run at a time in this process, standing in for `CronLock::acquire('sync-pull')`. */
let running = false;

/**
 * `admin/sync/cron_sync_pull.php`: Pull + ACK for every pull entity, up to ten
 * batches each while a batch comes back full (100 acknowledged records).
 */
export async function POST(request: NextRequest) {
  const authorised = authoriseCronRequest(request.headers);
  if (!authorised.ok) return apiError(authorised.message, authorised.status);
  if (running) return apiSuccess({ skipped: true }, "A pull cycle is already running; this run was skipped.");
  running = true;
  try {
    const results: { entity: string; batch: number; success: boolean; message: string }[] = [];
    for (const entity of PULLABLE_ENTITIES) {
      let batchCount = 100;
      for (let batch = 1; batch <= 10 && batchCount === 100; batch += 1) {
        const result = await pullAndSyncEntity(entity);
        batchCount = result.success ? Number(result.synced_count ?? 0) : 0;
        results.push({ entity, batch, success: result.success, message: result.message });
      }
    }
    return apiSuccess({ results }, "Pull + ACK sync cycle complete.");
  } catch (error) {
    console.error("The sync pull cycle failed", error);
    return apiError("The sync pull cycle failed.", 500);
  } finally {
    running = false;
  }
}
