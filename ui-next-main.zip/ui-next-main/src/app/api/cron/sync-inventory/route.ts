import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { authoriseCronRequest } from "@/lib/sync/cron-secret";
import { runScheduledInventoryPushes } from "@/modules/sync/website-push";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** One run at a time in this process, standing in for `CronLock::acquire('sync-inventory')`. */
let running = false;

/** `admin/sync/cron_sync_inventory.php`: up to 100 pending products, every minute. */
export async function POST(request: NextRequest) {
  const authorised = authoriseCronRequest(request.headers);
  if (!authorised.ok) return apiError(authorised.message, authorised.status);
  if (running) return apiSuccess({ skipped: true }, "An inventory cycle is already running; this run was skipped.");
  running = true;
  try {
    const result = await runScheduledInventoryPushes();
    return apiSuccess({ processed: result.processed, failed: result.failed }, result.message);
  } catch (error) {
    console.error("The inventory sync cycle failed", error);
    return apiError("The inventory sync cycle failed.", 500);
  } finally {
    running = false;
  }
}
