import { NextRequest } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { apiError, apiSuccess } from "@/lib/http/json";
import { runDueReminders } from "@/modules/notifications/reminders";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * `cronjob.php?calendarReminders` (`admin/cronjob.php:93-103`): one pass over
 * the calendar, finance and tender reminder generators.
 *
 * The current entry point is open to anyone who can reach the URL. Here it is
 * behind a shared secret, read from `CRON_REMINDERS_SECRET` on the server only
 * (never a NEXT_PUBLIC_ name, which would ship the secret to the browser), and
 * sent either as `Authorization: Bearer <secret>` or an `X-Cron-Secret` header.
 * With no secret configured the route refuses rather than running unguarded.
 */
function secretMatches(request: NextRequest): boolean {
  const expected = process.env.CRON_REMINDERS_SECRET ?? "";
  if (expected.length === 0) return false;
  const header = request.headers.get("x-cron-secret")
    ?? request.headers.get("authorization")?.replace(/^Bearer\s+/i, "")
    ?? "";
  const given = Buffer.from(header);
  const wanted = Buffer.from(expected);
  return given.length === wanted.length && timingSafeEqual(given, wanted);
}

export async function POST(request: NextRequest) {
  if (!secretMatches(request)) return apiError("Not authorised.", 401);
  try {
    const counts = await runDueReminders();
    return apiSuccess({ notifications_created: counts.total, created: counts }, "Reminders generated.");
  } catch (error) {
    console.error("Unable to run the reminder generators", error);
    return apiError("Something went wrong.", 500);
  }
}
