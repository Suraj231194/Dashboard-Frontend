import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { authoriseCronRequest } from "@/lib/sync/cron-secret";
import { runSyncRetryCycle } from "@/modules/sync/sync-retry-worker";

export const runtime = "nodejs";
/** A scheduled run must never be answered from a cache. */
export const dynamic = "force-dynamic";

/**
 * The automatic retry cycle (`admin/sync/cron_sync_retry.php`), behind a shared
 * secret rather than a session: a scheduler has no user to sign in as.
 *
 * Run it every five minutes, which is the interval the current worker is
 * documented with.
 */
export async function POST(request: NextRequest) {
  const authorised = authoriseCronRequest(request.headers);
  if (!authorised.ok) return apiError(authorised.message, authorised.status);
  try {
    const result = await runSyncRetryCycle();
    return apiSuccess({
      considered: result.considered,
      retried: result.retried,
      succeeded: result.succeeded,
      failed: result.failed,
      skipped: result.skipped,
      results: result.results,
    }, result.message);
  } catch (error) {
    console.error("The sync retry cycle failed", error);
    return apiError("The sync retry cycle failed.", 500);
  }
}
