import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { authoriseEmailCronRequest } from "@/modules/intake/email/cron-secret";
import { canSendMail } from "@/modules/intake/email/config";
import { pollAndProcess, testConnection } from "@/modules/intake/email/poller";

export const runtime = "nodejs";
/** A scheduled run must never be answered from a cache. */
export const dynamic = "force-dynamic";

/**
 * `admin/cron_email_orders.php`, behind the shared secret the other scheduled
 * routes use. Its two CLI flags become query parameters:
 *
 *   `?test=1`   connectivity check only, nothing is read or written
 *   `?dryrun=1` parse and report, but create no drafts and send no replies
 *
 * Run it every two minutes, which is the interval the current crontab entry
 * documents.
 */
export async function POST(request: NextRequest) {
  const authorised = authoriseEmailCronRequest(request.headers);
  if (!authorised.ok) return apiError(authorised.message, authorised.status);

  const params = request.nextUrl.searchParams;

  if (params.has("test")) {
    const result = await testConnection();
    return apiSuccess({ connection: result }, result.message);
  }

  try {
    const result = await pollAndProcess(params.has("dryrun"));
    const message = `POLL COMPLETE: ${result.processed} processed, ${result.success} success, `
      + `${result.failed} failed${result.dryRun ? " [DRY-RUN]" : ""}`;
    return apiSuccess({
      processed: result.processed,
      success: result.success,
      failed: result.failed,
      errors: result.errors,
      dry_run: result.dryRun,
      // Says plainly whether a reply could have left the process, so a run
      // with no mail transport is not mistaken for a run that answered nobody.
      replies_deliverable: canSendMail(),
    }, message);
  } catch (error) {
    console.error("The email order run failed", error);
    return apiError("The email order run failed.", 500);
  }
}
