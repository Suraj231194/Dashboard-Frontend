import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { PlanError, createProductionPlan, listProductionPlans } from "@/modules/production/production-plans";
import { PLAN_SORT_COLUMNS, PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `loadProductionPlan`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.planView, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, PLAN_SORT_COLUMNS, "recent", "DESC");
    return apiSuccess(await listProductionPlans({
      page: query.page,
      perPage: query.perPage,
      search: query.search,
      sortColumn: query.sortColumn,
      sortDirection: query.sortDirection,
    }));
  } catch (error) {
    console.error("Unable to load the production plans", error);
    return apiError("Error loading data.", 500);
  }
}

/** `addProductionPlan`: the multi-product batch campaign. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, PRODUCTION_PERMISSIONS.planAdd, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const names = data.getAll("productName[]").map((value) => String(value));
    const sizes = data.getAll("prodPlanBatchSize[]").map((value) => String(value));
    const units = data.getAll("prodPlanBatchSizeUnit[]").map((value) => String(value));
    const result = await createProductionPlan({
      dateEntry: String(data.get("dateEntry") ?? "").trim(),
      timelineStatus: Number.parseInt(String(data.get("timelineStatus") ?? "0"), 10) || 0,
      remark: String(data.get("prodPlanRemark") ?? "").trim(),
      products: names.map((productName, index) => ({
        productName,
        batchSize: sizes[index] ?? "",
        batchUnit: units[index] ?? "",
      })),
      createdBy: guard.user.user_id,
    });
    if (result.status === "bom_incomplete") {
      // The screen shows its own dialog for this, so it answers 200 with a
      // status of its own rather than an error envelope.
      return apiSuccess(
        { status_code: "bom_incomplete", incomplete_products: result.incomplete_products },
        result.message,
      );
    }
    return apiSuccess({ status_code: "created" }, result.message);
  } catch (error) {
    if (error instanceof PlanError) return apiError(error.message, 422);
    console.error("Unable to create the production plan", error);
    return apiError("Server error occurred.", 500);
  }
}
