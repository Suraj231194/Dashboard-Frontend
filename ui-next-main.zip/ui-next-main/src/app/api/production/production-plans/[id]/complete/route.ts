import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, requireApiPermission } from "@/lib/http/guard";
import { PlanError, completeProductionPlan } from "@/modules/production/production-plans";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** `completeProductionPlan`. */
export async function POST(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPermission(request, PRODUCTION_PERMISSIONS.planEdit, "Permission denied.");
  if (!guard.ok) return guard.response;
  const { id } = await context.params;
  try {
    const result = await completeProductionPlan(readId(id), guard.user.user_id);
    return apiSuccess(
      result.orderUpdate === undefined
        ? { order_routing: result.orderRouting }
        : { order_update: result.orderUpdate, order_routing: result.orderRouting },
      result.message,
    );
  } catch (error) {
    if (error instanceof PlanError) return apiError(error.message, 422);
    console.error("Unable to complete the production plan", error);
    return apiError("Unable to complete the production plan.", 500);
  }
}
