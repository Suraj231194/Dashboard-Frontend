import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { confirmTransferTicket, listTransferQueue } from "@/modules/production/transfer-workflow";

export const runtime = "nodejs";

/**
 * `transfer_queue_list`: released batches waiting for their Transfer Ticket to
 * be confirmed — Step 11 of the production cycle.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "transfer_ticket_menu_list", "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    return apiSuccess({ records: await listTransferQueue() });
  } catch (error) {
    console.error("Unable to load incoming Transfer Tickets", error);
    return apiError("Unable to load incoming Transfer Tickets.", 500);
  }
}

/**
 * `create_transfer_ticket`: confirms the ticket and routes the batch by its
 * origin — straight to stock for a live-inventory batch, or to a pending store
 * receipt for an order batch.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, "transfer_ticket_add", "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const number = (key: string) => Number(data.get(key) ?? 0) || 0;
    const result = await confirmTransferTicket({
      sourceFgCoaId: number("source_fg_coa_id"),
      mfgDate: String(data.get("mfg_date") ?? ""),
      expDate: String(data.get("exp_date") ?? ""),
      sampledBy: String(data.get("sampled_by") ?? ""),
      quantity: number("quantity"),
      userId: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 422);
    return apiSuccess(
      {
        id: result.id, ticket_no: result.ticketNo,
        origin: result.origin, live_stock_id: result.liveStockId,
      },
      result.message,
    );
  } catch (error) {
    console.error("Unable to confirm the Transfer Ticket", error);
    return apiError("Unable to confirm the Transfer Ticket.", 500);
  }
}
