import { NextRequest } from "next/server";
import { documentError, documentId, documentPage, requireDocumentPermission } from "@/lib/documents/document-page";
import {
  readSampleAdviceDocument, renderSampleAdviceDocument, SAMPLE_ADVICE_STYLES,
} from "@/modules/production/sample-advice-render";

export const runtime = "nodejs";

/**
 * The Sampling Advice document (`admin/pages/sample_advice_template.php`).
 * `?download=1` opens the print dialog, where the current template streams
 * a PDF (`triggerDownload=1`).
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/production/sa-generation/[id]/document">) {
  const guard = await requireDocumentPermission(["sa_generation_pdf"]);
  if (!guard.ok) return guard.response;

  const id = documentId((await context.params).id);
  if (id === 0) return documentError("A valid document ID is required.", 422);

  try {
    const advice = await readSampleAdviceDocument(id);
    if (!advice) return documentError("Sample Advice record not found.", 404);
    return documentPage({
      title: advice.fileName || `sample_advice_${id}`,
      bodyHtml: renderSampleAdviceDocument(advice),
      pageStyles: SAMPLE_ADVICE_STYLES,
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    console.error(`Unable to render the sampling advice ${id}`, error);
    return documentError("The Sampling Advice document could not be rendered.", 500);
  }
}
