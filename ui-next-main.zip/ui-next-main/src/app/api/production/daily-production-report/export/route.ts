import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { buildDailyReportExport } from "@/modules/production/daily-report";
import { BSEH_SORT_COLUMNS } from "@/modules/production/production-constants";

export const runtime = "nodejs";

/** The chosen columns of the list as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "daily-production-report-bseh");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const requested = String(data.get("sort_column") ?? "");
    const direction = String(data.get("sort_order") ?? "DESC").toUpperCase() === "ASC" ? "ASC" : "DESC";
    const result = await buildDailyReportExport({
      search: String(data.get("search") ?? "").trim(),
      sortColumn: (BSEH_SORT_COLUMNS as readonly string[]).includes(requested) ? requested : "recent",
      sortDirection: direction,
      page: Number.parseInt(String(data.get("page") ?? "1"), 10) || 1,
      perPage: Number.parseInt(String(data.get("perPage") ?? "10"), 10) || 10,
      columns: data.getAll("listOfColumns[]").map((value) => String(value)),
    });
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "Daily Production Report BSEH", filePrefix: "daily_production_bseh",
      headers: result.columns, rows: result.rows,
    });
  } catch (error) {
    console.error("Unable to export the BSEH daily production reports", error);
    return apiError("Server error occurred.", 500);
  }
}
