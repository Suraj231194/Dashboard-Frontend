import { NextRequest } from "next/server";
import { documentError, documentId, documentPage, requireDocumentPermission } from "@/lib/documents/document-page";
import { COA_PRINT_STYLES, readCoaPrintDocument, renderCoaPrintDocument } from "@/modules/production/coa-rm-pm-render";

export const runtime = "nodejs";

/**
 * The inbound RM/PM Certificate of Analysis (`admin/pages/coa_template_print.php`).
 * `?download=1` opens the print dialog, where the current template streams
 * a PDF (`triggerDownload=1`).
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/production/coa-generation/[id]/document">) {
  const guard = await requireDocumentPermission(["coa_generation_pdf"]);
  if (!guard.ok) return guard.response;

  const id = documentId((await context.params).id);
  if (id === 0) return documentError("A valid document ID is required.", 422);

  try {
    const certificate = await readCoaPrintDocument(id);
    if (!certificate) return documentError("COA record not found.", 404);
    return documentPage({
      title: certificate.fileName || "COA",
      bodyHtml: renderCoaPrintDocument(certificate),
      pageStyles: COA_PRINT_STYLES,
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    console.error(`Unable to render the RM/PM certificate of analysis ${id}`, error);
    return documentError("The Certificate of Analysis could not be rendered.", 500);
  }
}
