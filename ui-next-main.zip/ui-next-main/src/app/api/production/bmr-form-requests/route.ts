import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { BMR_PERMISSIONS } from "@/modules/production/bmr-constants";
import {
  BmrRequestError, deleteBmrRequest, getMappedProductCatalog, listBmrRequests, listBmrTemplateOptions,
  submitBmrRequest,
} from "@/modules/production/bmr-requests";

export const runtime = "nodejs";

/** `request_list`: every request, with the templates and the mapped-product catalogue the editor offers. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request, BMR_PERMISSIONS.requestList, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const [requests, templates, mappedProducts] = await Promise.all([
      listBmrRequests(), listBmrTemplateOptions(), getMappedProductCatalog(),
    ]);
    return apiSuccess({ requests, templates, mapped_products: mappedProducts });
  } catch (error) {
    console.error("Unable to load BMR/BPR requests", error);
    return apiError("Unable to load BMR/BPR requests.", 500);
  }
}

/** `submit_request`: an upcoming request moves to QA/QC issuance; a submitted one is edited. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request, BMR_PERMISSIONS.submitRequest, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const number = (key: string) => Number.parseFloat(String(data.get(key) ?? "0")) || 0;
    const id = (key: string) => {
      const value = Number.parseInt(String(data.get(key) ?? "0"), 10);
      return Number.isInteger(value) && value > 0 ? value : null;
    };
    const result = await submitBmrRequest({
      requestId: id("request_id") ?? 0,
      productId: id("product_id") ?? 0,
      batchSize: number("batch_size"),
      formCount: Math.trunc(number("form_count")),
      bmrTemplateId: id("bmr_template_id"),
      bprTemplateId: id("bpr_template_id"),
      remarks: String(data.get("remarks") ?? "").trim(),
      userId: guard.user.user_id,
    });
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof BmrRequestError) return apiError(error.message, 422);
    console.error("Unable to submit the BMR/BPR request", error);
    return apiError("The BMR/BPR workflow action could not be completed.", 500);
  }
}

/**
 * `delete_request`: an upcoming request is deleted; one further along is
 * archived off the list, with a history row.
 */
export async function DELETE(request: NextRequest) {
  const guard = await requireApiPermission(
    request, BMR_PERMISSIONS.submitRequest, "You do not have permission to perform this action.");
  if (!guard.ok) return guard.response;
  const requestId = Number.parseInt(request.nextUrl.searchParams.get("request_id") ?? "0", 10) || 0;
  try {
    const result = await deleteBmrRequest(requestId, guard.user.user_id);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof BmrRequestError) return apiError(error.message, 422);
    console.error("Unable to delete the BMR/BPR request", error);
    return apiError("The BMR/BPR workflow action could not be completed.", 500);
  }
}
