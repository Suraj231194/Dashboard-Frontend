import { NextRequest } from "next/server";
import { documentError, documentId, documentPage, requireDocumentPermission } from "@/lib/documents/document-page";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";
import {
  DAILY_REPORT_STYLES, dailyProductionFileName, readDailyProductionEntry, renderDailyProductionReports,
} from "@/modules/production/daily-report-render";

export const runtime = "nodejs";

/**
 * One Daily Production Report (`admin/pages/daily_report_template.php`),
 * behind the same `generate_rapid_pdf` permission the template checks.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/production/rapid/[id]/document">) {
  const guard = await requireDocumentPermission([PRODUCTION_PERMISSIONS.rapidPdf]);
  if (!guard.ok) return guard.response;

  const id = documentId((await context.params).id);
  if (id === 0) return documentError("A valid document ID is required.", 422);

  try {
    const entry = await readDailyProductionEntry(id);
    if (!entry) return documentError("Daily production report not found.", 404);
    return documentPage({
      title: dailyProductionFileName(entry),
      bodyHtml: renderDailyProductionReports([entry]),
      pageStyles: DAILY_REPORT_STYLES,
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    console.error(`Unable to render the daily production report ${id}`, error);
    return documentError("The Daily Production Report could not be rendered.", 500);
  }
}
