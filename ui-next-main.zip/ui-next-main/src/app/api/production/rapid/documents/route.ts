import { NextRequest } from "next/server";
import { documentError, documentPage, requireDocumentPermission } from "@/lib/documents/document-page";
import { isSameOrigin } from "@/lib/http/same-origin";
import { PRODUCTION_PERMISSIONS } from "@/modules/production/production-constants";
import {
  bulkDailyProductionFileName, DAILY_REPORT_STYLES, DailyProductionBulkError,
  parseBulkReportIds, readDailyProductionEntries, renderDailyProductionReports,
} from "@/modules/production/daily-report-render";

export const runtime = "nodejs";

/**
 * The bulk Daily Production Report
 * (`admin/pages/daily_report_bulk_template.php`): the rapid screen posts the
 * ticked ids and gets back one document holding every selected report.
 *
 * The template insists on POST and on its own CSRF token; the same-origin
 * check stands in for the token, which this application does not carry.
 */
export async function POST(request: NextRequest) {
  const guard = await requireDocumentPermission([PRODUCTION_PERMISSIONS.rapidPdf]);
  if (!guard.ok) return guard.response;
  if (!isSameOrigin(request)) {
    return documentError("Your session token is invalid or expired. Refresh the page and try again.", 419);
  }

  try {
    const data = await request.formData();
    const ids = parseBulkReportIds(String(data.get("ids") ?? ""));
    const entries = await readDailyProductionEntries(ids);
    return documentPage({
      title: bulkDailyProductionFileName(),
      bodyHtml: renderDailyProductionReports(entries),
      pageStyles: DAILY_REPORT_STYLES,
      print: true,
    });
  } catch (error) {
    if (error instanceof DailyProductionBulkError) return documentError(error.message, error.status);
    console.error("Unable to render the selected daily production reports", error);
    return documentError("The Daily Production Reports could not be rendered.", 500);
  }
}
