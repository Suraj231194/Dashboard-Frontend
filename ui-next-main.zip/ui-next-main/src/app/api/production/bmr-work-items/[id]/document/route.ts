import { NextRequest } from "next/server";
import { documentError, documentPage } from "@/lib/documents/document-page";
import { getSession } from "@/modules/auth/session";
import { roleHasPermission } from "@/modules/access/permissions";
import { loadWorkItemTemplate, type WorkItemForm } from "@/modules/production/bmr-production";
import { safeDocumentName } from "@/modules/production/coa-render";

export const runtime = "nodejs";

/**
 * The BMR/BPR record (`pages/bmr_bpr_record_template.php`): the structured
 * document for a schema-2 template, or the scanned pages with their values
 * for a schema-1 one. `?download=1` opens the print dialog, where the current
 * page streams a PDF.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/production/bmr-work-items/[id]/document">) {
  const user = await getSession();
  if (!user) return documentError("Your session has expired.", 401);
  if (!(await roleHasPermission(user.user_id, user.role_id, "production_bmr_bpr_view"))) {
    return documentError("You do not have permission to view this BMR/BPR record.", 403);
  }

  const raw = (await context.params).id;
  const workItemId = /^[1-9][0-9]*$/.test(raw) ? Number(raw) : 0;
  if (workItemId <= 0) return documentError("A valid BMR/BPR record is required.", 400);

  let form: WorkItemForm;
  try {
    form = await loadWorkItemTemplate(workItemId, { printable: true });
  } catch {
    return documentError("The BMR/BPR record could not be found.", 404);
  }
  if (!form.has_template) return documentError("No approved product template is mapped to this BMR/BPR record.", 422);

  const source = form.source_values;
  const title = safeDocumentName(`${form.form_type || "BMR"}_${source.product_name ?? "Record"}_${source.batch_number ?? workItemId}`, "");
  const print = request.nextUrl.searchParams.get("download") === "1";

  if (form.schema_version >= 2) {
    // Loaded `printable`, so read-only whatever the record's status.
    const bodyHtml = form.rendered_html;
    if (bodyHtml === "") return documentError("The common BMR/BPR template profile is unavailable for this product.", 422);
    return documentPage({ title: title || "BMR_BPR_Record", bodyHtml, print });
  }

  return documentPage({ title: title || "BMR_BPR_Record", bodyHtml: scannedPages(form), print, pageStyles: SCANNED_STYLES });
}

const escapeHtml = (value: string): string =>
  value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");

/** `bmrBprTemplateFieldStyle`: the box a value is printed into, in page percentages. */
function fieldStyle(field: { x: number; y: number; w: number; h: number; erase_background?: boolean }): string {
  const x = Math.max(0, Math.min(100, Number(field.x) || 0));
  const y = Math.max(0, Math.min(100, Number(field.y) || 0));
  const w = Math.max(0.1, Math.min(100 - x, Number(field.w ?? 1) || 1));
  const h = Math.max(0.1, Math.min(100 - y, Number(field.h ?? 1) || 1));
  const fontSize = Math.max(7.0, Math.min(13.0, h * 5.2));
  const background = field.erase_background ? "#ffffff" : "transparent";
  return `left:${x.toFixed(5)}%;top:${y.toFixed(5)}%;width:${w.toFixed(5)}%;height:${h.toFixed(5)}%;font-size:${fontSize.toFixed(2)}px;background:${background};`;
}

/** The schema-1 record: each scanned page with its source and saved values laid over it. */
function scannedPages(form: WorkItemForm): string {
  const saved = typeof form.form_payload.fields === "object" && form.form_payload.fields !== null
    ? form.form_payload.fields as Record<string, unknown> : {};
  const custom = Array.isArray(form.form_payload.custom_fields)
    ? form.form_payload.custom_fields as Record<string, unknown>[] : [];
  let html = '<main id="bmrBprDownloadDocument">';
  for (const page of form.pages) {
    html += `<section class="bmr-bpr-pdf-page" data-page="${page.page}">`
      + `<img src="${escapeHtml(page.image_url)}" alt="${escapeHtml(`${form.form_type || "BMR"} page ${page.page}`)}">`;
    for (const field of page.fields) {
      const sourceKey = field.source.trim();
      const value = sourceKey !== "" ? String(form.source_values[sourceKey] ?? "") : String(saved[field.id] ?? "");
      if (value === "") continue;
      html += `<span class="bmr-bpr-pdf-value${field.multiline ? " multiline" : ""}" style="${escapeHtml(fieldStyle(field))}">`
        + `${escapeHtml(value)}</span>`;
    }
    for (const field of custom.filter((entry) => Number(entry.page ?? 0) === page.page)) {
      const box = { x: Number(field.x), y: Number(field.y), w: Number(field.w), h: Number(field.h) };
      html += `<span class="bmr-bpr-pdf-value multiline" style="${escapeHtml(fieldStyle(box))}">`
        + `${escapeHtml(String(field.value ?? ""))}</span>`;
    }
    html += "</section>";
  }
  // `fitBmrBprPdfValue`: each value shrinks to fit its box once the page loads.
  return `${html}</main><script>${FIT_SCRIPT}</script>`;
}

const FIT_SCRIPT = "window.addEventListener('load',function(){document.querySelectorAll('.bmr-bpr-pdf-value').forEach(function(e){"
  + "var m=Number(e.dataset.maximumFontSize)||parseFloat(getComputedStyle(e).fontSize)||13,s=m;e.dataset.maximumFontSize=String(m);e.style.fontSize=s+'px';"
  + "while(s>4&&(e.scrollWidth>e.clientWidth+1||e.scrollHeight>e.clientHeight+1)){s=Math.max(4,s-0.25);e.style.fontSize=s+'px';}});});";

const SCANNED_STYLES = "*{box-sizing:border-box}html,body{font-family:Arial,Helvetica,sans-serif}"
  + "#bmrBprDownloadDocument{width:794px;margin:0 auto}"
  + ".bmr-bpr-pdf-page{position:relative;width:794px;height:1123px;overflow:hidden;background:#ffffff;page-break-after:always}"
  + ".bmr-bpr-pdf-page:last-child{page-break-after:auto}"
  + ".bmr-bpr-pdf-page>img{position:absolute;inset:0;display:block;width:100%;height:100%}"
  + ".bmr-bpr-pdf-value{position:absolute;z-index:2;display:flex;align-items:center;overflow:hidden;padding:1px 3px;color:#000000;"
  + "font-family:Arial,Helvetica,sans-serif;font-weight:400;line-height:1.08;white-space:pre-wrap;overflow-wrap:anywhere}"
  + ".bmr-bpr-pdf-value.multiline{align-items:flex-start;padding-top:2px}"
  + "@media screen{.bmr-bpr-pdf-page{margin-bottom:20px;box-shadow:0 8px 28px rgba(15,23,42,0.18)}}";
