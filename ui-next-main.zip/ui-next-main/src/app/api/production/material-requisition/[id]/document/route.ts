import { NextRequest } from "next/server";
import { documentError, documentId, documentPage, requireDocumentPermission } from "@/lib/documents/document-page";
import {
  MATERIAL_REQUISITION_STYLES, readRequisitionPrintDocument, renderRequisitionPrintDocument,
} from "@/modules/production/material-requisition-render";

export const runtime = "nodejs";

/**
 * The printable Material Requisition (`admin/pages/material_requisition_template.php`),
 * opened from both the production requisition screen and the store material
 * request screen, which is why either permission admits.
 * `?download=1` opens the print dialog, where the current template streams a PDF.
 */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/production/material-requisition/[id]/document">,
) {
  const guard = await requireDocumentPermission([
    "production_material_requisition_view",
    "store_material_request_view",
  ]);
  if (!guard.ok) return guard.response;

  const id = documentId((await context.params).id);
  if (id === 0) return documentError("A valid document ID is required.", 422);

  try {
    const requisition = await readRequisitionPrintDocument(id);
    if (!requisition) return documentError("Material Requisition not found.", 404);
    return documentPage({
      title: requisition.fileName || `material_requisition_${id}`,
      bodyHtml: renderRequisitionPrintDocument(requisition),
      pageStyles: MATERIAL_REQUISITION_STYLES,
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    console.error(`Unable to render the material requisition ${id}`, error);
    return documentError("The Material Requisition could not be rendered.", 500);
  }
}
