import { NextRequest, NextResponse } from "next/server";
import crypto from "node:crypto";
import { queryOne, withTransaction } from "@/lib/db/query";
import { recalculateAttendance } from "@/modules/hr/attendance-engine";
import type { ResultSetHeader, RowDataPacket } from "mysql2";

export const runtime = "nodejs";

type BiometricEvent = {
  employee_code?: string;
  employee_id?: string | number;
  punch_time?: string;
  timestamp?: string;
  punch_type?: string;
  type?: string;
  external_event_id?: string;
  event_id?: string;
  id?: string | number;
};

type FailedEvent = { index: number; reason: string };

/** `admin/biometric-push-api.php:164-169`: the device's own vocabulary, mapped. */
function punchTypeOf(raw: string): "in" | "out" | "unknown" {
  switch (raw.trim().toLowerCase()) {
    case "in": case "checkin": case "check_in": case "entry": case "0":
      return "in";
    case "out": case "checkout": case "check_out": case "exit": case "1":
      return "out";
    default:
      return "unknown";
  }
}

/**
 * `new DateTimeImmutable($raw, $deviceTz)->setTimezone($deviceTz)`. A bare
 * timestamp is already device-local and is kept verbatim; one that carries an
 * offset or a zone is re-rendered in the device's timezone.
 */
function normalisedPunchTime(raw: string, timezone: string): string | null {
  const bare = raw.match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})(:\d{2})?$/);
  if (bare) return `${bare[1]} ${bare[2]}${bare[3] ?? ":00"}`;

  const parsed = Date.parse(raw);
  if (Number.isNaN(parsed)) return null;
  let format: Intl.DateTimeFormat;
  try {
    format = new Intl.DateTimeFormat("en-GB", {
      timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
    });
  } catch {
    return null;
  }
  const parts: Record<string, string> = {};
  for (const part of format.formatToParts(new Date(parsed))) parts[part.type] = part.value;
  const hour = parts.hour === "24" ? "00" : parts.hour;
  return `${parts.year}-${parts.month}-${parts.day} ${hour}:${parts.minute}:${parts.second}`;
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization") || "";
    const tokenMatch = authHeader.match(/^Bearer\s+([^\s]+)$/i);
    if (!tokenMatch) {
      return NextResponse.json({ status: "error", message: "Device authentication is required." }, { status: 401 });
    }
    const deviceToken = tokenMatch[1].trim();

    const rawBody = await request.text();
    let payload: Record<string, unknown>;
    try {
      payload = JSON.parse(rawBody);
    } catch {
      return NextResponse.json({ status: "error", message: "Provide a valid JSON request body." }, { status: 400 });
    }

    const deviceCode = String(request.headers.get("x-device-code") || payload.device_code || "").trim().toUpperCase();
    if (!deviceCode || deviceToken.length < 16) {
      return NextResponse.json({ status: "error", message: "Device authentication is invalid." }, { status: 401 });
    }

    const tokenHash = crypto.createHash("sha256").update(deviceToken).digest("hex");

    // Authenticate device
    const device = await queryOne<RowDataPacket & {
      id: number;
      company_id: number;
      branch_id: number | null;
      device_code: string;
      timezone: string;
      ingest_rate_limit: number;
    }>(
      `SELECT id, company_id, branch_id, device_code, timezone, ingest_rate_limit
       FROM hr_biometric_devices
       WHERE device_code = ? AND ingest_token_hash = ? AND ingest_enabled = 1 AND status = 1
       LIMIT 1`,
      [deviceCode, tokenHash]
    );

    if (!device) {
      return NextResponse.json({ status: "error", message: "Device authentication is invalid." }, { status: 401 });
    }

    const events = (payload.events ?? []) as BiometricEvent[];
    if (!Array.isArray(events) || events.length === 0 || events.length > 5000) {
      return NextResponse.json({ status: "error", message: "Provide between 1 and 5000 biometric events." }, { status: 422 });
    }

    const companyId = Number(device.company_id);
    const branchId = device.branch_id ? Number(device.branch_id) : null;
    const timezone = String(device.timezone || "").trim() || "Asia/Kolkata";
    const batchKey = String(request.headers.get("x-ingest-batch-id") || payload.batch_id || "").trim() ||
      crypto.createHash("sha256").update(`${deviceCode}|${rawBody}`).digest("hex");
    const remoteIp = request.headers.get("x-forwarded-for") || "127.0.0.1";

    let imported = 0;
    let duplicates = 0;
    let unmapped = 0;
    const failedEvents: FailedEvent[] = [];
    const dates = new Set<string>();

    const { batchId, batchStatus } = await withTransaction(async (conn) => {
      await conn.execute(
        `INSERT INTO hr_biometric_ingest_batches
           (device_id, batch_key, remote_ip, event_count, status)
         VALUES (?, ?, ?, ?, 'processing')
         ON DUPLICATE KEY UPDATE remote_ip = VALUES(remote_ip), event_count = VALUES(event_count),
           imported_count = 0, duplicate_count = 0, unmapped_count = 0, attendance_count = 0,
           status = 'processing', error_message = NULL, received_at = NOW(), completed_at = NULL`,
        [device.id, batchKey, remoteIp, events.length]
      );
      const [batchRows] = await conn.execute<RowDataPacket[]>(
        "SELECT id FROM hr_biometric_ingest_batches WHERE device_id = ? AND batch_key = ? LIMIT 1",
        [device.id, batchKey]
      );
      const id = Number((batchRows[0] as { id?: number } | undefined)?.id ?? 0);

      for (const [index, ev] of events.entries()) {
        if (ev === null || typeof ev !== "object" || Array.isArray(ev)) {
          failedEvents.push({ index, reason: "Event must be an object." });
          continue;
        }
        const employeeCode = String(ev.employee_code ?? ev.employee_id ?? "").trim();
        const rawPunchTime = String(ev.punch_time ?? ev.timestamp ?? "").trim();
        const punchType = punchTypeOf(String(ev.punch_type ?? ev.type ?? "unknown"));
        if (employeeCode === "" || employeeCode.length > 100 || rawPunchTime === "") {
          failedEvents.push({ index, reason: "Employee code and punch time are required." });
          continue;
        }
        const punchTime = normalisedPunchTime(rawPunchTime, timezone);
        if (punchTime === null) {
          failedEvents.push({ index, reason: "Punch time is invalid." });
          continue;
        }
        let externalEventId = String(ev.external_event_id ?? ev.event_id ?? ev.id ?? "").trim();
        if (externalEventId === "") {
          externalEventId = crypto.createHash("sha256")
            .update(`${deviceCode}|${employeeCode}|${punchTime}|${punchType}`).digest("hex");
        }
        if (externalEventId.length > 150) {
          failedEvents.push({ index, reason: "External event identifier is too long." });
          continue;
        }

        // The device only sees its own company and branch slice.
        const [empRows] = await conn.execute<RowDataPacket[]>(
          `SELECT employee.id FROM employees employee
             LEFT JOIN users user ON user.id = employee.user_id AND user.deleted_at IS NULL
             LEFT JOIN hr_employee_profiles profile ON profile.employee_id = employee.id
             LEFT JOIN erp_companies legacy_company ON legacy_company.id = employee.company
                  AND legacy_company.status = 1 AND legacy_company.deleted_at IS NULL
            WHERE employee.emp_code = ? AND employee.deleted_at IS NULL
              AND COALESCE(profile.company_id, user.company_id, legacy_company.id) = ?
              AND (? IS NULL OR COALESCE(profile.branch_id, user.branch_id) = ?)
            LIMIT 1`,
          [employeeCode, companyId, branchId, branchId]
        );
        const employeeId = (empRows[0] as { id?: number } | undefined)?.id ?? null;

        const [result] = await conn.execute<ResultSetHeader>(
          `INSERT IGNORE INTO hr_biometric_punches
             (device_id, external_event_id, employee_code, employee_id, punch_time, punch_type, raw_payload)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [device.id, externalEventId, employeeCode, employeeId, punchTime, punchType, JSON.stringify(ev)]
        );
        if (result.affectedRows === 1) {
          imported++;
          if (employeeId === null) {
            unmapped++;
            if (failedEvents.length < 100) {
              failedEvents.push({ index, reason: "Employee code is not mapped in this device scope." });
            }
          } else {
            dates.add(punchTime.slice(0, 10));
          }
        } else {
          duplicates++;
        }
      }

      const status: "success" | "partial" = failedEvents.length > 0 || unmapped > 0 ? "partial" : "success";
      const errorMessage = failedEvents.length > 0 ? JSON.stringify(failedEvents).slice(0, 1000) : null;
      await conn.execute(
        `UPDATE hr_biometric_ingest_batches
            SET imported_count = ?, duplicate_count = ?, unmapped_count = ?,
                status = ?, error_message = ?, completed_at = NOW()
          WHERE id = ?`,
        [imported, duplicates, unmapped, status, errorMessage, id]
      );
      await conn.execute(
        "UPDATE hr_biometric_devices SET last_synced_at = NOW(), last_ingested_at = NOW() WHERE id = ?",
        [device.id]
      );
      return { batchId: id, batchStatus: status };
    });

    // The punches are only half the import: every date they land on has to be
    // reclassified (`admin/biometric-push-api.php:218-221`). It runs after the
    // commit so the engine reads the rows that were just written.
    let attendanceCount = 0;
    for (const date of dates) {
      attendanceCount += await recalculateAttendance(date, companyId, branchId);
    }
    if (attendanceCount > 0 && batchId > 0) {
      await withTransaction(async (conn) => {
        await conn.execute(
          "UPDATE hr_biometric_ingest_batches SET attendance_count = ? WHERE id = ?",
          [attendanceCount, batchId]
        );
      });
    }

    return NextResponse.json({
      status: batchStatus,
      message: batchStatus === "success"
        ? "Biometric events imported successfully."
        : "Biometric events imported with exceptions.",
      batch_id: batchId,
      imported_count: imported,
      duplicate_count: duplicates,
      unmapped_count: unmapped,
      attendance_count: attendanceCount,
      total_received: events.length,
      failed_events: failedEvents,
    });
  } catch (error) {
    console.error("Biometric push error:", error);
    return NextResponse.json({ status: "error", message: "Failed to process biometric push payload." }, { status: 500 });
  }
}
