import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { createLowStocks, type LowStockLine } from "@/modules/inventory/low-stocks";
import { normalizeIntList } from "@/modules/inventory/stock-list-sql";
import { PURCHASE_MANAGEMENT_PAGE, requirePurchasingAccess } from "@/modules/purchasing/guard";
import { getPurchaseRequests } from "@/modules/purchasing/purchase-management";
import { list, rowCount, toFloat, toInt } from "../forms";

export const runtime = "nodejs";

/** `fetchMultipleLowStockRequestsByIds`: the rows behind the bulk PO step. */
export async function GET(request: NextRequest) {
  const guard = await requirePurchasingAccess(request, [PURCHASE_MANAGEMENT_PAGE]);
  if (!guard.ok) return guard.response;
  const ids = normalizeIntList(request.nextUrl.searchParams.get("ids") ?? "");
  if (ids.length === 0) return apiError("No purchase request IDs specified.", 422);
  try {
    return apiSuccess({ rows: await getPurchaseRequests(ids) });
  } catch (error) {
    console.error("Unable to read the purchase requests", error);
    return apiError("Server error occurred.", 500);
  }
}

/** `addLowStocksRecord`: the Low Stock purchase request form on this screen. */
export async function POST(request: NextRequest) {
  const guard = await requirePurchasingAccess(request, [PURCHASE_MANAGEMENT_PAGE]);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const itemType = list(data, "itemType[]");
    const nonInventoryItemName = list(data, "nonInventoryItemName[]");
    const materialCategory = list(data, "materialCategory[]");
    const productsList = list(data, "productsList[]");
    const packSizeId = list(data, "packSizeId[]");
    const quantity = list(data, "ProductItemquantity[]");
    const quantityUnit = list(data, "ProductItemquantityUnit[]");
    const vendorName = list(data, "vendorName[]");
    const critical = list(data, "isThisCritical[]");
    const deliveryDate = list(data, "dateOfDelivery[]");
    const procurementSource = list(data, "procurementSource[]");
    const branchId = list(data, "branchId[]");
    const warehouseId = list(data, "warehouseId[]");
    const currentStock = list(data, "currentStock[]");
    const reorderLevel = list(data, "reorderLevel[]");
    const currencyType = list(data, "currencyType[]");
    const priceValue = list(data, "priceInValue[]");

    const rows = rowCount(materialCategory, productsList, nonInventoryItemName, quantity);
    const lines: LowStockLine[] = [];
    for (let index = 0; index < rows; index += 1) {
      lines.push({
        itemType: itemType[index] ?? "inventory",
        nonInventoryItemName: nonInventoryItemName[index] ?? "",
        materialCategory: toInt(materialCategory[index]),
        productId: toInt(productsList[index]),
        packSizeId: toInt(packSizeId[index]),
        quantity: toFloat(quantity[index]),
        quantityUnit: toInt(quantityUnit[index]),
        vendorName: vendorName[index] ?? "",
        critical: toInt(critical[index]),
        deliveryDate: deliveryDate[index] ?? "",
        procurementSource: procurementSource[index] ?? "",
        branchId: toInt(branchId[index]),
        warehouseId: toInt(warehouseId[index]),
        currentStock: currentStock[index] ?? "",
        reorderLevel: reorderLevel[index] ?? "",
        currencyType: toInt(currencyType[index]),
        priceValue: priceValue[index] ?? "",
      });
    }

    const result = await createLowStocks({
      reportingPerson: String(data.get("reportingPerson") ?? ""),
      dateOfReport: String(data.get("dateOfReport") ?? ""),
      lines,
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, result.message ?? "Low Stock records added successfully.");
  } catch (error) {
    console.error("Unable to add the purchase requests", error);
    return apiError("Something went wrong.", 500);
  }
}
