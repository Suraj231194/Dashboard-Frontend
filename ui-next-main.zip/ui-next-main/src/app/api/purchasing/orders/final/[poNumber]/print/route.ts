import { NextRequest } from "next/server";
import { documentError, documentPage } from "@/lib/documents/document-page";
import { requirePurchasingAccess } from "@/modules/purchasing/guard";
import { PURCHASE_ORDER_STYLES, renderFinalPurchaseOrder } from "@/modules/purchasing/purchase-order-render";

export const runtime = "nodejs";

/**
 * The Purchase Order document (`admin/pages/purchase_order_template.php`),
 * opened with `triggerDownload=1` from the preview. `branch_id` picks the
 * letterhead address, exactly as the template's own query parameter does.
 */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/purchasing/orders/final/[poNumber]/print">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const poNumber = decodeURIComponent((await context.params).poNumber ?? "");
  if (poNumber.trim() === "") return documentError("No ID provided.", 422);
  try {
    const branchId = Number(request.nextUrl.searchParams.get("branch_id") ?? 0) || 0;
    const printable = await renderFinalPurchaseOrder(poNumber, branchId);
    if (!printable) return documentError("No Purchase Order found.", 404);
    return documentPage({
      title: printable.title,
      bodyHtml: printable.bodyHtml,
      pageStyles: PURCHASE_ORDER_STYLES,
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    console.error(`Unable to render the purchase order ${poNumber}`, error);
    return documentError("The Purchase Order document could not be rendered.", 500);
  }
}
