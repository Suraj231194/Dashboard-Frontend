import { NextRequest } from "next/server";
import { documentError, documentId, documentPage } from "@/lib/documents/document-page";
import { requirePurchasingAccess } from "@/modules/purchasing/guard";
import { PURCHASE_ORDER_STYLES, renderRawPurchaseOrder } from "@/modules/purchasing/purchase-order-render";

export const runtime = "nodejs";

/**
 * The raw Purchase Order document
 * (`admin/pages/purchase_order_raw_template.php`), opened with
 * `triggerDownload=1` from the preview. `branch_id` picks the letterhead
 * address, exactly as the template's own query parameter does.
 */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/purchasing/orders/raw/[id]/print">,
) {
  const guard = await requirePurchasingAccess(request);
  if (!guard.ok) return guard.response;
  const id = documentId((await context.params).id);
  if (id === 0) return documentError("No ID provided.", 422);
  try {
    const branchId = Number(request.nextUrl.searchParams.get("branch_id") ?? 0) || 0;
    const printable = await renderRawPurchaseOrder(id, branchId);
    if (!printable) return documentError("No Purchase Order found.", 404);
    return documentPage({
      title: printable.title,
      bodyHtml: printable.bodyHtml,
      pageStyles: PURCHASE_ORDER_STYLES,
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    console.error(`Unable to render the raw purchase order ${id}`, error);
    return documentError("The Purchase Order document could not be rendered.", 500);
  }
}
