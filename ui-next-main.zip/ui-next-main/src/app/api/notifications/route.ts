import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiSession } from "@/lib/http/guard";
import {
  listNavbarNotifications, markAllNotificationsRead,
  markNotificationArchived, markNotificationRead,
} from "@/modules/notifications/notifications";
import { runDueReminders } from "@/modules/notifications/reminders";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * `notificationListNavbar` (`admin/notificationajax.php:9-80`). The bell carries
 * no permission of its own — any signed-in user sees their own notifications.
 */
export async function GET(request: NextRequest) {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  try {
    // The current poll delivers due reminders before it reads the list, so the
    // bell works with no scheduler at all. The cron route does the same work.
    try {
      await runDueReminders();
    } catch (error) {
      console.error("Unable to generate due reminders", error);
    }
    const offset = Number.parseInt(request.nextUrl.searchParams.get("offset") ?? "0", 10) || 0;
    const result = await listNavbarNotifications(guard.user.user_id, guard.user.role_id, offset);
    return apiSuccess(result);
  } catch (error) {
    console.error("Unable to list notifications", error);
    return apiError("Error loading data.", 500);
  }
}

/**
 * The three POST actions of `notificationajax.php`, named by an `action` field:
 * `read` (`:82`), `archive` (`:114`) and `read-all` (`:145`).
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const action = String(data.get("action") ?? "");
    const notificationId = Number.parseInt(String(data.get("notification_id") ?? "0"), 10) || 0;

    if (action === "read") {
      if (!await markNotificationRead(guard.user.user_id, notificationId)) {
        return apiError("Invalid request");
      }
      return apiSuccess({}, "Notification marked as read");
    }
    if (action === "archive") {
      if (!await markNotificationArchived(guard.user.user_id, notificationId)) {
        return apiError("Invalid request");
      }
      return apiSuccess({}, "Notification marked as archive");
    }
    if (action === "read-all") {
      if (!await markAllNotificationsRead(guard.user.user_id, guard.user.role_id)) {
        return apiError("Invalid session");
      }
      return apiSuccess({}, "All notifications marked as read");
    }
    return apiError("Invalid request");
  } catch (error) {
    console.error("Unable to update a notification", error);
    return apiError("Something went wrong.", 500);
  }
}
