import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createPermission, listPermissions, PERMISSION_SORT_COLUMNS } from "@/modules/access/app-permissions";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "permissions");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, PERMISSION_SORT_COLUMNS, "recent", "DESC");
    return apiSuccess(await listPermissions(query));
  } catch (error) {
    console.error("Unable to list permissions", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "permissions");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createPermission({
      name: String(data.get("permissionName") ?? ""),
      slug: String(data.get("permissionSlug") ?? ""),
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Permission added successfully.");
  } catch (error) {
    console.error("Unable to add a permission", error);
    return apiError("Something went wrong while inserting the permission.", 500);
  }
}
