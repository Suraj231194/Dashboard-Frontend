import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission, requireApiSession } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { createRole, listRoles, ROLE_SORT_COLUMNS } from "@/modules/access/roles";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiSession();
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, ROLE_SORT_COLUMNS, "recent", "DESC");
    return apiSuccess(await listRoles(query));
  } catch (error) {
    console.error("Unable to list roles", error);
    return apiError("Error loading data.", 500);
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "roles_add", "You do not have permission to add roles.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const result = await createRole({
      name: String(data.get("rolesName") ?? ""),
      description: String(data.get("rolesDesc") ?? ""),
      departmentId: Number.parseInt(String(data.get("department_id") ?? "0"), 10) || 0,
      createdBy: guard.user.user_id,
    });
    if (!result.ok) return apiError(result.message, result.status ?? 400);
    return apiSuccess({}, "Role added successfully");
  } catch (error) {
    console.error("Unable to add a role", error);
    return apiError("Something went wrong.", 500);
  }
}
