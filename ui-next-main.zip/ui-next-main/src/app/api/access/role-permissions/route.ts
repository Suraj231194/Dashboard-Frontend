import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { addRolePermissions, listRolesForPermissions } from "@/modules/access/role-permissions";
import { isSameOrigin } from "@/lib/http/same-origin";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPermission(
    request,
    "role_has_permission_menu_list",
    "You do not have permission to view role permissions.",
  );
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(request.nextUrl.searchParams, ["name"], "name", "ASC");
    return apiSuccess(await listRolesForPermissions(query));
  } catch (error) {
    console.error("Unable to list roles for permissions", error);
    return apiError("Error loading data.", 500);
  }
}

/**
 * `addRoleHasPermissions`: assigns permissions to a role without removing any.
 *
 * Separate from the edit dialog's PUT, which replaces the role's whole set.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(
    request,
    "role_has_permission_add",
    "You do not have permission to assign role permissions.",
  );
  if (!guard.ok) return guard.response;
  if (!isSameOrigin(request)) {
    return apiError("Your session token is invalid. Please refresh the page and try again.", 419);
  }
  try {
    const data = await request.formData();
    const roleId = Number.parseInt(String(data.get("roleddl") ?? "0"), 10) || 0;
    const permissionIds = data.getAll("permissions")
      .map((value) => Number.parseInt(String(value), 10))
      .filter((id) => Number.isInteger(id) && id > 0);
    const result = await addRolePermissions(roleId, permissionIds);
    if (!result.ok) return apiError(result.message, result.status ?? 422);
    return apiSuccess({}, "Permissions assigned successfully.");
  } catch (error) {
    console.error("Unable to assign role permissions", error);
    return apiError("Failed to assign permissions.", 500);
  }
}
