import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { refuseRetiredProductionWrite, requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { listMaterialRequisitions } from "@/modules/procurement/material-requisitions";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "material-requisition");
  if (!guard.ok) return guard.response;
  try {
    // The current list has no sortable heading: it always orders by id.
    const query = readListQuery(request.nextUrl.searchParams, [], "id", "DESC");
    return apiSuccess(await listMaterialRequisitions(query));
  } catch (error) {
    console.error("Unable to list material requisitions", error);
    return apiError("Error loading data.", 500);
  }
}

/**
 * `addMaterialRequisitionForm` is one of the standalone production writes the current
 * application refuses (`bmrBprLegacyWriteActions()`): production now runs
 * through the linked workflow queue. The record stays readable.
 */
export async function POST(request: NextRequest) {
  return refuseRetiredProductionWrite(request);
}
