import { NextRequest } from "next/server";
import { refuseRetiredProductionWrite } from "@/lib/http/guard";

export const runtime = "nodejs";

/**
 * `materialRequisitionFinalQtyUpdate` is one of the standalone production writes the current
 * application refuses (`bmrBprLegacyWriteActions()`): production now runs
 * through the linked workflow queue. The record stays readable.
 */
export async function GET(request: NextRequest) {
  return refuseRetiredProductionWrite(request);
}

/**
 * `materialRequisitionEditQtyFinal` is one of the standalone production writes the current
 * application refuses (`bmrBprLegacyWriteActions()`): production now runs
 * through the linked workflow queue. The record stays readable.
 */
export async function PUT(request: NextRequest) {
  return refuseRetiredProductionWrite(request);
}
