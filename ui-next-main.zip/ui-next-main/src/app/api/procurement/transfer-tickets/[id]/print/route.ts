import { NextRequest } from "next/server";
import { documentError, documentId, documentPage, requireDocumentPermission } from "@/lib/documents/document-page";
import { readTransferTicketDocument } from "@/modules/procurement/transfer-tickets";
import { renderTransferTicketDocument, TRANSFER_TICKET_STYLES } from "@/modules/production/transfer-ticket-render";

export const runtime = "nodejs";

/**
 * The printable Transfer Ticket (`admin/pages/transfer_ticket_template.php`).
 * `?download=1` opens the print dialog, where the current template streams
 * a PDF (`triggerDownload=1`). The permission list is the template's own.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/procurement/transfer-tickets/[id]/print">) {
  const guard = await requireDocumentPermission([
    "transfer_ticket_view",
    "transfer_ticket_generate_pdf",
    "transfer_ticket_menu_list",
    "transfer_ticket_add",
    "transfer_ticket_edit",
    "store_goods_received_production_list",
    "production_plan_view",
    "material_requisition_view",
  ]);
  if (!guard.ok) return guard.response;

  const id = documentId((await context.params).id);
  if (id === 0) return documentError("A valid document ID is required.", 422);

  try {
    const ticket = await readTransferTicketDocument(id);
    if (!ticket) return documentError("No transfer ticket found.", 404);
    return documentPage({
      title: ticket.fileName || `transfer_ticket_${id}`,
      bodyHtml: renderTransferTicketDocument(ticket),
      pageStyles: TRANSFER_TICKET_STYLES,
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    console.error(`Unable to render the transfer ticket ${id}`, error);
    return documentError("The Transfer Ticket could not be rendered.", 500);
  }
}
