import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, refuseRetiredProductionWrite, requireApiPermission } from "@/lib/http/guard";
import { readTransferTicket } from "@/modules/procurement/transfer-tickets";

export const runtime = "nodejs";

/** `transferTicketViewRecord` and `fetchTransferTicketRecord` read the same row. */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/procurement/transfer-tickets/[id]">,
) {
  const guard = await requireApiPermission(
    request, "transfer_ticket_view", "You do not have permission to view transfer tickets.",
  );
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const detail = await readTransferTicket(id);
    if (!detail) return apiError("No data found...!!", 404);
    return apiSuccess(detail);
  } catch (error) {
    console.error("Unable to read the transfer ticket", error);
    return apiError("Server error occurred.", 500);
  }
}

/**
 * `updateTransferTicket` is one of the standalone production writes the current
 * application refuses (`bmrBprLegacyWriteActions()`): production now runs
 * through the linked workflow queue. The record stays readable.
 */
export async function PUT(request: NextRequest) {
  return refuseRetiredProductionWrite(request);
}

/**
 * `deleteTransfetTicketRecord` is one of the standalone production writes the current
 * application refuses (`bmrBprLegacyWriteActions()`): production now runs
 * through the linked workflow queue. The record stays readable.
 */
export async function DELETE(request: NextRequest) {
  return refuseRetiredProductionWrite(request);
}
