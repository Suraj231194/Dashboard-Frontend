import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { refuseRetiredProductionWrite, requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { TRANSFER_TICKET_SORT_COLUMNS } from "@/modules/procurement/material-list-sql";
import { listTransferTickets } from "@/modules/procurement/transfer-tickets";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "transfer-ticket");
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, TRANSFER_TICKET_SORT_COLUMNS, "recent", "DESC");
    return apiSuccess(await listTransferTickets(query, {
      fromDate: (params.get("fromDate") ?? "").trim(),
      toDate: (params.get("toDate") ?? "").trim(),
    }));
  } catch (error) {
    console.error("Unable to list transfer tickets", error);
    return apiError("Error loading data.", 500);
  }
}

/**
 * `addTransferTicket` is one of the standalone production writes the current
 * application refuses (`bmrBprLegacyWriteActions()`): production now runs
 * through the linked workflow queue. The record stays readable.
 */
export async function POST(request: NextRequest) {
  return refuseRetiredProductionWrite(request);
}
