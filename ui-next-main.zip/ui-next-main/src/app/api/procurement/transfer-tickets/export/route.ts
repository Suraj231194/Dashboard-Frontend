import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { requireApiPageAccess } from "@/lib/http/guard";
import { TRANSFER_TICKET_SORT_COLUMNS } from "@/modules/procurement/material-list-sql";
import { buildTransferTicketExport, TRANSFER_TICKET_EXPORT_COLUMNS } from "@/modules/procurement/transfer-tickets";

export const runtime = "nodejs";

/** `exportTransferTicketManual`: the chosen columns as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "transfer-ticket");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const value = (name: string) => String(data.get(name) ?? "").trim();
    const sortColumn = value("sort_column");
    const columns = data.getAll("listOfColumns[]").map((entry) => String(entry));
    const result = await buildTransferTicketExport({
      search: value("search"),
      // The toolbar's own range, which the export modal does not repeat.
      fromDate: value("fromDate"),
      toDate: value("toDate"),
      sortColumn: (TRANSFER_TICKET_SORT_COLUMNS as readonly string[]).includes(sortColumn) ? sortColumn : "id",
      sortDirection: value("sort_direction").toUpperCase() === "ASC" ? "ASC" : "DESC",
      page: Number.parseInt(value("page"), 10) || 1,
      perPage: Number.parseInt(value("perPage"), 10) || 10,
      columns: columns.length > 0 ? columns : [...TRANSFER_TICKET_EXPORT_COLUMNS],
    });
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "Transfer Ticket", filePrefix: "transfer_ticket",
      headers: result.columns, rows: result.rows,
    });
  } catch (error) {
    console.error("Unable to build the transfer ticket export", error);
    return apiError("Server error occurred.", 500);
  }
}
