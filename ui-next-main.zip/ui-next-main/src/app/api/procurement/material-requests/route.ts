import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { MATERIAL_REQUEST_SORT_COLUMNS } from "@/modules/procurement/material-list-sql";
import { listMaterialRequests } from "@/modules/procurement/material-requests";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "material-request");
  if (!guard.ok) return guard.response;
  try {
    const query = readListQuery(
      request.nextUrl.searchParams, MATERIAL_REQUEST_SORT_COLUMNS, "recent", "DESC",
    );
    return apiSuccess(await listMaterialRequests(query));
  } catch (error) {
    console.error("Unable to list material requests", error);
    return apiError("Error loading data.", 500);
  }
}
