import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import {
  exportPeriodSubtitle, readExportDateRange, readExportFormat, tableExportResponse,
} from "@/lib/export/table-export";
import { requireApiPageAccess } from "@/lib/http/guard";
import { MATERIAL_REQUEST_SORT_COLUMNS } from "@/modules/procurement/material-list-sql";
import { buildMaterialRequestExport, MATERIAL_REQUEST_EXPORT_COLUMNS } from "@/modules/procurement/material-requests";

export const runtime = "nodejs";

/** `exportMaterialRequest`: the chosen columns as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, "material-request");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const range = readExportDateRange(data);
    if (!range.ok) return apiError(range.message, 422);
    const value = (name: string) => String(data.get(name) ?? "").trim();
    const sortColumn = value("sort_column");
    const columns = data.getAll("listOfColumns[]").map((entry) => String(entry));
    const result = await buildMaterialRequestExport({
      search: value("search"),
      fromDate: range.fromDate,
      toDate: range.toDate,
      sortColumn: (MATERIAL_REQUEST_SORT_COLUMNS as readonly string[]).includes(sortColumn) ? sortColumn : "id",
      sortDirection: value("sort_order").toUpperCase() === "ASC" ? "ASC" : "DESC",
      page: Number.parseInt(value("page"), 10) || 1,
      perPage: Number.parseInt(value("perPage"), 10) || 10,
      columns: columns.length > 0 ? columns : [...MATERIAL_REQUEST_EXPORT_COLUMNS],
    });
    if (result.rows.length === 0) return apiError("No records found", 404);
    return await tableExportResponse({
      format, title: "Material Request", filePrefix: "material_request",
      headers: result.columns, rows: result.rows,
      subtitle: exportPeriodSubtitle(range.fromDate, range.toDate, result.rows.length),
    });
  } catch (error) {
    console.error("Unable to build the material request export", error);
    return apiError("Server error occurred.", 500);
  }
}
