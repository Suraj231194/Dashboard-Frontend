import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, refuseRetiredProductionWrite, requireApiPermission } from "@/lib/http/guard";
import { readRequestStatus } from "@/modules/procurement/material-requests";

export const runtime = "nodejs";

const EDIT_SLUG = "store_material_request_edit";
const DENIED = "You do not have permission to edit material requests.";

/** `fetchMaterialRequestStatusRecord`. */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/procurement/material-requests/[id]/status">,
) {
  const guard = await requireApiPermission(request, EDIT_SLUG, DENIED);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const record = await readRequestStatus(id);
    if (!record) return apiError("No data found...!!", 404);
    return apiSuccess(record);
  } catch (error) {
    console.error("Unable to read the material request status", error);
    return apiError("Server error occurred.", 500);
  }
}

/**
 * `updateMaterialRequestStatusRecord` is one of the standalone production writes the current
 * application refuses (`bmrBprLegacyWriteActions()`): production now runs
 * through the linked workflow queue. The record stays readable.
 */
export async function PUT(request: NextRequest) {
  return refuseRetiredProductionWrite(request);
}
