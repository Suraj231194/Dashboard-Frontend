import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { readId, refuseRetiredProductionWrite, requireApiPermission } from "@/lib/http/guard";
import { readIssuanceForm } from "@/modules/procurement/material-requests";

export const runtime = "nodejs";

const EDIT_SLUG = "store_material_request_edit";
const DENIED = "You do not have permission to edit material requests.";

/** `fetchMaterialRequestRecord` / `fetchMaterialRequestBomRecord`. */
export async function GET(
  request: NextRequest, context: RouteContext<"/api/procurement/material-requests/[id]/issue">,
) {
  const guard = await requireApiPermission(request, EDIT_SLUG, DENIED);
  if (!guard.ok) return guard.response;
  const id = readId((await context.params).id);
  if (id === 0) return apiError("Something went wrong with this record..!!", 422);
  try {
    const form = await readIssuanceForm(id);
    if (!form) return apiError("No data found...!!", 404);
    return apiSuccess(form);
  } catch (error) {
    console.error("Unable to read the material issuance form", error);
    return apiError("Server error occurred.", 500);
  }
}

/**
 * `updateMaterialReqestRecord` / `updateMaterialReqestBOMRecord` is one of the standalone production writes the current
 * application refuses (`bmrBprLegacyWriteActions()`): production now runs
 * through the linked workflow queue. The record stays readable.
 */
export async function PUT(request: NextRequest) {
  return refuseRetiredProductionWrite(request);
}
