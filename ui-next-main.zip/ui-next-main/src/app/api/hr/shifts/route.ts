import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { hrScope } from "@/modules/hr/hr-scope";
import {
  deleteRoster, deleteShift, listRosters, listShifts, saveRoster, saveShift, saveShiftPolicy,
  shiftBranches, shiftCompanies, shiftEmployees, unassignedEmployeeCount, hrToday,
} from "@/modules/hr/shifts";

export const runtime = "nodejs";

const PAGE = "shift-management";

/** Everything the shift screen shows: the shifts, the roster and the pickers. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  try {
    const scope = await hrScope(guard.user.user_id);
    const [shifts, rosters, companies, branches, employees, unassigned] = await Promise.all([
      listShifts(scope), listRosters(scope), shiftCompanies(scope),
      shiftBranches(scope), shiftEmployees(scope), unassignedEmployeeCount(scope),
    ]);
    return apiSuccess({ shifts, rosters, companies, branches, employees, unassigned, today: hrToday() });
  } catch (error) {
    console.error("Unable to load shift management", error);
    return apiError("Error loading data.", 500);
  }
}

/**
 * One endpoint for the five writes the screen performs, selected by `action`,
 * matching the action names the current API dispatches.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const action = String(data.get("action") ?? "");
    const scope = await hrScope(guard.user.user_id);
    const userId = guard.user.user_id;
    const number = (key: string, fallback = 0) =>
      Number.parseInt(String(data.get(key) ?? ""), 10) || fallback;
    const text = (key: string) => String(data.get(key) ?? "").trim();

    if (action === "create_hrms_shift" || action === "update_hrms_shift") {
      const result = await saveShift({
        shiftId: number("shift_id"),
        name: text("name"),
        startTime: text("start_time"),
        endTime: text("end_time"),
        lunchStart: text("lunch_start_time"),
        lunchEnd: text("lunch_end_time"),
        lateGraceMinutes: number("late_grace_minutes"),
        earlyLeaveMinutes: number("early_leave_minutes"),
        fullDayMinutes: number("full_day_minutes"),
        halfDayMinutes: number("half_day_minutes"),
        companyId: number("company_id"),
        branchId: number("branch_id"),
        effectiveFrom: text("effective_from") || hrToday(),
        workingDays: data.getAll("working_days")
          .map((value) => Number.parseInt(String(value), 10))
          .filter((value) => value >= 1 && value <= 7),
      }, action === "update_hrms_shift", scope, userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({ shiftId: result.shiftId }, result.message);
    }

    if (action === "delete_hrms_shift") {
      const result = await deleteShift(number("shift_id"), scope, userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    if (action === "save_employee_shift_roster") {
      const result = await saveRoster({
        employeeId: number("employee_id"),
        shiftId: number("shift_id"),
        startDate: text("start_date"),
        endDate: text("end_date"),
      }, scope, userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    if (action === "delete_employee_shift_roster") {
      const result = await deleteRoster(number("roster_id"), scope, userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    if (action === "save_shift_policy") {
      const result = await saveShiftPolicy({
        shiftId: number("shift_id"),
        companyId: number("company_id"),
        branchId: number("branch_id"),
        fullDayMinutes: number("full_day_minutes"),
        halfDayMinutes: number("half_day_minutes"),
        effectiveFrom: text("effective_from"),
        effectiveTo: text("effective_to"),
      }, scope, userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    return apiError("No HRMS action was supplied.", 400);
  } catch (error) {
    console.error("Unable to complete the shift action", error);
    return apiError("Server error occurred.", 500);
  }
}
