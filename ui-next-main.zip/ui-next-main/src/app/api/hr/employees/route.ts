import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import { workforceHeadcount } from "@/modules/workforce/headcount";
import {
  addEmployee, addEmployeeAdvance, deleteEmployee, employeesByCount, EMPLOYEE_SORT_COLUMNS,
  listEmployees, resignEmployee, setEmployeeStatus, type EmployeeDetailsInput, type EmployeeFilters,
} from "@/modules/hr/employees";

export const runtime = "nodejs";

const PAGE = "employees";

/** A repeated or comma-joined list of ids, as the filter checkboxes send it. */
export function readIds(params: URLSearchParams, key: string): number[] {
  const values = [...params.getAll(key), ...params.getAll(`${key}[]`)];
  return values
    .flatMap((value) => String(value).split(","))
    .map((value) => Number.parseInt(value.trim(), 10))
    .filter((value) => Number.isInteger(value));
}

function readFilters(params: URLSearchParams): EmployeeFilters {
  return {
    categories: readIds(params, "categoryType"),
    statuses: readIds(params, "selectedStatus"),
    companies: readIds(params, "selectedCompany"),
  };
}

/** `loadEmployees`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    // The client's own default is `id`/`DESC`, and `id` is not in the
    // allow-list, so the effective default is `first_name DESC`.
    const query = readListQuery(params, EMPLOYEE_SORT_COLUMNS, "recent", "DESC");
    const result = await listEmployees(query, readFilters(params));
    return apiSuccess(result);
  } catch (error) {
    console.error("Unable to list employees", error);
    return apiError("Error loading data.", 500);
  }
}

/** The employee-details payload the add and edit dialogs both post. */
export function readDetails(data: FormData): EmployeeDetailsInput {
  const text = (key: string) => String(data.get(key) ?? "").trim();
  const number = (key: string) => Number.parseInt(text(key), 10) || 0;
  return {
    empCode: text("empCode"),
    solutation: text("solutation"),
    firstName: text("firstName"),
    lastName: text("lastName"),
    dob: text("dob"),
    gender: number("gender"),
    email: text("userEmail"),
    contactNumber: text("contactNumber"),
    altContactNumberOne: text("altContactNumberOne"),
    altContactNumberTwo: text("altContactNumberTwo"),
    fathersName: text("fathersName"),
    maritalStatus: number("maritalStatus"),
    husbandName: text("husbandName"),
    bloodGroup: text("bloodGroup"),
    localAddress: text("localAddress"),
    permanentAddress: text("permanentAddress"),
    doj: text("doj"),
    company: number("empCompany"),
    employmentCategory: number("employmentCategory"),
    employmentType: number("employmentType"),
    designationId: number("empDesignation"),
    status: number("userStatus"),
  };
}

/**
 * The writes that do not target one row's details: create, the status switch,
 * resign, delete, the advance payment and the dashboard drill-down.
 */
export async function POST(request: NextRequest) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const action = String(data.get("action") ?? "");
    const userId = guard.user.user_id;
    const text = (key: string) => String(data.get(key) ?? "").trim();
    const number = (key: string) => Number.parseInt(text(key), 10) || 0;

    if (action === "addEmployees") {
      const result = await addEmployee(readDetails(data), userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    if (action === "updateEmployeeStatus") {
      const result = await setEmployeeStatus(number("id"), number("status"), userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    if (action === "resignEmployeesRecord") {
      const result = await resignEmployee(number("id"), userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    if (action === "deleteEmployeesRecord") {
      const result = await deleteEmployee(number("id"), userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    if (action === "addAdvancePaymentToEployee") {
      const amount = Number.parseFloat(text("amount"));
      const installment = Number.parseFloat(text("installment_amount"));
      const result = await addEmployeeAdvance({
        entryDate: text("entryDate"),
        employeeId: number("employeeId"),
        amount: Number.isFinite(amount) ? amount : 0,
        deductionType: number("deduction_type"),
        installmentAmount: Number.isFinite(installment) ? installment : 0,
        remark: text("remark"),
      }, userId);
      if (!result.ok) return apiError(result.message, result.status);
      return apiSuccess({}, result.message);
    }

    if (action === "fetchEmployeeCountRecord") {
      const result = await employeesByCount({
        companyType: number("companyType"),
        categoryType: number("categoryType"),
        statusType: number("statusType"),
      });
      if (!result.ok) return apiError(result.message, 404);
      return apiSuccess({ title: result.title, rows: result.rows });
    }

    if (action === "loadEmployeesDashboard") {
      return apiSuccess({ cards: await workforceHeadcount() });
    }

    return apiError("Missing or invalid input.", 400);
  } catch (error) {
    console.error("Unable to complete the employees action", error);
    return apiError("Server error occurred.", 500);
  }
}
