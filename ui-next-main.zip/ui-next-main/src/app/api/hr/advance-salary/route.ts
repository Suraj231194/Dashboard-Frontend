import { NextRequest } from "next/server";
import { apiError, apiSuccess } from "@/lib/http/json";
import { requireApiPageAccess, requireApiPermission } from "@/lib/http/guard";
import { readListQuery } from "@/lib/pagination";
import {
  ADVANCE_SORT_COLUMNS, AdvanceSalaryError, createAdvanceSalary, listAdvanceSalary,
} from "@/modules/hr/advance-salary";

export const runtime = "nodejs";

const PAGE = "advance-salary";

/** `loadAdvanceSalary`. */
export async function GET(request: NextRequest) {
  const guard = await requireApiPageAccess(request, PAGE);
  if (!guard.ok) return guard.response;
  try {
    const params = request.nextUrl.searchParams;
    const query = readListQuery(params, ADVANCE_SORT_COLUMNS, "recent", "DESC");
    return apiSuccess(await listAdvanceSalary(query, {
      month: String(params.get("month") ?? "").trim(),
    }));
  } catch (error) {
    console.error("Unable to list advance salary records", error);
    return apiError("Error loading data.", 500);
  }
}

/** `addAdvancePaymentToEployee`. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "hr_advance_salary_add",
    "You do not have permission to record an advance salary.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const number = (key: string) => Number.parseInt(String(data.get(key) ?? ""), 10) || 0;
    const decimal = (key: string) => {
      const value = Number.parseFloat(String(data.get(key) ?? ""));
      return Number.isFinite(value) ? value : Number.NaN;
    };
    const result = await createAdvanceSalary({
      employeeId: number("employeeId"),
      issuedOn: String(data.get("entryDate") ?? "").trim(),
      amount: decimal("amount"),
      deductionType: number("deduction_type"),
      installmentAmount: decimal("installment_amount"),
      remark: String(data.get("remark") ?? ""),
    }, guard.user.user_id);
    return apiSuccess({}, result.message);
  } catch (error) {
    if (error instanceof AdvanceSalaryError) return apiError(error.message, error.status);
    console.error("Unable to record the advance salary", error);
    return apiError("Server error occurred.", 500);
  }
}
