import { NextRequest } from "next/server";
import { documentError, documentId, documentPage, requireDocumentPermission } from "@/lib/documents/document-page";
import { hrScope } from "@/modules/hr/hr-scope";
import { CalendarError } from "@/modules/hr/annual-calendar";
import {
  calendarReportStyles, readCalendarReport, renderCalendarReport,
} from "@/modules/hr/annual-calendar-report";

export const runtime = "nodejs";

/**
 * The Annual Calendar report (`admin/annual-calendar-export.php` with
 * `format=pdf`), behind the same `hrms_calendar_export` permission.
 */
export async function GET(request: NextRequest, context: RouteContext<"/api/hr/annual-calendar/[id]/document">) {
  const guard = await requireDocumentPermission(["hrms_calendar_export"]);
  if (!guard.ok) return guard.response;

  const id = documentId((await context.params).id);
  if (id === 0) return documentError("Select a valid finalized calendar and export format.", 422);

  try {
    const scope = await hrScope(guard.user.user_id);
    const report = await readCalendarReport(id, scope);
    return documentPage({
      title: report.safeBaseName,
      bodyHtml: renderCalendarReport(report),
      pageStyles: calendarReportStyles(report),
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    if (error instanceof CalendarError) return documentError(error.message, error.status);
    console.error(`Unable to render the annual calendar report ${id}`, error);
    return documentError("The Annual Calendar report could not be rendered.", 500);
  }
}
