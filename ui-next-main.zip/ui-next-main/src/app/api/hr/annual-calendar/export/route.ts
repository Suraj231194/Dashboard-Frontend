import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { requireApiPermission } from "@/lib/http/guard";
import { readExportFormat, tableExportResponse } from "@/lib/export/table-export";
import { hrScope } from "@/modules/hr/hr-scope";
import { CalendarError, buildCalendarExport } from "@/modules/hr/annual-calendar";

export const runtime = "nodejs";

/** The finalized day ledger, or the audit trail, as a CSV, an .xlsx or a PDF. */
export async function POST(request: NextRequest) {
  const guard = await requireApiPermission(request, "hrms_calendar_export",
    "You do not have permission to export Annual Calendars.");
  if (!guard.ok) return guard.response;
  try {
    const data = await request.formData();
    const format = readExportFormat(data.get("exportType"));
    if (!format) return apiError("Invalid export type", 422);
    const calendarId = Number.parseInt(String(data.get("calendar_id") ?? ""), 10) || 0;
    if (calendarId <= 0) return apiError("Invalid calendar.", 422);
    const kind = String(data.get("kind") ?? "ledger") === "audit" ? "audit" : "ledger";
    const scope = await hrScope(guard.user.user_id);
    const result = await buildCalendarExport(calendarId, kind, scope);
    if (result.rows.length === 0) return apiError("No records found", 404);
    const requested = data.getAll("listOfColumns[]").map(String);
    const headers = requested.length > 0
      ? result.headers.filter((header) => requested.includes(header))
      : result.headers;
    if (headers.length === 0) return apiError("Select at least one export column.", 422);
    return await tableExportResponse({
      format, title: result.title,
      filePrefix: kind === "audit" ? "annual_calendar_audit" : "annual_calendar",
      headers,
      rows: result.rows.map((row) => Object.fromEntries(headers.map((header) => [header, row[header] ?? ""]))),
      subtitle: `${result.rows.length} record(s)`,
      csvPreamble: result.csvPreamble,
      // The reference escapes any cell a spreadsheet would read as a formula.
      escapeFormulas: true,
    });
  } catch (error) {
    if (error instanceof CalendarError) return apiError(error.message, error.status);
    console.error("Unable to build the annual calendar export", error);
    return apiError("Server error occurred.", 500);
  }
}
