import { NextRequest } from "next/server";
import { apiError } from "@/lib/http/json";
import { readId, requireApiPageAccess } from "@/lib/http/guard";
import { documentPage } from "@/lib/documents/document-page";
import { can } from "@/modules/access/permissions";
import { OffboardingError, offboardingDocument } from "@/modules/hr/offboarding";
import {
  OFFBOARDING_LETTER_STYLES, renderOffboardingLetter,
} from "@/modules/hr/offboarding-letter-render";

export const runtime = "nodejs";

/**
 * One offboarding letter (`hrmsGenerateOffboardingDocuments`). The employee
 * the letter is about may open it; anybody else needs the offboarding
 * permission.
 *
 * The file generated at approval is served when it is still on disk, so the
 * letter somebody was sent is the letter they can download again; otherwise it
 * is rendered from the stored data, dated when it was generated.
 */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const guard = await requireApiPageAccess(request, "offboarding");
  if (!guard.ok) return guard.response;
  try {
    const { id } = await context.params;
    const canManage = await can(guard.user, "hrms_offboarding_manage");
    const document = await offboardingDocument(readId(id), guard.user.user_id, canManage);
    if (document.kind === "file") {
      return new Response(document.bytes.buffer as ArrayBuffer, {
        headers: {
          "Content-Type": "application/pdf",
          "Content-Disposition": `inline; filename="${document.fileName}"`,
          "Cache-Control": "private, no-store, max-age=0",
          "X-Frame-Options": "SAMEORIGIN",
        },
      });
    }
    return documentPage({
      title: document.fileName,
      bodyHtml: renderOffboardingLetter(document.letter),
      pageStyles: OFFBOARDING_LETTER_STYLES,
      print: request.nextUrl.searchParams.get("download") === "1",
    });
  } catch (error) {
    if (error instanceof OffboardingError) return apiError(error.message, error.status);
    console.error("Unable to render the offboarding document", error);
    return apiError("Server error occurred.", 500);
  }
}
