import { notFound } from "next/navigation";

/**
 * Any address no screen answers. Next.js would otherwise show its own bare
 * 404 outside the shell; sending it through notFound() here renders
 * (erp)/not-found.tsx inside the sidebar and navbar instead.
 */
export default function MissingPage() {
  notFound();
}
