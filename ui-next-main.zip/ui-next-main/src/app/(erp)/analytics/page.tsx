import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { AnalyticsScreen } from "@/modules/analytics/AnalyticsScreen";
import { getAnalyticsData } from "@/modules/analytics/analytics";
import { analyticsVisibility } from "@/modules/analytics/visibility";

export default async function AnalyticsPage() {
  const { user, allowed } = await getPageAccess("analytics");
  if (!allowed) return <Forbidden />;
  // Resolved before anything is read, so a section the signed-in user cannot
  // open is never queried and never reaches the browser.
  const visibility = await analyticsVisibility(user);
  const data = await getAnalyticsData(visibility);
  return <AnalyticsScreen initial={data} userName={user.name} />;
}
