import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { RolePermissionsScreen } from "@/modules/access/RolePermissionsScreen";

export default async function RoleHasPermissionsPage() {
  const { user, allowed } = await getPageAccess("role-has-permissions");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    edit: "role_has_permission_edit",
    add: "role_has_permission_add",
  });
  return <RolePermissionsScreen canEdit={permissions.edit} canAdd={permissions.add} />;
}
