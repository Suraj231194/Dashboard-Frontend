import { ui } from "@/components/ui/styles";

/**
 * Shown inside the shell the moment a menu entry is clicked, while the next
 * screen loads its data on the server. It sketches the usual screen (a page
 * header, then a card with a toolbar and a table) so the click visibly took.
 *
 * `ui-skeleton` already stops shimmering for anyone who has asked their system
 * to reduce motion (see globals.css), so nothing here animates for them.
 */
const ROWS = 8;
const COLUMNS = ["w-24", "w-40", "w-32", "w-20", "w-28"];

export default function ErpLoading() {
  return (
    <div role="status" aria-live="polite" aria-busy="true" className={ui.pageStack}>
      <span className="sr-only">Loading the page</span>

      {/* PageHeader: icon chip, title and subtitle, actions on the end. */}
      <div aria-hidden="true" className="flex flex-wrap items-center justify-between gap-x-6 gap-y-4">
        <div className="flex min-w-0 flex-[1_1_20rem] items-center gap-3.5">
          <span className={`${ui.skeleton} hidden h-11 w-11 shrink-0 rounded-xl sm:block`} />
          <div className="min-w-0 flex-1 space-y-2">
            <span className={`${ui.skeleton} h-6 w-56 max-w-full`} />
            <span className={`${ui.skeleton} h-4 w-80 max-w-full`} />
          </div>
        </div>
        <span className={`${ui.skeleton} h-10 w-32 rounded-[0.625rem]`} />
      </div>

      {/* A list card: toolbar band, table header, rows, pagination. */}
      <div aria-hidden="true" className={ui.card}>
        <div className={`${ui.toolbarBand} flex flex-col gap-2 sm:flex-row sm:items-center`}>
          <span className={`${ui.skeleton} h-10 w-full rounded-[0.625rem] sm:w-72`} />
          <span className={`${ui.skeleton} h-10 w-full rounded-[0.625rem] sm:ms-auto sm:w-28`} />
        </div>
        <div className="overflow-hidden">
          <div className="flex gap-6 bg-slate-50 px-4 py-3.5 lg:px-5">
            {COLUMNS.map((width, index) => (
              <span key={index} className={`${ui.skeleton} h-3 ${width} ${index > 2 ? "hidden md:block" : ""}`} />
            ))}
          </div>
          <div className="divide-y divide-slate-100">
            {Array.from({ length: ROWS }, (_, row) => (
              <div key={row} className="flex items-center gap-6 px-4 py-3.5 lg:px-5">
                {COLUMNS.map((width, index) => (
                  <span key={index} className={`${ui.skeleton} h-4 ${width} ${index > 2 ? "hidden md:block" : ""}`} />
                ))}
              </div>
            ))}
          </div>
        </div>
        <div className="flex items-center justify-between gap-3 border-t border-slate-200/70 px-4 py-3 lg:px-5">
          <span className={`${ui.skeleton} h-4 w-40`} />
          <span className={`${ui.skeleton} h-8 w-28 rounded-lg`} />
        </div>
      </div>
    </div>
  );
}
