import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { AppearanceForm } from "@/modules/settings/AppearanceForm";
import { getAppearance } from "@/modules/settings/appearance";

export default async function AppearancePage() {
  // Same guard as the current router: open unless a menu row gives the page a slug.
  const { user, allowed } = await getPageAccess("appearance");
  if (!allowed) return <Forbidden />;
  return <AppearanceForm initial={await getAppearance(user.user_id)} />;
}
