"use client"; // Error boundaries must be Client Components.

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { AlertTriangle, Check, Copy, RefreshCw } from "@/components/ui/icons";
import { ui } from "@/components/ui/styles";

/**
 * Shown inside the shell when a screen fails to render, so the sidebar and
 * navbar stay usable. "Try again" re-fetches and re-renders the screen;
 * "Copy details" puts the reference and message on the clipboard for a
 * support request.
 */
export default function ErpError({ error, retry }: {
  error: Error & { digest?: string };
  retry: () => void;
}) {
  const [copy, setCopy] = useState<"idle" | "copied" | "failed">("idle");
  const headingRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    console.error(error);
  }, [error]);

  // Move focus to the message so keyboard and screen-reader users land on it.
  useEffect(() => {
    headingRef.current?.focus();
  }, []);

  async function copyDetails() {
    const details = [
      `Reference: ${error.digest ?? "none"}`,
      `Message: ${error.message || "No message"}`,
      `Page: ${window.location.href}`,
      `Time: ${new Date().toISOString()}`,
    ].join("\n");
    try {
      await navigator.clipboard.writeText(details);
      setCopy("copied");
    } catch {
      setCopy("failed");
    }
  }

  return (
    <div className="mx-auto flex w-full max-w-xl flex-col items-center px-2 py-16 text-center sm:py-24">
      <span className="mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 ring-1 ring-inset ring-rose-100">
        <AlertTriangle className="h-6 w-6" aria-hidden="true" />
      </span>
      <div role="alert">
        <h1 ref={headingRef} tabIndex={-1} className="m-0 text-2xl font-semibold tracking-tight text-slate-900 outline-none">
          This screen could not be loaded
        </h1>
        <p className="mt-2 max-w-md text-sm leading-6 text-slate-600">
          Something went wrong while opening this screen. Try again; if it keeps happening,
          copy the details and send them to your administrator.
        </p>
      </div>
      {error.digest && (
        <p className="mt-3 text-xs text-slate-500">
          Reference <span className={ui.codeChip}>{error.digest}</span>
        </p>
      )}
      <div className="mt-6 flex flex-col-reverse items-stretch gap-2 sm:flex-row sm:items-center sm:justify-center sm:gap-3">
        <Link href="/dashboard" className={ui.ghostButton}>Go to dashboard</Link>
        <button type="button" onClick={copyDetails} className={ui.secondaryButton}>
          {copy === "copied"
            ? <Check className="h-4 w-4" aria-hidden="true" />
            : <Copy className="h-4 w-4" aria-hidden="true" />}
          {copy === "copied" ? "Copied" : "Copy details"}
        </button>
        <button type="button" onClick={() => retry()} className={ui.primaryButton}>
          <RefreshCw className="h-4 w-4" aria-hidden="true" />
          Try again
        </button>
      </div>
      <p role="status" aria-live="polite" className="mt-3 min-h-5 text-xs text-slate-500">
        {copy === "copied" ? "Details copied to the clipboard." : copy === "failed" ? "Could not copy the details. Tell your administrator the page and the time it happened." : ""}
      </p>
    </div>
  );
}
