import { Forbidden } from "@/components/layout/Forbidden";
import { getPageAccess } from "@/modules/access/page-access";
import { canAll } from "@/modules/access/permissions";
import { LowStocksScreen } from "@/modules/inventory/LowStocksScreen";

export default async function LowStocksPage() {
  const { user, allowed } = await getPageAccess("low-stocks");
  if (!allowed) return <Forbidden />;
  const permissions = await canAll(user, {
    add: "low_stocks_menu_add",
    edit: "low_stocks_menu_edit",
    remove: "low_stocks_menu_delete",
    view: "low_stocks_menu_view",
    // Produce raises a Production Plan, so it carries the production permission.
    produce: "operations_admin_production_plan_add",
  });
  // The form opens with today's date and the signed-in user's email, as today.
  const today = new Date().toLocaleDateString("en-CA");
  return <LowStocksScreen permissions={permissions} reporter={user.email} today={today} />;
}
