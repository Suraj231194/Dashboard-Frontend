import Link from "next/link";
import { FolderX } from "@/components/ui/icons";
import { ui } from "@/components/ui/styles";
import { BackButton } from "@/components/layout/BackButton";

/** The 404 screen, shown inside the shell so the sidebar still leads somewhere. */
export default function ErpNotFound() {
  return (
    <div className="mx-auto flex w-full max-w-xl flex-col items-center px-2 py-16 text-center sm:py-24">
      <span className={`${ui.iconChip} mb-5 h-14 w-14 rounded-2xl`}>
        <FolderX className="h-6 w-6" aria-hidden="true" />
      </span>
      <h1 className="m-0 text-2xl font-semibold tracking-tight text-slate-900">Page not found</h1>
      <p className="mt-2 max-w-md text-sm leading-6 text-slate-600">
        This page does not exist, or the link that led here is out of date. Check the address,
        or pick a screen from the menu.
      </p>
      <div className="mt-6 flex flex-col-reverse items-stretch gap-2 sm:flex-row sm:items-center sm:justify-center sm:gap-3">
        <BackButton />
        <Link href="/dashboard" className={ui.primaryButton}>Go to dashboard</Link>
      </div>
    </div>
  );
}
