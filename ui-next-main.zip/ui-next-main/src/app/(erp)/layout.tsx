import { Navbar } from "@/components/layout/Navbar";
import { SidebarNav } from "@/components/layout/SidebarNav";
import { NavigationProvider } from "@/components/layout/NavigationProvider";
import { requireSession } from "@/modules/auth/session";
import { getMenuTree } from "@/modules/navigation/menus";
import { getAppearance } from "@/modules/settings/appearance";
import { appearanceCss } from "@/modules/settings/appearance-css";

export default async function ErpLayout({ children }: LayoutProps<"/">) {
  const user = await requireSession();
  const [menus, appearance] = await Promise.all([
    getMenuTree(user),
    getAppearance(user.user_id),
  ]);

  return (
    <>
      <style>{appearanceCss(appearance)}</style>
      <NavigationProvider menus={menus}>
        <div className="min-h-dvh">
          <Navbar user={user} />
          <div className="flex min-h-[calc(100dvh-4rem)]">
          <SidebarNav menus={menus} />
          <div className="flex min-w-0 flex-1 flex-col">
            <main className="flex-1 bg-slate-50 p-3 sm:p-4 lg:p-6">{children}</main>
          </div>
          </div>
        </div>
      </NavigationProvider>
    </>
  );
}
