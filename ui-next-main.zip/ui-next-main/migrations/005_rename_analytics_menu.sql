-- Renames the analytics sidebar entry from 'Dashboard' to 'Analytics'.
--
-- 004 first inserted the row for `index.php?page=analytics` under the name
-- 'Dashboard', so the sidebar showed two items with the same name: the real
-- dashboard and the analytics screen. 004 now writes 'Analytics' for fresh
-- installs; this file brings a database that already ran the old 004 in line.
--
-- It touches only the analytics route, and only while the row still carries
-- the old name, so a name changed by hand to anything else is left alone.
--
-- Idempotent: once the row is named 'Analytics' the WHERE clause matches
-- nothing, so re-running this file changes nothing.

UPDATE `menus`
   SET `name` = 'Analytics',
       `updated_at` = NOW()
 WHERE `route` = 'index.php?page=analytics'
   AND `name` = 'Dashboard';
