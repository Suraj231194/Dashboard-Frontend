-- The sidebar entry for the analytics dashboard.
--
-- The sidebar is built from the `menus` table (`MENUS_FOR_USER_SQL`), so the
-- new screen at `index.php?page=analytics` needs a row of its own before it can
-- be reached. Nothing else about the screen touches the database: it only
-- reads.
--
-- The row follows the house style of the other top-level rows:
--   * `name`            'Dashboard', the name the sidebar prints.
--   * `route`           'index.php?page=analytics' - the spelling every
--                       converted screen uses, which `pageSlugFromRoute()`
--                       reads the `analytics` slug out of.
--   * `icon`            'fas fa-chart-pie', the Font Awesome spelling the other
--                       rows carry; `MENU_ICONS` already maps it, as it does
--                       for the tender dashboard row.
--   * `parent_id`       NULL, so it sits at the top level beside Dashboard,
--                       Live Inventory and Human Resources.
--   * `sort_order`      0. The sidebar orders by `parent_id, sort_order ASC`
--                       and the existing top-level rows start at 1, so 0 puts
--                       this row first without renumbering anything.
--   * `permission_slug` NULL, exactly like the existing Dashboard row: the page
--                       is open to anyone signed in, and each block of figures
--                       is gated on its own module's permission inside the
--                       screen (`modules/analytics/visibility.ts`).
--   * `showmenu` / `status`  1 and 1, as every live row carries.
--
-- Idempotent: the insert is skipped when the row is already there, and the
-- update afterwards brings an older copy of the row back in line. Re-running
-- this file changes nothing on a database that already has it.

INSERT INTO `menus`
  (`name`, `route`, `icon`, `parent_id`, `sort_order`, `permission_slug`,
   `showmenu`, `status`, `created_by`, `created_at`)
SELECT
  'Dashboard', 'index.php?page=analytics', 'fas fa-chart-pie', NULL, 0, NULL,
  1, 1, NULL, NOW()
FROM DUAL
WHERE NOT EXISTS (
  SELECT 1 FROM `menus` WHERE `route` = 'index.php?page=analytics'
);

-- Restores the row's own columns should an earlier copy have been renamed,
-- re-sorted, hidden or soft-deleted. It touches only this one route.
UPDATE `menus`
   SET `name` = 'Dashboard',
       `icon` = 'fas fa-chart-pie',
       `parent_id` = NULL,
       `sort_order` = 0,
       `permission_slug` = NULL,
       `showmenu` = 1,
       `status` = 1,
       `deleted_by` = NULL,
       `deleted_at` = NULL,
       `updated_at` = NOW()
 WHERE `route` = 'index.php?page=analytics';
