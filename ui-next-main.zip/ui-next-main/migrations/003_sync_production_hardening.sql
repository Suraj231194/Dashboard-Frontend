-- Website <-> ERP synchronisation hardening.
--
-- Copied verbatim from the current application's own pending migration
-- (`admin/migrations/2026_09_25_001_sync_production_hardening_pending.sql`),
-- which has not been applied to any database yet.
--
-- Until it is applied, three things run without their guard rails:
--   * customer, meeting and quiz pulls have no stale-version protection, so an
--     older website record can overwrite a newer ERP one;
--   * order status pushes send version 1 rather than a real version;
--   * the inventory transaction audit table does not exist.
--
-- The application detects each missing column and degrades rather than failing,
-- so applying this is safe at any time and is what turns those guards on.
-- Additive and re-runnable on MariaDB 10.6+. Take a backup first.

-- Additive production hardening for Website <-> ERP synchronization.
-- Safe to re-run on MariaDB 10.6+; deploy after taking a database backup.

ALTER TABLE `order_received`
  ADD COLUMN IF NOT EXISTS `sync_status_version` bigint(20) unsigned NOT NULL DEFAULT 0 AFTER `status`;

UPDATE `order_received`
SET `sync_status_version` = 1
WHERE `source_type` = 2
  AND `external_reference` IS NOT NULL
  AND `external_reference` <> ''
  AND `sync_status_version` = 0;

ALTER TABLE `live_stock`
  ADD COLUMN IF NOT EXISTS `sync_change_version` bigint(20) unsigned NOT NULL DEFAULT 1 AFTER `sync_pending`,
  ADD KEY IF NOT EXISTS `idx_live_stock_sync_version` (`product_id`, `sync_change_version`);

UPDATE `live_stock` SET `sync_change_version` = 1 WHERE `sync_change_version` = 0;

ALTER TABLE `customers`
  ADD COLUMN IF NOT EXISTS `source_sync_version` bigint(20) unsigned NOT NULL DEFAULT 0 AFTER `website_user_id`;
ALTER TABLE `meeting_requests`
  ADD COLUMN IF NOT EXISTS `source_sync_version` bigint(20) unsigned NOT NULL DEFAULT 0 AFTER `website_meeting_id`;
ALTER TABLE `quiz_leads`
  ADD COLUMN IF NOT EXISTS `source_sync_version` bigint(20) unsigned NOT NULL DEFAULT 0 AFTER `website_quiz_response_id`;

CREATE TABLE IF NOT EXISTS `inventory_transaction_audit` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `quantity` decimal(20,8) NOT NULL,
  `action_name` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `live_stock_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `quantity_available_after` decimal(20,8) DEFAULT NULL,
  `reserved_quantity_after` decimal(20,8) DEFAULT NULL,
  `unreserved_quantity_after` decimal(20,8) DEFAULT NULL,
  `source_type` varchar(100) DEFAULT NULL,
  `source_id` bigint(20) DEFAULT NULL,
  `reference_key` varchar(255) DEFAULT NULL,
  `coa_number` varchar(255) DEFAULT NULL,
  `batch_number` varchar(255) DEFAULT NULL,
  `mfg_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `performed_by` int(11) DEFAULT NULL,
  `request_id` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `metadata_json` longtext DEFAULT NULL,
  `occurred_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_inventory_tx_product_time` (`product_id`, `created_at`),
  KEY `idx_inventory_tx_action_time` (`action_name`, `created_at`),
  KEY `idx_inventory_tx_reference` (`reference_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TRIGGER IF EXISTS `trg_live_stock_sync_pending_bi`;
CREATE TRIGGER `trg_live_stock_sync_pending_bi`
BEFORE INSERT ON `live_stock`
FOR EACH ROW
SET NEW.`sync_pending` = 1,
    NEW.`sync_change_version` = GREATEST(COALESCE(NEW.`sync_change_version`, 0), 1);

DROP TRIGGER IF EXISTS `trg_live_stock_sync_pending_bu`;
CREATE TRIGGER `trg_live_stock_sync_pending_bu`
BEFORE UPDATE ON `live_stock`
FOR EACH ROW
SET NEW.`sync_pending` = IF(
      NOT (NEW.`quantity_available` <=> OLD.`quantity_available`)
      OR NOT (NEW.`reserved_qty` <=> OLD.`reserved_qty`)
      OR NOT (NEW.`status` <=> OLD.`status`)
      OR NOT (NEW.`deleted_at` <=> OLD.`deleted_at`)
      OR NOT (NEW.`coa_number` <=> OLD.`coa_number`)
      OR NOT (NEW.`lot_batch_no` <=> OLD.`lot_batch_no`)
      OR NOT (NEW.`mfg_date` <=> OLD.`mfg_date`)
      OR NOT (NEW.`exp_date` <=> OLD.`exp_date`),
      1,
      NEW.`sync_pending`
    ),
    NEW.`sync_change_version` = IF(
      NOT (NEW.`quantity_available` <=> OLD.`quantity_available`)
      OR NOT (NEW.`reserved_qty` <=> OLD.`reserved_qty`)
      OR NOT (NEW.`status` <=> OLD.`status`)
      OR NOT (NEW.`deleted_at` <=> OLD.`deleted_at`)
      OR NOT (NEW.`coa_number` <=> OLD.`coa_number`)
      OR NOT (NEW.`lot_batch_no` <=> OLD.`lot_batch_no`)
      OR NOT (NEW.`mfg_date` <=> OLD.`mfg_date`)
      OR NOT (NEW.`exp_date` <=> OLD.`exp_date`),
      OLD.`sync_change_version` + 1,
      NEW.`sync_change_version`
    );

DROP TRIGGER IF EXISTS `trg_order_received_sync_status_version_bu`;
CREATE TRIGGER `trg_order_received_sync_status_version_bu`
BEFORE UPDATE ON `order_received`
FOR EACH ROW
SET NEW.`sync_status_version` = IF(
  NOT (NEW.`status` <=> OLD.`status`),
  OLD.`sync_status_version` + 1,
  NEW.`sync_status_version`
);
